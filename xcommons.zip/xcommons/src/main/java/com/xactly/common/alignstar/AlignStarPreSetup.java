package com.xactly.xcommons.alignstar;

import java.io.File;
import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.UnhandledAlertException;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.xactly.xcommons.app.LoginToApplication;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;


public class AlignStarPreSetup {

	private static String environment;
	private static String application;
	private static InputStream systemPropertyInputStream;
	private static Properties symProPath = new Properties();

	public static String getEnvironment() {
		return environment;
	}
	public static void setEnvironment(String env) {
		environment = env;
	}
	public static String getApplication() {
		return application;
	}
	public static void setApplication(String app) {
		  application = app;
	}
	
	public static InputStream getSystemPropertyInputStream() {
		return systemPropertyInputStream;
	}
	public static void setSystemPropertyInputStream(
			InputStream stemPropertyInputStream) {
            systemPropertyInputStream = stemPropertyInputStream;
	}
	
	LoginToApplication login = new LoginToApplication();


	@BeforeSuite(alwaysRun = true)	
	@Parameters({"environment","application","mode","browser"})
	public void preSetUp(@Optional String environment,@Optional String application,@Optional String mode,
			@Optional String browser ) throws Exception 
	{
		setEnvironment(environment);
		setApplication(application);
		SetWebDrivers.setBrowser(browser);
		
		String propFile=environment+File.separator+environment+".properties";
		System.out.println(propFile);
		setSystemPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(propFile));
		symProPath.load(getSystemPropertyInputStream());
		
		LoginToApplication.setApplication(application);
		LoginToApplication.setUrl(symProPath.getProperty("url"));	
		LoginToApplication.setUsername(symProPath.getProperty("username"));
		LoginToApplication.setPassword(symProPath.getProperty("password"));		
		
		System.out.println("URL : "+LoginToApplication.getUrl());
		System.out.println("UserName : "+LoginToApplication.getUsername());
		System.out.println("Password : "+LoginToApplication.getPassword());
		
		if(mode.equalsIgnoreCase("gui")){			
			SeleniumHelperClass.createDownloadDir();
		}
		
	}


	@BeforeTest(alwaysRun = true)
	@Parameters({"application","environment","mode","browser"})
	public void preSetUpTest(@Optional String appname, @Optional String envname, @Optional String mode,@Optional String _browser) throws Exception
	{		
		if(mode.equalsIgnoreCase("gui") && appname.equals("alignstar")){

			LoginToApplication login = new LoginToApplication();			
			login.loginToAlignStar();		
		}	
	}


	@AfterTest(alwaysRun = true)
	@Parameters({"application","environment","mode","browser"})
	public void terminateTest(@Optional String appname, @Optional String envname, @Optional String mode,@Optional String _browser) throws Exception 
	{
		LoginToApplication login = new LoginToApplication();	
		
		if(mode.equalsIgnoreCase("gui")){

			if(appname.equals("alignstar"))
			{
				try {
					login.logOutFromAlignStar();
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);				
				}catch(UnhandledAlertException uae){					
					SetWebDrivers.getDriver().switchTo().alert().accept();
					login.logOutFromAlignStar();
				}catch (Exception e) {								
					e.printStackTrace();					
				}
				finally
				{
					SetWebDrivers.getDriver().quit();
				}
			}
		}
	}




	@AfterSuite(alwaysRun = true)	
	@Parameters({"mode"})
	public void terminateSuite(@Optional String mode) throws Exception
	{
		if(mode.equalsIgnoreCase("gui")){		

			if(SetWebDrivers.OSDetector().equalsIgnoreCase("Mac") && SetWebDrivers.getBrowser().equalsIgnoreCase("chrome"))
			{
				Runtime.getRuntime().exec("killall chromedriver_mac");
			}
			if(SetWebDrivers.OSDetector().equalsIgnoreCase("Mac") && SetWebDrivers.getBrowser().equalsIgnoreCase("firefox"))
			{
				Runtime.getRuntime().exec("killall geckodriver_mac");
			}
		}
	}

}
