package com.xactly.common.xac.wso;

import java.util.List;

/**
 * Created by rshah@XactlyCorporation.local on 5/19/16.
 */
public class PayCurveVersionWSO {

    private String payCurveVersionId;
    private String payCurveAssignmentId;
    private String description;
    private Long startPeriodId;
    private Long endPeriodId;
    private String startPeriodName;
    private String endPeriodName;
    private Boolean lastTierCapPersonalTarget;
    private Boolean lowerQuotaAttainment;
    private List<PayCurveDetailWSO> payCurveDetailWSOList;

    public String getPayCurveVersionId() {
        return payCurveVersionId;
    }

    public void setPayCurveVersionId(String payCurveVersionId) {
        this.payCurveVersionId = payCurveVersionId;
    }

    public Long getStartPeriodId() {
        return startPeriodId;
    }

    public void setStartPeriodId(Long startPeriodId) {
        this.startPeriodId = startPeriodId;
    }

    public Long getEndPeriodId() {
        return endPeriodId;
    }

    public void setEndPeriodId(Long endPeriodId) {
        this.endPeriodId = endPeriodId;
    }

    public List<PayCurveDetailWSO> getPayCurveDetailWSOList() {
        return payCurveDetailWSOList;
    }

    public void setPayCurveDetailWSOList(List<PayCurveDetailWSO> payCurveDetailWSOList) {
        this.payCurveDetailWSOList = payCurveDetailWSOList;
    }

    public String getPayCurveAssignmentId() {
        return payCurveAssignmentId;
    }

    public void setPayCurveAssignmentId(String payCurveAssignmentId) {
        this.payCurveAssignmentId = payCurveAssignmentId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getLastTierCapPersonalTarget() {
        return lastTierCapPersonalTarget;
    }

    public void setLastTierCapPersonalTarget(Boolean lastTierCapPersonalTarget) {
        this.lastTierCapPersonalTarget = lastTierCapPersonalTarget;
    }

    public Boolean getLowerQuotaAttainment() {
        return lowerQuotaAttainment;
    }

    public void setLowerQuotaAttainment(Boolean lowerQuotaAttainment) {
        this.lowerQuotaAttainment = lowerQuotaAttainment;
    }

    public String getStartPeriodName() {
        return startPeriodName;
    }

    public void setStartPeriodName(String startPeriodName) {
        this.startPeriodName = startPeriodName;
    }

    public String getEndPeriodName() {
        return endPeriodName;
    }

    public void setEndPeriodName(String endPeriodName) {
        this.endPeriodName = endPeriodName;
    }

    @Override
    public String toString() {
        return "PayCurveVersionWSO{" +
                "payCurveVersionId='" + payCurveVersionId + '\'' +
                ", payCurveAssignmentId='" + payCurveAssignmentId + '\'' +
                ", description='" + description + '\'' +
                ", startPeriodId=" + startPeriodId +
                ", endPeriodId=" + endPeriodId +
                ", lastTierCapPersonalTarget=" + lastTierCapPersonalTarget +
                ", lowerQuotaAttainment=" + lowerQuotaAttainment +
                ", payCurveDetailWSOList=" + payCurveDetailWSOList +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PayCurveVersionWSO)) return false;

        PayCurveVersionWSO that = (PayCurveVersionWSO) o;

        if (payCurveVersionId != null ? !payCurveVersionId.equals(that.payCurveVersionId) : that.payCurveVersionId != null)
            return false;
        if (payCurveAssignmentId != null ? !payCurveAssignmentId.equals(that.payCurveAssignmentId) : that.payCurveAssignmentId != null)
            return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;
        if (startPeriodId != null ? !startPeriodId.equals(that.startPeriodId) : that.startPeriodId != null)
            return false;
        if (endPeriodId != null ? !endPeriodId.equals(that.endPeriodId) : that.endPeriodId != null) return false;
        if (lastTierCapPersonalTarget != null ? !lastTierCapPersonalTarget.equals(that.lastTierCapPersonalTarget) : that.lastTierCapPersonalTarget != null)
            return false;
        if (lowerQuotaAttainment != null ? !lowerQuotaAttainment.equals(that.lowerQuotaAttainment) : that.lowerQuotaAttainment != null)
            return false;
        return !(payCurveDetailWSOList != null ? !payCurveDetailWSOList.equals(that.payCurveDetailWSOList) : that.payCurveDetailWSOList != null);

    }

    @Override
    public int hashCode() {
        int result = payCurveVersionId != null ? payCurveVersionId.hashCode() : 0;
        result = 31 * result + (payCurveAssignmentId != null ? payCurveAssignmentId.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (startPeriodId != null ? startPeriodId.hashCode() : 0);
        result = 31 * result + (endPeriodId != null ? endPeriodId.hashCode() : 0);
        result = 31 * result + (lastTierCapPersonalTarget != null ? lastTierCapPersonalTarget.hashCode() : 0);
        result = 31 * result + (lowerQuotaAttainment != null ? lowerQuotaAttainment.hashCode() : 0);
        result = 31 * result + (payCurveDetailWSOList != null ? payCurveDetailWSOList.hashCode() : 0);
        return result;
    }
}