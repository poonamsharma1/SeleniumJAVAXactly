package com.xactly.common.tw.constants;

import java.util.Arrays;
import java.util.List;

public interface TWConstants {

	public static final String REPORTS_PODCUSTOMIZATION = "reports.podcustomization";
	public static final String REPORTS_INCENTIVEDETAIL = "reports.incentivedetail";
	public static final String REPORTS_PAYMENTCUSTOMLABEL = "reports.paymentcustomlabel";
	public static final String REPORTS_PLANSUMMARY = "reports.plansummary";
	public static final String REPORTS_INCENTIVESTATEMENT = "reports.incentivestatement";
	public static final String REPORTS_PAYMENTSUMMARY = "reports.paymentsummary";
	public static final String REPORTS_REPORTCOLUMNS = "reports.reportcolumns";
	
	public static final String PLANDESIGN_RULE = "plandesign.rule";
	public static final String PLANDESIGN_RULERESULT = "plandesign.ruleresult";
	public static final String PLANDESIGN_DRAW = "plandesign.draw";
	public static final String PLANDESIGN_RATETABLE = "plandesign.ratetable";
	public static final String PLANDESIGN_QUOTA = "plandesign.quota";
	public static final String PLANDESIGN_PAYCURVE = "plandesign.paycurve";
	public static final String PLANDESIGN_QUOTARELATIONSHIP = "plandesign.quotarelationship";
	public static final String SETUP_ORDERCUSTOMFIELD = "setup.ordercustomfield";
	public static final String SETUP_PERSONFIELD = "setup.personfield";
	public static final String SETUP_ORDERTYPE = "setup.ordertype";
	public static final String SETUP_EMPLOYEESTATUS = "setup.employeestatus";
	public static final String SETUP_EARNINGGROUP = "setup.earninggroup";
	public static final String SETUP_CREDITTYPE = "setup.credittype";
	public static final String SETUP_CALENDAR = "setup.calendar";
	public static final String SETUP_REASONCODE = "setup.reasoncode";
	
	public static final String REPORTCOLUMNS_TEAMOVERVIEW = "reportcolumns.teamoverview";
	public static final String REPORTCOLUMNS_RANKING = "reportcolumns.teamranking";
	public static final String REPORTCOLUMNS_PAYMENT = "reportcolumns.payment";
	public static final String REPORTCOLUMNS_PROCESSEDORDER = "reportcolumns.processedorder";
	public static final String REPORTCOLUMNS_BONUS = "reportcolumns.bonus";
	public static final String REPORTCOLUMNS_COMMISSION = "reportcolumns.commission";
	public static final String REPORTCOLUMNS_CREDIT = "reportcolumns.credit";
	
	public static final List<String> REPORT_COLUMNS_ENTITY_TYPES = Arrays
			.asList(REPORTCOLUMNS_TEAMOVERVIEW, 
					REPORTCOLUMNS_RANKING, 
					REPORTCOLUMNS_PAYMENT, 
					REPORTCOLUMNS_PROCESSEDORDER, 
					REPORTCOLUMNS_BONUS, 
					REPORTCOLUMNS_COMMISSION, 
					REPORTCOLUMNS_CREDIT);

	public static final String TW_TEMPLATE_COLUMNS_INCENT_AREA = "Incent Area";
	public static final String TW_TEMPLATE_COLUMNS_FIELD_NAME = "Field Name";
	public static final String TW_TEMPLATE_COLUMNS_FIELD_VALUE = "Field Value";
	public static final String TW_TEMPLATE_COLUMNS_KEY = "Key";
	public static final String TW_TEMPLATE_COLUMNS_TEMPLATE = "Template";
	public static final String TW_TEMPLATE_COLUMNS_POD_NAME = "Pod Name";
	
	public static final String TW_COLUMN_OBJECT_TYPE = "objectType";
	public static final String TW_COLUMN_DEFAULT_LABEL = "defaultLabel";
	public static final String TW_COLUMN_FIELD_NAME = "fieldName";
	public static final String TW_COLUMN_OBJECT_KEY = "objectKey";
	
	public static final String defaultFieldName = "name";
	public static final String defaultFieldDisplayName = "Name";

	
	public static final List<String> TW_TEMPLATE_STANDARD_COLUMNS = Arrays
			.asList(TW_TEMPLATE_COLUMNS_FIELD_NAME, 
					TW_TEMPLATE_COLUMNS_FIELD_VALUE,
					TW_TEMPLATE_COLUMNS_KEY, 
					TW_TEMPLATE_COLUMNS_TEMPLATE,
					TW_TEMPLATE_COLUMNS_POD_NAME,
					TW_TEMPLATE_COLUMNS_INCENT_AREA);

}