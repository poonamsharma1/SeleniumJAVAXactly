package com.xactly.xcommons.amf;

import flex.messaging.io.amf.client.AMFConnection;
import flex.messaging.io.amf.client.exceptions.ClientStatusException;
import flex.messaging.io.amf.client.exceptions.ServerStatusException;

import javax.net.ssl.*;

//import com.jayway.restassured.response.Response;
import com.xactly.xcommons.amf.LoginClient;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

/**
 * Created by sbhowmick on 12/27/16.
 */
public class AmfClient<R> {
    public final LoginClient loginClient;

    public AmfClient(LoginClient logindo){
        this.loginClient = logindo;
    }

    @SuppressWarnings("unchecked")
	public R call(AmfRequest amfRequest) throws InterruptedException{
        AMFConnection amfConnection = new AMFConnection();
        // Initialize AMF connection
        String url = amfRequest.getUrl();//"http://colva.xactlycorporation.local/xicm/messagebroker/amf";
        try {
        	Thread.sleep(2000);
            amfConnection.connect(url);
        } catch (ClientStatusException eClient) {
            throw new RuntimeException(eClient);
        }
        amfConnection.addHttpRequestHeader("Content-type", "application/x-amf");
        amfConnection.addHttpRequestHeader("Cookie", this.loginClient.getRespo().getCookies().toString());
        AMFConnection.registerAlias("DSA", flex.messaging.messages.AsyncMessageExt.class.getName());
        AMFConnection.registerAlias("DSK", flex.messaging.messages.AcknowledgeMessageExt.class.getName());
        AMFConnection.registerAlias("DSC", flex.messaging.messages.CommandMessageExt.class.getName());

        // AMF v3
        AMFConnection.setDefaultObjectEncoding(3);

        // no-check-certificate
        try {
            noCheckCertConnection();
            Object[] params = amfRequest.getParams();
            String amfEndpoint = amfRequest.getCommand();
            return (R)amfConnection.call(amfEndpoint, params);
        } catch (NoSuchAlgorithmException ex) {
            throw new RuntimeException(ex);
        } catch (KeyManagementException ex) {
            throw new RuntimeException(ex);
        }catch (ClientStatusException cse){
            throw new RuntimeException(cse);
        }catch (ServerStatusException sse){
            throw new RuntimeException(sse);
        }finally {
            amfConnection.removeAllAmfHeaders();
            amfConnection.close();
        }
    }

    private void noCheckCertConnection() throws NoSuchAlgorithmException, KeyManagementException {

        TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }

            public void checkClientTrusted(X509Certificate[] certs, String authType) {
            }

            public void checkServerTrusted(X509Certificate[] certs, String authType) {
            }
        } };
        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        HostnameVerifier allHostsValid = new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        };
        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
    }
    
    

}