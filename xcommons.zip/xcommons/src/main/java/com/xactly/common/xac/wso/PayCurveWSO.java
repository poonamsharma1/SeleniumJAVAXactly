package com.xactly.common.xac.wso;

import java.util.List;

/**
 * Created by rshah@XactlyCorporation.local on 5/19/16.
 */
public class PayCurveWSO {

    private Long payCurveId;
    private String name;
    private String description;
    private List<ObjectTagWSO> objectTagWSOList;
    private PayCurveAssignmentWSO payCurveAssignmentWSO;
    private List<PayCurveVersionWSO> payCurveVersionWSOList;
    private Boolean canChangeName;
    private String personalTarget;
    private Long formulaId;
    private String formulaName;


    public PayCurveWSO() {
    }

    public Long getPayCurveId() {
        return payCurveId;
    }

    public void setPayCurveId(Long payCurveId) {
        this.payCurveId = payCurveId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    public List<PayCurveVersionWSO> getPayCurveVersionWSOList() {
        return payCurveVersionWSOList;
    }

    public void setPayCurveVersionWSOList(List<PayCurveVersionWSO> payCurveVersionWSOList) {
        this.payCurveVersionWSOList = payCurveVersionWSOList;
    }

    public PayCurveAssignmentWSO getPayCurveAssignmentWSO() {
        return payCurveAssignmentWSO;
    }

    public void setPayCurveAssignmentWSO(PayCurveAssignmentWSO payCurveAssignmentWSO) {
        this.payCurveAssignmentWSO = payCurveAssignmentWSO;
    }

    public List<ObjectTagWSO> getObjectTagWSOList() {
        return objectTagWSOList;
    }

    public void setObjectTagWSOList(List<ObjectTagWSO> objectTagWSOList) {
        this.objectTagWSOList = objectTagWSOList;
    }

    public Boolean getCanChangeName() {
        return canChangeName;
    }

    public void setCanChangeName(Boolean canChangeName) {
        this.canChangeName = canChangeName;
    }

    public String getPersonalTarget() {
        return personalTarget;
    }

    public void setPersonalTarget(String personalTarget) {
        this.personalTarget = personalTarget;
    }

    public Long getFormulaId() {
        return formulaId;
    }

    public void setFormulaId(Long formulaId) {
        this.formulaId = formulaId;
    }

    public String getFormulaName() {
        return formulaName;
    }

    public void setFormulaName(String formulaName) {
        this.formulaName = formulaName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PayCurveWSO)) return false;

        PayCurveWSO that = (PayCurveWSO) o;

        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;
        if (personalTarget != null ? !personalTarget.equals(that.personalTarget) : that.personalTarget != null)
            return false;
        return !(formulaId != null ? !formulaId.equals(that.formulaId) : that.formulaId != null);

    }

    @Override
    public int hashCode() {
        int result = name != null ? name.hashCode() : 0;
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (personalTarget != null ? personalTarget.hashCode() : 0);
        result = 31 * result + (formulaId != null ? formulaId.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "PayCurveWSO{" +
                "payCurveId=" + payCurveId +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", objectTagWSOList=" + objectTagWSOList +
                ", payCurveAssignmentWSO=" + payCurveAssignmentWSO +
                ", payCurveVersionWSOList=" + payCurveVersionWSOList +
                ", canChangeName=" + canChangeName +
                ", personalTarget='" + personalTarget + '\'' +
                ", formulaId=" + formulaId +
                ", formulaName='" + formulaName + '\'' +
                '}';
    }

}