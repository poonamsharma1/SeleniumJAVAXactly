package com.xactly.common.toolkit;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.rmi.RemoteException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.log4j.Logger;
import com.xactly.icm.xtoolkit.service.XService;
import com.xactly.icm.xtoolkit.wso.SearchResponse;
import com.xactly.icm.xtoolkit.wso.XObject;

public class Excel {
	private XService service;
	private static Logger logger = Logger.getLogger(Excel.class.getName());


	/* Returns the contents of the file in a byte array. */
	public static byte[] getBytesFromFile(File file) throws Exception, IOException {
		InputStream is = new FileInputStream(file);
		/* Get the size of the file */
		long length = file.length();

		/*
		 * You cannot create an array using a long type. // It needs to be an int type.
		 * // Before converting to an int type, check // to ensure that file is not
		 * larger than Integer.MAX_VALUE.
		 */
		if (length > Integer.MAX_VALUE) {
			throw new Exception("File too large");
		}

		/* Create the byte array to hold the data */
		byte[] bytes = new byte[(int) length];

		// Read in the bytes
		int offset = 0;
		int numRead = 0;
		while (offset < bytes.length && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0) {
			offset += numRead;
		}
		// Ensure all the bytes have been read in
		if (offset < bytes.length) {
			throw new IOException("Could not completely read file " + file.getName());
		}
		// Close the input stream and return bytes
		is.close();
		return bytes;
	}


	public void unZipToDir(String fileName, String outputDir) throws IOException {

		logger.info("Unzipping : " + outputDir + "/" + fileName + "_AR.zip");
		String fileZip = outputDir + "/" + fileName + "_AR.zip";
		File destDir = new File(outputDir);
		byte[] buffer = new byte[1024];
		ZipInputStream zis = new ZipInputStream(new FileInputStream(fileZip));
		ZipEntry zipEntry = zis.getNextEntry();
		while (zipEntry != null) {
			File newFile = newFile(destDir, zipEntry);
			FileOutputStream fos = new FileOutputStream(newFile);
			int len;
			while ((len = zis.read(buffer)) > 0) {
				fos.write(buffer, 0, len);
			}

			newFile.renameTo(new File(outputDir, "fileName" + "_AR.txt"));
			logger.info("Saving as text file into :  " + outputDir + "/" + "fileName" + "_AR.txt");
			fos.close();
			zipEntry = zis.getNextEntry();
		}
		zis.closeEntry();
		zis.close();

	}

	public File newFile(File destinationDir, ZipEntry zipEntry) throws IOException {
		File destFile = new File(destinationDir, zipEntry.getName());

		String destDirPath = destinationDir.getCanonicalPath();
		String destFilePath = destFile.getCanonicalPath();

		if (!destFilePath.startsWith(destDirPath + File.separator)) {
			throw new IOException("Entry is outside of the target dir: " + zipEntry.getName());
		}

		return destFile;

	}

}
