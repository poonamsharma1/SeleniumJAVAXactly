package com.xactly.common.toolkit;

import java.net.URL;
import java.util.Calendar;
import java.util.Random;
import javax.xml.rpc.Stub;
import org.apache.log4j.Logger;
import org.testng.asserts.SoftAssert;
import java.io.File;
import com.xactly.icm.xtoolkit.service.DiscoveryServiceSoapBindingStub;
import com.xactly.icm.xtoolkit.service.XService;
import com.xactly.icm.xtoolkit.service.XServiceServiceLocator;
import com.xactly.icm.xtoolkit.wso.ErrorCode;
import com.xactly.icm.xtoolkit.wso.LoginResponse;
import com.xactly.icm.xtoolkit.wso.ReleaseGroupWSO;
import com.xactly.icm.xtoolkit.wso.SaveResponse;
import com.xactly.icm.xtoolkit.wso.UploadResponse;
import com.xactly.xcommons.selenium.DBConnections;
import com.xactly.xcommons.app.LoginToApplication;

public class UploadStagedCommission {
	
	
	
	private static Logger logger = Logger.getLogger(UploadStagedCommission.class.getName());
	private static XService service;
	private static Random random = new Random();
	private static DBConnections db = new DBConnections();
	private String business_id;
	
	
	
	public String loginToToolkitAPI(String loginCredential) throws Exception {

		String DISCOVERY_SERVICE_URL = LoginToApplication.getConnectBaseURI() + "/icm/services/DiscoveryService";
        String loginResponse = "";
        String[] loginCredentials = loginCredential.split(":");
        logger.info("ReqCredentials: " + loginCredentials);
     
        service = new XServiceServiceLocator().getDiscoveryService(new URL(DISCOVERY_SERVICE_URL));
		((DiscoveryServiceSoapBindingStub) service).setMaintainSession(true);
		LoginResponse response = service.login(loginCredentials[0], loginCredentials[1], "Incent");
		


        System.out.println("isAuthenticated :" + response.isAuthenticated());
        System.out.println("getSessionId :" + response.getSessionId());
        if (!response.isAuthenticated()) {
            System.out.println("Login failed");
            loginResponse = (response.getErrorCodes()).getReason();
        } else {
            System.out.println("Login successful ");
            ((DiscoveryServiceSoapBindingStub) service).clearHeaders();
            String sessionId = response.getSessionId();
            String serverUrl = response.getServerUrl();
            System.out.println("serverUrl :" + response.getServerUrl());
            ((DiscoveryServiceSoapBindingStub) service)._setProperty(Stub.ENDPOINT_ADDRESS_PROPERTY, serverUrl);
            ((DiscoveryServiceSoapBindingStub) service)
                    .setHeader(new XServiceServiceLocator().getServiceName().getNamespaceURI(), "SessionId", sessionId);
            ((DiscoveryServiceSoapBindingStub) service)
                    .setHeader(new XServiceServiceLocator().getServiceName().getNamespaceURI(), "UserName", loginCredentials[0]);
            loginResponse = "Login Successful";
        }

        business_id = db.connect_Db_string("select business_id from incent.xc_user where email= '" + loginCredentials[0] + "'", "BUSINESS_ID");
        return loginResponse;
    }

	
	public String uploadStageCommission(Long PeriodID,int businessID,int Year,int Month,String RelTemplatePath) throws Exception  {

        SoftAssert massert = new SoftAssert();
        String uploadStatus="";
        logger.info("Create Release Group");
        String groupName = "Automation-"+random.nextInt(1000);
        Calendar cal = Calendar.getInstance();
        cal.set(Year,Month,1);
        ReleaseGroupWSO releaseGroupWSO = new ReleaseGroupWSO();
        releaseGroupWSO.setGroupName(groupName);
        releaseGroupWSO.setDescription("Testing");
        releaseGroupWSO.setPeriodId(PeriodID);
        releaseGroupWSO.setReleaseDate(cal);
        SaveResponse saveResponse = service.save(releaseGroupWSO);
        logger.info("Service Result: "+saveResponse.isResult());
        massert.assertTrue(saveResponse.isResult(),"ReleaseGroupWSO : Release Group creation failed");
        logger.info("Get Release Group ID from DB");
        String query = "select group_id from xc_release_group where business_id =" +businessID+ " and group_name = '" +groupName+ "'";
        String relGroupID = db.connect_Db_string(query,"group_id","calc");
        int releaseGroupID = Integer.parseInt(relGroupID);

        logger.info("Uploading Release Template to staged");
        String filepath = RelTemplatePath;
        File uploadFile = new File(RelTemplatePath);
        byte[] uploadBytes = Excel.getBytesFromFile(uploadFile);
        cal = Calendar.getInstance();
        cal.set(Year,Month,1);
        UploadResponse uploadResponse = service.uploadForRelease(uploadBytes, releaseGroupID, cal, "testing");
        if (uploadResponse.isResult()) {
            System.out.println("Uploaded commission records to staging");
            uploadStatus = String.valueOf(uploadResponse.isResult());
        } else {
            for(ErrorCode code : uploadResponse.getErrorCodes()) {
                System.out.println(code.getReason());
                uploadStatus = code.getReason();
            }
            System.out.println("Failed to upload commission records to staging");
        }	

        return uploadStatus;
    }
	
	
}
