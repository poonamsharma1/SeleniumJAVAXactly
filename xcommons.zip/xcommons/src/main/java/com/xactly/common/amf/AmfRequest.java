package com.xactly.xcommons.amf;

import com.jayway.restassured.response.Response;

/**
 * Created by sbhowmick on 12/27/16.
 */
public class AmfRequest {

    public final String url;

    public final String DESTINATION;

    public final String OPERATION;

    public final Object[] params;

    public AmfRequest(String url, String DESTINATION, String OPERATION, Object[] params) {
        this.url = url;
        this.DESTINATION = DESTINATION;
        this.OPERATION = OPERATION;
        this.params = params;
    }

    public String getDESTINATION() {
        return DESTINATION;
    }

    public String getOPERATION() {
        return OPERATION;
    }

    public Object[] getParams() {
        return params;
    }

    public String getCommand(){
        return DESTINATION + "." + OPERATION;
    }

    public String getUrl() {
        return url;
    }
}