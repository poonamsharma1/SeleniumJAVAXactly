package com.xactly.common.xac.wso;

/**
 * Created by rshah@XactlyCorporation.local on 6/1/16.
 */
public class PayCurveAssignmentWSO {

    private String payCurveAssignmentId;
    private Long payCurveId;
    private String assignmentType;
    private Long assignmentId;
    private String name;

    public String getPayCurveAssignmentId() {
        return payCurveAssignmentId;
    }

    public void setPayCurveAssignmentId(String payCurveAssignmentId) {
        this.payCurveAssignmentId = payCurveAssignmentId;
    }

    public Long getPayCurveId() {
        return payCurveId;
    }

    public void setPayCurveId(Long payCurveId) {
        this.payCurveId = payCurveId;
    }

    public String getAssignmentType() {
        return assignmentType;
    }

    public void setAssignmentType(String assignmentType) {
        this.assignmentType = assignmentType;
    }

    public Long getAssignmentId() {
        return assignmentId;
    }

    public void setAssignmentId(Long assignmentId) {
        this.assignmentId = assignmentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "PayCurveAssignmentWSO{" +
                "payCurveAssignmentId='" + payCurveAssignmentId + '\'' +
                ", payCurveId='" + payCurveId + '\'' +
                ", assignmentType='" + assignmentType + '\'' +
                ", assignmentId=" + assignmentId +
                ", name='" + name + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PayCurveAssignmentWSO)) return false;

        PayCurveAssignmentWSO that = (PayCurveAssignmentWSO) o;

        if (payCurveAssignmentId != null ? !payCurveAssignmentId.equals(that.payCurveAssignmentId) : that.payCurveAssignmentId != null)
            return false;
        if (!payCurveId.equals(that.payCurveId)) return false;
        if (!assignmentType.equals(that.assignmentType)) return false;
        return assignmentId.equals(that.assignmentId);

    }

    @Override
    public int hashCode() {
        int result = payCurveAssignmentId != null ? payCurveAssignmentId.hashCode() : 0;
        result = 31 * result + payCurveId.hashCode();
        result = 31 * result + assignmentType.hashCode();
        result = 31 * result + assignmentId.hashCode();
        return result;
    }
}