package com.xactly.common.xac.wso;

/**
 * Created by rshah@XactlyCorporation.local on 5/19/16.
 */
public class PayCurveDetailWSO {

    private String payCurveDetailId;
    private String payCurveVersionId;
    private Double quotaAttainment;
    private Double targetIncome;
    private Long tierRank;
    private Long formulaId;
    private String formulaName;



    public String getPayCurveDetailId() {
        return payCurveDetailId;
    }

    public void setPayCurveDetailId(String payCurveDetailId) {
        this.payCurveDetailId = payCurveDetailId;
    }

    public String getPayCurveVersionId() {
        return payCurveVersionId;
    }

    public void setPayCurveVersionId(String payCurveVersionId) {
        this.payCurveVersionId = payCurveVersionId;
    }

    public Double getQuotaAttainment() {
        return quotaAttainment;
    }

    public void setQuotaAttainment(Double quotaAttainment) {
        this.quotaAttainment = quotaAttainment;
    }

    public Double getTargetIncome() {
        return targetIncome;
    }

    public void setTargetIncome(Double targetIncome) {
        this.targetIncome = targetIncome;
    }

    public Long getTierRank() {
        return tierRank;
    }

    public void setTierRank(Long tierRank) {
        this.tierRank = tierRank;
    }

    public Long getFormulaId() {
        return formulaId;
    }

    public void setFormulaId(Long formulaId) {
        this.formulaId = formulaId;
    }

    public String getFormulaName() {
        return formulaName;
    }

    public void setFormulaName(String formulaName) {
        this.formulaName = formulaName;
    }

    @Override
    public String toString() {
        return "PayCurveDetailWSO{" +
                "payCurveDetailId='" + payCurveDetailId + '\'' +
                ", payCurveVersionId='" + payCurveVersionId + '\'' +
                ", quotaAttainment=" + quotaAttainment +
                ", targetIncome=" + targetIncome +
                ", tierRank=" + tierRank +
                ", formulaId=" + formulaId +
                ", formulaName='" + formulaName + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PayCurveDetailWSO)) return false;

        PayCurveDetailWSO that = (PayCurveDetailWSO) o;

        if (payCurveDetailId != null ? !payCurveDetailId.equals(that.payCurveDetailId) : that.payCurveDetailId != null)
            return false;
        if (payCurveVersionId != null ? !payCurveVersionId.equals(that.payCurveVersionId) : that.payCurveVersionId != null)
            return false;
        if (quotaAttainment != null ? !quotaAttainment.equals(that.quotaAttainment) : that.quotaAttainment != null)
            return false;
        if (targetIncome != null ? !targetIncome.equals(that.targetIncome) : that.targetIncome != null) return false;
        if (tierRank != null ? !tierRank.equals(that.tierRank) : that.tierRank != null) return false;
        if (formulaId != null ? !formulaId.equals(that.formulaId) : that.formulaId != null) return false;
        return !(formulaName != null ? !formulaName.equals(that.formulaName) : that.formulaName != null);

    }

    @Override
    public int hashCode() {
        int result = payCurveDetailId != null ? payCurveDetailId.hashCode() : 0;
        result = 31 * result + (payCurveVersionId != null ? payCurveVersionId.hashCode() : 0);
        result = 31 * result + (quotaAttainment != null ? quotaAttainment.hashCode() : 0);
        result = 31 * result + (targetIncome != null ? targetIncome.hashCode() : 0);
        result = 31 * result + (tierRank != null ? tierRank.hashCode() : 0);
        result = 31 * result + (formulaId != null ? formulaId.hashCode() : 0);
        result = 31 * result + (formulaName != null ? formulaName.hashCode() : 0);
        return result;
    }
}