package com.xactly.xcommons.amf;

import org.apache.log4j.Logger;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
import com.xactly.xcommons.app.LoginToApplication;
import com.xactly.xcommons.restapi.LoginToRestAPI;
import com.xactly.xcommons.restapi.PreSetupRestAPI;
import com.xactly.xcommons.restapi.RestAPIHelperClass;
import com.xactly.xcommons.selenium.Constants;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

/**
 * Created by sbhowmick on 12/27/16.
 */
public class LoginClient {
    private final String userName;
    private final String password;
    public static Logger logger = Logger.getLogger(LoginClient.class.getName());

    private Response login;
    private Response appLogin;
    private Response loginEx;
    private Response appLoginInit;
    RestAPIHelperClass rest = new RestAPIHelperClass();
	private Response logiExInitdo;
	private Response loginappdo;
    private Response respo;
	
	public Response getRespo() {
		return respo;
	}

	public void setRespo(Response respo) {
		this.respo = respo;
	}
    
    public WebElement get_ousername() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("user","none"));
	}

	public WebElement get_opassword() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("pass","none"));
	}
	public WebElement get_ologin() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("loginButton","none"));
	}    
    
   public void loginInNewIncent(String username, String Password) throws Exception {
    	
    	//SeleniumHelperClass.Logout();
    	Thread.sleep(100);
    	get_ousername().sendKeys(username);
    	get_opassword().sendKeys(Password);
    	get_ologin().submit();
    	
    	SetWebDrivers.getDriver().manage().timeouts()
    	.implicitlyWait(5, TimeUnit.SECONDS);
    	
    	logger.info("Logging in with name:"+username);
    	

    	
    	}
      
    

   public LoginClient login() throws Exception{
       // return doLogin().doAppLogin().doAppLoginEx().doAppExInit().Applogindo();
    	if(LoginToRestAPI.getGrs().equalsIgnoreCase("OFF"))
			 respo = (LoginToRestAPI.loginWithoutGRS(LoginToRestAPI.getUsername(), LoginToRestAPI.getPassword()));
		else
			respo = (LoginToRestAPI.loginWithGRS(LoginToRestAPI.getUsername(), LoginToRestAPI.getPassword()));
       setRespo(respo);
       
       return this;
    }    
    
    public LoginClient login(String userName, String password) throws Exception{
        // return doLogin().doAppLogin().doAppLoginEx().doAppExInit().Applogindo();
     	if(LoginToRestAPI.getGrs().equalsIgnoreCase("OFF"))
 			 respo = (LoginToRestAPI.loginWithoutGRS(userName, password));
 		else
 			respo = (LoginToRestAPI.loginWithGRS(userName, password));
        setRespo(respo);
        
        return this;
     }

    
    
    
    
	
    private LoginClient doLogin() {
    	String loginURL = PreSetupRestAPI.grsBaseuri == null ? PreSetupRestAPI.symProPath.getProperty("url"): PreSetupRestAPI.grsBaseuri + "/xlsweb/login.do";
		logger.info("System loginURL: " + loginURL);

        login = RestAssured.given().relaxedHTTPSValidation()
        		.formParam("userName", userName)
        		.formParam("password", password)
        		.formParam("xreferer", "")
        		.formParam("startPage", "")
        		.expect().statusCode(200)
                .when()
                .post(loginURL);
        return this;
    }

    private LoginClient doAppLogin() {
    	String xloginticket = LoginToRestAPI.getXLoginTicket(login.asString()) == null? login.getCookie(LoginToRestAPI.getVusidtemplate()) : LoginToRestAPI.getXLoginTicket(login.asString());

		String appLoginUrl = LoginToRestAPI.getLoginRedirectUrl(login.asString()) == null? Constants.envBaseUri + "/xicm/loginEx.do" : LoginToRestAPI.getLoginRedirectUrl(login.asString());
		
		logger.info("xloginticket: "+xloginticket);
		logger.info("LoginToRestAPI.getUsername(): "+userName);

		appLogin = RestAssured.given()
						.relaxedHTTPSValidation()
						.formParam("userName", userName)
						.formParam("xLoginTicket", xloginticket)
						.formParam("startPage", "")
						.cookies(login.getCookies())
						.expect()
						//.statusCode(302)
						.when().post(appLoginUrl);
        return this;
    }

    private LoginClient doAppLoginEx() {
    	String token = appLogin.getHeader("Location");
	//	token = token.substring(token.indexOf("token=")+6);
		logger.info(token);
		token = RestAPIHelperClass.getSubStringValues(token,"token=","&");
		loginEx = RestAssured.given()
				.relaxedHTTPSValidation().param("token", token)
				.cookies(appLogin.getCookies())
				.expect()
				.statusCode(200).when().get(Constants.envBaseUri + "/xicm/loginEx.do");
		
        return this;
    }
    private LoginClient doAppExInit() {
    	
    	String response = loginEx.asString();		
		String sessionId = RestAPIHelperClass.getSubStringValues(response, "\"sessionId\" value=\"", "\"");
		String xbaseSessionId = RestAPIHelperClass.getSubStringValues(response, "\"xbaseSessionId\" value=\"", "\"");
		
		logiExInitdo = RestAssured.given()
				.relaxedHTTPSValidation()
				.cookies(loginEx.getCookies())
				.formParam("userEmail", userName)
				.formParam("sessionId", sessionId)
				.formParam("xbaseSessionId", xbaseSessionId)
				.expect()
				.statusCode(200).when().post(LoginToApplication.getRestAssuredBaseURI()+"/xicm/loginExInit.do");
        return this;
    }
    
private LoginClient Applogindo() {
    	
		loginappdo = RestAssured.given()
			.relaxedHTTPSValidation()
			.cookies(logiExInitdo.getCookies())
			.expect()
			.statusCode(200).when().post(LoginToApplication.getRestAssuredBaseURI()+"/xicm/login.do");

        return this;
    }



    public static class Builder {
        private final String userName;
        private final String password;
      

        public Builder(String userName, String password){
            this.userName = userName;
            this.password = password;
        }

       

        public LoginClient build(){
            return new LoginClient(this);
        }
    }

    private LoginClient(Builder builder)
    {
        userName = builder.userName;
        password = builder.password;
        
    }

    public Response getAppLoginInit() {
        return logiExInitdo;
        
        
        
    }
    public LoginClient logout() {
    	logger.info("calling.....logout");

    	
    	if(appLoginInit != null){
    		
    	Response  logOutRes = RestAssured.given()

    	.relaxedHTTPSValidation()

    	.formParam("sessionId", appLoginInit.getCookie("requestid"))

    	.formParam("loginType", "null").cookies(appLoginInit.cookies()).cookies(appLoginInit.cookies())

    	.expect()

    	.statusCode(200).when().post("http://qaintx.xactlycorporation.local/xicm/logout.async.do");

    	}
    	return this;
    }
}