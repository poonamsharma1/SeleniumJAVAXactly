package com.xactly.common.xac.wso;

import java.io.Serializable;

/**
 * Created by rshah@XactlyCorporation.local on 6/14/16.
 */
public class ObjectTagWSO implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String objectTagId;
    private String tagId;
    private String tagName;
    private String objectId;


    public String getObjectTagId() {
        return objectTagId;
    }

    public void setObjectTagId(String objectTagId) {
        this.objectTagId = objectTagId;
    }

    public String getTagId() {
        return tagId;
    }

    public void setTagId(String tagId) {
        this.tagId = tagId;
    }

    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName;
    }

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    @Override
    public String toString() {
        return "ObjectTagWSO{" +
                "objectTagId='" + objectTagId + '\'' +
                ", tagId='" + tagId + '\'' +
                ", tagName='" + tagName + '\'' +
                ", objectId='" + objectId + '\'' +
                '}';
    }
}