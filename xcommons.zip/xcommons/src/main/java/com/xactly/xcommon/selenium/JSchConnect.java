package com.xactly.xcommons.selenium;

import com.jcraft.jsch.*;

import java.awt.*;

import javax.swing.*;

import java.io.*;
import java.util.ArrayList;
import org.apache.log4j.Logger;

public class JSchConnect {

	public JSchConnect() {
		// TODO Auto-generated constructor stub
	}
public static Logger logger = Logger.getLogger(JSchConnect.class.getName());
	private JSch jschSSHChannel;
	private String strUserName;
	private String strConnectionIP;
	private int intConnectionPort;
	private String strPassword;
	private Session sesConnection;
	private int intTimeOut;

	private void doCommonConstructorActions(String userName, String password,
			String connectionIP, String knownHostsFileName) {
		jschSSHChannel = new JSch();

		try {
			jschSSHChannel.setKnownHosts(knownHostsFileName);
		} catch (JSchException jschX) {
			logError(jschX.getMessage());
		}

		strUserName = userName;
		strPassword = password;
		strConnectionIP = connectionIP;
	}

	public JSchConnect(String userName, String password, String connectionIP,
			String knownHostsFileName) {
		doCommonConstructorActions(userName, password, connectionIP,
				knownHostsFileName);
		intConnectionPort = 22;
		intTimeOut = 60000;
	}

	public JSchConnect(String userName, String password, String connectionIP,
			String knownHostsFileName, int connectionPort) {
		doCommonConstructorActions(userName, password, connectionIP,
				knownHostsFileName);
		intConnectionPort = connectionPort;
		intTimeOut = 60000;
	}

	public JSchConnect(String userName, String password, String connectionIP,
			String knownHostsFileName, int connectionPort,
			int timeOutMilliseconds) {
		doCommonConstructorActions(userName, password, connectionIP,
				knownHostsFileName);
		intConnectionPort = connectionPort;
		intTimeOut = timeOutMilliseconds;
	}

	public String connect() {
		String errorMessage = null;

		try {
			sesConnection = jschSSHChannel.getSession(strUserName,
					strConnectionIP, intConnectionPort);
			sesConnection.setPassword(strPassword);
			sesConnection.setConfig("StrictHostKeyChecking", "no");
			
			sesConnection.connect(intTimeOut);
		} catch (JSchException jschX) {
			errorMessage = jschX.getMessage();
		}

		return errorMessage;
	}

	private String logError(String errorMessage) {
		if (errorMessage != null) {
			logger.info("{0}:{1} - {2}"
					+ new Object[] { strConnectionIP, intConnectionPort,
							errorMessage });
		}

		return errorMessage;
	}

	private String logWarning(String warnMessage) {
		if (warnMessage != null) {
			logger.info(" {0}:{1} - {2}"
					+ new Object[] { strConnectionIP, intConnectionPort,
							warnMessage });
		}

		return warnMessage;
	}

	public String sendCommand(String command) {
		StringBuilder outputBuffer = new StringBuilder();

		try {
			Channel channel = sesConnection.openChannel("exec");
			((ChannelExec) channel).setCommand(command);
			InputStream commandOutput = channel.getInputStream();
			channel.connect();
			int readByte = commandOutput.read();

			while (readByte != 0xffffffff) {
				outputBuffer.append((char) readByte);
				readByte = commandOutput.read();
			}

			channel.disconnect();
		} catch (IOException ioX) {
			logWarning(ioX.getMessage());
			return ioX.getMessage();
		} catch (JSchException jschX) {
			logWarning(jschX.getMessage());
			return jschX.getMessage();
		}

		return outputBuffer.toString();
	}

	public void close() {
		sesConnection.disconnect();
	}

	public ArrayList<String> ReadingFile(String userName, String password,
			String hostname, String propertyFileLocation) throws JSchException,
			IOException, SftpException {

		/*
		 * String userName = "xactly"; String password = "xactlyincent"; String
		 * hostname = "xautomation";
		 */
		String sCurrentLine;
		BufferedReader br = null;
		ArrayList<String> ar=new ArrayList<String>();
		JSch jsch = new JSch();
		Session session = null;

		session = jsch.getSession(userName, hostname, 22);
		jsch.setKnownHosts("C:\\Windows\\System32\\drivers\\etc\\hosts");

		UserInfo ui = new MyUserInfo();
		session.setUserInfo(ui);
		session.setPassword(password);
		session.setConfig("StrictHostKeyChecking", "no");

		session.connect();
		logger.info("Connected to the server :"+hostname);

		Channel channel = session.openChannel("sftp");
		channel.connect();

		ChannelSftp sftpChannel = (ChannelSftp) channel;

		// InputStream stream = sftpChannel.get("/home/xactly/nohup.properties");
		InputStream stream = sftpChannel.get(propertyFileLocation);
		try {
			br = new BufferedReader(new InputStreamReader(stream));

			while ((sCurrentLine = br.readLine()) != null) {
				//logger.info(sCurrentLine);
				ar.add(sCurrentLine);
			}
		} finally {
			stream.close();
		}
		return ar;
	}
	
	public void copyFileFromWindowsToLinux(String userName, String password,
			String hostname, String windowsFileLocation, String linuxFileLocation) throws JSchException,
			IOException, SftpException {

		JSch jsch = new JSch();
		Session session = null;

		session = jsch.getSession(userName, hostname, 22);
		jsch.setKnownHosts("C:\\Windows\\System32\\drivers\\etc\\hosts");

		UserInfo ui = new MyUserInfo();
		session.setUserInfo(ui);
		session.setPassword(password);
		session.setConfig("StrictHostKeyChecking", "no");

		session.connect();
		logger.info("Connected to the server :"+hostname);

		Channel channel = session.openChannel("sftp");
		channel.connect();

		ChannelSftp sftpChannel = (ChannelSftp) channel;
		sftpChannel.put(windowsFileLocation, linuxFileLocation);
		logger.info("File copied from Windows to linix...");		
	}

	public static class MyUserInfo implements UserInfo, UIKeyboardInteractive {

		public String getPassphrase() {
			return null;
		}

		public String getPassword() {
			return null;
		}

		public boolean promptPassphrase(String arg0) {
			return false;
		}

		public boolean promptPassword(String arg0) {
			return false;
		}

		public boolean promptYesNo(String arg0) {
			return false;
		}

		public void showMessage(String arg0) {
		}

		public String[] promptKeyboardInteractive(String arg0, String arg1,
				String arg2, String[] arg3, boolean[] arg4) {
			return null;
		}
	}

}
