package com.xactly.xcommons.xlsxlibrary;

import java.text.SimpleDateFormat;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.*;

public class XlsxCellReader {

	/*This method retrieves the string value of a particular cell in the given Excel Workbook.
	Note on arguments to be passed: 
	1) Provide the workbook in which the target cell is present,
	2) Sheet number in the workbook which has the target cell starting from 0 (e.g: Sheet1 value should be 0),
	3) Row number of the target cell starting from 0 (e.g: For row A in excel, row number value should be 0),
	4) Column number of the target cell starting from 0 (e.g: For column 1 in excel, column number value should be 0),
	*/
	public static String readCellFromExcel(XSSFWorkbook workbook, int sheetNum, int rowNum, int colNum) {
		XSSFCell cell = workbook.getSheetAt(sheetNum).getRow(rowNum).getCell(colNum); 
		String cellString = getCellValueAsString(cell);
		return cellString;
	}
	
	// Get XLSX sheet cell value as a string
	public static String getCellValueAsString(Cell cell) {
		String strCellValue = null;
		if (cell != null) {
			switch (cell.getCellType()) {
			case Cell.CELL_TYPE_STRING:
				strCellValue = cell.toString();
				break;
			case Cell.CELL_TYPE_NUMERIC:
				if (DateUtil.isCellDateFormatted(cell)) {
					SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
					strCellValue = dateFormat.format(cell.getDateCellValue());
				} else {
					Double value = cell.getNumericCellValue();
					Long longValue = value.longValue();
					strCellValue = new String(longValue.toString());
				}
				break;
			case Cell.CELL_TYPE_BOOLEAN:
				strCellValue = new String(new Boolean(cell.getBooleanCellValue()).toString());
				break;
			case Cell.CELL_TYPE_BLANK:
				strCellValue = "";
				break;
			}
		}
		return strCellValue;
	}
}
