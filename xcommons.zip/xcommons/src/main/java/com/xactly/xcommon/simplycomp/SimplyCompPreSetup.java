package com.xactly.xcommons.simplycomp;

import static org.hamcrest.Matchers.containsString;

import java.io.File;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.xactly.xcommons.app.LoginToApplication;
import com.xactly.xcommons.selenium.SetWebDrivers;




public class SimplyCompPreSetup {
	public static Logger logger = Logger.getLogger(SimplyCompPreSetup.class.getName());
	LoginToApplication login = new LoginToApplication();
	public static InputStream systemPropertyInputStream;
	public static Properties symProPath = new Properties();
	public static String baseurl;
	public static String userid;
	public static String password;
	public static String basepath;
	public static Response loginresponse;
	public static Response getLoginresponse() {
		return loginresponse;
	}
	public static void setLoginresponse(Response loginresponse) {
		SimplyCompPreSetup.loginresponse = loginresponse;
	}
	public static String getBasepath() {
		return basepath;
	}
	public static void setBasepath(String basepath) {
		SimplyCompPreSetup.basepath = basepath;
	}
	public static String getBaseurl() {
		return baseurl;
	}
	public static void setBaseurl(String baseurl) {
		SimplyCompPreSetup.baseurl = baseurl;
	}
	public static String getUserid() {
		return userid;
	}
	public static void setUserid(String userid) {
		SimplyCompPreSetup.userid = userid;
	}
	public static String getPassword() {
		return password;
	}
	public static void setPassword(String password) {
		SimplyCompPreSetup.password = password;
	}
	public static InputStream getSystemPropertyInputStream() {
		return systemPropertyInputStream;
	}
	public static void setSystemPropertyInputStream(
			InputStream systemPropertyInputStream) {
		SimplyCompPreSetup.systemPropertyInputStream = systemPropertyInputStream;
	}
	
	
	@BeforeSuite(alwaysRun = true)	
	@Parameters({"environment","application","mode","browser"})
	public void preSetUp(@Optional String environment,@Optional String application,@Optional String mode,@Optional String browser) throws Exception 
	{			
		logger.info("Running Before Suite Setup ");
		
		String propFile=environment+File.separator+environment+".properties";
		System.out.println(propFile);
		setSystemPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(propFile));
		symProPath.load(SimplyCompPreSetup.getSystemPropertyInputStream());
		
		setBaseurl(SimplyCompPreSetup.symProPath.getProperty("base.url"));	
		setBasepath(SimplyCompPreSetup.symProPath.getProperty("base.path"));	

		setUserid(SimplyCompPreSetup.symProPath.getProperty("user.id"));
		setPassword(SimplyCompPreSetup.symProPath.getProperty("password"));
		LoginToApplication.setApplication(application);
		LoginToApplication.setUrl(getBaseurl());
		SetWebDrivers.setBrowser(browser);
		logger.info("username|password "+getUserid()+"|"+getPassword());
		logger.info("url "+getBaseurl());

		if(mode.equalsIgnoreCase("gui"))
		{
			new SetWebDrivers();
			login.loginToSimplyComp();
		}
		else if(mode.equalsIgnoreCase("api"))
		{
			System.out.println("Logging in as api"+getBasepath()+"/api/auth/v1/login");
			Response loginResponse = RestAssured.given()
					   .relaxedHTTPSValidation()
					   .log().all()
					   .given()
					   .header("Referer", ""+getBasepath()+"/apploginpwd")
					   .header("mssid","")
					   .contentType(ContentType.JSON)
					   .body("{\"loginId\":\""+getUserid()+"\",\"password\":\""+getPassword()+"\"}")
					   .expect()
					   .when().post(getBasepath()+"/api/auth/v1/login");
			setLoginresponse(loginResponse);
		}
		
	}
	
	@AfterSuite(alwaysRun = true)	
	@Parameters({"mode"})
	public void terminateSuite(@Optional String mode) throws Exception
	{
		
		if(mode.equalsIgnoreCase("gui")){
			SetWebDrivers.getDriver().quit();
			
			if(SetWebDrivers.OSDetector().equalsIgnoreCase("Mac") && SetWebDrivers.getBrowser().equalsIgnoreCase("chrome"))
			{
				Runtime.getRuntime().exec("killall chromedriver_mac");
			}
			if(SetWebDrivers.OSDetector().equalsIgnoreCase("Mac") && SetWebDrivers.getBrowser().equalsIgnoreCase("firefox"))
			{
				Runtime.getRuntime().exec("killall geckodriver_mac");
			}
		}
	}

}
