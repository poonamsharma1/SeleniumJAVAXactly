package com.xactly.xcommons.selenium;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.log4j.Logger;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xactly.xcommons.app.LoginToApplication;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SetWebDrivers {
	public static InputStream systemPropertyInputStream;
	public static Logger logger = Logger.getLogger(SetWebDrivers.class.getName());
	public static Properties symProPath = new Properties();
	public static Properties tableDet = new Properties();
	public static WebDriver driver;
	public static WebDriver savedriver;
	public static WebDriver secondarydriver;
	public static String runningOS = OSDetector();

	public static WebDriver getSecondarydriver() {
		return secondarydriver;
	}

	private static final String TASKLIST = "tasklist";
	private static final String KILL = "taskkill /F /IM ";

	public static void setSecondarydriver(WebDriver secondarydriver) {
		SetWebDrivers.secondarydriver = secondarydriver;
	}

	public static WebDriver getSavedriver() {
		return savedriver;
	}

	public static void setSavedriver(WebDriver savedriver) {
		SetWebDrivers.savedriver = savedriver;
	}

	public static String browser;

	public static String getBrowser() {
		return browser;
	}

	public static void setBrowser(String browser) {
		SetWebDrivers.browser = browser;
	}

	private static String navigationType;

	public static void setNavigationType(String navigationType) {
		logger.info("navigation type recieved is:" + navigationType);
		// default navigation is gui-new
		if (navigationType == null || navigationType.contains("navigation")) {
			logger.info("navigationType value not provided, taking default value : gui-new");
			SetWebDrivers.navigationType = "gui-new";
		} else {
			SetWebDrivers.navigationType = navigationType;
		}
		logger.info("navigationType is set to : " + SetWebDrivers.navigationType);
	}

	public static String getNavigationType() {
		return navigationType;
	}

	public static InputStream getSystemPropertyInputStream() {
		return systemPropertyInputStream;
	}

	public static void setSystemPropertyInputStream(InputStream systemPropertyInputStream) {
		SetWebDrivers.systemPropertyInputStream = systemPropertyInputStream;
	}

	public static WebDriver getDriver() {
		return driver;
	}

	public static void setDriver(WebDriver driver) {
		SetWebDrivers.driver = driver;
	}

	public SetWebDrivers() throws Exception {
		// setSystemPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream("\\config.properties"));
		System.setProperty("java.net.preferIPv4Stack", "true");
		String app = LoginToApplication.getApplication();
		if (LoginToApplication.getApplication().equalsIgnoreCase("incent")) {
			setSystemPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream("config.properties"));
			symProPath.load(getSystemPropertyInputStream());
			setSystemPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream("tables.properties"));
			tableDet.load(getSystemPropertyInputStream());
			// setBrowser(symProPath.getProperty("system_BrowserType"));
			// setBrowser(browser);
			// createDownloadDir();
			logger.info("Browser: " + getBrowser());
		}
		if (getBrowser().trim().contains("Edge")) {
//			System.setProperty("webdriver.ie.driver.extractpath", "\\temp");

			WebDriverManager.edgedriver().setup();
			logger.info("iedriver setup is done : using WebDriverManager dependency");

//			System.setProperty("webdriver.ie.logfile", "\\temp\\IEDriverServer.log");

			// DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();
//			DesiredCapabilities ieCapabilities = null;
			// ieCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);

//			ieCapabilities.setCapability("ensureCleanSession", true);
//			ieCapabilities.setCapability("ignoreZoomSetting", true);
//			ieCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);

			if (runningOS.equals("Windows")) {

				String processName = "msedgedriver.exe";
				if (isProcessRunning(processName)) {

					killProcess(processName);
				}
			}
			driver = new EdgeDriver();
			setDriver(driver);
//			setDriver(new InternetExplorerDriver(ieCapabilities));
			logger.info("launched internet explorer browser..");

		} else if (getBrowser().trim().equalsIgnoreCase("Firefox")
				|| getBrowser().trim().equalsIgnoreCase("Firefox_Headless")) {
			logger.info("launchin firefox driver..");
			// logger.info("Path of the gecko driver is :"
			// + SetWebDrivers.class.getResource("/thirdparty/geckodriver.exe").getFile());
			WebDriverManager.firefoxdriver().setup();
			logger.info("firefoxdriver setup is done : using WebDriverManager dependency");

			logger.info("Running OS is " + runningOS);
			if (runningOS.equals("Windows")) {
				// System.setProperty("webdriver.gecko.driver",
				// SetWebDrivers.class.getResource("/thirdparty/geckodriver.exe").getFile());
				String processName = "geckodriver.exe";
				if (isProcessRunning(processName)) {
					killProcess(processName);
				}
			}
			// else if (runningOS.equals("Mac")) {
			// System.setProperty("webdriver.gecko.driver", "/usr/local/geckodriver_mac");
			// } else if (runningOS.equals("Linux")) {
			// System.setProperty("webdriver.gecko.driver",
			// "/usr/local/jenkins/geckodriver_linux");
			// }

			FirefoxOptions options = new FirefoxOptions();
			if (getBrowser().trim().equalsIgnoreCase("Firefox_Headless")) {
				options.addArguments("--headless");
			}

			FirefoxProfile profile = new FirefoxProfile();
			profile.setPreference("browser.download.folderList", 2);
			profile.setPreference("browser.download.manager.showWhenStarting", false);
			// Set downloadPath
			profile.setPreference("browser.download.dir", Constants.downloadLoc);
			// Set File Open &amp; Save preferences
			profile.setPreference("browser.helperApps.neverAsk.openFile",
					"text/csv,application/x-msexcel,application/excel,application/x-excel,application/vnd.ms-excel,image/png,image/jpeg,text/html,text/plain,application/msword,application/xml,application/pdf,application/zip,application/x-zip-compressed,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			profile.setPreference("browser.helperApps.neverAsk.saveToDisk",
					"text/csv,application/x-msexcel,application/excel,application/x-excel,application/vnd.ms-excel,image/png,image/jpeg,text/html,text/plain,application/msword,application/xml,application/pdf,application/zip,application/x-zip-compressed,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			profile.setPreference("pdfjs.disabled", true);
			profile.setPreference("plugin.scan.Acrobat", "99.0");
			profile.setPreference("plugin.scan.plid.all", false);
			profile.setPreference("browser.helperApps.alwaysAsk.force", false);
			profile.setPreference("dom.file.createInChild", true);
			// options.setLegacy(true);
			options.setProfile(profile);
			options.setCapability("acceptInsecureCerts", true);
			options.addPreference("javascript.options.showInConsole", false);
			options.addPreference("dom.ipc.processCount", 8);
			// options.isJavascriptEnabled();
			options.setCapability("marionette", true);
			options.setCapability("browser.download.folderList", 2);
			options.setCapability("browser.download.manager.showWhenStarting", false);
			options.setCapability("dom.successive_dialog_time_limit", 0);
			options.setCapability("browser.download.dir", Constants.downloadLoc);
			options.setCapability("browser.helperApps.neverAsk.saveToDisk",
					"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv,application/vnd.ms-excel,application/pdf,application/zip,application/x-zip-compressed,");
			options.setCapability("pdfjs.disabled", true);
			options.setCapability("network.http.response.timeout", 900);
			options.setCapability("extensions.update.enabled", false);
			options.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.ACCEPT);
			setDriver(new FirefoxDriver(options));
			logger.info("launched firefox driver..");

		} else if (getBrowser().trim().equalsIgnoreCase("Chrome")) {

			// if (runningOS.equals("Windows")) {
			// // System.setProperty("webdriver.chrome.driver",
			// //
			// SetWebDrivers.class.getResource("/thirdparty/chromedriver.exe").getFile());
			// killSession();
			// } else if (runningOS.equals("Mac")) {
			// System.setProperty("webdriver.chrome.driver", "/usr/local/chromedriver_mac");
			// }
			killSession();
			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("test-type");
			options.addArguments("disable-infobars");
			options.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.ACCEPT);

			if (runningOS.equals("Mac"))
				options.addArguments("--window-size=1280,800");

			Map<String, Object> prefs = new HashMap<String, Object>();
			prefs.put("download.default_directory", Constants.downloadLoc);
			prefs.put("download.prompt_for_download", false);
			prefs.put("profile.default_content_setting_values.plugins", 1);
			prefs.put("profile.content_settings.plugin_whitelist.adobe-flash-player", 1);
			prefs.put("profile.content_settings.exceptions.plugins.*,*.per_resource.adobe-flash-player", 1);
			prefs.put("PluginsAllowedForUrls", LoginToApplication.getUrl());
			prefs.put("profile.content_settings.exceptions.plugins.*,*.per_resource.adobe-flash-player", 1);
			prefs.put("profile.content_settings.exceptions.plugins.*,*.setting", 1);

			options.setExperimentalOption("prefs", prefs);
			options.addArguments("--disable-features=EnableEphemeralFlashPermission");
			options.addArguments("--no-sandbox");
			options.addArguments("--disable-dev-shm-usage"); // overcome limited resource problems
			options.addArguments("start-maximized"); // open Browser in maximized mode
			options.addArguments("disable-infobars"); // disabling infobars
			options.addArguments("--ignore-certificate-errors");
			options.addArguments("--remote-allow-origins=*");
			options.setAcceptInsecureCerts(true);

			// options.setExperimentalOption("prefs", prefs);
			driver = new ChromeDriver(options);
			// driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS) ;

		} else if (getBrowser().trim().equalsIgnoreCase("Chrome_headless")) {
			logger.info("Running OS is " + runningOS);
			WebDriverManager.chromedriver().setup();

			// if (runningOS.equals("Linux")) {
			// System.setProperty("webdriver.chrome.driver",
			// "/usr/local/jenkins/chromedriver_linux");
			//
			// } else if (runningOS.equals("Mac")) {
			// System.setProperty("webdriver.chrome.driver", "/usr/local/chromedriver_mac");
			//
			// } else

			if (runningOS.equals("Windows")) {
				// System.setProperty("webdriver.chrome.driver",
				// SetWebDrivers.class.getResource("/thirdparty/chromedriver.exe").getFile());
				String processName = "chromedriver.exe";
				if (isProcessRunning(processName)) {
					killProcess(processName);
				}
			}

			ChromeOptions options = new ChromeOptions();
			options.addArguments("test-type");
			options.addArguments("disable-infobars");
			// WebDriver driver=new ht

			options.addArguments("--headless");
			options.addArguments("--window-size=1280,800");
			// options.setHeadless(true);
			options.addArguments("--disable-gpu");
			options.addArguments("--disable-popup-blocking");
			options.addArguments("--no-sandbox");
			options.addArguments("--disable-dev-shm-usage");

			Map<String, Object> prefs = new HashMap<String, Object>();
			prefs.put("download.default_directory", Constants.downloadLoc);
			prefs.put("download.prompt_for_download", false);
			prefs.put("profile.default_content_setting_values.plugins", 1);
			prefs.put("profile.content_settings.plugin_whitelist.adobe-flash-player", 1);
			prefs.put("profile.content_settings.exceptions.plugins.*,*.per_resource.adobe-flash-player", 1);
			prefs.put("PluginsAllowedForUrls", LoginToApplication.getUrl());
			prefs.put("profile.content_settings.exceptions.plugins.*,*.per_resource.adobe-flash-player", 1);
			prefs.put("profile.content_settings.exceptions.plugins.*,*.setting", 1);
			prefs.put("download.directory_upgrade", true);
			prefs.put("download.prompt_for_download", false);
			prefs.put("download.default_directory", Constants.downloadLoc);
			prefs.put("behavior", "allow");
			prefs.put("downloadPath", Constants.downloadLoc);
			// prefs.put("browser.set_download_behavior", "{behavior : \"allow\",
			// downloadPath: \""+Constants.downloadLoc+"\"}");
			prefs.put("browser.set_download_behavior",
					"{'behavior': 'allow', 'downloadPath':}" + Constants.downloadLoc);

			options.setExperimentalOption("prefs", prefs);
			options.addArguments("--disable-features=EnableEphemeralFlashPermission");
			options.addArguments("--disable-dev-shm-usage"); // overcome limited resource problems
			options.addArguments("start-maximized"); // open Browser in maximized mode
			options.addArguments("disable-infobars");
			options.addArguments("--ignore-certificate-errors");
			options.setAcceptInsecureCerts(true);
			ChromeDriverService driverService = ChromeDriverService.createDefaultService();
			driver = new ChromeDriver(driverService, options);

			Map<String, Object> commandParams = new HashMap<>();
			commandParams.put("cmd", "Page.setDownloadBehavior");
			Map<String, String> params = new HashMap<>();
			params.put("behavior", "allow");
			params.put("downloadPath", Constants.downloadLoc);
			commandParams.put("params", params);
			ObjectMapper objectMapper = new ObjectMapper();
			HttpClient httpClient = HttpClientBuilder.create().build();
			String command = objectMapper.writeValueAsString(commandParams);
			String u = driverService.getUrl().toString() + "/session/" + ((RemoteWebDriver) driver).getSessionId()
					+ "/chromium/send_command";
			HttpPost request = new HttpPost(u);
			request.addHeader("content-type", "application/json");
			request.setEntity(new StringEntity(command));
			httpClient.execute(request);

			// driver=new ChromeDriver(options);
			setDriver(driver);

		} else if (getBrowser().trim().equalsIgnoreCase("Safari")) {
			try {
				WebDriverManager.safaridriver().setup();
				logger.info("SafariDriver setup is done : using WebDriverManager dependency");

				setDriver(new SafariDriver());
				logger.info("launched Safari browser..");
			} catch (Exception e) {
				logger.error(
						"*** Error: Unable to Launch the Safari Browser. Possible reason could be - In Your Mac, Your safari browser might not be configured properly. "
								+ "Visit this URL to configure your Safari Browser - https://www.lambdatest.com/blog/selenium-safaridriver-macos/");
				e.printStackTrace();
			}

		} else if (getBrowser().trim().equalsIgnoreCase("Edge")) {

//			System.setProperty("webdriver.edge.extractpath", "\\temp");

			WebDriverManager.edgedriver().setup();
			logger.info("edgeDriver setup is done : using WebDriverManager dependency");
//			System.setProperty("webdriver.edge.logfile", "\\temp\\EdgeDriverServer.log");

			// DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();
			// ieCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);

			if (runningOS.equals("Windows")) {
				String processName = "msedgedriver.exe";
				if (isProcessRunning(processName)) {

					killProcess(processName);
				}
			}
			driver = new EdgeDriver();
			setDriver(driver);
			logger.info("launched Edge browser..");
		}
		setFrames();
		// print get driver
		logger.info("Get driver step...." + getDriver());
		getDriver().manage().deleteAllCookies();

		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().pageLoadTimeout(300, TimeUnit.SECONDS);
		logger.info(LoginToApplication.getUrl());
		getDriver().get(LoginToApplication.getUrl());
	}

	public static String OSDetector() {
		String os = System.getProperty("os.name").toLowerCase();
		if (os.contains("win")) {
			return "Windows";
		} else if (os.contains("nux") || os.contains("nix")) {
			return "Linux";
		} else if (os.contains("mac") || os.contains("darwin")) {
			return "Mac";
		} else if (os.contains("sunos")) {
			return "Solaris";
		} else {
			return "Other";
		}
	}

	public void setFrames() {
		SeleniumHelperClass.frameMap = new HashMap<String, String>();

		// New Incent UI frames
		SeleniumHelperClass.frameMap.put("appiconsframe", "appIconsframe");

		// Old Incent UI frames
		SeleniumHelperClass.frameMap.put("sframe", "sFrame : uiclientFrame");
		SeleniumHelperClass.frameMap.put("listframe", "sFrame : uiclientFrame : mainFrame : listFrame");
		SeleniumHelperClass.frameMap.put("topframe", "sFrame : topFrame");
		SeleniumHelperClass.frameMap.put("headerframe", "sFrame : headerFrame");
		SeleniumHelperClass.frameMap.put("fframe", "fFrame");
		SeleniumHelperClass.frameMap.put("appframe", "appframe");
		SeleniumHelperClass.frameMap.put("profileframe", "profileFrame");
		SeleniumHelperClass.frameMap.put("iframecontent", "iframeContent");
		SeleniumHelperClass.frameMap.put("dashboardframe", "iframeContent : dashboardframe");
		SeleniumHelperClass.frameMap.put("ddashboardframe", "dashboardframe");
		SeleniumHelperClass.frameMap.put("editframe", "sFrame : uiclientFrame : mainFrame : editFrame");
		SeleniumHelperClass.frameMap.put("uiclientframe", "sFrame : uiclientFrame");
		SeleniumHelperClass.frameMap.put("mainframe", "sFrame : uiclientFrame : mainFrame");
		SeleniumHelperClass.frameMap.put("contentframe", "sFrame : uiclientFrame : mainFrame : contentFrame");
		SeleniumHelperClass.frameMap.put("reportcontentframe",
				"sFrame : uiclientFrame : mainFrame : reportFrame : contentFrame");
		SeleniumHelperClass.frameMap.put("reportframe", "sFrame : uiclientFrame : mainFrame : reportFrame");
		SeleniumHelperClass.frameMap.put("clistframe", "sFrame : uiclientFrame : mainFrame : contentFrame : listFrame");
		SeleniumHelperClass.frameMap.put("ceditframe", "sFrame : uiclientFrame : mainFrame : contentFrame : editFrame");
		SeleniumHelperClass.frameMap.put("uploadpeopleframe", "uploadPeopleFrame");
		SeleniumHelperClass.frameMap.put("uploadexchangerateframe", "uploadExchangeRateFrame");
		SeleniumHelperClass.frameMap.put("syseditframe",
				"sFrame : uiclientFrame : mainFrame : mainFrame : sFrame : uiclientFrame : mainFrame : editFrame");
		SeleniumHelperClass.frameMap.put("syslistframe",
				"sFrame : uiclientFrame : mainFrame : mainFrame : sFrame : uiclientFrame : mainFrame : listFrame");
		SeleniumHelperClass.frameMap.put("sysmainframe",
				"sFrame : uiclientFrame : mainFrame : mainFrame : sFrame : uiclientFrame : mainFrame");
		SeleniumHelperClass.frameMap.put("addversionframe", "addVersionframe");
		SeleniumHelperClass.frameMap.put("uploadTitleFrame", "uploadTitleFrame");
		SeleniumHelperClass.frameMap.put("downloadframe", "downloadFrame");
		SeleniumHelperClass.frameMap.put("xbasehierarchyframe",
				"sFrame : uiclientFrame : mainFrame : reportFrame : xbaseHierarchyFrame");
		SeleniumHelperClass.frameMap.put("plandocframe",
				"sFrame : uiclientFrame : mainFrame : reportFrame : contentFrame : planDocFrame");
		SeleniumHelperClass.frameMap.put("sendforapprovalframe", "sendForApprovalFrame");
		SeleniumHelperClass.frameMap.put("xbaseutility", "xbaseUtility");
		SeleniumHelperClass.frameMap.put("profiletabcontentframe_xactlycorp.xactly",
				"profileTabContentFrame_XactlyCorp.Xactly");
		SeleniumHelperClass.frameMap.put("profiletabcontentframe_sfdc.home", "profileTabContentFrame_sfdc.home");
		SeleniumHelperClass.frameMap.put("profiletabcontentframe_xactlycorp.analytics_dashboard",
				"profileTabContentFrame_XactlyCorp.Analytics_Dashboard");
		SeleniumHelperClass.frameMap.put("itarget", "itarget");
		SeleniumHelperClass.frameMap.put("dashboardIframe", "theIframe : dashboardframe");
		SeleniumHelperClass.frameMap.put("introduction_template_edit_ifr",
				"sFrame : uiclientFrame : mainFrame : editFrame : introduction_template_edit_ifr");
		SeleniumHelperClass.frameMap.put("uploadimageframe", "uploadImageFrame");
		SeleniumHelperClass.frameMap.put("planapproveframe", "planApproveFrame");
		SeleniumHelperClass.frameMap.put("uploadratetableframe", "uploadRateTableFrame");
		SeleniumHelperClass.frameMap.put("uploadquotaframe", "uploadQuotaFrame");
		SeleniumHelperClass.frameMap.put("uploadtitleframe", "uploadTitleFrame");
		SeleniumHelperClass.frameMap.put("oracleincenttopframe", "TabForm : sFrame : topFrame");
		SeleniumHelperClass.frameMap.put("oracleincentframe", "TabForm : sFrame : uiclientFrame : mainFrame");
		SeleniumHelperClass.frameMap.put("oracleanalytics", "TabForm : dashboardframe");
		SeleniumHelperClass.frameMap.put("oraclefframe", "TabForm : fFrame");
		SeleniumHelperClass.frameMap.put("canvasinner",
				"canvas-outer-_:alignstar_canvas:j_id0:j_id2:canvasapp : canvas-inner-_:alignstar_canvas:j_id0:j_id2:canvasapp");
		SeleniumHelperClass.frameMap.put("reportframe", "sFrame : uiclientFrame : mainFrame : reportFrame");
		SeleniumHelperClass.frameMap.put("clistframe", "sFrame : uiclientFrame : mainFrame : contentFrame : listFrame");
		SeleniumHelperClass.frameMap.put("ceditframe", "sFrame : uiclientFrame : mainFrame : contentFrame : editFrame");
		SeleniumHelperClass.frameMap.put("uploadpeopleframe", "uploadPeopleFrame");
		SeleniumHelperClass.frameMap.put("uploadexchangerateframe", "uploadExchangeRateFrame");
		SeleniumHelperClass.frameMap.put("syseditframe",
				"sFrame : uiclientFrame : mainFrame : mainFrame : sFrame : uiclientFrame : mainFrame : editFrame");
		SeleniumHelperClass.frameMap.put("syslistframe",
				"sFrame : uiclientFrame : mainFrame : mainFrame : sFrame : uiclientFrame : mainFrame : listFrame");
		SeleniumHelperClass.frameMap.put("addversionframe", "addVersionframe");
		SeleniumHelperClass.frameMap.put("downloadframe", "downloadFrame");
		SeleniumHelperClass.frameMap.put("xbasehierarchyframe",
				"sFrame : uiclientFrame : mainFrame : reportFrame : xbaseHierarchyFrame");
		SeleniumHelperClass.frameMap.put("plandocframe",
				"sFrame : uiclientFrame : mainFrame : reportFrame : contentFrame : planDocFrame");
		SeleniumHelperClass.frameMap.put("sendforapprovalframe", "sendForApprovalFrame");
		SeleniumHelperClass.frameMap.put("xbaseutility", "xbaseUtility");
		SeleniumHelperClass.frameMap.put("profiletabcontentframe_xactlycorp.xactly",
				"profileTabContentFrame_XactlyCorp.Xactly");
		SeleniumHelperClass.frameMap.put("profiletabcontentframe_sfdc.home", "profileTabContentFrame_sfdc.home");
		SeleniumHelperClass.frameMap.put("profiletabcontentframe_xactlycorp.analytics_dashboard",
				"profileTabContentFrame_XactlyCorp.Analytics_Dashboard");
		SeleniumHelperClass.frameMap.put("itarget", "itarget");
		SeleniumHelperClass.frameMap.put("dashboardTheIframe", "theIframe : dashboardframe");
		SeleniumHelperClass.frameMap.put("incentsfdc", "theIframe : sFrame : uiclientFrame : mainFrame");
		SeleniumHelperClass.frameMap.put("incentsfdctab", "theIframe : sFrame : topFrame");
		SeleniumHelperClass.frameMap.put("incentsfdctheframe", "theIframe");
		SeleniumHelperClass.frameMap.put("incentsfdctabsalesconsole",
				"ext-comp-1005 : j_id1 : theIframe : sFrame : topFrame");
		SeleniumHelperClass.frameMap.put("incentsfdcconsole",
				"ext-comp-1005 : j_id1 : theIframe : sFrame : uiclientFrame : mainFrame");
		SeleniumHelperClass.frameMap.put("profiletabcontentframe_xactlycorp.xactlytab",
				"profileTabContentFrame_XactlyCorp.Xactly");
		SeleniumHelperClass.frameMap.put("incentsfdcmoduleswitch", "theIframe : appframe");
		SeleniumHelperClass.frameMap.put("incentsnewuimoduleswitch", "appIconsframe");
		SeleniumHelperClass.frameMap.put("incentsfdcheader", "theIframe : sFrame : headerFrame");
		SeleniumHelperClass.frameMap.put("reskinframe","sFrame : uiclientFrame : mainFrame : listFrame : editframe");
		// Forecast
		SeleniumHelperClass.frameMap.put("perf_frame", "perf_frame");
	}

	public static void createDownloadDir() {
		String uniqueId;
		if (Constants.uniqueId == null)
			uniqueId = SeleniumHelperClass.setUniqueId();
		else
			uniqueId = Constants.uniqueId;
		Constants.uniqueId = uniqueId;
		File downloadLoc = new File(
				new File(System.getProperty("java.io.tmpdir")).getAbsolutePath() + File.separator + uniqueId);
		logger.info("DownloadPath:" + downloadLoc.getAbsolutePath());
		if (!downloadLoc.exists())
			downloadLoc.mkdir();
		Constants.downloadLoc = downloadLoc.getAbsolutePath();
	}

	public static boolean isProcessRunning(String serviceName) throws Exception {

		Process p = Runtime.getRuntime().exec(TASKLIST);
		BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
		String line;
		while ((line = reader.readLine()) != null) {

			// logger.info(line);
			if (line.contains(serviceName)) {
				return true;
			}
		}

		return false;

	}

	public static void killProcess(String serviceName) throws Exception {

		String command = "";
		if (runningOS.equals("Mac")) {
			command = "pkill -9 ";
		} else if (runningOS.equals("Windows")) {
			command = KILL;
		}
		Process p = Runtime.getRuntime().exec(command + serviceName);
		BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
		String line;
		while ((line = reader.readLine()) != null) {
			logger.info(line);
		}
	}

	public static void killSession() {
		try {
			if (runningOS.equals("Windows") && getBrowser().trim().toLowerCase().contains("chrome")) {
				String process_ChromeDriver = "chromedriver.exe";
				String process_chromeBrowser = "chrome.exe";
				logger.info("in killSession()-Windows: killing chrome browser and driver if exists....");
				if (isProcessRunning(process_ChromeDriver)) {
					killProcess(process_ChromeDriver);
				}

				if (isProcessRunning(process_chromeBrowser)) {
					killProcess(process_chromeBrowser);
				}
				logger.info("killing chrome browser and driver if exists....completed");
			} else if (runningOS.equals("Mac")) {
				String process_ChromeDriver = "chromedriver_mac";
				String process_chromeBrowser = "Google Chrome";
				logger.info("in killSession()-Mac: killing chrome browser and driver if exists....");
				driver.quit();
				killProcess(process_ChromeDriver);
				// killProcess(process_chromeBrowser);
				logger.info("killing chrome browser and driver if exists....completed");
			}
		} catch (Exception e) {
			logger.info("failed to kill process..." + e.getMessage());
		}

	}

}