package com.xactly.xcommons.javahelper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import org.apache.log4j.Logger;

public class Time {
public static Logger logger = Logger.getLogger(Time.class.getName());
	
	 public static long getTimeDifference(String startTime,String endTime){
	        long milliseconds=0;
	       
	        try {
	            SimpleDateFormat sdf=new SimpleDateFormat("yyyy:MM:dd-HH:mm:ss.SSS");
	            Date d1=sdf.parse(startTime);
	            Date d2=sdf.parse(endTime);
	            milliseconds=d2.getTime()-d1.getTime();
	
	        } catch (Exception ex) {
	            logger.error(ex);
	        }
	        return milliseconds;
	    
	    }
	 

	 public static String currentTime(){
		    String time=new SimpleDateFormat("yyyy:MM:dd-HH:mm:ss.SSS").format( Calendar.getInstance().getTime());
		    return time;
		    }
	 
	 /**
	  * returns a Calendar instance 'n' days from today, n being the integer passed
	  * time zone used is PST
	  * Can be used to avoid using same date for multiple actions
	  * @param noOfDays - from today
	  * @return Calendar object with the desired date
	  */
	 public Calendar getCalendarInstanceIncremented(int noOfDays){
		String timeStamp = new SimpleDateFormat("MM/dd/yyyy").format(new Date());
		Date EFFECTIVE_START_DATE = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		try {
			EFFECTIVE_START_DATE = sdf.parse(timeStamp);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Calendar c = new GregorianCalendar();
		c.setTime(EFFECTIVE_START_DATE);
		c.add(Calendar.DATE, noOfDays);
		return c;
	 }
	 public Calendar getCalendarInstanceIncrementedwithUserInputdate(String date,int noOfDays) throws ParseException{
			
			// String newstr = "01/02/2019";
			 SimpleDateFormat defaultformat = new SimpleDateFormat("MM/dd/yyyy");
			 SimpleDateFormat Timeformat = new SimpleDateFormat("EE MMM dd hh:mm:ss z yyyy");
			 Calendar c = Calendar.getInstance();
			 c.setTime(defaultformat.parse(date));
			 logger.info(Timeformat.format(c.getTime()));
			 c.add(Calendar.DATE, noOfDays);
			return c;
		 }
}
