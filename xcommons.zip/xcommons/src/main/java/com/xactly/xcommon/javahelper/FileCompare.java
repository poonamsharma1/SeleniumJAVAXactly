package com.xactly.xcommons.javahelper;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.function.ToDoubleFunction;
import java.util.function.ToIntFunction;
import java.util.function.ToLongFunction;

import org.apache.commons.io.FileUtils;
import org.testng.Reporter;

import com.xactly.xcommons.presetup.PreSetup;
import com.xactly.xcommons.selenium.Constants;
import com.xactly.xcommons.selenium.SeleniumHelperClass;

import au.com.bytecode.opencsv.CSVReader;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;


public class FileCompare {
	public static Logger logger = Logger.getLogger(FileCompare.class.getName());
	static final String ESCAPE_PROPERTY = "org.uncommons.reportng.escape-output";
	static Map<Integer, ArrayList<String>> mismatchedData;
	public static List<String[]> sourceData;
	public static List<String[]> targetData;
	public static List<String> sourceHeader;
	public static List<String> targetHeader;
	public static String[] ignoreHeaders = null;
	public static String sortOnColumn = null;
	private static ArrayList<Integer> ignoreHeaderIndices = null;

	public static void main(String arg[]) throws IOException {
		/*
		 * try { FileCompare.ignoreHeaders=new String[]{"Created Date"};
		 * FileCompare.sortOnColumn="Order Code";
		 * 
		 * 
		 * compareFiles(
		 * "D:\\pg\\regression\\singleVersion\\downloads\\JAN-2015_preCredits_ER.csv",
		 * "D:\\pg\\regression\\singleVersion\\downloads\\preCreditandCreditCalcThroughPG_JAN-2015_preCredits_AR.csv"
		 * ); for(String s[]:sourceData) logger.info(Arrays.toString(s));
		 * logger.info("Mismatched:"+mismatchedData); } catch (Exception e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); }
		 */

	}

	public static void readCSVFiles(String sourcePath, String targetPath) throws IOException {

		CSVReader sourceReader = new CSVReader(
				new InputStreamReader(new FileInputStream(new File(sourcePath)), "UTF-8"));
		CSVReader targetReader = new CSVReader(
				new InputStreamReader(new FileInputStream(new File(targetPath)), "UTF-8"));
		sourceData = sourceReader.readAll();
		sourceReader.close();
		targetData = targetReader.readAll();
		targetReader.close();

		if (PreSetup.getApplication().equalsIgnoreCase("incent")) {
			System.out.println("In Incent");
			// Replacing the illigal characters from file headers // ANT-1287
			String[] firstRow = targetData.get(0);
			firstRow[0] = firstRow[0].replaceAll("[^\\p{ASCII}]", "");
			targetData.set(0, firstRow);
		} else
			System.out.println("Not in Incent");

		readHeaders();
		if (sortOnColumn != null) {
			String[] sortColArr = sortOnColumn.split(",");
			for (String columnName : sortColArr) {
				sortSourceData(getHeaderIndex(columnName));
				sortTargetData(getHeaderIndex(columnName));
			}
		}

		sourceData = encodeCommaAndIgnoreUnwantedHeaders(sourceData);
		targetData = encodeCommaAndIgnoreUnwantedHeaders(targetData);
		logger.info(sourcePath + " : sourcePath");
		logger.info(targetPath + " : targetPath");
		// ReportPortal.emitLog("message", "INFO", new Date(), new File(sourcePath));
		// ReportPortal.emitLog("message", "INFO", new Date(), new File(targetPath));

	}

	public static void readTXTFiles(String sourcePath, String targetPath) throws IOException {

		CSVReader sourceReader = new CSVReader(
				new InputStreamReader(new FileInputStream(new File(sourcePath)), "UTF-8"), ';');
		CSVReader targetReader = new CSVReader(
				new InputStreamReader(new FileInputStream(new File(targetPath)), "UTF-8"), ';');
		sourceData = sourceReader.readAll();
		sourceReader.close();
		targetData = targetReader.readAll();
		targetReader.close();
		readHeaders();
		if (sortOnColumn != null) {
			sortSourceData(getHeaderIndex(sortOnColumn));
			sortTargetData(getHeaderIndex(sortOnColumn));
		}
		sourceData = encodeCommaAndIgnoreUnwantedHeaders(sourceData);
		targetData = encodeCommaAndIgnoreUnwantedHeaders(targetData);
	}

	private static int getHeaderIndex(String headerName) {
		for (int i = 0; i < sourceHeader.size(); i++) {
			if (sourceHeader.get(i).trim().equalsIgnoreCase(headerName.trim()))
				return i;
		}
		return -1;

	}

	private static void readHeaders() {
		sourceHeader = new ArrayList<String>();

		targetHeader = new ArrayList<String>();
		for (int i = 0; i < sourceData.get(0).length; i++) {
			sourceHeader.add(sourceData.get(0)[i]);
		}
		for (int i = 0; i < targetData.get(0).length; i++) {
			targetHeader.add(targetData.get(0)[i]);
		}
		if (ignoreHeaders != null) {
			ignoreHeaderIndices = new ArrayList<Integer>();
			int index = -1;
			for (String headerName : ignoreHeaders) {
				index = getHeaderIndex(headerName);
				if (index != -1) {
					ignoreHeaderIndices.add(index);
				}

			}
			for (int i = 0; i < sourceHeader.size(); i++) {
				if (Arrays.asList(ignoreHeaders).contains(sourceHeader.get(i))) {
					ignoreHeaderIndices.add(i);
				}

			}

		}
		// logger.info(sourceHeader);
	}

	private static List<String[]> encodeCommaAndIgnoreUnwantedHeaders(List<String[]> data) {
		if (ignoreHeaders == null) {
			for (int i = 0; i < data.size(); i++) {
				String[] item = data.get(i);// logger.info(Arrays.toString(item));
				for (int j = 0; j < item.length; j++) {
					// logger.info(data.get(i)[j]);
					data.get(i)[j] = data.get(i)[j].replaceAll(",", "@#%comma%#@");
					// logger.info(data.get(i)[j]);

				}
			}
		} else {
			for (int i = 0; i < data.size(); i++) {
				String[] item = data.get(i);// logger.info(Arrays.toString(item));
				for (int j = 0; j < item.length; j++) {
					// logger.info(data.get(i)[j]);
					if (ignoreHeaderIndices.contains(j)) {
						data.get(i)[j] = "<ignored>";
					}
					data.get(i)[j] = data.get(i)[j].replaceAll(",", "@#%comma%#@");
					// logger.info(data.get(i)[j]);
				}
			}
		}
		return data;
	}

	private static String decodeComma(String text) {
		text = text.replaceAll("@#%comma%#@", ",");
		return text;
	}

	public static boolean compareFiles(String sourcePath, String targetPath) throws Exception {
		logger.info(sourcePath + " : sourcePath");
		logger.info(targetPath + " : targetPath");
		// ReportPortal.emitLog("message", "INFO", new Date(), new File(sourcePath));
		// ReportPortal.emitLog("message", "INFO", new Date(), new File(targetPath));
		logger.info("RP_MESSAGE#FILE#" + sourcePath + "#sourcePath");
		logger.info("RP_MESSAGE#FILE#" + targetPath + "#targetPath");

		int dotIndex = sourcePath.lastIndexOf(".");
		String ext = sourcePath.substring(dotIndex + 1);
		boolean isHeaderSame = true;
		boolean comparisonStatus = false;
		Reporter.setEscapeHtml(false);
		System.setProperty(ESCAPE_PROPERTY, "false");

		if (ext.equalsIgnoreCase("csv")) {
			System.out.println("entered in to csv");
			mismatchedData = new HashMap<Integer, ArrayList<String>>();
			readCSVFiles(sourcePath, targetPath);
			isHeaderSame = compareHeaders();

			if (isHeaderSame) {
				compareLists(sourceData, targetData);
				mismatchedData = new TreeMap<Integer, ArrayList<String>>(mismatchedData);
				generateOutput();
				if (mismatchedData.size() > 0)
					comparisonStatus = false;
				else
					comparisonStatus = true;
			} else {
				logger.debug("<p>Header Mismatch<br/>Expected:" + sourceHeader + "<br/>Actual" + targetHeader + "</p>");
				comparisonStatus = false;
			}
		} else if (ext.equalsIgnoreCase("txt")) {
			mismatchedData = new HashMap<Integer, ArrayList<String>>();
			readTXTFiles(sourcePath, targetPath);
			isHeaderSame = compareHeaders();

			if (isHeaderSame) {
				compareLists(sourceData, targetData);
				mismatchedData = new TreeMap<Integer, ArrayList<String>>(mismatchedData);
				generateOutput();
				if (mismatchedData.size() > 0)
					comparisonStatus = false;
				else
					comparisonStatus = true;
			} else {
				logger.debug("<p>Header Mismatch<br/>Expected:" + sourceHeader + "<br/>Actual" + targetHeader + "</p>");
				comparisonStatus = false;
			}
		} else {
			logger.info("This is not a CSV file");
			throw new Exception("This is not a csv file");
		}
		FileCompare.ignoreHeaders = null;
		FileCompare.sortOnColumn = null;
		return comparisonStatus;
	}

	public static boolean compareHeaders() {
		boolean isHeaderSame = false;
		ArrayList<String> mismatched = new ArrayList<String>();

		if (sourceData.size() > 0 && targetData.size() > 0) {
			String sourceRow = Arrays.toString(sourceData.get(0));
			String targetRow = Arrays.toString(targetData.get(0));
			if (sourceRow.length() > 0 && ((int) sourceRow.substring(1).charAt(0)) > 127) {
				String c = sourceRow.substring(1, 2);
				sourceRow = sourceRow.replace(c, "");// This is to replace the BOM character in source
				// sourceRow=sourceRow.substring(1);
			}
			if (targetRow.length() > 0 && ((int) targetRow.substring(1).charAt(0)) > 127) {
				String c = targetRow.substring(1, 2);
				targetRow = targetRow.replace(c, "");// This is to replace the BOM character in Target
				// targetRow=targetRow.substring(1);
			}
			if (sourceRow.equals(targetRow))
				isHeaderSame = true;
			else {

				mismatched.add(sourceRow);
				mismatched.add(targetRow);
				mismatchedData.put(0, mismatched);
			}
		} else if (sourceData.size() > 0 && targetData.size() == 0) {
			isHeaderSame = false;
		}
		return isHeaderSame;
	}

	public static void compareLists(List<String[]> sourceData, List<String[]> targetData) {

		ArrayList<String> mismatched;
		int minLen = sourceData.size() < targetData.size() ? sourceData.size() : targetData.size();
		int maxLen = sourceData.size() > targetData.size() ? sourceData.size() : targetData.size();
		boolean isSourceLarge = sourceData.size() > targetData.size() ? true : false;
		int i = 0;
		for (; i < minLen; i++) {

			String sourceRow = Arrays.toString(sourceData.get(i));
			String targetRow = Arrays.toString(targetData.get(i));
			if (sourceRow.length() > 0 && ((int) sourceRow.substring(1).charAt(0)) > 127) {
				String c = sourceRow.substring(1, 2);
				sourceRow = sourceRow.replace(c, "");// This is to replace the BOM character in source
				// sourceRow=sourceRow.substring(1);
			}
			if (targetRow.length() > 0 && ((int) targetRow.substring(1).charAt(0)) > 127) {
				String c = targetRow.substring(1, 2);
				targetRow = targetRow.replace(c, "");// This is to replace the BOM character in Target
				// targetRow=targetRow.substring(1);
			}
			/*
			 * logger.info("source:"+sourceRow); logger.info("target:"+targetRow);
			 * logger.info("Target first char:"+(int)targetRow.substring(2).charAt(0));
			 * logger.info("Source first char:"+(int)sourceRow.substring(2).charAt(0));
			 */
			if (sourceRow.equals(targetRow)) {

			} else {
				mismatched = new ArrayList<String>();
				mismatched.add(sourceRow);
				mismatched.add(targetRow);
				mismatchedData.put(i, mismatched);
			}
		}
		String sourceRow = "[", targetRow = "[";
		for (int k = 0; k < sourceHeader.size() - 1; k++)
			sourceRow += ", ";
		sourceRow += "]";
		for (int k = 0; k < targetHeader.size() - 1; k++)
			targetRow += ", ";
		targetRow += "]";
		// String sourceRow="",targetRow="";
		for (; i < maxLen; i++) {
			mismatched = new ArrayList<String>();

			if (isSourceLarge) {
				sourceRow = Arrays.toString(sourceData.get(i));
				mismatched.add(sourceRow);
				mismatched.add(targetRow);
			} else {
				targetRow = Arrays.toString(targetData.get(i));
				mismatched.add(sourceRow);
				mismatched.add(targetRow);
			}
			mismatchedData.put(i, mismatched);
		}

	}

	public static void generateOutput() throws Exception {

		logger.info(mismatchedData);
		if (mismatchedData.size() > 0) {
			logger.info("<style>		table{"
					+ "font-family: wf_segoe-ui_normal, \'Segoe UI\', Segoe, \'Segoe WP\', Tahoma, Verdana, Arial, sans-serif;"
					+ "font-size:14px; }" + "table tr th{" + "background-color:#346F8F;" + "	color:#FFFFFF; }"

					+ "</style>");
			logger.info(
					"<h2>Mismatched rows</h2><br><table cellpadding='4' style='border: 1px solid #000000; border-collapse: collapse;' border='1'><tr><th>line no</th>");
			for (int i = 0; i < sourceHeader.size(); i++) {
				logger.info("<th>" + decodeComma(sourceHeader.get(i)) + "</th>");
			}
			logger.info("</tr>");
			// "<tr><th>line</th><th>File1</th><th>File2</th></tr>");
			for (Entry<Integer, ArrayList<String>> entry : mismatchedData.entrySet()) {
				logger.info("<tr><td rowspan=2 style='vertical-align:middle;'>" + entry.getKey() + "</td>");

				String[] sourceList = entry.getValue().get(0).replace("[", "").replace("]", "").split(",");
				String[] targetList = entry.getValue().get(1).replace("[", "").replace("]", "").split(",");
				ArrayList ar = new ArrayList<String>();
				for (int i = 0; i < sourceList.length; i++) {
					ar.add(sourceList[i]);
					if (sourceList[i].equals(""))
						logger.info("<td> &nbsp; </td>");
					else
						logger.info("<td>" + decodeComma(sourceList[i]) + "</td>");

				}

				logger.info("</tr>");
				logger.info("<tr style='background-color:#e7e7e7;'>");

				for (int i = 0; i < targetList.length; i++) {
					if (ar.size() > i) {
						if (!ar.get(i).equals(targetList[i])) {
							if (targetList[i].equals(""))
								logger.info("<td style='background-color:#FF0000;'>&nbsp;</td>");
							else
								logger.info("<td style='background-color:#FF0000;'>" + decodeComma(targetList[i])
										+ "</td>");
						} else {
							if (targetList[i].equals(""))
								logger.info("<td>&nbsp;</td>");
							else
								logger.info("<td>" + decodeComma(targetList[i]) + "</td>");
						}
					} else if (targetList[i].equals(""))
						logger.info("<td style='background-color:#FF0000;'>&nbsp;</td>");
					else
						logger.info("<td style='background-color:#FF0000;'>" + decodeComma(targetList[i]) + "</td>");

				}

				logger.info("</tr>");

			}
			logger.info("</table>");
			FileCompare.generateCSVOutput(Constants.downloadLoc, "Errorfile");

		} else {
			logger.info("<p>No Mismatched rows</p>");
		}
	}

	public static void generateCSVOutput(String destDirectory, String FileName) throws Exception {

		File errorFile = new File(destDirectory + File.separator + FileName + "_Error.csv");
		List<String> sourceHeader_csv = sourceHeader;
		sourceHeader_csv.add(0, "line Num");

		FileUtils.writeStringToFile(errorFile, sourceHeader_csv.toString().replace("[", "").replace("]", ""));

		for (Entry<Integer, ArrayList<String>> entry : mismatchedData.entrySet()) {
			Integer lineNo = entry.getKey();
			String sourceList = entry.getValue().get(0).toString().replace("[", "").replace("]", "");
			String targetList = entry.getValue().get(1).toString().replace("[", "").replace("]", "");
			sourceList = lineNo + " in ER," + decodeComma(sourceList);
			targetList = lineNo + " in AR," + decodeComma(targetList);
			FileUtils.writeStringToFile(errorFile, "\n", true);
			FileUtils.writeStringToFile(errorFile, sourceList, true);
			FileUtils.writeStringToFile(errorFile, "\n", true);
			FileUtils.writeStringToFile(errorFile, targetList, true);

		}

		logger.info("RP_MESSAGE#FILE#" + errorFile + "#sourcePath");

	}

	public static void generateTXTOutput(String destDirectory, String FileName) throws Exception {
		File errorFile = new File(destDirectory + "\\" + FileName + "_Error.txt");
		List<String> sourceHeader_txt = sourceHeader;
		sourceHeader_txt.add(0, "line Num");

		FileUtils.writeStringToFile(errorFile, sourceHeader_txt.toString().replace("[", "").replace("]", ""));

		for (Entry<Integer, ArrayList<String>> entry : mismatchedData.entrySet()) {
			Integer lineNo = entry.getKey();
			String sourceList = entry.getValue().get(0).toString().replace("[", "").replace("]", "");
			String targetList = entry.getValue().get(1).toString().replace("[", "").replace("]", "");
			sourceList = lineNo + " in ER," + decodeComma(sourceList);
			targetList = lineNo + " in AR," + decodeComma(targetList);
			FileUtils.writeStringToFile(errorFile, "\n", true);
			FileUtils.writeStringToFile(errorFile, sourceList, true);
			FileUtils.writeStringToFile(errorFile, "\n", true);
			FileUtils.writeStringToFile(errorFile, targetList, true);

		}
	}

	public static void sortSourceData(final int headerIndex) {
		Collections.sort(sourceData, new Comparator<String[]>() {
			public int compare(String[] array1, String[] array2) {
				return array1[headerIndex].compareTo(array2[headerIndex]);
			}

			public Comparator<String[]> reversed() {
				// TODO Auto-generated method stub
				return null;
			}

			public Comparator<String[]> thenComparing(Comparator<? super String[]> other) {
				// TODO Auto-generated method stub
				return null;
			}

			public <U> Comparator<String[]> thenComparing(Function<? super String[], ? extends U> keyExtractor,
					Comparator<? super U> keyComparator) {
				// TODO Auto-generated method stub
				return null;
			}

			public <U extends Comparable<? super U>> Comparator<String[]> thenComparing(
					Function<? super String[], ? extends U> keyExtractor) {
				// TODO Auto-generated method stub
				return null;
			}

			public Comparator<String[]> thenComparingInt(ToIntFunction<? super String[]> keyExtractor) {
				// TODO Auto-generated method stub
				return null;
			}

			public Comparator<String[]> thenComparingLong(ToLongFunction<? super String[]> keyExtractor) {
				// TODO Auto-generated method stub
				return null;
			}

			public Comparator<String[]> thenComparingDouble(ToDoubleFunction<? super String[]> keyExtractor) {
				// TODO Auto-generated method stub
				return null;
			}

			public <T extends Comparable<? super T>> Comparator<T> reverseOrder() {
				// TODO Auto-generated method stub
				return null;
			}

			public <T extends Comparable<? super T>> Comparator<T> naturalOrder() {
				// TODO Auto-generated method stub
				return null;
			}

			public <T> Comparator<T> nullsFirst(Comparator<? super T> comparator) {
				// TODO Auto-generated method stub
				return null;
			}

			public <T> Comparator<T> nullsLast(Comparator<? super T> comparator) {
				// TODO Auto-generated method stub
				return null;
			}

			public <T, U> Comparator<T> comparing(Function<? super T, ? extends U> keyExtractor,
					Comparator<? super U> keyComparator) {
				// TODO Auto-generated method stub
				return null;
			}

			public <T, U extends Comparable<? super U>> Comparator<T> comparing(
					Function<? super T, ? extends U> keyExtractor) {
				// TODO Auto-generated method stub
				return null;
			}

			public <T> Comparator<T> comparingInt(ToIntFunction<? super T> keyExtractor) {
				// TODO Auto-generated method stub
				return null;
			}

			public <T> Comparator<T> comparingLong(ToLongFunction<? super T> keyExtractor) {
				// TODO Auto-generated method stub
				return null;
			}

			public <T> Comparator<T> comparingDouble(ToDoubleFunction<? super T> keyExtractor) {
				// TODO Auto-generated method stub
				return null;
			}
		});
	}

	public static void sortTargetData(final int headerIndex) {
		Collections.sort(targetData, new Comparator<String[]>() {
			public int compare(String[] array1, String[] array2) {
				return array1[headerIndex].compareTo(array2[headerIndex]);
			}

			public Comparator<String[]> reversed() {
				// TODO Auto-generated method stub
				return null;
			}

			public Comparator<String[]> thenComparing(Comparator<? super String[]> other) {
				// TODO Auto-generated method stub
				return null;
			}

			public <U> Comparator<String[]> thenComparing(Function<? super String[], ? extends U> keyExtractor,
					Comparator<? super U> keyComparator) {
				// TODO Auto-generated method stub
				return null;
			}

			public <U extends Comparable<? super U>> Comparator<String[]> thenComparing(
					Function<? super String[], ? extends U> keyExtractor) {
				// TODO Auto-generated method stub
				return null;
			}

			public Comparator<String[]> thenComparingInt(ToIntFunction<? super String[]> keyExtractor) {
				// TODO Auto-generated method stub
				return null;
			}

			public Comparator<String[]> thenComparingLong(ToLongFunction<? super String[]> keyExtractor) {
				// TODO Auto-generated method stub
				return null;
			}

			public Comparator<String[]> thenComparingDouble(ToDoubleFunction<? super String[]> keyExtractor) {
				// TODO Auto-generated method stub
				return null;
			}

			public <T extends Comparable<? super T>> Comparator<T> reverseOrder() {
				// TODO Auto-generated method stub
				return null;
			}

			public <T extends Comparable<? super T>> Comparator<T> naturalOrder() {
				// TODO Auto-generated method stub
				return null;
			}

			public <T> Comparator<T> nullsFirst(Comparator<? super T> comparator) {
				// TODO Auto-generated method stub
				return null;
			}

			public <T> Comparator<T> nullsLast(Comparator<? super T> comparator) {
				// TODO Auto-generated method stub
				return null;
			}

			public <T, U> Comparator<T> comparing(Function<? super T, ? extends U> keyExtractor,
					Comparator<? super U> keyComparator) {
				// TODO Auto-generated method stub
				return null;
			}

			public <T, U extends Comparable<? super U>> Comparator<T> comparing(
					Function<? super T, ? extends U> keyExtractor) {
				// TODO Auto-generated method stub
				return null;
			}

			public <T> Comparator<T> comparingInt(ToIntFunction<? super T> keyExtractor) {
				// TODO Auto-generated method stub
				return null;
			}

			public <T> Comparator<T> comparingLong(ToLongFunction<? super T> keyExtractor) {
				// TODO Auto-generated method stub
				return null;
			}

			public <T> Comparator<T> comparingDouble(ToDoubleFunction<? super T> keyExtractor) {
				// TODO Auto-generated method stub
				return null;
			}
		});
	}

	public static void compareListsRowSkip(List<String[]> sourceData, List<String[]> targetData, int skipRow) {

		ArrayList<String> mismatched;
		int minLen = sourceData.size() < targetData.size() ? sourceData.size() : targetData.size();
		int maxLen = sourceData.size() > targetData.size() ? sourceData.size() : targetData.size();
		boolean isSourceLarge = sourceData.size() > targetData.size() ? true : false;
		int i = 0;
		for (; i < minLen; i++) {

			String sourceRow = Arrays.toString(sourceData.get(i));
			String targetRow = Arrays.toString(targetData.get(i));
			if (sourceRow.length() > 0 && ((int) sourceRow.substring(1).charAt(0)) > 127) {
				String c = sourceRow.substring(1, 2);
				sourceRow = sourceRow.replace(c, "");// This is to replace the BOM character in source
				// sourceRow=sourceRow.substring(1);
			}
			if (targetRow.length() > 0 && ((int) targetRow.substring(1).charAt(0)) > 127) {
				String c = targetRow.substring(1, 2);
				targetRow = targetRow.replace(c, "");// This is to replace the BOM character in Target
				// targetRow=targetRow.substring(1);
			}
			if (i == skipRow) {
				logger.info("\n\nSkipping Row Number:" + skipRow);
				continue;
			}
			/*
			 * logger.info("source:"+sourceRow); logger.info("target:"+targetRow);
			 * logger.info("Target first char:"+(int)targetRow.substring(2).charAt(0));
			 * logger.info("Source first char:"+(int)sourceRow.substring(2).charAt(0));
			 */
			if (sourceRow.equals(targetRow)) {

			} else {
				mismatched = new ArrayList<String>();
				mismatched.add(sourceRow);
				mismatched.add(targetRow);
				mismatchedData.put(i, mismatched);
			}
		}
		String sourceRow = "[", targetRow = "[";
		for (int k = 0; k < sourceHeader.size() - 1; k++)
			sourceRow += ", ";
		sourceRow += "]";
		for (int k = 0; k < targetHeader.size() - 1; k++)
			targetRow += ", ";
		targetRow += "]";
		// String sourceRow="",targetRow="";
		for (; i < maxLen; i++) {
			mismatched = new ArrayList<String>();

			if (isSourceLarge) {
				sourceRow = Arrays.toString(sourceData.get(i));
				mismatched.add(sourceRow);
				mismatched.add(targetRow);
			} else {
				targetRow = Arrays.toString(targetData.get(i));
				mismatched.add(sourceRow);
				mismatched.add(targetRow);
			}
			mismatchedData.put(i, mismatched);
		}

	}

	public static boolean compareFilesRowSkip(String sourcePath, String targetPath, int rowSkip) throws Exception {
		int dotIndex = sourcePath.lastIndexOf(".");
		String ext = sourcePath.substring(dotIndex + 1);
		boolean isHeaderSame = true;
		boolean comparisonStatus = false;
		Reporter.setEscapeHtml(false);
		System.setProperty(ESCAPE_PROPERTY, "false");

		if (ext.equalsIgnoreCase("csv")) {

			mismatchedData = new HashMap<Integer, ArrayList<String>>();
			readCSVFiles(sourcePath, targetPath);
			isHeaderSame = compareHeaders();

			if (isHeaderSame) {
				compareListsRowSkip(sourceData, targetData, rowSkip);
				mismatchedData = new TreeMap<Integer, ArrayList<String>>(mismatchedData);
				generateOutput();
				if (mismatchedData.size() > 0)
					comparisonStatus = false;
				else
					comparisonStatus = true;
			} else {
				logger.info("<p>Header Mismatch<br/>Expected:" + sourceHeader + "<br/>Actual" + targetHeader + "</p>");
				comparisonStatus = false;
			}
		} else if (ext.equalsIgnoreCase("txt")) {
			mismatchedData = new HashMap<Integer, ArrayList<String>>();
			readTXTFiles(sourcePath, targetPath);
			isHeaderSame = compareHeaders();

			if (isHeaderSame) {
				compareLists(sourceData, targetData);
				mismatchedData = new TreeMap<Integer, ArrayList<String>>(mismatchedData);
				generateOutput();
				if (mismatchedData.size() > 0)
					comparisonStatus = false;
				else
					comparisonStatus = true;
			} else {
				logger.info("<p>Header Mismatch<br/>Expected:" + sourceHeader + "<br/>Actual" + targetHeader + "</p>");
				comparisonStatus = false;
			}
		} else {
			logger.info("This is not a CSV file");
			throw new Exception("This is not a csv file");
		}
		FileCompare.ignoreHeaders = null;
		FileCompare.sortOnColumn = null;
		return comparisonStatus;
	}

	public static boolean compareFilesTest(String sourcePath, String targetPath) throws Exception {
		int dotIndex = sourcePath.lastIndexOf(".");
		String ext = sourcePath.substring(dotIndex + 1);
		boolean isHeaderSame = true;
		boolean comparisonStatus = false;
		Reporter.setEscapeHtml(false);
		System.setProperty(ESCAPE_PROPERTY, "false");

		if (ext.equalsIgnoreCase("csv")) {

			mismatchedData = new HashMap<Integer, ArrayList<String>>();
			readCSVFilesTest(sourcePath, targetPath);
			isHeaderSame = compareHeaders();

			if (isHeaderSame) {
				compareLists(sourceData, targetData);
				mismatchedData = new TreeMap<Integer, ArrayList<String>>(mismatchedData);
				generateOutput();
				if (mismatchedData.size() > 0)
					comparisonStatus = false;
				else
					comparisonStatus = true;
			} else {
				logger.info("<p>Header Mismatch<br/>Expected:" + sourceHeader + "<br/>Actual" + targetHeader + "</p>");
				comparisonStatus = false;
			}
		} else if (ext.equalsIgnoreCase("txt")) {
			mismatchedData = new HashMap<Integer, ArrayList<String>>();
			readTXTFiles(sourcePath, targetPath);
			isHeaderSame = compareHeaders();

			if (isHeaderSame) {
				compareLists(sourceData, targetData);
				mismatchedData = new TreeMap<Integer, ArrayList<String>>(mismatchedData);
				generateOutput();
				if (mismatchedData.size() > 0)
					comparisonStatus = false;
				else
					comparisonStatus = true;
			} else {
				logger.info("<p>Header Mismatch<br/>Expected:" + sourceHeader + "<br/>Actual" + targetHeader + "</p>");
				comparisonStatus = false;
			}
		} else {
			logger.info("This is not a CSV file");
			throw new Exception("This is not a csv file");
		}
		FileCompare.ignoreHeaders = null;
		FileCompare.sortOnColumn = null;
		return comparisonStatus;
	}

	public static void readCSVFilesTest(String sourcePath, String targetPath) throws IOException, InterruptedException {

		CSVReader sourceReader = new CSVReader(
				new InputStreamReader(new FileInputStream(new File(sourcePath)), "UTF-8"));
		CSVReader targetReader = new CSVReader(
				new InputStreamReader(new FileInputStream(new File(targetPath)), "UTF-8"));
		sourceData = sourceReader.readAll();
		sourceReader.close();
		targetData = targetReader.readAll();
		targetReader.close();

		readHeaders();
		if (sortOnColumn != null) {
			String[] sortColArr = sortOnColumn.split(",");
			for (String columnName : sortColArr) {
				sortSourceData(getHeaderIndexTest(columnName));
				sortTargetData(getHeaderIndexTest(columnName));
			}
		}
		sourceData = encodeCommaAndIgnoreUnwantedHeaders(sourceData);
		targetData = encodeCommaAndIgnoreUnwantedHeaders(targetData);

	}

	private static int getHeaderIndexTest(String headerName) throws InterruptedException {
		for (int i = 0; i < sourceHeader.size(); i++) {
			if (sourceHeader.get(i).equalsIgnoreCase(headerName))
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
			return i;
		}
		return -1;

	}

	public static void sortByColumn(String targetPath) throws IOException, InterruptedException {
		List<String[]> records;
		int sortDirection = -1; // 1 for ASC, -1 for DESC
		try {
			logger.info("Path of file : " + targetPath);
			records = new ArrayList<String[]>();
			try (BufferedReader in = new BufferedReader(new FileReader(targetPath))) {
				String ln;
				while ((ln = in.readLine()) != null) {
					records.add(ln.split("\t"));
				}
			}

			Comparator<String[]> comp = new Comparator<String[]>() {
				public int compare(String[] a, String[] b) {
					// reverse result if DESC (sortDirection = -1)
					return sortDirection * a[0].compareTo(b[0]);
				}
			};
			Collections.sort(records, comp);

			try (BufferedWriter out = new BufferedWriter(new FileWriter(targetPath))) {
				for (String[] arr : records) {
					for (String s : arr) {
						out.write(s + "\n");
					}
				}
			}
			logger.info("Sorting Done Based on First Column");
		} catch (IOException e) {
			logger.info("File doesn't exist");
			logger.info(0);
		}
	}

	public static String getCellvalueXLSX(String filePath, int vRow, int vColumn) throws IOException {
		String value = null;
		logger.info("FIle path " + filePath);
		FileInputStream fis = new FileInputStream(filePath);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		Sheet sheet = wb.getSheetAt(0);
		Row row = sheet.getRow(vRow);
		Cell cell = row.getCell(vColumn);
		value = cell.getStringCellValue();
		return value;

	}

	public static String getCellvalueCSV(String csvFile, int vRow, int vColumn) throws IOException {
		String value = null;
		logger.info("FIle path " + csvFile);
		BufferedReader br = new BufferedReader(new FileReader(csvFile));
		String line;
		while ((line = br.readLine()) != null) {
			// use comma as separator
			String[] cols = line.split(",");
			System.out.println("Coulmn " + vColumn + " = " + cols[vColumn]);
			value = cols[vColumn];
		}
		return value;

	}

	/**
	 * This compares two xlsx file i.e actual and expected file
	 * 
	 * @param expectedFileLocation
	 * @param actualFileLocation
	 * @return
	 */
	public static boolean xlsxFileComparison(String expectedFileLocation, String actualFileLocation,
			int actualSheetIndex, int expectedSheetIndex) {
		boolean flag = false;
		try {
			File fielE = new File(expectedFileLocation);
			File fielA = new File(actualFileLocation);

			FileInputStream expectedFile = new FileInputStream(fielE);
			FileInputStream actualFile = new FileInputStream(fielA);
			List<String> actualFileHeaders = new ArrayList<String>();
			List<String> expectedFileHeaders = new ArrayList<String>();
			XSSFWorkbook wBookActual = new XSSFWorkbook(actualFile);
			XSSFWorkbook wBookExpected = new XSSFWorkbook(expectedFile);
			XSSFSheet sheetA = wBookActual.getSheetAt(actualSheetIndex);
			XSSFSheet sheetE = wBookExpected.getSheetAt(expectedSheetIndex);
			Iterator<Row> rowIteratorA = sheetA.iterator();
			while (rowIteratorA.hasNext()) {
				Row row = rowIteratorA.next();
				// For each row, iterate through all the columns
				Iterator<Cell> cellIterator = row.cellIterator();

				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					cell.getCellType();
					// Check the cell type and format accordingly
					switch (cell.getCellType()) {
					//Numeric Cell Type 0
					case 0:
						System.out.print(cell.getNumericCellValue());
						actualFileHeaders.add(String.valueOf(cell.getNumericCellValue()));
						break;
					//String Cell Type 1
					case 1:
						System.out.print(cell.getStringCellValue());
						actualFileHeaders.add(String.valueOf(cell.getStringCellValue()));
						break;
					}
				}
				System.out.println("");
				actualFile.close();
				fielA.delete();
				wBookActual.close();
			}
			Iterator<Row> rowIteratorE = sheetE.iterator();
			while (rowIteratorE.hasNext()) {
				Row row = rowIteratorE.next();
				// For each row, iterate through all the columns
				Iterator<Cell> cellIterator = row.cellIterator();
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					// Check the cell type and format accordingly
					switch (cell.getCellType()) {
					case 0:
						System.out.print(cell.getNumericCellValue() + " ");
						expectedFileHeaders.add(String.valueOf(cell.getNumericCellValue()));
						break;
					case 1:
						System.out.print(cell.getStringCellValue() + " ");
						expectedFileHeaders.add(String.valueOf(cell.getStringCellValue()));
						break;
					}
				}
				System.out.println("");
			}
			logger.info("expectedFileHeader::" + expectedFileHeaders);
			logger.info("actualFileHeaders::" + actualFileHeaders);
			flag = actualFileHeaders.equals(expectedFileHeaders);
			expectedFile.close();
			wBookExpected.close();

		} catch (Exception ioe) {
			ioe.printStackTrace();
		}
		return flag;
	}
}
