package com.xactly.xcommons.selenium;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;


import com.epam.reportportal.message.ReportPortalMessage;
import com.xactly.xcommons.app.LoginToApplication;


/**
 * @author Subham Kumar
 * @date created 18 April 2017
 * 
 * This listener class takes the screenshot at point of method failure and store it in workspace.
 * Screenshot name would be the combination of the Class name, Method name and time stamp of the failure. 
 */

public class ScreenshotListener extends TestListenerAdapter  {
public static Logger logger = Logger.getLogger(ScreenshotListener.class.getName());
	public void onTestFailure(ITestResult tr) {

		String m1 = tr.getMethod().getMethodName();
		String c1 = tr.getMethod().getTestClass().getName();
		String rp_message = "test message for ReportPortal";

		DateFormat dateFormat = new SimpleDateFormat("dd_MMM_yyyy_hh_mm_ssaa");
		String currentDate = dateFormat.format(new Date()) ;			

		String screenFileName = c1 + "." + m1 + "_" + currentDate + ".png" ;

		String destDir = "./target/ScreenshotsFailedTests";
		new File(destDir).mkdirs();
		File destFile = new File(destDir + "/" + screenFileName);
		logger.info("Business details :"+LoginToApplication.getUsername());
		WebDriver driver = SetWebDrivers.getDriver();
		File scrFile = null;
		try{
			scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);	
			String rp_file = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BASE64);
			logger.info("took screenshot #BASE64# for failed test: "+tr.getName());
            logger.info("RP_MESSAGE#BASE64#" + rp_file + "#MESSAGE_TEST");
            logger.info("Screenshot attached successfully");
			FileUtils.copyFile(scrFile, destFile);
		}catch(Exception uae){
			try {				
				BufferedImage screenFullImage = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
				ImageIO.write(screenFullImage, "png", destFile);
				//ReportPortalMessage message = new ReportPortalMessage(new File(destFile.getAbsolutePath()), rp_message);
				//logger.info(message);
				//logger.info("RP_MESSAGE#BASE64#BASE_64_REPRESENTATION#MESSAGE_TEST");

			} catch (IOException e) {				
				e.printStackTrace();
			} catch (AWTException e1){
				e1.printStackTrace();
			}		
		} 
	}


	public void onTestSuccess(ITestResult tr) {
		logger.info("Test Case Status"+tr.getName());

	}


}







