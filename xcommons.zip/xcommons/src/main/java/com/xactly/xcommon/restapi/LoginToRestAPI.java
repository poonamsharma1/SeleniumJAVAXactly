package com.xactly.xcommons.restapi;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONObject;
import org.testng.Reporter;
import org.testng.annotations.Optional;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import static org.hamcrest.Matchers.containsString;
import com.xactly.xcommons.selenium.Constants;
import org.apache.log4j.Logger;

public class LoginToRestAPI 
{
	public static Logger logger = Logger.getLogger(LoginToRestAPI.class.getName());
	public static Response loginresponse;
	public static Response analyticsLoginResponse;
	public static Response objectiveLoginResponse;
	public static Response obieeLoginResponse;
	public static String obiee_scid;
	public static String vusid;
	public static String vusidtemplate;
	public static String requestid;
	public static String grs;
	public static String _csrfToken;
	public static String incentjsessionid;
	public static String remoteaddress;
	public static String getGrs() {
		return grs;
	}

	public static void setIncentJsessionid(String incentjsessionid) {
		LoginToRestAPI.incentjsessionid = incentjsessionid;
	}
	
	public static String getIncentJsessionid() {
		return incentjsessionid;
	}
	
	public static void setRemoteAddress(String remoteaddress) {
		LoginToRestAPI.remoteaddress = remoteaddress;
	}
	
	public static String getIRemoteAddress() {
		return remoteaddress;
	}
	
	
	public static void setGrs(String grs) {
		LoginToRestAPI.grs = grs;
	}
	
	public static String get_csrfToken() {
		return _csrfToken;
	}

	public static void setcsrfToken(String csrfToken) {
		LoginToRestAPI._csrfToken = csrfToken;
	}
	
	public static String getRequestid() {
		return requestid;
	}

	public static void setRequestid(String requestid) {
		LoginToRestAPI.requestid = requestid;
	}
	public static String getVusidtemplate() {
		return vusidtemplate;
	}

	public static void setVusidtemplate(String vusidtemplate) {
		LoginToRestAPI.vusidtemplate = vusidtemplate;
	}

	public static String xbaseSessionId;
	public static String environmenttype;
	
	
	public static String getEnvironmenttype() {
		return environmenttype;
	} 

	public static void setEnvironmenttype(String environmenttype) {
		LoginToRestAPI.environmenttype = environmenttype;
	}

	public static String getXbaseSessionId() {
		return xbaseSessionId;
	}

	public static void setXbaseSessionId(String xbaseSessionId) {
		LoginToRestAPI.xbaseSessionId = xbaseSessionId;
	}

	public static String getVusid() {
		return vusid;
	}

	public static void setVusid(String vusid) {
		LoginToRestAPI.vusid = vusid;
	}


	public static Response getLoginresponse() {
		return loginresponse;
	}

	public static void setLoginresponse(Response loginresponse) {
		LoginToRestAPI.loginresponse = loginresponse;
	}

	public static String Username;

	public static String getUsername() {
		return Username;
	}

	public static void setUsername(String username) {
		Username = username;
	}

	public static String password;

	public static String getPassword() {
		return password;
	}

	public static void setPassword(String password) {
		LoginToRestAPI.password = password;
	}

	public static Response login(String propertypath) throws Exception 
	{	
			RestAPIHelperClass rest = new RestAPIHelperClass();
			rest.ApploginToIncent(propertypath);
		return loginresponse;

	}
	/**
	 * Login is a three step process in api
	 * 1 login with url:PreSetupRestAPI.grsBaseuri+"/xlsweb/login.do, params username/pwd
	 * 2 Url:loginRedirectUrl from the above response ,params:xLoginTicket,username, userLoggedIn,firstLoginRestToken
	 * 3 URL:base url from loginRedirectUrl+/xicm/appLoginInit.do  ,params:xLoginTicket,username, userLoggedIn,firstLoginRestToken
	 * 
	 * @param propertypath
	 * @return
	 * @throws Exception
	 */
	
	public static Response loginAdv(String propertypath) throws Exception
	{
		RestAPIHelperClass rest = new RestAPIHelperClass();
		
		String userdetails = PreSetupRestAPI.userProPath.getProperty(propertypath);
		String[] user = userdetails.split(":");
		LoginToRestAPI.setUsername(user[0]);
		LoginToRestAPI.setPassword(user[1]);
		logger.info("credentials ..... "+ user[0] +":"+ user[1]);
		Response respo = null;
		
		if(LoginToRestAPI.getGrs().equalsIgnoreCase("OFF"))
			respo = loginWithoutGRS(user[0], user[1]);
		else
			 respo = loginWithGRS(user[0],user[1]);
		
		LoginToRestAPI.setLoginresponse(respo);
		LoginToRestAPI.loginresponse = respo;
		setConstants();
		return loginresponse;

	}
	
	public static int mobileLoginIncentAPI(String environment, String username) throws Exception {
		RestAPIHelperClass rest = new RestAPIHelperClass();
		String path = environment + "/mobile/ssoServiceUrl?userName=" + username;
		int resp = rest.getRequestRedirectAPIResponse(path);
		return resp;
	}
	
	
	
	public static void setConstants()
	{
		if(Constants.environmentResourceBasePath.contains("@")){
			Constants.environmentResourceBasePath = Constants.environmentResourceBasePath.substring(0, Constants.environmentResourceBasePath.lastIndexOf("/"));
			Constants.environmentResourceBasePath = Constants.environmentResourceBasePath.substring(0, Constants.environmentResourceBasePath.lastIndexOf("/"))+"/";
		}
		Constants.environmentResouceFeaturePath = Constants.environmentResourceBasePath+"Feature/";
		Constants.environmentResourceBasePath = Constants.environmentResourceBasePath+LoginToRestAPI.getUsername()+"/";
	}
	
	public static Response loginAdv(String username, String password) throws Exception{
		RestAPIHelperClass rest = new RestAPIHelperClass();
		logger.info("credentials ..... "+ username +":"+ password);
		LoginToRestAPI.setUsername(username);
		LoginToRestAPI.setPassword(password);
		loginresponse = rest.ApploginToIncent(username, password);
		LoginToRestAPI.setLoginresponse(loginresponse);
		setConstants();
		
		return loginresponse;
		
	}
	
	public static String getCSRFToken()
	{
		String csrfTokenURL = Constants.envBaseUri + "/xicm/forward.do?url=/jsp/pages/csrf.jsp";
		logger.info("post url for getting CSRF token is :"+ csrfTokenURL);
		Response csrfTokenResponse = RestAssured.given()
				.relaxedHTTPSValidation()
				.formParam("xbaseSessionId", LoginToRestAPI.getXbaseSessionId())
				.when().post(csrfTokenURL);
		String csrfToken = csrfTokenResponse.asString();
		logger.info("CSRF token is valid for 15sec, and the CSRF Token is:"+ csrfToken);
		return csrfToken;
	}
	
	public static String getCSRFToken(Response loginResponse )
	{
		String xbaseSessionId = loginResponse.getCookie("xbaseSessionId");
		logger.info("xbaseSessionId to generate CSRF token is:"+ xbaseSessionId);
		String csrfTokenURL = Constants.envBaseUri + "/xicm/forward.do?url=/jsp/pages/csrf.jsp";
		logger.info("post url for getting CSRF token is :"+ csrfTokenURL);
		Response csrfTokenResponse = RestAssured.given()
				.relaxedHTTPSValidation()
				.formParam("xbaseSessionId", xbaseSessionId)
				.when().post(csrfTokenURL);
		String csrfToken = csrfTokenResponse.asString();
		logger.info("CSRF token is valid for 15sec, and the CSRF Token is:"+ csrfToken);
		return csrfToken;
	}
	
	public static Response loginWithoutGRS(String username, String password) throws Exception{
		logger.info("GRS OFF");
		String loginURL = Constants.envBaseUri + "/xlsweb/login.do";
		String loginExInitURL = Constants.envBaseUri + "/xicm/loginExInit.do";
		//String loginExInitURL = Constants.envBaseUri + "/xicm/login.do";

		// Bootes xtmcaenv URI property has a port in it, strip before logging in.
		if (loginURL.contains("xtmcaenv.xactlycorporation.local:10180")) {
			loginURL = loginURL.replace(":10180", "");
			loginExInitURL = loginExInitURL.replace(":10180", "");
		}
		if (loginURL.contains("https://qaintx.talarianweb.com/carest")) {
			loginURL = loginURL.replace("/carest", "");
			logger.info("checkQAINTX======");

			loginExInitURL = loginExInitURL.replace("/carest", "");
		}
	
		
		if (loginURL.contains("http://setdev01.xactlycorporation.local/carest")) {
			loginURL = loginURL.replace("/carest", "");
			logger.info("check-Setdev======"+loginURL);

			loginExInitURL = loginExInitURL.replace("/carest", "");
		}
		
		System.out.println("LOGIN EXINIT URL NOW: " + loginExInitURL);

		logger.info("user: "+username);
		logger.info("password: "+password);
		logger.info("LoginURL: "+loginURL);
		Response login = RestAssured.given()
						 .relaxedHTTPSValidation()
						 .formParam("password", password)
						 .formParam("userName", username)
						 .formParam("submit", "LOG IN")
						 .expect()
						 .response().header("Location", containsString("token")).when().post(loginURL);
		
		String loginEXURL = login.header("Location");
		
		
		Response loginEX = RestAssured.given()
							 .relaxedHTTPSValidation()
							 .cookies(login.cookies())
							 .expect()
							 .response().body(containsString("sessionId")).when().get(loginEXURL);
		
		String xbaseSessionId =  RestAPIHelperClass.getSubStringValues(loginEX.asString(), "\"xbaseSessionId\" value=\"", "\"");
		String sessionId = RestAPIHelperClass.getSubStringValues(loginEX.asString(), "\"sessionId\" value=\"", "\"");
		String remoteAddr = RestAPIHelperClass.getSubStringValues(loginEX.asString(), "\"remoteAddr\" value=\"", "\"");
		
		Response loginExInit = RestAssured.given()
								.relaxedHTTPSValidation()
								.formParam("remoteAddr", remoteAddr)
								.formParam("xbaseSessionId", xbaseSessionId)
								.formParam("userEmail", username)
								.formParam("sessionId", sessionId)
								.cookies(loginEX.cookies())
								.expect()
								.cookie("xbaseSessionId").when().post(loginExInitURL);
		LoginToRestAPI.setLoginresponse(loginExInit);
		LoginToRestAPI.loginresponse = loginExInit;
		
		LoginToRestAPI.setVusid(sessionId);
		LoginToRestAPI.setXbaseSessionId(xbaseSessionId);
		
		return loginExInit;
	}
	
	public static Response loginWithGRS(String username, String password) throws Exception{
		logger.info("GRS ON");

		
		String GRSLoginURL = PreSetupRestAPI.grsBaseuri + "/xlsweb/login.do?useLegacy=1";
		
		logger.info("User: "+ username);
		logger.info("password: "+ password);
		logger.info("LoginURL: " + GRSLoginURL);
		
		Response grsLogin = RestAssured.given()
							.relaxedHTTPSValidation()
							.formParam("userName", username)
							.expect()							
							.response().body(containsString("loginRedirectUrl")).when().post(GRSLoginURL);
		
		String loginRedirectUrl = getLoginRedirectUrl(grsLogin.asString());
		logger.info("loginRedirectUrl: " + loginRedirectUrl);
		
		Response login = RestAssured.given()
						 .relaxedHTTPSValidation()
						 .formParam("startPage", "")						
						 .formParam("user", username)
						 .cookies(grsLogin.cookies())
						 .expect()						
		                 .header("Set-Cookie", containsString("JSESSIONID")).when().post(loginRedirectUrl);
		
		Response login2 = RestAssured.given()
				 .relaxedHTTPSValidation()
				 .formParam("step", 2)
				 .formParam("userName", username)
				 .formParam("password", password)
				 .cookies(login.cookies())
				 .expect()
				 .header("Set-Cookie", containsString("JSESSIONID")).when().post(loginRedirectUrl);		
		
		
		String loginEXURL = login2.getHeader("Location");
		logger.info("login2 loginEXURL" +loginEXURL);
		
		Response loginEX = RestAssured.given()
						   .relaxedHTTPSValidation()
						   .cookies(login.cookies())
						   .cookies(login2.cookies())
						   .expect()
						   .response().body(containsString("xbaseSessionId")).when().get(loginEXURL);
		
		String xbaseSessionId =  RestAPIHelperClass.getSubStringValues(loginEX.asString(), "\"xbaseSessionId\" value=\"", "\"");
		String sessionId = RestAPIHelperClass.getSubStringValues(loginEX.asString(), "\"sessionId\" value=\"", "\"");
		String remoteAddr = RestAPIHelperClass.getSubStringValues(loginEX.asString(), "\"remoteAddr\" value=\"", "\"");
		
		String loginRedirectHost = getLoginRedirectHost(grsLogin.asString());
		
		Response loginEXInit = RestAssured.given()
							   .relaxedHTTPSValidation()
							   .formParam("remoteAddr", remoteAddr)
							   .formParam("userEmail", username)
							   .formParam("sessionId", sessionId)
							   .formParam("xbaseSessionId", xbaseSessionId)							  
							   .cookies(login.cookies())
							   .cookies(loginEX.cookies())
							   .expect()
							   .cookie("xbaseSessionId").when().post(loginRedirectHost+"/xicm/loginExInit.do");
		
		LoginToRestAPI.setLoginresponse(loginEXInit);
		LoginToRestAPI.loginresponse = loginEXInit;
		

		return loginEXInit;
	}

	
	public static String getLoginRedirectHost(String loginResponse) {
		try {
			Pattern pattern = Pattern.compile("name=\"loginRedirectUrl\" value=\"(.+?)/xlsweb/login.do\" />");
			Matcher matcher = pattern.matcher(loginResponse);
			matcher.find();
			logger.info("RedirectHost " + matcher.group(1));
			return matcher.group(1);

		} catch (Exception e) {

			return null;

		}
	}
	
	public Response login() throws Exception 
	{	
		if(getLoginresponse() == null || getLoginresponse().cookies().isEmpty()){
			RestAPIHelperClass rest = new RestAPIHelperClass();
			rest.ApploginToIncent();
		}
		
		return loginresponse;
	}
	
	public Response loginToModeling() throws Exception 
	{	
		logger.info("Logging into Incent : "+Constants.restAPIPath+"/auth/loginby");
		loginresponse = RestAssured.given()
				.relaxedHTTPSValidation()
				.formParam("username", LoginToRestAPI.getUsername())
				.formParam("password", LoginToRestAPI.getPassword())
				.expect()
				.statusCode(200).when().post(Constants.restAPIPath+"/auth/loginby");
		LoginToRestAPI.setLoginresponse(loginresponse);
		logger.info("Login response cookies :"+loginresponse.getCookies());
		logger.info("Response of login :"+loginresponse.body());
		return loginresponse;
		
	}

	public void logout() throws Exception 
	{	
		logger.info("Logging out of Incent : "+Constants.restAPIPath+"/auth/logout");		 
		logoutAdv(loginresponse);	  
		logger.info("Logged out of Incent "+loginresponse.body());
		
		
	}
	
	public static void logoutAdv(Response resp) throws Exception
	{
		logger.info("Logging out of Incent : "+Constants.envBaseUri+"/xicm/logout.async.do");
		loginresponse = RestAssured.given()
				.relaxedHTTPSValidation()
				.formParam("sessionId", resp.getCookie("requestid"))
				.formParam("loginType", "null")
				.expect()
				.statusCode(200).when().post(Constants.envBaseUri+"/xicm/logout.async.do");
		logger.info("Logged out of Incent "+loginresponse.body());
	}


	public static Response loginOBJ(String propertypath) throws Exception{
			RestAPIHelperClass rest = new RestAPIHelperClass();
			String userdetails = PreSetupRestAPI.userProPath.getProperty(propertypath);
			String[] user = userdetails.split(":");
			LoginToRestAPI.setUsername(user[0]);
			LoginToRestAPI.setPassword(user[1]);
			
			Response respo = null;
			
			respo = loginToOBJ(user[0], user[1]);
			return respo;
		
	}

	public static Response loginToOBJ(String username,String password ){
		String baseUri = PreSetupRestAPI.baseuri;
		System.out.println(baseUri);
		LoginToRestAPI.setUsername(username);
		LoginToRestAPI.setPassword(password);
		String resp = RestAssured.given()
				.formParam("login",LoginToRestAPI.getUsername())
				.formParam("password",LoginToRestAPI.getPassword())
				.formParam("loginAction","userpassword")	
				.expect()
				.statusCode(200).when().post(baseUri + "/xmbo/clientws/api/v1/auth/validateLogin").asString();
		//https://qaintx.talarianweb.com/xmbo/clientws/api/v1/auth/validateLogin
		System.out.println(resp);
		JSONObject jsonObj = new JSONObject(resp);
		//String email=jsonObj.getString("userEmail");
		String sessionId=jsonObj.getString("sessionId");
		String startUrl=jsonObj.getString("startUrl");
		String[] token = startUrl.split("=");
		String[] token2 = token[1].split("&");
		objectiveLoginResponse  = RestAssured.given()
				.queryParam("isStart", token[2])
				.queryParam("token", token2[0])
//				.formParam("userEmail",email)
				.formParam("sessionId",sessionId)

				.expect()
				.statusCode(301).when().post(startUrl);
		
		System.out.println(objectiveLoginResponse .getCookies().toString() );
		//return  analyticsLoginResponse.asString();
		LoginToRestAPI.setLoginresponse(objectiveLoginResponse);
		return  LoginToRestAPI.getLoginresponse();
	}
	
	public String loginToAnalytics11g(String username,String password ){
		String baseUri = PreSetupRestAPI.analyticsBaseUriCustom;
		logger.info(baseUri);
		LoginToRestAPI.setUsername(username);
		LoginToRestAPI.setPassword(password);
		String resp = RestAssured.given()
				.formParam("userEmail",LoginToRestAPI.getUsername())
				.formParam("password",LoginToRestAPI.getPassword())
				.formParam("loginAction","userpassword")	
				.expect()
				.statusCode(200).when().post(baseUri+"validateLogin.do").asString();
		logger.info(resp);
		JSONObject jsonObj = new JSONObject(resp);
		String email=jsonObj.getString("userEmail");
		String sessionId=jsonObj.getString("xticket");
		 analyticsLoginResponse  = RestAssured.given()
				.formParam("userEmail",email)
				.formParam("sessionId",sessionId)

				.expect()
				.statusCode(200).when().post(baseUri+"login.do");
		
		logger.info(analyticsLoginResponse .getCookies().toString() );
		return  analyticsLoginResponse.asString();
	}
	public String loginToAnalytics(String username,String password ){
		System.out.println("Login vk");
		String baseUri = PreSetupRestAPI.analyticsBaseUriCustom;
		//String baseUri ="http://obi12c-vanilla-new.xactlycorporation.local:9502";
		logger.info(baseUri);
		System.out.println(baseUri);
		LoginToRestAPI.setUsername(username);
		LoginToRestAPI.setPassword(password);
		Response response = RestAssured.given()
				.formParam("userEmail",LoginToRestAPI.getUsername())
				.formParam("password",LoginToRestAPI.getPassword())
				.formParam("loginAction","userpassword")	
				.expect()
				.statusCode(200).when().post(baseUri+"validateLogin.do");
		System.out.println("response"+response);
		String resp=response.asString();
		System.out.println(resp);
		
	
		logger.info(resp);
		JSONObject jsonObj = new JSONObject(resp);
		String email=jsonObj.getString("userEmail");
		String sessionId=jsonObj.getString("xticket");
		String StartUrl=jsonObj.getString("startUrl");
		
		
		Response loginEX = RestAssured.given()
				 .relaxedHTTPSValidation()
				 .cookies(response.cookies())
				 .expect()
				 .response().body(containsString("sessionId")).when().get(StartUrl);
		System.out.println("loginEX"+loginEX.asString());

String xbaseSessionId =  RestAPIHelperClass.getSubStringValues(loginEX.asString(), "\"xbaseSessionId\" value=\"", "\"");
String sessionId1 = RestAPIHelperClass.getSubStringValues(loginEX.asString(), "\"sessionId\" value=\"", "\"");
String remoteAddr = RestAPIHelperClass.getSubStringValues(loginEX.asString(), "\"remoteAddr\" value=\"", "\"");
String serverToken = RestAPIHelperClass.getSubStringValues(loginEX.asString(), "\"serverToken\" value=\"", "\"");
String isImpersonation = RestAPIHelperClass.getSubStringValues(loginEX.asString(), "\"isImpersonation\" value=\"", "\"");//NQServiceInstanceKey
String NQServiceInstanceKey = RestAPIHelperClass.getSubStringValues(loginEX.asString(), "\"NQServiceInstanceKey\" value=\"", "\"");

		 analyticsLoginResponse  = RestAssured.given()
				.formParam("userEmail",email)
				.formParam("sessionId",sessionId1)
				.formParam("serverToken", serverToken)
				.formParam("NQServiceInstanceKey", NQServiceInstanceKey)
				.formParam("xbaseSessionId", xbaseSessionId)
				.formParam("isImpersonation", isImpersonation)
				.expect()
				.statusCode(200).when().post(baseUri+"login.do");
		
		//logger.info(analyticsLoginResponse .getCookies().toString() );
		 System.out.println(analyticsLoginResponse .getCookies().toString());
		return  analyticsLoginResponse.asString();
	}
	
	public static String getNQPassword(HashMap<String, String> userDetails){//This method is added to handle the security fix rolled out in i2017-04
		String nqPassword="";
		RestAssured.requestSpecification= new RequestSpecBuilder().addHeader("User-Agent", "	Mozilla/5.0 (Windows NT 6.1; WOW64; rv:34.0) Gecko/20100101 Firefox/34.0").build();
		String path="analytics.do?Catalog&NQUser="
		+userDetails.get("email")
	//	+"&NQPassword="+userDetails.get("sessionId")
		+"&requestId=B6E1802F36D21D0757F41F8EDA4B838E"
		+"&IMPERSON_ID="+userDetails.get("impersonId")+"&PortalPath=/shared/Business%20Reports/_portal/dashboardBiz"+userDetails.get("businessId")+"&page=db&DB_INSTANCE=XBI_OLAP&EFF_DATE="+userDetails.get("effDate");
		path=PreSetupRestAPI.analyticsBaseUriCustom+path;	
		logger.info("Getting API for : " +path);	
		Map<String,String> cookies=new HashMap<String, String>();
		cookies.putAll(LoginToRestAPI.analyticsLoginResponse.getCookies());
		cookies.put("requestid", "B6E1802F36D21D0757F41F8EDA4B838E");
		  Response resp1 = RestAssured
				.given()
				.relaxedHTTPSValidation()
				.cookies(cookies)
				.when()
				.expect()
				.statusCode(200)
				.get(path);
		String resp=resp1.asString();
		int startIndexOfNQPassword=resp.indexOf("NQPassword\" value=\"") + ("NQPassword\" value=\"".length());
		nqPassword=resp.substring(startIndexOfNQPassword,resp.indexOf("\"/>", startIndexOfNQPassword));
		return nqPassword;
	}
	public static String loginToObiee(HashMap<String, String> userDetails)	
	{   
			userDetails.put("sessionId",getNQPassword(userDetails));
		RestAssured.requestSpecification= new RequestSpecBuilder().addHeader("User-Agent", "	Mozilla/5.0 (Windows NT 6.1; WOW64; rv:34.0) Gecko/20100101 Firefox/34.0").build();
		 String path="analytics.do?Catalog&NQUser="
		+userDetails.get("email")
		+"&NQPassword="+userDetails.get("sessionId")
		+"&IMPERSON_ID="+userDetails.get("impersonId")+"&PortalPath=/shared/Business%20Reports/_portal/dashboardBiz"+userDetails.get("businessId")+"&page=db&DB_INSTANCE=XBI_OLAP&EFF_DATE="+userDetails.get("effDate");
		path=PreSetupRestAPI.analyticsBaseUriObiee+path;	
		logger.info("Getting API for : " +path);	
		  obieeLoginResponse = RestAssured
				.given()
				.relaxedHTTPSValidation()
				.when()
				.expect()
				.statusCode(200)
				.get(path);
		 String resp=obieeLoginResponse.asString();
	//	logger.info("Obiee loginresp:"+resp);
		int startPos=resp.indexOf("obips_scid=\"")+"obips_scid=\"".length();
		String substring=resp.substring(startPos);
		String scidValue=substring.substring(0,substring.indexOf('\"'));		
		obiee_scid=scidValue;
		logger.info("The Response of the API : "+obieeLoginResponse.getCookies());
		//logger.info("The Response of the strbg : "+obieeLoginResponse.asString());
		return obieeLoginResponse.getCookies().toString();
	}

public static String getFormattedBearerToken(String token) {
    return String.format("Bearer %s", token);
}	

	
	
		/**
	 * from the html response of login retrieve value for xLoginTicket
	 * 
	 * @param loginResponse
	 * @return
	 */
	public static String getXLoginTicket(String loginResponse) {
		try {

		Pattern pattern = Pattern.compile("name=\"xLoginTicket\" value=\"(.+?)\" />");
		Matcher matcher = pattern.matcher(loginResponse);
		matcher.find();
		logger.info("getXLoginTicket" + matcher.group(1));

		return matcher.group(1);
		} catch (Exception e) {

			return null;

		}

	}

	/**
	 * from the html response of login retrieve value for loginRedirectUrl
	 * 
	 * @param loginResponse
	 * @return
	 */
	public static String getLoginRedirectUrl(String loginResponse) {
		try {
			Pattern pattern = Pattern.compile("name=\"loginRedirectUrl\" value=\"(.+?)\" />");
			Matcher matcher = pattern.matcher(loginResponse);
			matcher.find();
			logger.info("RedirectUrl " + matcher.group(1));
			return matcher.group(1);

		} catch (Exception e) {

			return null;

		}
	}

	public static Response loginAdmiUI(String propertypath, String URL) throws Exception
	{
		RestAPIHelperClass rest = new RestAPIHelperClass();
		rest.ApploginToComputeAdmin(propertypath,URL);
		return loginresponse;

	}
	public static Response loginComputeAdminui(String username, String password, String url) throws Exception{
		logger.info("GRS OFF");
		String loginURL = url + "/icxp/api/auth";
		logger.info("user: "+username);
		logger.info("password: "+password);
		logger.info("LoginURL: "+loginURL);
		Response login = RestAssured.given()
				.relaxedHTTPSValidation()
				.formParam("password", password)
				.formParam("userName", username)
				.formParam("submit", "LOG IN")
				.expect()
				.response().when().post(loginURL);

		return login;
	}
	
	
}
