package com.xactly.xcommons.selenium;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.Logger;
import java.io.File;

public class ExtractUpdateDataInPropertyFile {

	public static Logger logger = Logger.getLogger(ExtractUpdateDataInPropertyFile.class.getName());
//	public static Properties userData = new Properties();
	String directoryName = System.getProperty("user.dir");
	String propFile=directoryName+File.separator+"src/main/resources/Environment"+File.separator+"data"+File.separator+"automationData.properties";
	public String extractData(String variableName) throws Exception
	{
		Properties prop = new Properties();
		FileInputStream in = new FileInputStream(propFile);
		prop.load(in);
		String val=prop.getProperty(variableName);
		logger.info(variableName+": variable value in property file automationData : "+val);
		in.close();
		return val;
	}
	
    public void updateData(String variableName,String valueToBeUpdated) throws Exception
    {
    	// Read data from this file
    	PropertiesConfiguration properties = new PropertiesConfiguration(propFile);
    	properties.setProperty(variableName, valueToBeUpdated);
    	properties.save();
    }
}

