package com.xactly.xcommons.selenium;
import org.apache.log4j.Logger;

import java.io.*;
import java.net.URLDecoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.apache.commons.io.FileUtils;
import org.json.JSONObject;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;







import org.testng.Reporter;
import org.testng.asserts.SoftAssert;

import au.com.bytecode.opencsv.CSVReader;

import com.xactly.xcommons.app.LoginToApplication;
import com.xactly.xcommons.restapi.LoginToRestAPI;
import com.xactly.xcommons.restapi.PreSetupRestAPI;
import com.xactly.xcommons.restapi.RestAPIHelperClass;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;



public class AnalyticsHelperClass {
	public static Logger logger = Logger.getLogger(AnalyticsHelperClass.class.getName());
	public static int timeout=60;
	public static int pollingtime=3;
	public static Duration timeoutDur = Duration.between(Instant.now(), Instant.now().plusSeconds(60));
	public static Duration timeoutPolling = Duration.between(Instant.now(), Instant.now().plusSeconds(3));
	static RestAPIHelperClass rest=new RestAPIHelperClass();
	public static WebElement getUserLInk() throws Exception{
		return SeleniumHelperClass.findWebElementbyid("userName", "default");

	}
	public static WebElement getLogoutLInk() throws Exception{
		return SeleniumHelperClass.findWebElementbyid("logOutLnk", "default");

	}
	public static WebElement getswitchingDropdown() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath(".//*[@class='k-select']", "default");

	}
	public static List<WebElement> getAllItemsInDropdown() throws Exception{
		return SeleniumHelperClass.findWebElements(".//*[@role='option']", "default");

	}
	public  static WebElement getPreferenceTab() throws Exception{
		return (SeleniumHelperClass.findWebElementbyid("TAB_MIDDLE_SECURITY_TAB","topFrame"));

	}
	public static boolean isAnalytics(){

		return SeleniumHelperClass.isElementPresent("id", "TAB_MIDDLE_ADVANCED_ANALYTICS_DASHBOARDS_TAB", "default", 5);
	}
	public static void logout() throws Exception{
		getUserLInk().click();
		logger.info("Clicked on UserLink");
		Thread.sleep(5000);
		getLogoutLInk().click();
		logger.info("Clicked on logout link");
	}
	public static void switchToIncentFromAnalytics() throws Exception{
		SetWebDrivers.getDriver().switchTo().defaultContent();
		SeleniumHelperClass.findWebElementbyid("TAB_MIDDLE_ADVANCED_ANALYTICS_DASHBOARDS_TAB", "default");
		AnalyticsHelperClass.waitForPageLoad();
		SeleniumHelperClass.findWebElementbyid("TAB_MIDDLE_ADVANCED_ANALYTICS_DASHBOARDS_TAB", "default").click();
		Thread.sleep(7000);
		WebElement arrow=getswitchingDropdown();
		arrow.click();
		Thread.sleep(3000);
		List<WebElement> listOfItems=getAllItemsInDropdown();
		for(WebElement item:listOfItems){
			if(item.getText().equalsIgnoreCase("Incent")){
				logger.info("Found Incent app");
				item.click();
				break;
			}
		}

		getPreferenceTab().click();
	}
	public static void acceptAlert() {

		try {
			WebDriver driver=SetWebDrivers.getDriver();
			WebDriverWait wait11 = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait11.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			alert.accept();
		} catch (Exception e) {
			//logger.info("No alert");
		}

	}

	public static boolean isFileExist(String fileName){
		String filePath=Constants.downloadLoc+File.separator+fileName;
		File file=new File(filePath);
		logger.info(file.getAbsolutePath());
		if(file.exists())
			return true;
		else 
			return false;	
	}

	public static void waitForPageLoad() throws InterruptedException{
		Thread.sleep(5000);
		Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
				.withTimeout(timeoutDur)
				.pollingEvery(timeoutPolling)
				.ignoring(NoSuchElementException.class);
		//WebDriverWait wait=new WebDriverWait(SetWebDrivers.getDriver(), timeout);
		wait.until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				try {
					if(!SeleniumHelperClass.findWebElementbyCssSelector("span.loading","default").isDisplayed())		{
						return true;

					}
					else 
						return false;
				} catch (Exception e) {
					// TODO Auto-generated catch block
					return true;
					//e.printStackTrace();
				}


				//				while(true){
				//					try {
				//						logger.info("Page is loading ..");
				//					
				//						if(!SeleniumHelperClass.findWebElementbyCssSelector("span.loading","default").isDisplayed())		{
				//							logger.info("Page loader not found");
				//							break;
				//						}
				//						logger.info("Found loader image ...Page is loading ..");
				//						Thread.sleep(3000);
				//						//			log.info("Waiting to Complete the page loading");
				//					} catch (Exception e) {
				//						// TODO Auto-generated catch block
				//						logger.info("..Page loader not found");
				//						//e.printStackTrace();
				//					}
				//
				//				}
				//				return true;
			}

			public <V> Function<V, Boolean> compose(
					Function<? super V, ? extends WebDriver> before) {
				// TODO Auto-generated method stub
				return null;
			}

			public <V> Function<WebDriver, V> andThen(
					Function<? super Boolean, ? extends V> after) {
				// TODO Auto-generated method stub
				return null;
			}

			public  <T> Function<T, T> identity() {
				// TODO Auto-generated method stub
				return null;
			}

		});

	}

	public static boolean waitForSearchImg() throws Exception{
		Thread.sleep(1000);
		boolean existForLongTime=false;
		int time=0;
		/*Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
				.withTimeout(timeout, TimeUnit.SECONDS)
				.pollingEvery(pollingtime, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);

		wait.until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				boolean stat=false;int time=0;
				try{
		 */
		while(SeleniumHelperClass.isElementPresent("css",".SrchImg", "none",2)&&time<timeout)
		{
			//logger.info("inside while");
			Thread.sleep(2000);
			time+=2;

			//else
			//		log.info("Searching.....Waiting to complete the page loading");
		}
		if(time>=timeout)
			existForLongTime=true;
		/*			return true;
				}catch(Exception e){}
				return true;
			}		
		});*/
		return existForLongTime;
	}
	public static boolean verifyStringInFile(String text, String filepath) throws IOException {
		String ext = filepath.substring(filepath.lastIndexOf(".") + 1);
		File path = new File(filepath);

		BufferedReader br = null;
		if (ext.equalsIgnoreCase("csv")||ext.equalsIgnoreCase("txt")) {
			try {
				br = new BufferedReader(new InputStreamReader(new FileInputStream(path)));
			} catch (FileNotFoundException ex) {
				throw new FileNotFoundException(ex.toString());
			}
			String s =null;
			while ((s = br.readLine()) != null) {
				logger.info(s);
				if (s.contains(text)) {
					logger.info("found "+text+"in the line "+s);
					return true;
				}

			}

		}
		return false;
	}
	public static void takeScreenshot(String testcaseName){

		final String ESCAPE_PROPERTY = "org.uncommons.reportng.escape-output";
		WebDriver driver = SetWebDrivers.getDriver();
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		DateFormat dateFormat = new SimpleDateFormat("dd_MMM_yyyy__hh_mm_ssaa");
		String destDir = Constants.downloadLoc;

		new File(destDir).mkdirs();
		String destFile = dateFormat.format(new Date()) + ".png";

		String loc=destDir + File.separator + testcaseName.replaceAll(" ","_")+"__"+destFile;
		logger.info("dest:"+loc);
		try {
			FileUtils.copyFile(scrFile, new File(loc));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Reporter.setEscapeHtml(false);

		System.setProperty(ESCAPE_PROPERTY, "false");
		//	logger.info("Saved Screenshot  ------");
		//	logger.info("<a href=\""+loc+"\"> Clickhere </a>");
		logger.info("<a href=\""+loc+"\" ><img alt=\"unable to show screenshot\" src=\""+loc+"\"/></a>");
	}

	public static void compareCSV(File sourceFile,File targetFile) throws Exception{
		CSVReader sourceReader=null,targetReader=null;
		
		sourceReader = new CSVReader(new InputStreamReader(new FileInputStream(sourceFile), "UTF-8"));
		targetReader= new CSVReader(new InputStreamReader(new FileInputStream(targetFile), "UTF-8"));
		List<String[]> sourceData = sourceReader.readAll();
		List<String[]> targetData = targetReader.readAll();

		compareCSVData(sourceData, targetData);
		compareCSVData(targetData,sourceData);
		sourceReader.close();
		targetReader.close();
		
		
	}
	public static void compareCSVData( List<String[]> sourceData,List<String[]> targetData){
		Map<String, Integer> sourceMap = new HashMap<String, Integer>();
		// int rowIndex=0;
		logger.info("started");
		for (int i = 0; i < sourceData.size(); i++) {
			String[] row = sourceData.get(i);
			if (sourceMap.containsKey(Arrays.toString(row))) {
				sourceMap.put(Arrays.toString(row), sourceMap.get(Arrays.toString(row)) + 1);
			} else {
				sourceMap.put(Arrays.toString(row), 1);
			}
			// logger.info(Arrays.toString(row));
		}
		logger.info(sourceMap);
		for (int i = 0; i < targetData.size(); i++) {
			String[] row = targetData.get(i);
			String currentRow = Arrays.toString(row);
			if (sourceMap.containsKey(currentRow)) {
				int index = sourceMap.get(currentRow) - 1;
				if (index == 0) {
					sourceMap.remove(currentRow);
				} else {
					sourceMap.put(currentRow, index);
				}
				logger.info("Found row in source:"+currentRow);
			} 

		}
		logger.info("Extra rows:"+sourceMap);
		logger.info("-----------------------");
		
	}
	public static HashMap<String,String> getSessionCredentials(String resp){
		HashMap<String,String> map=new HashMap<String,String>();
		String[] respArray=resp.split("</");
		ArrayList<String> ar=new ArrayList<String>();
		String properties="";
		for(String resp1:respArray)
			if(resp1.contains("<input type=\"hidden\" name="))
				properties=resp1;
		String[] propertiesArray=properties.split("<");

		for(String row:propertiesArray){
			if(row.contains("NQUser"))
				try {
					map.put("email",URLDecoder.decode(row.substring(row.lastIndexOf("=")+2,row.lastIndexOf("\"")), "UTF-8"));
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			if(row.contains("NQPassword"))
				map.put("sessionId",row.substring(row.lastIndexOf("=")+2, row.lastIndexOf("\"")));
			if(row.contains("ImpersonId"))
				map.put("impersonId",row.substring(row.lastIndexOf("=")+2, row.lastIndexOf("\"")));
			if(row.contains("businessId"))
				map.put("businessId",row.substring(row.lastIndexOf("=")+2, row.lastIndexOf("\"")));
			if(row.contains("dateFormat"))
				map.put("dateFormat",row.substring(row.lastIndexOf("=")+2, row.lastIndexOf("\"")));
			if(row.contains("timeZone"))
				map.put("timeZone",row.substring(row.lastIndexOf("=")+2, row.lastIndexOf("\"")));
		}
		map.put("effDate", AnalyticsHelperClass.getEffDate());
		return map;

	}
	public static String getEffDate(){

		String resp= rest.postRestAPIAnalytics("loadCalendarInfo.ajax.do", "appName=web&isValidated=false-FAILURE");
		// logger.info(resp);
		JSONObject jsonObj = new JSONObject(resp);
		JSONObject periodJson=jsonObj.getJSONObject("period");
		String effDate=periodJson.getString("startDateStr");
		return effDate;
	}
	public static String loginToRestAPIUsingProperty(String prop){
		LoginToRestAPI rest1=new LoginToRestAPI();
		String userdetails = PreSetupRestAPI.userProPath.getProperty(prop);	
		String[] user = userdetails.split(":");
		logger.info("username"+user[0]);
		String resp=rest1.loginToAnalytics(user[0],user[1]);

		return resp;
	}
	public static String loginToRestAPI(String username,String password){
		LoginToRestAPI rest1=new LoginToRestAPI();
		//logger.info(username);
		//logger.info(password);
		String resp=rest1.loginToAnalytics(username,password);

		return resp;
	}
	public static void main(String arg[]) throws Exception{

		//takeScreenshot(testcaseName);
	}
	public static File getLatestFilefromDir(String dirPath) throws InterruptedException {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*2);
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			return null;
		}

		File lastModifiedFile = files[0];
		for (int i = 1; i < files.length; i++) {
			if (lastModifiedFile.lastModified() < files[i].lastModified()) {
				lastModifiedFile = files[i];
			}
		}
		logger.info("lastModifiedFile: "+lastModifiedFile);
		return lastModifiedFile;
		}

}
