package com.xactly.xcommons.selenium;
 
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.ToDoubleFunction;
import java.util.function.ToIntFunction;
import java.util.function.ToLongFunction;

import org.testng.IMethodInstance;
import org.testng.IMethodInterceptor;
import org.testng.ITestContext;

import com.xactly.xcommons.selenium.Priority;

public class PriorityInterceptor implements IMethodInterceptor  {

    public List<IMethodInstance> intercept(List<IMethodInstance> methods, ITestContext context) {
      Comparator<IMethodInstance> comparator = new Comparator<IMethodInstance>() {
        
        private int getPriority(IMethodInstance mi) {
          int result = 0;
          @SuppressWarnings("deprecation")
		
          int a1 = mi.getMethod().getPriority();
           
          if (a1 != 0) {
            result = a1;
          } else {
            Class<?> cls = mi.getClass();
            Priority classPriority = (Priority) cls.getAnnotation(Priority.class);
            if (classPriority != null) {
              result = classPriority.value();
            }
          }
          return result;
        }

        public int compare(IMethodInstance m1, IMethodInstance m2) {
          return getPriority(m1) - getPriority(m2);
        }

		public Comparator<IMethodInstance> reversed() {
			// TODO Auto-generated method stub
			return null;
		}

		public Comparator<IMethodInstance> thenComparing(
				Comparator<? super IMethodInstance> other) {
			// TODO Auto-generated method stub
			return null;
		}

		public <U> Comparator<IMethodInstance> thenComparing(
				Function<? super IMethodInstance, ? extends U> keyExtractor,
				Comparator<? super U> keyComparator) {
			// TODO Auto-generated method stub
			return null;
		}

		public <U extends Comparable<? super U>> Comparator<IMethodInstance> thenComparing(
				Function<? super IMethodInstance, ? extends U> keyExtractor) {
			// TODO Auto-generated method stub
			return null;
		}

		public Comparator<IMethodInstance> thenComparingInt(
				ToIntFunction<? super IMethodInstance> keyExtractor) {
			// TODO Auto-generated method stub
			return null;
		}

		public Comparator<IMethodInstance> thenComparingLong(
				ToLongFunction<? super IMethodInstance> keyExtractor) {
			// TODO Auto-generated method stub
			return null;
		}

		public Comparator<IMethodInstance> thenComparingDouble(
				ToDoubleFunction<? super IMethodInstance> keyExtractor) {
			// TODO Auto-generated method stub
			return null;
		}

		public  <T extends Comparable<? super T>> Comparator<T> reverseOrder() {
			// TODO Auto-generated method stub
			return null;
		}

		public  <T extends Comparable<? super T>> Comparator<T> naturalOrder() {
			// TODO Auto-generated method stub
			return null;
		}

		public  <T> Comparator<T> nullsFirst(
				Comparator<? super T> comparator) {
			// TODO Auto-generated method stub
			return null;
		}

		public  <T> Comparator<T> nullsLast(
				Comparator<? super T> comparator) {
			// TODO Auto-generated method stub
			return null;
		}

		public  <T, U> Comparator<T> comparing(
				Function<? super T, ? extends U> keyExtractor,
				Comparator<? super U> keyComparator) {
			// TODO Auto-generated method stub
			return null;
		}

		public  <T, U extends Comparable<? super U>> Comparator<T> comparing(
				Function<? super T, ? extends U> keyExtractor) {
			// TODO Auto-generated method stub
			return null;
		}

		public  <T> Comparator<T> comparingInt(
				ToIntFunction<? super T> keyExtractor) {
			// TODO Auto-generated method stub
			return null;
		}

		public  <T> Comparator<T> comparingLong(
				ToLongFunction<? super T> keyExtractor) {
			// TODO Auto-generated method stub
			return null;
		}

		public  <T> Comparator<T> comparingDouble(
				ToDoubleFunction<? super T> keyExtractor) {
			// TODO Auto-generated method stub
			return null;
		}
        
      };
      IMethodInstance[] array = methods.toArray(new IMethodInstance[methods.size()]);
      Arrays.sort(array, comparator);
      return Arrays.asList(array);
    }

  }

