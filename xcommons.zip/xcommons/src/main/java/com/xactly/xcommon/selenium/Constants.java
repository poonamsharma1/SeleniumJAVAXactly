package com.xactly.xcommons.selenium;

public class Constants {

	public static String uniqueId;
	public static String downloadLoc;
	public static String restAPIPath;
	public static String envBaseUri;
	public static String environmentResourceBasePath;
	public static String environmentResouceFeaturePath;
	public static final String ENVIRONMENT_RESOURCE_BASEPATH = "src/main/resources/Environment/";
	public static final String COMMISSION_RATE_CONFIG = "Commission_Rate";
	public static final String BONUS_CONFIG = "Bonus";
	public static final String DRAWS_CONFIG = "Draw";
	public static final String QUOTA_CONFIG = "Quota";
	public static final String COMMISSION_RATE_CONFIG_PREVIEW = "Commission Rates";
	public static final String BONUS_CONFIG_PREVIEW = "Bonuses";
	public static final String DRAWS_CONFIG_PREVIEW = "Draws";
	public static final String ACCEPT_ROUTE_DOC = "I Accept";
	public static final String DECLINE_ROUTE_DOC = "I Decline";
	
	public static final String INCENT = "Incent";
	public static final String ANALYTICS = "AnalyticsR9";
	public static final String ANALYTICS_BETA = "Analytics12c";
	public static final String CREDIT_ASSIGNMENTS = "Credit Assignment";
	public static final String INSIGHTS = "Insights";
	public static final String MODELING = "Modeling";
	public static final String OBJECTIVE = "Objectives";
	public static final String QUOTA = "Quota";
	public static final String CONNECT = "Connect";
	public static final String CEA = "CEA";
	public static final String BENCHMARKING = "Benchmarking";
	public static final String FORMS = "Forms";


	/*
	 * Locators
	 */
	public static final String LOCATOR_XPATH = "xpath";
	public static final String LOCATOR_CSS = "css";
	public static final String LOCATOR_ID = "id";
	public static final String LOCATOR_NAME = "name";
	public static final String LOCATOR_LINKTEXT = "linktext";
	public static final String LOCATOR_PARTIAL_LINKTEXT = "partial_linktext";
	public static final String LOCATOR_CLASSNAME = "classname";
	public static final String LOCATOR_TAGNAME = "tagname";
	
}
