package com.xactly.xcommons.javahelper;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TracingPrintStream extends PrintStream 
{
  public TracingPrintStream(PrintStream original) {
    super(original);
  }
  @Override
  public void println(String line) {
    StackTraceElement[] stack = Thread.currentThread().getStackTrace();
    DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    Date date = new Date();
    // Element 0 is getStackTrace
    // Element 1 is println
    // Element 2 is the caller
    StackTraceElement caller = stack[2];
    super.println(sdf.format(date) + " : " +" INFO: " + " : " +caller.getClassName() + " : " + line);
  }
}


