package com.xactly.xcommons.restapi;

import org.apache.log4j.Logger;
import org.testng.Reporter;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.xactly.xcommons.app.LoginToApplication;

public class QuotaRestAPIHelperClass {
	public static Logger logger = Logger.getLogger(QuotaRestAPIHelperClass.class.getName());
	
	public Response ApploginToQuota(Response resp, String adminUserName) throws Exception {
		
		Response respo = RestAssured.given().relaxedHTTPSValidation().cookies(resp.getCookies())
				.formParam("action", "getIncentSession")
				.formParam("targetApp", "Xactly Quota Management")
				.expect().statusCode(200).when()
				.post(LoginToApplication.getRestAssuredBaseURI() + "/xicm/misc.ajax.do");
		
		Response respogotoAnother = RestAssured.given().relaxedHTTPSValidation().cookies(resp.getCookies())
				.formParam("from_hidden", "1")
				.formParam("incentSessionInfo", respo.asString())
				.formParam("targetApp", "Xactly Quota Management")
				.formParam("customApp", "false")
				.formParam("vusid", respo.getCookie("requestid"))
				.expect()
				//.statusCode(200).when()
				.post(LoginToApplication.getRestAssuredBaseURI() + "/xicm/gotoAnotherApp.do");
		
		String[] loadMetaDataUrl = respo.getBody().asString().split("\\|");
		logger.info("reqUrl: "+ loadMetaDataUrl[0]);
		
		Response startApp = RestAssured.given().relaxedHTTPSValidation().cookies(resp.getCookies())
				.formParam("from_hidden", "1")
				.formParam("incentSessionInfo", respo.asString())
				.formParam("targetApp", "Xactly Quota Management")
				.formParam("customApp", "false")
				.formParam("sessionId", loadMetaDataUrl[0])
				.formParam("remoteAddr", "10.250.85.44")
				.formParam("actionId", "null")
				.formParam("userEmail", adminUserName)
				.formParam("vusid", respo.getCookie("requestid"))
				.expect().statusCode(302).when()
				.post(LoginToApplication.getRestAssuredBaseURI() + "/xquota/xquotaws/api/xbase/startApp");


		return startApp;
	}

	public  String postRestAPI(String path, String rbody) {
		Reporter.log("Posting API for : " + RestAssured.baseURI + path, 2, true);
		String resp = RestAssured.given().relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.loginresponse.getCookies())
				.log().all()
				.contentType(ContentType.JSON)
				.body(rbody).when().expect().statusCode(200).post(RestAssured.baseURI+ path).asString();
		return resp;
	}
	
	public  Response postRestAPI(String path, String rbody,Response response) {
		logger.info("cookies"+response.getCookies());
		Reporter.log("Posting API for : " + RestAssured.baseURI + path, 2, true);
		Response resp = RestAssured.given().relaxedHTTPSValidation()
				.cookies(response.getCookies())
				.log().all()
				.contentType(ContentType.JSON)
				.body(rbody).when().expect().statusCode(200).post(RestAssured.baseURI+ path);
		return resp;
	}
	
	public  String getRestAPI(String path) {
		Reporter.log("Getting API for : " + RestAssured.baseURI + path, 2, true);
		logger.info(RestAssured.baseURI + path);
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.when().expect().statusCode(200).get(RestAssured.baseURI + path).asString();
		return resp;
	}

	public  Response getRestAPI(String path,Response response) {
		Reporter.log("Getting API for : " + RestAssured.baseURI + path, 2, true);
		logger.info(RestAssured.baseURI + path);
		Response resp = RestAssured.given().relaxedHTTPSValidation().cookies(response.getCookies())
				.when().expect().statusCode(200).get(RestAssured.baseURI + path);
		
		return resp;
	}

	public Response deleteRestAPI(String path, Response response) {
		Reporter.log("Getting API for : " + RestAssured.baseURI + path, 2, true);
		logger.info(RestAssured.baseURI + path);
		Response resp = RestAssured.given().relaxedHTTPSValidation().cookies(response.getCookies())
				.when().expect().statusCode(200).delete(RestAssured.baseURI + path);
		return resp;
	}
}