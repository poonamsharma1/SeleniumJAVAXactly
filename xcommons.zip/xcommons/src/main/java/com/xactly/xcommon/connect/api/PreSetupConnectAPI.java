package com.xactly.xcommons.connectapi;

import java.io.File;
import java.io.InputStream;
import java.util.Properties;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.jayway.restassured.RestAssured;
import org.apache.log4j.Logger;

public class PreSetupConnectAPI {
	
	public static InputStream systemPropertyInputStream;
	public static InputStream systemUserPropertyInputStream;
	public static String baseuri;
	public static Logger logger = Logger.getLogger(PreSetupConnectAPI.class.getName());
	
	
	public static InputStream getSystemUserPropertyInputStream() {
		return systemUserPropertyInputStream;
	}
	public static void setSystemUserPropertyInputStream(
			InputStream systemUserPropertyInputStream) {
		PreSetupConnectAPI.systemUserPropertyInputStream = systemUserPropertyInputStream;
	}
	public static Properties symProPath = new Properties();
	public static Properties userProPath = new Properties();
	
	public static InputStream getSystemPropertyInputStream() {
		return systemPropertyInputStream;
	}
	public static void setSystemPropertyInputStream(
			InputStream systemPropertyInputStream) {
		PreSetupConnectAPI.systemPropertyInputStream = systemPropertyInputStream;
	}
	@BeforeSuite(alwaysRun = true)	
	@Parameters({"application","environment"})
	public void preSetUp(@Optional String application,@Optional String environment) throws Exception 
	{	
		logger.info("Running Before Suite Setup ");
		String propFile="environment"+File.separator+environment+File.separator+environment+".properties";
		String userpropFile="environment"+File.separator+environment+File.separator+environment+"_api_users.properties";
		logger.info("propFile: "+propFile);
		logger.info("userpropFile :"+userpropFile);
		setSystemPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(propFile));
		setSystemUserPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(userpropFile));
		
		symProPath.load(PreSetupConnectAPI.getSystemPropertyInputStream());
		userProPath.load(PreSetupConnectAPI.getSystemUserPropertyInputStream());

		baseuri = PreSetupConnectAPI.symProPath.getProperty("RestAssured.baseURI");	
		
		

	}
	@AfterSuite(alwaysRun = true)	
	@Parameters("application")
	public void terminate(String application) throws Exception
	{
		//TODO : Need to get a logout feature

	}


}
