package com.xactly.xcommons.javahelper;

import javax.mail.*;
import javax.mail.search.AndTerm;
import javax.mail.search.ComparisonTerm;
import javax.mail.search.RecipientStringTerm;
import javax.mail.search.SearchTerm;
import javax.mail.search.SentDateTerm;
import javax.mail.search.SubjectTerm;
import org.apache.log4j.Logger;

import com.xactly.xcommons.restapi.RestAPIHelperClass;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class EmailParser {

	public static Logger logger = Logger.getLogger(EmailParser.class.getName());

	RestAPIHelperClass rest = new RestAPIHelperClass();

	public static Date subtractDays(Date date, int days) {
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(date);
		cal.add(Calendar.DATE, -days);

		return cal.getTime();
	}


	private Message getEmail(String subjectToBeSearched, String recipientEmailId) throws Exception {
		Properties props = new Properties();

		/*
		 * props.setProperty("mail.store.protocol", "imaps");
		 *
		 * props.setProperty("mail.imaps.ssl.trust", "*");
		 *
		 * props.setProperty("mail.host", "imap.gmail.com");
		 * props.setProperty("mail.port", "995");
		 * props.setProperty("mail.transport.protocol", "imaps");
		 *
		 * Session session = Session.getDefaultInstance(props, null); Store
		 * store = session.getStore("imaps"); System.out.println(
		 * "connecting ..."); store.connect("imap.gmail.com", emailID,
		 * password);
		 */

		String host = "10.250.40.93";
		String emailID = "qauser";
		String password = "demoUser1";

		Properties properties = System.getProperties();
		properties.setProperty("mail.port", "110");
		Session session = Session.getDefaultInstance(properties);
		Store store = session.getStore("pop3");
		store.connect(host, emailID, password);

		Folder folder = store.getFolder("INBOX");
		folder.open(Folder.READ_WRITE);


		Message[] messages = null;
		boolean mailFound = false;
		Message email = null;

		for (int i = 0; i < 10; i++)
		{
			logger.info("Total Number of messages in the INBOX folder ... " + folder.getMessageCount());

			Calendar cal = new GregorianCalendar();
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date rightNow = new Date();
			Date past = new Date();
			past.setHours(rightNow.getHours() - 8);

			SearchTerm olderThan = new SentDateTerm(ComparisonTerm.LE, rightNow);
			SearchTerm newerThan = new SentDateTerm(ComparisonTerm.GE, past);


			messages = folder.search(new AndTerm(newerThan, olderThan), folder.getMessages());
			messages = folder.search(new SubjectTerm(subjectToBeSearched), messages);
			messages = folder.search(new RecipientStringTerm(Message.RecipientType.TO, recipientEmailId), messages);


			logger.info(" Total Number of messages matching the search criteria ... " + messages.length);

			if (messages.length == 0) {
				logger.info(" No messages found, waiting for 10 secs ... ");
				Thread.sleep(10000);
			} else {

				break;
			}
		}

		if (messages.length > 1){
			for (int i = 0; i < messages.length-1; i ++) {
				logger.info("i "+ messages[i].getSentDate());
				logger.info("i+1 "+ messages[i+1].getSentDate());

				if (i == 0){
					int diffDate = messages[i+1].getSentDate().compareTo(messages[i].getSentDate());
					if (diffDate > 0){
						email = messages[i+1];
						mailFound = true;
					}
					else{
						email = messages[i];
						mailFound = true;
					}
				}else{
					int diffDate = messages[i+1].getSentDate().compareTo(email.getSentDate());
					if (diffDate > 0){
						email = messages[i+1];
						mailFound = true;
					}
				}
				logger.info("Required email timestamp: "+ email.getSentDate());
			}
		}else{
			email = messages[0];
			mailFound = true;
		}

		if (!mailFound) {
			throw new Exception("Could not find Email.. ");
		}

		//folder.close(true);
		//store.close();
		return email;
	}

	public String followEmailLink(String emailSubject, String recipientEmailId, String searchStartPattern, String searchEndPattern) throws Exception {
		int count = 0;
		Message email;
		Object contents;
		String requiredText = "";

		boolean emailFound = false;

		while (!emailFound && count < 20) {
			try {
				email = getEmail(emailSubject, recipientEmailId);
				contents = email.getContent().toString();
				logger.info("email content ... " + contents);

				requiredText = rest.getSubStringValues(contents.toString(), searchStartPattern, searchEndPattern).replace("&amp;", "&");

				emailFound = true;
			} catch (Exception e) {
				Thread.sleep(10000);
				System.out.println("exception: " + e);
				emailFound = false;
				count++;
			}
		}

		logger.info("Required text ... " + requiredText);
		return requiredText;
	}


	public Boolean findEmailPresence(String subjectToBeSearched, String recipientEmailId) throws Exception {
		Properties props = new Properties();


		String host = "10.250.40.93";
		String emailID = "qauser";
		String password = "demoUser1";

		Properties properties = System.getProperties();
		properties.setProperty("mail.port", "110");
		Session session = Session.getDefaultInstance(properties);
		Store store = session.getStore("pop3");
		store.connect(host, emailID, password);

		Folder folder = store.getFolder("INBOX");
		folder.open(Folder.READ_WRITE);


		Message[] messages = null;
		boolean mailFound = false;
		Message email = null;
		try {
			for (int i = 0; i < 30; i++) {
				logger.info("Total Number of messages in the INBOX folder ... " + folder.getMessageCount());

				Calendar cal = new GregorianCalendar();
				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				Date rightNow = new Date();
				Date past = new Date();
				past.setHours(rightNow.getHours() - 8);

				SearchTerm olderThan = new SentDateTerm(ComparisonTerm.LE, rightNow);
				SearchTerm newerThan = new SentDateTerm(ComparisonTerm.GE, past);


				messages = folder.search(new AndTerm(newerThan, olderThan), folder.getMessages());
				logger.info("Total recent messages found.." + messages.length);
				messages = folder.search(new SubjectTerm(subjectToBeSearched), messages);
				logger.info("Total  messages found with subject search .." + messages.length);
				messages = folder.search(new RecipientStringTerm(Message.RecipientType.TO, recipientEmailId), messages);
				logger.info("Total  messages found with subject & To Receipient search .." + messages.length);

				logger.info(" Total Number of messages matching the search criteria ... " + messages.length);

				if (messages.length == 0) {
					mailFound = false;

				} else {
					mailFound = true;
					logger.info("mail found , breaking the loop, number of messages found.." + messages.length);
					break;
				}
			}
		}catch(Exception IllegalStateException){
			logger.info("INBOX is not open");
		}

		return mailFound;
	}
	public int count(String subjectToBeSearched, String recipientEmailId) throws Exception {
		Properties props = new Properties();
		String host = "10.250.40.93";
		String emailID = "qauser";
		String password = "demoUser1";
		Properties properties = System.getProperties();
		properties.setProperty("mail.port", "110");
		Session session = Session.getDefaultInstance(properties);
		Store store = session.getStore("pop3");
		store.connect(host, emailID, password);
		Folder folder = store.getFolder("INBOX");
		folder.open(Folder.READ_ONLY);
		Calendar cal = new GregorianCalendar();
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date rightNow = new Date();
		Date past = new Date();
		past.setHours(rightNow.getHours() -10);
		SearchTerm olderThan = new SentDateTerm(ComparisonTerm.LE, rightNow);
		SearchTerm newerThan = new SentDateTerm(ComparisonTerm.GE, past);
		Message[] messages = null;

				logger.info("Total Number of messages in the INBOX folder ... " + folder.getMessageCount());
				messages = folder.search(new AndTerm(newerThan, olderThan), folder.getMessages());
				messages = folder.search(new SubjectTerm(subjectToBeSearched), messages);
				messages = folder.search(new RecipientStringTerm(Message.RecipientType.TO, recipientEmailId), messages);

		logger.info("Total messeges with search critieria is "+messages.length);

		return messages.length;
	}




}
