package com.xactly.xcommons.javahelper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.function.Function;

import org.apache.commons.io.FileUtils;

import com.xactly.xcommons.selenium.Constants;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Wait;

public class FileUtil {
	public static File latestFilefromDir;
	public static File latestFile;
	public static String downloadFileName;
	public static String OSDetector () {
		String os = System.getProperty("os.name").toLowerCase();
		if (os.contains("win")) {
		return "Windows";
		} else if (os.contains("nux") || os.contains("nix")) {
		return "Linux";
		}else if (os.contains("mac") || os.contains("darwin")) {
		return "Mac";
		}else if (os.contains("sunos")) {
		return "Solaris";
		}else {
		return "Other";
		}
	}

	public static String readFile(String path, Charset encoding) 
			  throws IOException 
	{
		String runningOS = OSDetector();
		if(runningOS.equals("Windows")){
			if(path.substring(0, 1).equals("/"))
				path = path.substring(1);
		}
			
	  byte[] encoded = Files.readAllBytes(Paths.get(path));
	  return new String(encoded, encoding);
	}
	
	public static String readFile(String path, Charset encoding, String resp) throws Exception 
	{
		String runningOS = OSDetector();
		if(runningOS.equals("Windows")){
			if(path.substring(0, 1).equals("/"))
				path = path.substring(1);
		}
		
		try{
			byte[] encoded = Files.readAllBytes(Paths.get(path));
			return new String(encoded, encoding);
		} catch(Exception e){
			throw new Exception(resp);
		}
	}
	
	
	
	public static File getLatestFilefromDir(String dirPath) throws Exception 
	{
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
				File dir = new File(dirPath);
				File[] files = dir.listFiles();
				if (files == null || files.length == 0) {
					return null;
				}

				File lastModifiedFile = files[0];
				for (int i = 1; i < files.length; i++) {
					if (lastModifiedFile.lastModified() < files[i].lastModified()) {
						lastModifiedFile = files[i];
					}
				}
				return lastModifiedFile;
				}

	public static void deleteExistingFile(String fileName,InputStream in) throws Exception {
		File file = new File(fileName);
		if(file.exists())
		{
		file.delete();
		}
		
		FileOutputStream fos = new FileOutputStream(fileName);
		byte[] buffer = new byte[4096];
		int length;
		while ((length = in.read(buffer)) > 0) {
		fos.write(buffer, 0, length);
		}
		
		fos.close();
}
public static boolean isFileDownloaded(String downloc, String fileName) {
		
	boolean flag = false;
	File dir = new File(downloc);
	File[] dir_contents = dir.listFiles();
	for (int i = 0; i < dir_contents.length; i++) {
		if (dir_contents[i].getName().contains(fileName)) {
			downloadFileName = dir_contents[i].getName();
			flag = true;
		} 
	}
	return flag;
}

	/* Check the file from a specific directory with extension */
	public static boolean isFileDownloaded_Ext(String dirPath, String ext) {
		boolean flag = false;
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			flag = false;
		}

		for (int i = 0; i<files.length; i++) {
			if (files[i].getName().endsWith(ext)) {
				flag = true;
			}
		}
		return flag;
	}
	
	/**
	 * deletes all files from a given folder
	 * @param folderPath
	 * @throws IOException 
	 */
	public static boolean deleteFilesFromFolder(String folderPath) throws IOException{
		boolean result = true;
		try {
			FileUtils.cleanDirectory(new File(folderPath));
		}
		catch(Exception e){
			result = false;
		}
		return result;
	}
	
	public  String getFileLocation(String file) {
		return this.getClass().getClassLoader().getResource(file).getFile();
	}
	
}
