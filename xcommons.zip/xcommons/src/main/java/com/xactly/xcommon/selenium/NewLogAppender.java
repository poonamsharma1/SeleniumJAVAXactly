package com.xactly.xcommons.selenium;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

import org.apache.log4j.FileAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.spi.ErrorCode;

/**
* extending log4j for Creating a new file
*
* 
*
*/

public class NewLogAppender extends FileAppender {

public NewLogAppender() {
}

public NewLogAppender(Layout layout, String filename,
        boolean append, boolean bufferedIO, int bufferSize)
        throws IOException {
    super(layout, filename, append, bufferedIO, bufferSize);
}

public NewLogAppender(Layout layout, String filename,
        boolean append) throws IOException {
    super(layout, filename, append);
}

public NewLogAppender(Layout layout, String filename)
        throws IOException {
    super(layout, filename);
}

public void activateOptions() {
if (fileName != null) {
    try {
        fileName = getNewLogFileName();
        setFile(fileName, fileAppend, bufferedIO, bufferSize);
    } catch (Exception e) {
        errorHandler.error("Error while activating log options", e,
                ErrorCode.FILE_OPEN_FAILURE);
    }
}
}

private String getNewLogFileName() {
if (fileName != null) {
    final String DOT = ".";
    final String HIPHEN = "-";
    final File logFile = new File(fileName);
    final String fileName = logFile.getName();
    String newFileName = "";
    String uniqueId = SeleniumHelperClass.setUniqueId();
    final int dotIndex = fileName.indexOf(DOT);
   // SetWebDrivers.setConstants();
    if (dotIndex != -1) {
        newFileName = fileName.substring(0, dotIndex)+HIPHEN+uniqueId+DOT+fileName.substring(dotIndex +1);
    } else {
        newFileName = fileName+HIPHEN+uniqueId+DOT+"log";
    }
    return "logs"+File.separator+newFileName;
}
return null;
}
}