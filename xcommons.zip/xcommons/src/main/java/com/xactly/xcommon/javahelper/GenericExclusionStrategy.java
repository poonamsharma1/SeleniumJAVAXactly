package com.xactly.xcommons.javahelper;

import java.util.ArrayList;
import java.util.List;
 
import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
 
public class GenericExclusionStrategy implements ExclusionStrategy {
	private final List<String> _skipFields = new ArrayList<String>();
	private final Class<?> _WSOClass; 
	
	public GenericExclusionStrategy(Class<?> WSOClass, String... fields) {
		_WSOClass = WSOClass;
 
		for (String field : fields) {
			_skipFields.add(field);
		}
	}
 
	public boolean shouldSkipClass(Class<?> WSOClass) {
		return false;
	}
 
	public boolean shouldSkipField(FieldAttributes f) {
		return f.getDeclaringClass() == _WSOClass
				&& _skipFields.contains(f.getName());
	}
}
