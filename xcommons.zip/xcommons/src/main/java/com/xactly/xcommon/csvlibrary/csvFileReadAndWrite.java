package com.xactly.xcommons.csvlibrary;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.List;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

public class csvFileReadAndWrite {
	public void modifyCSVFile(String filePath,int rowNumber,String columnName,String columnValue) throws Exception
	{
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		String line=br.readLine();
		String[] columns = line.split(",");
        int columnIndex = -1;
        for (int i = 0; i < columns.length; i++) {
        	columns[i]=columns[i].replace("\"", "");
            if (columnName.equals(columns[i])) {
                columnIndex = i;
                break;
            }
        }
        br.close();
        CSVReader reader = new CSVReader(new FileReader(filePath), ',');
		List<String[]> csvBody = reader.readAll();
		csvBody.get(rowNumber)[columnIndex] =columnValue;
		reader.close();
		CSVWriter writer = new CSVWriter(new FileWriter(filePath), ',');
		writer.writeAll(csvBody);
		writer.flush();
		writer.close();
	}
}
