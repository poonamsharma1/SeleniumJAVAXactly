package com.xactly.xcommons.javahelper;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Properties;

public class GetProperties {

	public static Properties getProperty(String fileName) throws Exception{
		String path="src/main/resources/"+fileName;
		Properties prop=new Properties();
		InputStream input = new FileInputStream(path);
		prop.load(input);
		return prop;
	}
	
	public static Properties getproperty(String fileName) throws Exception{
		String path=fileName;
		Properties prop=new Properties();
		InputStream input = new FileInputStream(path);
		prop.load(input);
		return prop;
	}
}
