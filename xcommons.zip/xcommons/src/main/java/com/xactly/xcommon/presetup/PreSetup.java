package com.xactly.xcommons.presetup;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.UnhandledAlertException;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

//import com.epam.reportportal.service.ReportPortal;
import com.xactly.xcommons.app.LoginToApplication;
import com.xactly.xcommons.javahelper.TracingPrintStream;
import com.xactly.xcommons.selenium.AnalyticsHelperClass;
import com.xactly.xcommons.selenium.Constants;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;



public class PreSetup {

	public static String environment;
	public static String application;
	public static String mode;
	public static String launchName;
	public static int timeout=0;
	private static Logger logger = Logger.getLogger(PreSetup.class);

	public static String getEnvironment() {
		return environment;
	}
	public static void setEnvironment(String env) {
		environment = env;
	}
	public static String getApplication() {
		return application;
	}
	public static void setApplication(String app) {
		  application = app;
	}
	public static String getMode() {
		return mode;
	}
	public static String getLaunchName() {
		return launchName;
	}
	public static void setMode(String modeType) {
		mode = modeType;
	}
	public static int getTimeout() {
		return timeout;
	}
	public static void setTimeout(int time) {
		timeout = time;
	}
	public static void setLaunchName(String launchNames) {
		launchName = launchNames;
	}

	@BeforeSuite(alwaysRun = true)
	@Parameters({"application","environment","mode","browser","grs","navigationType","useIAM","timeoutInMinutes","rp.launch"})
	public void preSetUpSuite(@Optional String appname, @Optional String envname,
							  @Optional String mode,@Optional String _browser, @Optional("off") String grs,@Optional String navigationType,@Optional String useIAM, @Optional String timeoutInMinutes, @Optional String launch) throws Exception
	{	 
	    System.setOut(new TracingPrintStream(System.out));
        //ReportPortal.emitLog("preSetUpSuite", "INFO", Calendar.getInstance().getTime());
        BasicConfigurator.configure();
        logger.info("Entering Before Suite.");

		logger.info("-------------- Before Suite --------------");
		setEnvironment(envname);
		setApplication(appname);
		setMode(mode);
		setLaunchName(launch);
		logger.info("Launch name is:" +launch);
		if(timeoutInMinutes==null)
		{
			setTimeout(120);
		}
		else
		{
			try {
				setTimeout(Integer.valueOf(timeoutInMinutes));
			}catch(Exception e) {
				logger.error("converting the "+timeoutInMinutes +" failed , error msg is :"+e.getMessage());
				setTimeout(120);	
			}
		}
		SetWebDrivers.setBrowser(_browser);
		SetWebDrivers.setNavigationType(navigationType);
		if(useIAM==null) {
			LoginToApplication.setUseIAM("no");
		}else {
			LoginToApplication.setUseIAM(useIAM);
		}
		LoginToApplication.setGrs(grs);
		LoginToApplication login = new LoginToApplication();		
		login.setProperties(envname, appname);		
		Constants.restAPIPath = LoginToApplication.getRestAssuredBaseURI()+ LoginToApplication.getRestAssuredBasePath();
		Constants.envBaseUri = LoginToApplication.getRestAssuredBaseURI();
		Constants.environmentResourceBasePath = "Environment/"+envname+"/";
		if(mode == null) {
			mode="gui";
		}
		if(mode.equalsIgnoreCase("gui") || mode.equalsIgnoreCase("gui-new") || mode.contains("gui")){
			Constants.environmentResourceBasePath = Constants.environmentResourceBasePath + LoginToApplication.getUsername() + "/";
			SeleniumHelperClass.createDownloadDir();
		}
		if (appname.equals("tmca") && envname.equals("boo") && mode.equals("api")) {
			logger.info("Logging into xtmca environment with API... ");
			Constants.restAPIPath = LoginToApplication.getRestAssuredBaseURI();
			System.out.println("Rest API path: " + Constants.restAPIPath);
		}
		if (appname.equals("objectives")|| appname.equals("tmca")){

			Constants.restAPIPath = LoginToApplication.getRestAssuredBaseURI();
		}
		if (mode.equalsIgnoreCase("api")) 
		{
			logger.info("Login in using api mode..");
			SeleniumHelperClass.createDownloadDir();
			logger.info("Business Name ****"+LoginToApplication.getUsername());			
		}
		
		
		logger.info("Environment Name : "+getEnvironment());
		logger.info("Application Name : "+getApplication());
		logger.info("URL  : "+LoginToApplication.getUrl());
		logger.info("Download Location : "+Constants.downloadLoc);
	}	

	@BeforeTest(alwaysRun = true)
	@Parameters({"application","environment","mode","browser","grs","defaultLogin"})
	public void preSetUpTest(@Optional String appname, @Optional String envname, @Optional String mode,@Optional String _browser, @Optional("off") String grs,@Optional("no") String defaultLogin) throws Exception
	{		
		if(mode == null) {
			mode = "gui";
		}
		if((mode.equalsIgnoreCase("gui")) && (!(appname.equals("SFDC"))) && (!(appname.equals("SAML")))){
			logger.info("-------------- Before Test --------------");
			LoginToApplication login = new LoginToApplication();			
			if (!appname.equalsIgnoreCase("xcommons")) 
			{
				
					if(LoginToApplication.getUseIAM().equalsIgnoreCase("yes")) {
						if(defaultLogin!=null && defaultLogin.equalsIgnoreCase("no")) {
							new SetWebDrivers();
						}else {
						    login.loginToIncentWithIAM();
						}
					}
					else {
						if(defaultLogin!=null && defaultLogin.equalsIgnoreCase("no")) {
							new SetWebDrivers();
						}else {
						login.loginToIncent();
						}
					}
					
					
					
					
			}
			if (!((appname.equals("incent")) ||(appname.equals("obero")) || (appname.equals("xcommons")) || (appname.equals("forecasting"))|| (appname.equals("territories")) || (appname.equals("orange")))) 
			{
				logger.info("application name is :"+appname +" and swithching to the module");
				login.switchToModule(appname);
			}
			if ((appname.equals("analytics") || appname.equals("analyticsbeta"))&& envname.equals("qaintx")) 
			{
				AnalyticsHelperClass.acceptAlert();
			}
	}
	
}

	@AfterTest(alwaysRun = true)
	@Parameters({"application","environment","mode","browser"})
	public void terminateTest(@Optional String appname, @Optional String envname, @Optional String mode,@Optional String _browser) throws Exception 
	{
		if(mode == null) {
			mode="gui";
		}
		if(mode.equalsIgnoreCase("gui")){
			logger.info("-------------- After Test --------------");
			if(appname.equals("incent"))
			{
				try {
					SeleniumHelperClass.Logout();
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);				
				}catch(UnhandledAlertException uae){
					logger.info("-----Unhandled alert exception-----");
					SetWebDrivers.getDriver().switchTo().alert().accept();
					SeleniumHelperClass.Logout();
				}
				catch(NoAlertPresentException uae) {
					logger.info("-----After Save-----");
					SeleniumHelperClass.Logout();
				} catch (Exception e) {
					logger.info("-----Issue while logging out-----");									
				}
				finally
				{
					try {
						SetWebDrivers.getDriver().quit();
					}catch(Exception e)
					{
						SetWebDrivers.killSession();
					}
				}
			}
			if(appname.equals("obero")) {
				SetWebDrivers.getDriver().quit();
			}
			if(appname.equals("analytics")||appname.equals("analyticsbeta")){//analytics is analyticsr9
				try {
					AnalyticsHelperClass.logout();
				} catch (Exception e) {				
					e.printStackTrace();
				}
			}
			if(appname.equals("SFDC")) {
				
				try {
					logger.info("sfdc logout");
					SeleniumHelperClass.sFDCLogout();
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
			// Kill all open browsers before running any test
			if (SetWebDrivers.getBrowser().trim().equalsIgnoreCase("Chrome")) {
				if (SetWebDrivers.runningOS.equals("Windows")) 
				{
					logger.info("killing the chrome browser and driver............");
					String processName = "chromedriver.exe";
					if (SetWebDrivers.isProcessRunning(processName)) {
						SetWebDrivers.killProcess(processName);
					}

					String chromeBrowserProcess = "chrome.exe";
					if (SetWebDrivers.isProcessRunning(chromeBrowserProcess)) {
						SetWebDrivers.killProcess(chromeBrowserProcess);
					}
					logger.info("killing the chrome browser and driver............completed");
				} else if (SetWebDrivers.runningOS.equals("Mac")) {
					System.setProperty("webdriver.chrome.driver", "/usr/local/chromedriver_mac");
				}
				
			}
			
			if (SetWebDrivers.getBrowser().trim().equalsIgnoreCase("Chrome_headless"))
				if (SetWebDrivers.runningOS.equals("Linux")) {
				System.setProperty("webdriver.chrome.driver", "/usr/local/jenkins/chromedriver_linux");
			}
				else if (SetWebDrivers.runningOS.equals("Mac")) {
				System.setProperty("webdriver.chrome.driver", "/usr/local/chromedriver_mac");
			}
	  }
		
	}

	@AfterSuite(alwaysRun = true)	
	@Parameters({"application","mode"})
	public void terminateSuite(@Optional String appname,@Optional String mode) throws Exception
	{
		/*if (mode.equalsIgnoreCase("api")) {
			logger.info("Logging out of api mode..");
			if (appname.equals("incent"))
			{
			LoginToRestAPI incent = new LoginToRestAPI();
			incent.logout();
			}

		} */
		if(mode == null) {
			mode="gui";
		}
		if(mode.equalsIgnoreCase("gui")){
			logger.info("-------------- After Suite --------------");
			if(SetWebDrivers.OSDetector().equalsIgnoreCase("Mac") && SetWebDrivers.getBrowser().equalsIgnoreCase("chrome"))
			{
				Runtime.getRuntime().exec("killall chromedriver_mac");
			}
			if(SetWebDrivers.OSDetector().equalsIgnoreCase("Mac") && SetWebDrivers.getBrowser().equalsIgnoreCase("firefox"))
			{
				Runtime.getRuntime().exec("killall geckodriver_mac");
			}
		}
	}
}