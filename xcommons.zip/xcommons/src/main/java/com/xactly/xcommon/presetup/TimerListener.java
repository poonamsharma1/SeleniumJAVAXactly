package com.xactly.xcommons.presetup;

import java.sql.Timestamp;
import java.util.HashMap;
import org.testng.ITestListener;
import org.testng.ITestResult;
import com.xactly.xcommons.selenium.SetWebDrivers;
import org.apache.log4j.Logger;

/**
 * 
 * @author syoganarasimha
 *
 */
public class TimerListener extends Thread implements ITestListener {
	public static Timestamp startTime = null;
	public static Timestamp endTime = null;
	public static int timeoutInMinutes;
	boolean startFlag = true;
	ReportPortalUtils rpUtils = new ReportPortalUtils();
	private static Logger logger = Logger.getLogger(TimerListener.class);
	HashMap<String, ReportPortalJob> launchIdMap;

	public int timeDiff(Timestamp startTime, Timestamp endTime) {
		long milliseconds = endTime.getTime() - startTime.getTime();
		int seconds = (int) milliseconds / 1000;
		int minutes = seconds / 60;
		return minutes;
	}

	public void run() {
		while (startTime != null) {
			// Displaying the thread that is running
			endTime = new Timestamp(System.currentTimeMillis());
			timeoutInMinutes = PreSetup.getTimeout();
			int timeDiff = timeDiff(startTime, endTime);
			if (timeDiff >= timeoutInMinutes) {
				launchIdMap = rpUtils.getLaunchDetails("release_automation", PreSetup.getLaunchName());
				logger.info("Launch map: " + launchIdMap);
				logger.error("Tests didnot finished within the time-out and time taken is " + timeDiff + " minutes");
				if (PreSetup.getMode().equalsIgnoreCase("gui")) {
					try {
						logger.info(
								"Closing browser since the tests didnot finished within the time-out and time taken is "
										+ timeDiff + " minutes");
						SetWebDrivers.getDriver().quit();
						logger.info("get ID: " + launchIdMap.get(PreSetup.getLaunchName()).getId());
						rpUtils.stopLaunch("release_automation", launchIdMap.get(PreSetup.getLaunchName()).getId());

					} catch (Exception e) {
						logger.error(
								"killing webdriver session since the tests didnot finished within the time-out and time taken is "
										+ timeDiff + " minutes");
						SetWebDrivers.killSession();
					}
				} else {
					rpUtils.stopLaunch("release_automation", launchIdMap.get(PreSetup.getLaunchName()).getId());
				}

				System.exit(0);
			}

		}
	}

	@Override
	public void onTestStart(ITestResult result) {
		if (startFlag) {
			startTime = new Timestamp(System.currentTimeMillis());
			startFlag = false;
			TimerListener t = new TimerListener();
			t.start();
		}
	}
}
