package com.xactly.xcommons.restapi;
import org.apache.log4j.Logger;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.testng.Reporter;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.net.URLDecoder;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.xactly.xcommons.app.LoginToApplication;
import com.xactly.xcommons.selenium.Constants;
import com.xactly.xcommons.selenium.DBConnections;

import net.minidev.json.JSONArray;

import static sun.net.www.ParseUtil.decode;

public class RestAPIHelperClass {
	LoginToRestAPI logintorest = new LoginToRestAPI();
	// RestAPIHelperClass resthelper = new RestAPIHelperClass();
	
	public String pathURI=Constants.envBaseUri+"/carest";

public static Logger logger = Logger.getLogger(RestAPIHelperClass.class.getName());
	Response applogindo;
	public static String incentsession;

	public static String getIncentsession() {
		return incentsession;
	}

	public static void setIncentsession(String incentsession) {
		RestAPIHelperClass.incentsession = incentsession;
	}

	public Response getApplogindo() {
		return applogindo;
	}

	public void setApplogindo(Response applogindo) {
		this.applogindo = applogindo;
	}

	public Response getLogindo() {
		return logindo;
	}

	public void setLogindo(Response logindo) {
		this.logindo = logindo;
	}

	Response logindo;

	public Response getRestAPIResponse(String path) {
		logger.info("Getting API for : " + Constants.restAPIPath + path);
		logger.info(LoginToRestAPI.loginresponse.getCookies());
		String getPath = Constants.restAPIPath + path;

		// Bootes xtmcaenv URI property has a port in it, strip before logging in.
		if (Constants.restAPIPath.contains("http://xtmcaenv.xactlycorporation.local:10180")) {
			getPath = Constants.restAPIPath.replace(":10180", "") + path;
		}
		System.out.println("GET PATH2: " + getPath);

		Response resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.when().expect().statusCode(200).get(getPath);
		logger.info("The Response of the API getRestAPIResponse: " + resp.asString());
		return resp;
	}
	
	public Response getRestAPIResponseBaseURI(String path) {
		logger.info("Getting API for : " + LoginToApplication.getRestAssuredBaseURI() + path);
		logger.info(LoginToRestAPI.loginresponse.getCookies());
		Response resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.when().expect().get(LoginToApplication.getRestAssuredBaseURI() + path);
		logger.info("The Response of the API getRestAPIResponse: " + resp.asString());
		return resp;
	}

	public String getRestAPI(String path) {
		logger.info("Getting API for : " + Constants.restAPIPath + path);
	//	logger.info(LoginToRestAPI.loginresponse.getCookies());
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.when().expect().statusCode(200).get(Constants.restAPIPath + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}
	
	//Updated method to get whole response with status line and body
	public String getRestAPIRawResponse(String path) {
		SoftAssert softAssert = new SoftAssert();
		logger.info("Getting API for : " + Constants.restAPIPath + path);
		Response response = RestAssured.given().relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.loginresponse.getCookies()).when().get(Constants.restAPIPath + path);
		softAssert.assertEquals(response.getStatusCode(), 200,
				"Failed to get reponse for " + Constants.restAPIPath + path);
		if (response.getStatusCode() != 200) {
			logger.info(response.getStatusLine());
			logger.info(response.getBody().asString());
		}
		softAssert.assertAll();
		return response.asString();
	}
	
	public String getRestAPI(String path, String baseURI) {
		logger.info("Getting API for : " + baseURI + path);
		logger.info(LoginToRestAPI.loginresponse.getCookies());
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.when().expect().statusCode(200).get(baseURI + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}
	
	public String getRestApiWithStatusCode(String path, String baseURI) {
		logger.info("Getting API for : " + baseURI + path);
		logger.info(LoginToRestAPI.loginresponse.getCookies());
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.when().expect().get(baseURI + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}
	
	public Response getHttpRequestResponse(Response response, String path) throws Exception {
		SoftAssert massert = new SoftAssert();
		System.out.println(LoginToApplication.getRestAssuredBaseURI() + path);
		Response fi = RestAssured.given().relaxedHTTPSValidation()
				.cookies(response.getCookies()).expect().statusCode(200)
		.when().get(LoginToApplication.getRestAssuredBaseURI() + path);
		massert.assertEquals(fi.asString().contains("Unexpected error (info code"), false,
		"GET Http failed : " + LoginToApplication.getRestAssuredBaseURI() + path);
		return fi;
	}

	public String getRestAPIWithCSRF(String path) {
	logger.info("Posting API for : " + Constants.restAPIPath + path);
	String JSESSIONID = LoginToRestAPI.getLoginresponse().getCookie("JSESSIONID");
	String _csrfToken = LoginToRestAPI.loginresponse.getCookie("_csrfToken");
	String resp = RestAssured.given()
			.header("Authorization", JSESSIONID)
			.header("_csrfToken", _csrfToken)
			.log().everything(true).relaxedHTTPSValidation()
			.cookies(LoginToRestAPI.getLoginresponse().getCookies())
			.contentType(ContentType.JSON)
			.when().expect().statusCode(200)
			.get(Constants.restAPIPath + path).asString();
	logger.info("The Response of the API : " + resp);
	return resp;

	}
	
	public byte[] getDownloadXlsxRestAPI(String path)

	{
		logger.debug(RestAssured.baseURI + ":" + RestAssured.port + RestAssured.basePath + path);
		logger.info("Getting API for : " + path);

		byte[] response = RestAssured.given().relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.loginresponse.getCookies()).when().expect().statusCode(200).get(path)
				.asByteArray();

		logger.info("The Response of the API : " + response);

		return response;
	}

	public byte[] getDownloadXlSXRestAPI(String path)

	{
		logger.debug(RestAssured.baseURI + ":" + RestAssured.port + RestAssured.basePath + path);
		logger.info("Getting API for : " + path);

		byte[] response = RestAssured.given().relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.loginresponse.getCookies()).when().expect().statusCode(200)
				.get(Constants.restAPIPath + path).asByteArray();

		logger.info("The Response of the API : " + response);

		return response;
	}

	public Response getRestAPIResponse(String path, Response response)

	{

		logger.info("Getting API for : " + Constants.restAPIPath + path);
		// logger.info(response.getCookies());
		Response resp = RestAssured.given().relaxedHTTPSValidation().cookies(response.getCookies()).when().expect()
				.statusCode(200).get(Constants.restAPIPath + path);
		logger.info("The Response of the API : " + resp.asString());

		return resp;
	}

	public String getRestAPIHeader(String path)

	{

		logger.info("Getting API for : " + Constants.restAPIPath + path);
		// logger.info(LoginToRestAPI.loginresponse.getCookies());
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.when().expect().statusCode(200).get(Constants.restAPIPath + path).getHeader("content-disposition");
		logger.info("The Response of the API : " + resp);

		return resp;
	}

	public byte[] getByteArrayFromGetRequest(String path)

	{
		logger.info("Getting API for : " + Constants.restAPIPath + path);

		byte[] bytes = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.when().expect().statusCode(200).get(path).getBody().asByteArray();
		logger.info("The Response of the API - length of file " + bytes.length);

		return bytes;
	}
	
	public String postHttp(Response r,Response response, String path) throws Exception {
		SoftAssert massert = new SoftAssert();
		System.out.println(LoginToApplication.getRestAssuredBaseURI() + path);
		Reporter.log("Posting API for : " + LoginToApplication.getRestAssuredBaseURI() + path, 3, true);
		String fi = RestAssured.given().relaxedHTTPSValidation()
				.log().all()
				.cookies(response.getCookies())
				.cookies(r.getCookies())
				.expect().statusCode(200)
				.when().post(LoginToApplication.getRestAssuredBaseURI() + path).asString();
		//System.out.println(fi);
		massert.assertEquals(fi.contains("Unexpected error (info code"), false,
				"POST Http failed : " + LoginToApplication.getRestAssuredBaseURI() + path);
		
		Reporter.log("The Response of the API : " + fi, 3, true);
		massert.assertAll();
		return fi;
	}

	public int getRestAPIStatusCode(String path)

	{
		logger.info("Getting API for : " + Constants.restAPIPath + path);
		RestAssured.baseURI = Constants.restAPIPath;
		String JSESSIONID = LoginToRestAPI.getLoginresponse().getCookie("JSESSIONID");
		Response response = RestAssured.given().header("Authorization", JSESSIONID)
				.log().everything(true).relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.when().expect().get(Constants.restAPIPath + path);
		 int statusCode = response.statusCode();
		 logger.info("Status code is "+statusCode);
		 return statusCode;
	}	
	
	public int getPostRestAPIStatusCode(String path,String rbody)

	{
		logger.info("Getting API for : " + Constants.restAPIPath + path);
		RestAssured.baseURI = Constants.restAPIPath;
		String JSESSIONID = LoginToRestAPI.getLoginresponse().getCookie("JSESSIONID");
		Response response = RestAssured.given().header("Authorization", JSESSIONID)
				.log().everything(true).relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON)
				.body(rbody)
				.when().expect().post(Constants.restAPIPath + path);
		 int statusCode = response.getStatusCode();
		 logger.info("Status code for Post Rest API is "+statusCode);
		 return statusCode;
	}
	
	public Response getPostRestAPIBody(String path,String rbody)

	{
		logger.info("Getting API for : " + LoginToApplication.getRestAssuredBaseURI() + path);
		RestAssured.baseURI = LoginToApplication.getRestAssuredBaseURI();
		String JSESSIONID = LoginToRestAPI.getLoginresponse().getCookie("JSESSIONID");
		Response response = RestAssured.given().header("Authorization", JSESSIONID)
				.log().everything(true).relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON+";charset=UTF-8")
				.body(rbody).when().expect().post(LoginToApplication.getRestAssuredBaseURI() + path); 
		logger.info("Response for Post Rest API is "+response.asString());
		 return response;
	}
	
	public int getPutRestAPIStatusCodeForLogin(String path,String rbody)

	{
		logger.info("Getting API for : " + LoginToApplication.getRestAssuredBaseURI() + path);
		RestAssured.baseURI = LoginToApplication.getRestAssuredBaseURI();
		String JSESSIONID = LoginToRestAPI.getLoginresponse().getCookie("JSESSIONID");
		Response response = RestAssured.given().header("Authorization", JSESSIONID)
				.log().everything(true).relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON)
				.body(rbody)
				.when().expect().put(LoginToApplication.getRestAssuredBaseURI() + path);
		 int statusCode = response.getStatusCode();
		 logger.info("Status code for Put Rest API is "+statusCode);
		 return statusCode;
	}
	
	public String postRestAPI(String path, String rbody) {
		logger.info("Posting API for : " + Constants.restAPIPath + path);
		String resp = RestAssured.given()
		.relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON)
				.body(rbody).when().expect().statusCode(200).post(Constants.restAPIPath + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}
	
	public int getRequestRedirectAPIResponse(String path) {
		logger.info("GET REQUEST CALL: " +path);
		Response response = RestAssured.given().relaxedHTTPSValidation().get(path);
		logger.info("GET CORRESPONDING RESPONSE" +response);
		return response.getStatusCode();
	}
	
	public String postRestAPIwith500(String path, String rbody) {
		logger.info("Posting API for : " + Constants.restAPIPath + path);
		String resp = RestAssured.given()
		.relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON)
				.body(rbody).when().expect().statusCode(500).post(Constants.restAPIPath + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}
	
	
	public Response getPostAPIResponse(String path, String rbody) {
		logger.info("Posting API for : " + Constants.restAPIPath + path);
		Response resp = RestAssured.given()
		.relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON+";charset=UTF-8")
				.body(rbody).when().expect().post(Constants.restAPIPath + path);
		logger.info("The Response of the API : " + resp.asString());
		return resp;
	}

	public String postRestAPIWithCSRF(String path, String rbody) {
		Reporter.log("Posting API for : " + Constants.restAPIPath + path, 2, true);
		String JSESSIONID = LoginToRestAPI.getLoginresponse().getCookie("JSESSIONID");
		String _csrfToken = LoginToRestAPI.getLoginresponse().getCookie("_csrfToken");
		
		String resp = RestAssured.given()
				.header("Authorization", JSESSIONID)
				.header("_csrfToken", _csrfToken)
				.log().everything(true).relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.getLoginresponse().getCookies())
				.contentType(ContentType.JSON).body(rbody)
				.when().expect()
				.statusCode(200)
				.post(Constants.restAPIPath + path).asString();
		
		Reporter.log("The Response of the API : " + resp, 2, true);
		return resp;
	}
	
	public Response postRestAPIWithCSRF(String path, String rbody, int statusCode) {
		Reporter.log("Posting API for : " + Constants.restAPIPath + path, 2, true);
		
		String JSESSIONID = LoginToRestAPI.getLoginresponse().getCookie("JSESSIONID");
		String _csrfToken = LoginToRestAPI.getLoginresponse().getCookie("_csrfToken");
		Response resp = RestAssured.given()
				.header("Authorization", JSESSIONID)
				//.header("_csrfToken", _csrfToken)
				.log().everything(true).relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.getLoginresponse().getCookies())
				.contentType(ContentType.JSON).body(rbody)
				.when().expect()
				.statusCode(statusCode)
				.post(Constants.restAPIPath + path);
		
		Reporter.log("The Response of the API : " + resp, 2, true);
		return resp;
	}
	
	public String postRestAPIwBaseURI(String path, String rbody, String baseuri) {
		logger.info("Posting API for : " + baseuri + path);
		String resp = RestAssured.given()

		.relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON+";charset=UTF-8")
				.body(rbody).when().expect().statusCode(200).post(baseuri + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}
	
	public Response postRestAPI_BaseURI_StatusCode(String path, String rbody, String baseuri) {
		logger.info("Posting API for : " + baseuri + path);
		Response response = RestAssured.given().relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON + ";charset=UTF-8")
				.body(rbody).when().expect().post(baseuri + path);
		logger.info("The Response of the API : " + response);
		return response;
	}

	public String postRest500API(String path, String rbody) {
		logger.info("Posting API for : " + Constants.restAPIPath + path);
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.contentType(ContentType.JSON).body(rbody).when().expect().statusCode(500)
				.post(Constants.restAPIPath + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public String postRestAPI(String path, String rbody, int code) {
		logger.info("Posting API for : " + Constants.restAPIPath + path);
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.contentType(ContentType.JSON).body(rbody).when().expect().statusCode(code)
				.post(Constants.restAPIPath + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public String postRest400API(String path, String rbody) {
		logger.info("Posting API for : " + Constants.restAPIPath + path);
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.contentType(ContentType.JSON).body(rbody).when().expect().statusCode(400)
				.post(Constants.restAPIPath + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public String postRestAPI1(String path, String rbody) {
		logger.info("Posting API for : " + Constants.restAPIPath + path);
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.header("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8").body(rbody).when().expect()
				.statusCode(200).post(Constants.restAPIPath + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public String postRestAPIObiee(String path, String rbody) {
		String resp = "";

		path = PreSetupRestAPI.analyticsBaseUriObiee + path;

		logger.info("Posting API for : " + path);
		Map<String, String> cookies = new HashMap<String, String>();
		cookies.putAll(LoginToRestAPI.analyticsLoginResponse.getCookies());

		Response resp1 = RestAssured.given().relaxedHTTPSValidation().cookies(cookies).body(rbody)
				.header("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8").when().expect()
				.statusCode(200).post(path);
		resp = resp1.asString();
		logger.info("post req resp:" + resp);
		logger.info("post req resp cookies:" + resp1.getCookies());

		return resp;
	}

	public String getRestAPIObiee(String path, String rbody) {
		String resp = "";
		path = PreSetupRestAPI.analyticsBaseUriObiee + path;

		logger.info("Getting API for : " + path);
		Map<String, String> cookies = new HashMap<String, String>();
		cookies.putAll(LoginToRestAPI.analyticsLoginResponse.getCookies());
		cookies.putAll(LoginToRestAPI.obieeLoginResponse.getCookies());
		logger.info("GET URL:" + path);
		logger.info("COOKIES:" + cookies);
		resp = RestAssured.given().relaxedHTTPSValidation().cookies(cookies).when().expect().statusCode(200).get(path)
				.asString();
		logger.info("The Response of the API : " + resp);

		return resp;
	}

	public String postRestAPIAnalytics(String path, String rbody) {
		/*String resp = "";
		path = PreSetupRestAPI.analyticsBaseUriCustom + path;
		logger.info("Posting API for : " + path + " body:" + rbody);
		logger.info(LoginToRestAPI.analyticsLoginResponse.getCookies());
		resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.analyticsLoginResponse.getCookies())
				.header("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8").body(rbody).when().expect()
				.statusCode(200).post(path).asString();

		logger.info("The Response of the API - " + path + "---->" + resp);
		return resp;*/
		
		String resp = "";
		path = PreSetupRestAPI.analyticsBaseUriCustom + path;
		rbody=rbody+ "&requestId=B6E1802F36D21D0757F41F8EDA4B838E";
		//cookies.put("requestid", "B6E1802F36D21D0757F41F8EDA4B838E");
		
		Map<String, String> cookies = new HashMap<String, String>();
        
             //path = Info.Config.baseUri2+ path;
            cookies.putAll(LoginToRestAPI.analyticsLoginResponse.getCookies());
        

        cookies.put("requestid", "B6E1802F36D21D0757F41F8EDA4B838E");
		
		System.out.println("Post Analytics path:"+path);
		Reporter.log("Posting API for : " + path + " body:" + rbody, 3, true);
		
		System.out.println("Cookies for api"+LoginToRestAPI.analyticsLoginResponse.getCookies());
		System.out.println(LoginToRestAPI.analyticsLoginResponse.getCookies());
		resp = RestAssured.given().relaxedHTTPSValidation().cookies(cookies)
				.header("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8").body(rbody).when().expect()
				.statusCode(200).post(path).asString();

		System.out.println("The Response of the API - " + path + "---->" + resp);
		return resp;
		
	}

	public String getRestAPIAnalytics(String path) {

		path = PreSetupRestAPI.analyticsBaseUriCustom + path;
		logger.info("Getting API for : " + path);
		String resp = RestAssured

		.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.analyticsLoginResponse.getCookies()).when().expect()
				.statusCode(200).get(path).asString();
		logger.info("The Response of the API : " + resp);

		return resp;
	}

	public String postRestAPIforUploadxlsxFile(String path, String fileLocation) {
		logger.info("Posting API for : " + RestAssured.baseURI + ":" + RestAssured.port + RestAssured.basePath + path);
		String resp = RestAssured.given().multiPart("file", new File(fileLocation)).relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.loginresponse.getCookies()).when().expect().statusCode(200).post(path)
				.asString();
		logger.info("The Response of the API : " + resp);

		return resp;
	}

	public String requestid = "";

	public Response postHttpRequestResponse(Response response, String path) throws Exception {
		if (requestid == null || requestid.trim().length() == 0) {
			requestid = response.getCookie("requestid");
		}
		// logger.info("Previous requestid :"+requestid);

		SoftAssert massert = new SoftAssert();
		logger.info("Posting API for : " + LoginToApplication.getRestAssuredBaseURI() + path);
		Response fi = RestAssured.given().relaxedHTTPSValidation()

		.cookies(response.getCookies()).cookie("requestid", requestid).expect().statusCode(200).when()
				.post(LoginToApplication.getRestAssuredBaseURI() + path);
		massert.assertEquals(fi.asString().contains("Unexpected error (info code"), false,
				"POST Http failed : " + LoginToApplication.getRestAssuredBaseURI() + path);
		// massert.assertEquals(fi.asString().contains("alert"), false,"Found
		// Alert in the response :
		// "+LoginToApplication.getRestAssuredBaseURI()+path);

		logger.info("The Response of the API : " + fi);
		requestid = fi.getCookie("requestid");
		LoginToRestAPI.setRequestid(requestid);
		// logger.info("Current cookie "+requestid);
		massert.assertAll();
		return fi;
	}
	
	public Response postHttpRequestBizCopy(Response response,String reqid, String path) throws Exception {
		SoftAssert massert = new SoftAssert();
		Map<String, String> cookies = new HashMap<String, String>();

		String reqid_1=reqid;
		cookies.putAll(response.getCookies());
		cookies.put("xbaseSessionId", reqid_1);
		logger.info("Posting API for : " + LoginToApplication.getRestAssuredBaseURI() + path);
		Response fi = RestAssured.given().relaxedHTTPSValidation().cookies(cookies).expect().statusCode(200)
				.when().post(LoginToApplication.getRestAssuredBaseURI() + path);
		massert.assertEquals(fi.asString().contains("Unexpected error (info code"), false,
				"POST Http failed : " + LoginToApplication.getRestAssuredBaseURI() + path);
		//logger.info("The Response of the API : " + fi);
		return fi;
	}

	public String postHttpRequest(Response response, String path) throws Exception {
		SoftAssert massert = new SoftAssert();
		logger.info("Posting API for : " + LoginToApplication.getRestAssuredBaseURI() + path);
		String fi = RestAssured.given().relaxedHTTPSValidation().cookies(response.getCookies()).expect().statusCode(200)
				.when().post(LoginToApplication.getRestAssuredBaseURI() + path).asString();
		massert.assertEquals(fi.contains("Unexpected error (info code"), false,
				"POST Http failed : " + LoginToApplication.getRestAssuredBaseURI() + path);
		logger.info("The Response of the API : " + fi);
		return fi;
	}

	public String getHttpRequest(Response response, String path) throws Exception {
		SoftAssert massert = new SoftAssert();
		logger.info("Getting API for : " + LoginToApplication.getRestAssuredBaseURI() + path);
		// RestAPIHelperClass rest = new RestAPIHelperClass();
		// Response re = rest.ApploginToIncent("incent.userdetails");
		String fi = RestAssured.given().relaxedHTTPSValidation().cookies(response.getCookies()).expect().statusCode(200)
				.when().get(LoginToApplication.getRestAssuredBaseURI() + path).asString();
		massert.assertEquals(fi.contains("Unexpected error (info code"), false,
				"GET Http failed : " + LoginToApplication.getRestAssuredBaseURI() + path);
		logger.info("The Response of the API : " + fi);
		return fi;
	}
	
	// Eg: formData like "dataFile"
		public String postRestAPIforUploadwithCSRF(String path, String fileName, String formData) {
			logger.info("Posting API for : " + Constants.restAPIPath + path);
			String _csrfToken = LoginToRestAPI.loginresponse.getCookie("_csrfToken");
			String resp = RestAssured.given().multiPart(formData, new File(fileName)).relaxedHTTPSValidation().header("XCSRF-TOKEN", _csrfToken)
						.cookies(LoginToRestAPI.loginresponse.getCookies())
						// .contentType(ContentType.JSON)
						// .body(rbody)
			.when().expect().statusCode(200).post(Constants.restAPIPath + path).asString();
			logger.info("The Response of the API : " + resp);
			return resp;
				}		

	public String postRestAPIforUpload(String path, File fileName) throws IOException {
		// String filepath = org.apache.commons.io.IOUtils.toString(fileName);
		// logger.info("I am uploading : "+fileName);
		// Added the Thread.sleep in line 542 and 552 becasue of the Open issue:INCENT-30973
		try{ Thread.sleep(7*1000); } catch(InterruptedException e) {}
		logger.info("Posting API for : " + Constants.restAPIPath + path);
		String resp = RestAssured
				// .given().multiPart(new File(filepath))
				.given().multiPart(fileName).relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				// .contentType(ContentType.JSON)
				// .body(rbody)
				.when().expect().statusCode(200).post(Constants.restAPIPath + path).asString();
		logger.info("The Response of the API : " + resp);
		try{ Thread.sleep(7*1000); } catch(InterruptedException e) {}
		return resp;

	}
	
	public String postRestAPIWithoutConstantPath(String path) {
		logger.info("Posting API for : " + path);
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.when().expect().statusCode(200).post(path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}

	// Eg: formData like "dataFile"
	public String postRestAPIforUpload(String path, String fileName, String formData) {
		logger.info("Posting API for : " + Constants.restAPIPath + path);
		String resp = RestAssured.given().multiPart(formData, new File(fileName)).relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.loginresponse.getCookies())
				// .contentType(ContentType.JSON)
				// .body(rbody)
				.when().expect().statusCode(200).post(Constants.restAPIPath + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}
	
	public String postRestAPIforUploadWithBaseURI(String path, File fileName, String baseuri) {
		logger.info("Posting API for : " + baseuri + path);
		String resp = RestAssured.given().multiPart(fileName).relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.loginresponse.getCookies())
				.when().expect().statusCode(200).post(baseuri + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
		
	}

	// Eg: formData like "dataFile"
	// send with body
	public String postRestAPIforUpload(String path, File fileName, String rbody) {
		logger.info("Posting API for : " + Constants.restAPIPath + path);
		String resp = RestAssured
				// .given().multiPart(new File(filepath))
				.given().multiPart(fileName).relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				// .contentType(ContentType.JSON)
				// .body(rbody)
				.when().expect().statusCode(200).post(Constants.restAPIPath + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public String postRestAPIforUploadReleaseTemplate(String path, String fileName, String rbody) {
		logger.info("Posting API for : " + Constants.restAPIPath + path);
		logger.info("Posting API for : " + Constants.restAPIPath + path);
		String resp = RestAssured.given().contentType("multipart/form-data")
				.multiPart("file", new File(fileName), "multipart/form-data").formParam("param", rbody)
				.relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				// .contentType(ContentType.JSON)
				// .body(rbody)
				.when().expect().statusCode(200).post(Constants.restAPIPath + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}
	/*
	 * //Eg: formData like "dataFile" public String
	 * postRestAPIforUploadxlsxFile(String path, String fileLocation) {
	 * logger.info("Posting API for : "
	 * +RestAssured.baseURI+":"+RestAssured.port+RestAssured.basePath+path,2,
	 * true); String resp = RestAssured .given() .multiPart("file",new
	 * File(fileLocation)) .relaxedHTTPSValidation()
	 * .cookies(LoginToRestAPI.loginresponse.getCookies()) .when() .expect()
	 * .statusCode(200) .post(path).asString(); logger.info(
	 * "The Response of the API : "+resp);
	 * 
	 * return resp; }
	 */

	public String putRestAPI(String path, String rbody) {

		logger.info("PUT API for : " + Constants.restAPIPath + path);
		// logger.info("Response Body :"+rbody);
		String resp = RestAssured.given()
								 .relaxedHTTPSValidation()
								 .cookies(LoginToRestAPI.loginresponse.getCookies())
								 .contentType(ContentType.JSON)
								 .body(rbody)
								 .when()
		.expect().statusCode(200).put(Constants.restAPIPath + path).asString();

		logger.info("The Response of the API : " + resp);
		return resp;
	}


	public String putRestAPI500(String path, String rbody) {

		logger.info("PUT API for : " + Constants.restAPIPath + path);
		String resp = RestAssured.given()
								 .relaxedHTTPSValidation()
								 .cookies(LoginToRestAPI.loginresponse.getCookies())
								 .contentType(ContentType.JSON)
								 .body(rbody)
								 .when()
		.expect().statusCode(500).put(Constants.restAPIPath + path).asString();

		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public String putRestAPIWithCSRF(String path, String rbody) {

		logger.info("PUT API for : " + Constants.restAPIPath + path);
		String JSESSIONID = LoginToRestAPI.getLoginresponse().getCookie("JSESSIONID");
		String _csrfToken = LoginToRestAPI.loginresponse.getCookie("_csrfToken");
		String resp = RestAssured.given()
				.header("Authorization", JSESSIONID)
				.header("_csrfToken", _csrfToken)
				.log().everything(true).relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.loginresponse.getCookies())
				.contentType(ContentType.JSON).body(rbody)
				.when().expect()
				.statusCode(200)
				.put(Constants.restAPIPath + path).asString();

		logger.info("The Response of the API : " + resp);
		return resp;
	}

	
	public String putRestAPI(String path, String rbody, int statusCode) {

		logger.info("PUT API for : " + Constants.restAPIPath + path);
		// logger.info("Response Body :"+rbody);
		String resp = RestAssured.given()

		.relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON)
				.body(rbody).when()

		.expect().statusCode(statusCode).put(Constants.restAPIPath + path).asString();

		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public Response putRestAPIResponse(String path, String rbody) {
		logger.info("Posting API for : " + Constants.restAPIPath + path);
		Response resp = RestAssured.given()
				.relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON+";charset=UTF-8")
				.body(rbody).when().expect().put(Constants.restAPIPath + path);
		logger.info("The Response of the API : " + resp.asString());
		return resp;
	}


	public String put500RestAPI(String path, String rbody) {
		logger.info("PUT API for : " + Constants.restAPIPath + path);
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.contentType(ContentType.JSON).body(rbody).when().expect().statusCode(200)
				.put(Constants.restAPIPath + path).asString();

		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public String putRestAPINoStatusCode(String path, String rbody) {

		logger.info("PUT API for : " + Constants.restAPIPath + path);
		// logger.info("Response Body :"+rbody);
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.contentType(ContentType.JSON).body(rbody).when().put(Constants.restAPIPath + path).asString();

		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public String putRestAPI(String path, Map<String, String> rbody) {

		logger.info("PUT API for : " + Constants.restAPIPath + path);
		// logger.info("Response Body :"+rbody);
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.contentType(ContentType.JSON).body(rbody).when().expect().statusCode(200)
				.put(Constants.restAPIPath + path).asString();

		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public String putRestAPIInt(String path, int rbody) {

		logger.info("PUT API for : " + Constants.restAPIPath + path);
		// logger.info("Response Body :"+rbody);
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.contentType(ContentType.JSON).body(rbody).when().expect().statusCode(200)
				.put(Constants.restAPIPath + path).asString();

		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public String putMapRestAPI(String path, Map<String, String> parameters) {

		logger.info("PUT API for : " + Constants.restAPIPath + path);
		// logger.info("Response Body :"+rbody);
		// String resp =
		// RestAssured.given().parameters(parameters).then().expect().when().put(Constants.restAPIPath+path).asString();
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.contentType(ContentType.JSON).body(parameters)
				// .parameters(parameters)
				.when().expect()
				// .statusCode(200)
				.put(Constants.restAPIPath + path).asString();

		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public Response postRest(String path, String rbody) {

		logger.info("Posting API for : " + Constants.restAPIPath + path);
		Response resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.contentType(ContentType.JSON).body(rbody).when().expect()
				// .statusCode(200)
				.post(Constants.restAPIPath + path);

		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public Response postRest(String path, String rbody, Response loginResp) {
		logger.info("Posting API for : " + Constants.restAPIPath + path);
		Response resp = RestAssured.given().relaxedHTTPSValidation().cookies(loginResp.getCookies())
				.contentType(ContentType.JSON).body(rbody).when().expect().statusCode(200)
				.post(Constants.restAPIPath + path);
		logger.info("The response is " + resp);
		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public String postRest(String path, String rbody, int statusCode) {

		logger.info("Posting API for : " + Constants.restAPIPath + path);
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.contentType(ContentType.JSON).body(rbody).when().expect().statusCode(statusCode)
				.post(Constants.restAPIPath + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public String putRest(String path, String rbody) {

		logger.info("PUT API for : " + Constants.restAPIPath + path);
		logger.info("Response Body :" + rbody);
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.contentType(ContentType.JSON).body(rbody).when().expect()
				// .statusCode(200)
				.put(Constants.restAPIPath + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}
	
	public String putRestBaseURI(String path, String rbody) {

		logger.info("PUT API for : " + RestAssured.baseURI + path);
		logger.info("Response Body :" + rbody);
		String resp = RestAssured.given().relaxedHTTPSValidation().header("Content-Type", "application/json;charset=UTF-8").cookies(LoginToRestAPI.loginresponse.getCookies())
				.body(rbody).when().expect()
				.put(RestAssured.baseURI + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public String deleteRestAPI(String path) {
		logger.info("Deleting API for : " + RestAssured.baseURI + ":" + RestAssured.port + RestAssured.basePath + path);
		String resp = RestAssured.given().log().everything(true).relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON).when().log()
				.everything(true).then().expect().statusCode(200).delete(Constants.restAPIPath + path).asString();
		return resp;
	}
	
	public Response deleteRestAPIWithBaseUri(String path, String baseURI) {
		logger.info("Deleting API for : " + baseURI + path);
		Response resp = RestAssured.given().log().everything(true).relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON).when().log()
				.everything(true).then().expect().delete(baseURI + path);
		return resp;
	}
	
	public Response deleteAPIResponse(String path) {
		logger.info("Deleting API for : " + RestAssured.baseURI + ":" + RestAssured.port + RestAssured.basePath + path);
		Response resp = RestAssured.given().log().everything(true).relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON).when().log()
				.everything(true).then().delete(Constants.restAPIPath + path);
		return resp;
	}
	
	public String deleteRestAPIWithCSRF(String path) {
		
		Reporter.log("Cookies under Post Rest API function : " + LoginToRestAPI.getLoginresponse().getCookies(), 2, true);
		Reporter.log("Deleting API for : " + Constants.restAPIPath + path, 2, true);
		
		String resp = RestAssured.given()
				.header("Authorization",LoginToRestAPI.loginresponse.getCookie("JSESSIONID"))
				.header("_csrfToken",LoginToRestAPI.loginresponse.getCookie("_csrfToken"))
				.log().everything(true).relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.getLoginresponse().getCookies())
				.cookie("vusid",LoginToRestAPI.getVusid())
				.contentType(ContentType.JSON).when()
				.then()
				.expect().statusCode(200).delete(Constants.restAPIPath + path).asString();
		return resp;
	}

	public Response deleteRestAPIErrorValidation(String path) {
		logger.info("Deleting API for : " + RestAssured.baseURI + ":" + RestAssured.port + RestAssured.basePath + path);

		Response resp = RestAssured.given().log().everything(true).relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON).when().log()
				.everything(true).expect().statusCode(500).delete(Constants.restAPIPath + path);
		return resp;
	}
	
	public String deleteRestAPI(String path, Response response) {
		logger.info("Posting API for : " + RestAssured.baseURI + ":" + RestAssured.port + RestAssured.basePath + path);
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(response.getCookies())
				.contentType(ContentType.JSON).when().expect().statusCode(200).delete(Constants.restAPIPath + path)
				.asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}
	
	public String deleteRestAPI(String path, int code) {
		logger.info("Deleting API for : " + RestAssured.baseURI + ":" + RestAssured.port + RestAssured.basePath + path);
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.contentType(ContentType.JSON).when().expect().statusCode(code).delete(Constants.restAPIPath + path)
				.asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public String deleteRestAPI_BaseURI_Path(String path, int code, Map<String, String> xbaseSessionId) {
		logger.info("Deleting API for : " + RestAssured.baseURI + path);
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(xbaseSessionId)
				.contentType(ContentType.JSON).when().expect().statusCode(code).delete(RestAssured.baseURI + path)
				.asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}
	
	public String deleteRestAPI(String path, String rbody) {
		Reporter.log("Deleting API for : " + RestAssured.baseURI + ":" + RestAssured.port + RestAssured.basePath + path,
				2, true);
		String resp = RestAssured.given().log().everything(true).relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON).body(rbody).when().log()
				.everything(true).then().expect().statusCode(200).delete(Constants.restAPIPath + path).asString();

		return resp;
	}
	
	public String deleteRestAPI(String path, String rbody, int statusCode) {
		Reporter.log("Deleting API for : " + RestAssured.baseURI + ":" + RestAssured.port + RestAssured.basePath + path,
				2, true);
		String resp = RestAssured.given().log().everything(true).relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON).body(rbody).when().log()
				.everything(true).then().expect().statusCode(statusCode).delete(Constants.restAPIPath + path).asString();

		return resp;
	}

	public String getParticipantId() throws SQLException, ClassNotFoundException {

		DBConnections db = new DBConnections("api");
		String participantid = db.connect_Db_string(
				"select part_assignment.participant_id from xc_participant part, xc_part_user_assignment part_assignment where part.business_id=part_assignment.business_id and part.business_id=(select business_id from xc_user where email='"
						+ LoginToRestAPI.getUsername()
						+ "') and part.is_master=1 and part.employee_id=part_assignment.employee_id and part_assignment.user_id=(select user_id from xc_user where email='"
						+ LoginToRestAPI.getUsername() + "')",
				"participant_id");
		logger.info("ParticipantID found for the Rep :" + participantid);
		return participantid;
	}

	@Parameters("environment")
	public String loadJsonFile(@Optional String environment, String jsonFileName) throws IOException {
		InputStream systemPropertyInputStream;
		Properties symProPath = new Properties();
		String propFile = "environment" + File.separator + environment + File.separator + "apiresponses"
				+ File.separator + jsonFileName + ".json";
		logger.info(propFile);
		systemPropertyInputStream = this.getClass().getClassLoader().getResourceAsStream(propFile);
		logger.info(systemPropertyInputStream);
		symProPath.load(systemPropertyInputStream);
		// baseuri =
		// PreSetupRestAPI.symProPath.getProperty("RestAssured.baseURI");
		return propFile;

	}

	// Returns a json object from an input stream
	public void loadAPIPropertyFile(String jsonFileName) throws IOException {

		Properties symProPath = new Properties();
		String propFile = "environment" + File.separator + "apiresponses" + File.separator + jsonFileName + ".json";
		logger.info(propFile);

	}

	// Objectives login
	public Response objectiveslogin(String propertypath) throws Exception {

		LoginToRestAPI loginToRestAPI = new LoginToRestAPI();
		String url = PreSetupRestAPI.symProPath.getProperty("url");

		String loginURL = PreSetupRestAPI.grsBaseuri == null ? url : PreSetupRestAPI.grsBaseuri + "/xlsweb/login.do";
		String userdetails = PreSetupRestAPI.userProPath.getProperty(propertypath);
		String[] user = userdetails.split(":");
		LoginToRestAPI.setUsername(user[0]);
		LoginToRestAPI.setPassword(user[1]);
		logger.info("Logging into Incent :" + user[0]);
		LoginToRestAPI.setUsername(user[0]);
		LoginToRestAPI.loginresponse = RestAssured.given().relaxedHTTPSValidation()
				.formParam("userName", LoginToRestAPI.getUsername()).formParam("password", LoginToRestAPI.getPassword())
				.expect().statusCode(200).when().post(loginURL);

		return LoginToRestAPI.loginresponse;
	}

	
	
	
	public static String getSubStringValues(String values,String startvalue, String endvalue)
	{
		int startvalues = values.indexOf(startvalue)+startvalue.length();
		int endvalues = values.indexOf(endvalue, startvalues);
		values = values.substring(startvalues, endvalues);
		
		return values;
	}

	/**
	 * Login is a three step process in api
	 * 1 login with url:Constants.envBaseUri+"/xlsweb/login.do, params username/pwd
	 * 2 Url:loginRedirectUrl from the above response ,params:xLoginTicket,username, userLoggedIn,firstLoginRestToken
	 * 3 URL:base url from loginRedirectUrl+/xicm/appLoginInit.do  ,params:xLoginTicket,username, userLoggedIn,firstLoginRestToken
	 * 
	 * @param propertypath
	 * @return
	 * @throws Exception
	 */
	
	/*public static Response loginwithUserName(String username, String password) throws Exception
	{
		String loginURL = PreSetupRestAPI.grsBaseuri == null ? PreSetupRestAPI.symProPath.getProperty("url"): PreSetupRestAPI.grsBaseuri + "/grsservice/login";
		logger.info("System loginURL: " + loginURL);
		
		Response login = RestAssured.given().relaxedHTTPSValidation()
				.formParam("userName", username)
				.formParam("password", password)
				.formParam("xreferer", "")
				.formParam("startPage", "")
				.expect().statusCode(200)
				.when().post(loginURL);

		logger.info("getCookies: " + login.getCookies());
		logger.info("getResponse: " + login.asString());
		 
		*//** check if grs base url available in evironment *//*

		String xloginticket = LoginToRestAPI.getXLoginTicket(login.asString()) == null? login.getCookie(LoginToRestAPI.getVusidtemplate()) : LoginToRestAPI.getXLoginTicket(login.asString());

		String loginRedirectURL = LoginToRestAPI.getLoginRedirectUrl(login.asString()) == null? Constants.envBaseUri + "/xicm/loginEx.do" : LoginToRestAPI.getLoginRedirectUrl(login.asString());
		
		login.getCookies();

		// Redirect Login
		Response appLogin = RestAssured.given()
				.relaxedHTTPSValidation()
				.formParam("userName", username)
				.formParam("xLoginTicket", xloginticket)
				.formParam("startPage", "")
				.cookies(login.getCookies())
				.expect()
				.statusCode(302).when().post(loginRedirectURL);

		//logger.info("getCookies: " + appLogin.getCookies());
		//logger.info("getResponse: " + appLogin.getHeader("Location"));
		String token = appLogin.getHeader("Location");
		token = token.substring(token.indexOf("token=")+6);

		
		// Login EX
		Response loginEx = RestAssured.given()
		.relaxedHTTPSValidation().param("token", token)
		.cookies(appLogin.getCookies())
		.expect()
		.statusCode(200).when().get(Constants.envBaseUri + "/xicm/loginEx.do");

		//logger.info("getCookies: " + loginEx.getCookies());
		//logger.info("getResponse: " + loginEx.asString());
		

		
		String response = loginEx.asString();		
		String sessionId = getSubStringValues(response, "\"sessionId\" value=\"", "\"");
		String xbaseSessionId =  getSubStringValues(response, "\"xbaseSessionId\" value=\"", "\"");
		
		
		//
		Response logiExInitdo = RestAssured.given()
				.relaxedHTTPSValidation()
				.cookies(loginEx.getCookies())
				.formParam("userEmail", username)
				.formParam("sessionId", sessionId)
				.formParam("xbaseSessionId", xbaseSessionId)
				.expect()
				.statusCode(200).when().post(LoginToApplication.getRestAssuredBaseURI()+"/xicm/loginExInit.do");
		
		LoginToRestAPI.setVusid(sessionId);
		LoginToRestAPI.setXbaseSessionId(xbaseSessionId);

		
		Response loginappdo = RestAssured.given()
				.relaxedHTTPSValidation()
				.cookies(logiExInitdo.getCookies())
				.expect()
				.statusCode(200).when().post(LoginToApplication.getRestAssuredBaseURI()+"/xicm/login.do");

		LoginToRestAPI.setLoginresponse(logiExInitdo);
		LoginToRestAPI.loginresponse = logiExInitdo;
		
		return logiExInitdo;
		
	}*/
	public Response ApploginToIncent(String propertypath) throws Exception {

		RestAPIHelperClass rest = new RestAPIHelperClass();		
		String userdetails = PreSetupRestAPI.userProPath.getProperty(propertypath);
		String[] user = userdetails.split(":");
		LoginToRestAPI.setUsername(user[0]);
		LoginToRestAPI.setPassword(user[1]);
		logger.info(user[0]);
		logger.info(user[1]);
		logger.info("Logging into Incent :" + user[0]);
		Response respo = null;
		if(LoginToRestAPI.getGrs().equalsIgnoreCase("OFF"))
			 respo = LoginToRestAPI.loginWithoutGRS(user[0], user[1]);
		else
			 respo = LoginToRestAPI.loginWithGRS(user[0],user[1]);
		
		return respo;
	}
	
	public Response ApploginToIncent(String userName, String password) throws Exception 
	{	
		Response respo = null;
		if(LoginToRestAPI.getGrs().equalsIgnoreCase("OFF"))
			 respo = LoginToRestAPI.loginWithoutGRS(userName, password);
		else
			 respo = LoginToRestAPI.loginWithGRS(userName,password);
		logger.info("AppLogin cookie :"+respo.getCookies());		
		return respo;		
	}
	

	public Response ApploginToIncent() throws Exception {
		
		Response respo = null;
		if(LoginToRestAPI.getGrs().equalsIgnoreCase("OFF"))
			 respo = LoginToRestAPI.loginWithoutGRS(LoginToRestAPI.getUsername(), LoginToRestAPI.getPassword());
		else
			 respo = LoginToRestAPI.loginWithGRS(LoginToRestAPI.getUsername(), LoginToRestAPI.getPassword());
		
		LoginToRestAPI.setLoginresponse(respo);
		LoginToRestAPI.loginresponse = respo;
		return respo;
	}

	// @Parameters({"environment"})
	public Response loginToObjectives(Response incentCookies, String environment) throws Exception {
		LoginToRestAPI loginToRestAPI = new LoginToRestAPI();
		String userName = LoginToRestAPI.getUsername();
		String jsession = incentCookies.getCookies().get("JSESSIONID");
		String vusid_incent = incentCookies.getCookie("vusid");
		String csrfTokenFromIncent = incentCookies.getCookie("_csrfToken");
		String xbaseSessionId = incentCookies.getCookie("xbaseSessionId");
		//String remoteAddress = loginToRestAPI.getIRemoteAddress();
		//String[] splittedRemoteAddress =  remoteAddress.split(",");
		LoginToRestAPI.xbaseSessionId=xbaseSessionId;
		logger.info("vusid BEFORE OBJECTIVE:" + vusid_incent);
		logger.info("userName BEFORE OBJECTIVE:" + userName);
		logger.info("JSESSIONID BEFORE OBJECTIVE:" + jsession);
		logger.info("CSRF BEFORE OBJECTIVE:" + csrfTokenFromIncent);
		Gson gson = new GsonBuilder().create();

		
		String request = "/xmbo/xmbows/login.do?sessionId=" + vusid_incent + "&userEmail=" + userName + "&remoteAddr=127.0.0.1";
		String data = "{\"sessionId\":" + vusid_incent + ",\"userEmail\":" + userName + ",\"remoteAddr\":127.0.0.1}";
		
		int statusCode = 200;
		Response resp = postRestAPIWithCSRF(request, data, statusCode);
		logger.info("Objectives Response:" + resp.getDetailedCookies());

		LoginToRestAPI.setLoginresponse(resp);
		LoginToRestAPI.setVusid(vusid_incent);
		LoginToRestAPI.setXbaseSessionId(xbaseSessionId);
		jsession = LoginToRestAPI.getLoginresponse().getCookie("JSESSIONID");
		vusid_incent = LoginToRestAPI.getVusid() ;
		csrfTokenFromIncent = LoginToRestAPI.loginresponse.getCookie("_csrfToken");
		xbaseSessionId = incentCookies.getCookie("xbaseSessionId");
		logger.info("vusid AFTER OBJECTIVE:" + vusid_incent);
		logger.info("userName AFTER OBJECTIVE:" + userName);
		logger.info("JSESSIONID AFTER OBJECTIVE:" + jsession);
		logger.info("CSRF AFTER OBJECTIVE:" + csrfTokenFromIncent);
		
		return LoginToRestAPI.getLoginresponse();
	}

	// @Parameters({"environment"})
	/*
	 * public Response loginToTMCA(Response incentCookies) throws Exception {
	 * LoginToRestAPI loginToRestAPI = new LoginToRestAPI(); String userName =
	 * LoginToRestAPI.getUsername(); Map<String, String> cookieMap =
	 * incentCookies.getCookies(); String vusidCookieName = null; for
	 * (Map.Entry<String, String> entry : cookieMap.entrySet()) {
	 * logger.info("Key = " + entry.getKey() + ", Value = " + entry.getValue()); if
	 * (entry.getKey().contains("vusid")) { vusidCookieName = entry.getKey(); } }
	 * 
	 * String jsession = incentCookies.getCookies().get("JSESSIONID"); String
	 * vusid_incent = incentCookies.getCookies().get(vusidCookieName);
	 * logger.info("jsession:" + jsession + "  vusid:" + vusid_incent); String
	 * request = "/xtmca/login.do?sessionId=" + vusid_incent + "&userEmail=" +
	 * userName + "&remoteAddr=10.250.2.77"; Gson gson = new GsonBuilder().create();
	 * String data = "{\"sessionId\":" + jsession + ",\"vusid\":" + vusid_incent +
	 * ",\"userEmail\":" + userName + ",\"remoteAddr\":10.250.2.77}";
	 * logger.info("Json:" + gson.toJson(data)); Response resp = postRest(request,
	 * data); logger.info("TMCA Response:" + resp.getDetailedCookies());
	 * LoginToRestAPI.setLoginresponse(resp); return resp; }
	 */
	
	public Response loginToTMCA(Response incentCookies) throws Exception {
		LoginToRestAPI loginToRestAPI = new LoginToRestAPI();
		String userName = LoginToRestAPI.getUsername();
		Map<String, String> cookieMap = incentCookies.getCookies();
		String vusidCookieName = null;
		for (Map.Entry<String, String> entry : cookieMap.entrySet()) {
			System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
			if (entry.getKey().contains("vusid")) {
				vusidCookieName = entry.getKey();
			}
		}
		String jsession = incentCookies.getCookies().get("JSESSIONID");
		String vusid_incent = incentCookies.getCookies().get(vusidCookieName);
		String xbaseSessionId = incentCookies.getCookie("xbaseSessionId");
		
		String request1 = "/xicm/misc.ajax.do?action=getIncentSession&targetApp=Xactly Territories";
		Response response1 = getRestAPIResponse(request1);
		System.out.println("Request1 Resp: "+ response1.getBody().asString());
		System.out.println("Request1 Cookies: "+ response1.getDetailedCookie("JSESSIONID"));

		String decodedResonse =  decode(response1.getBody().asString());
		System.out.println("decoded"+decodedResonse);
		String[] loadMetaDataUrl = decodedResonse.split("\\|");
//		String[] loadMetaDataUrl = response1.getBody().asString().split("\\|");
		System.out.println("reqUrl: "+ loadMetaDataUrl[3]);
		Response loadMetaDataResponse = RestAssured.given().relaxedHTTPSValidation().cookies(response1.cookies())
		.contentType(ContentType.JSON).when().expect()
		.statusCode(200)
		.post(loadMetaDataUrl[3]);
		
		System.out.println("loadMetaData Response: "+ loadMetaDataResponse.getBody().asString());
		System.out.println("loadMetaData Cookies: "+ loadMetaDataResponse.getDetailedCookies());
		
		
		/*System.out.println("jsession:" + jsession + "  vusid:" + vusid_incent + " xbaseSessionId:" + xbaseSessionId);
		String request = "/xtmca/login.do?sessionId=" + jsession + "&userEmail=" + userName
				+ "&remoteAddr=10.250.2.77";
		String request = "/xtmca/loadMetaData.do?method=launch&token=" + token ;
		Gson gson = new GsonBuilder().create();
		String data = "{\"sessionId\":" + jsession + ",\"vusid\":" + vusid_incent + ",\"userEmail\":" + userName
				+ ",\"remoteAddr\":10.250.2.77}";
		System.out.println("Json:" + gson.toJson(data));
		Response resp = rest.postRest(request, data);
		System.out.println("TMCA Response:" + resp.getDetailedCookies());*/
		LoginToRestAPI.setLoginresponse(loadMetaDataResponse);
		return loadMetaDataResponse;
		}

	public String logoutObjectives() throws Exception {
		String request = "/xmbo/clientws/api/v1/auth/logout";
		String resp = getRestAPI(request); //getRestAPIWithCSRF(request);
		return resp;
	}

	public Response loginToModelingUserdetails(Response respo) throws Exception {

		RestAPIHelperClass rest = new RestAPIHelperClass();
		LoginToRestAPI loginToRestAPI = new LoginToRestAPI();
		Response sessioninfo = getIncentSession(respo);
		// String url =
		// PreSetupRestAPI.symProPath.getProperty("https://int.xactlycorporation.local/xlsweb/loginEx.do");
		logger.info("Logging into Modeling :" + LoginToRestAPI.getUsername() + " url :"
				+ LoginToApplication.getRestAssuredBaseURI() + "/xiModel/loginEx.do");
		Response login = RestAssured.given().relaxedHTTPSValidation().cookies(respo.getCookies())
				.formParam("actionId", "null").formParam("customApp", "false").formParam("from_hidden", "1")
				.formParam("incentSessionInfo", getIncentsession()).formParam("sessionId", sessioninfo.asString())
				.formParam("targetApp", "Xactly Modeling").formParam("userEmail", LoginToRestAPI.getUsername())
				.formParam("vusid", LoginToRestAPI.getVusid()).expect().statusCode(200).when()
				.post(LoginToApplication.getRestAssuredBaseURI() + "/xiModel/loginEx.do");
		return login;
	}
	public static void logout(Response resp) throws Exception
	{
		logger.info("Logging out of Incent : "+Constants.envBaseUri+"/xicm/logout.async.do");
		Response rresp = RestAssured.given()
				.relaxedHTTPSValidation()
				.formParam("sessionId", resp.getCookie("requestid"))
				.formParam("loginType", "null")
				.expect()
				.statusCode(200).when().post(Constants.envBaseUri+"/xicm/logout.async.do");
		logger.info("Logged out of Incent "+rresp.body());
	}
	// To switch to modeling
	public Response getIncentSession(Response respo) throws Exception {

		RestAPIHelperClass rest = new RestAPIHelperClass();
		LoginToRestAPI loginToRestAPI = new LoginToRestAPI();
		logger.info("Request Cookies getIncentSession: " + respo.getCookies());

		logger.info("getIncentSession :" + LoginToRestAPI.getUsername() + " url :"
				+ LoginToApplication.getRestAssuredBaseURI()
				+ "/xicm/misc.ajax.do?action=getIncentSession&targetApp=Xactly%20Modeling");
		Response login = RestAssured.given().relaxedHTTPSValidation().cookies(respo.getCookies())
				.formParam("action", "getIncentSession").formParam("targetApp", "Xactly Modeling").expect()
				.statusCode(200).when().post(LoginToApplication.getRestAssuredBaseURI() + "/xicm/misc.ajax.do");

		String session = login.asString();
		logger.info("getIncentSession : " + session);
		int end = session.indexOf("|") + "|".length();
		String incentsession = session.substring(0, end - 1);
		logger.info("incentsession: " + incentsession);
		setIncentsession(incentsession);

		return login;
	}

	public Response ApploginToModeling(Response resp) throws Exception {

		// getIncentSession(resp);
		RestAPIHelperClass rest = new RestAPIHelperClass();
		LoginToRestAPI login = new LoginToRestAPI();
		Response respo = rest.loginToModelingUserdetails(resp);
		logger.info("loginToModelingUserdetails cookies :" + respo.getCookies());

		logger.info("Posting url : " + LoginToApplication.getRestAssuredBaseURI() + "/xiModel/loginExInit.do");
		Response loginappdo = RestAssured.given().relaxedHTTPSValidation().cookies(respo.getCookies())
				.formParam("sessionId", getIncentsession()).formParam("userEmail", LoginToRestAPI.getUsername())
				.formParam("userLoggedIn", "true").expect().statusCode(200).when()
				.post(LoginToApplication.getRestAssuredBaseURI() + "/xiModel/loginExInit.do");

		logger.info("AppLogin cookie /xiModel/loginExInit.do  :" + loginappdo.getCookies());
		LoginToRestAPI.setVusid(loginappdo.getCookie("vusid"));
		logger.info("VUSID :" + LoginToRestAPI.getVusid());

		return loginappdo;
	}

	public List<String> getBusinessPositionList() throws Exception {
		String response = getRestAPI("/v1/paycurve/-1/assignment/list?assignmentType=POSITION");
		JSONArray objectInfo = JsonPath.read(response, "$..name");
		List<String> posList = new ArrayList<String>();
		for (int i = 0; i < objectInfo.size(); i++)
			posList.add(objectInfo.get(i).toString());
		return posList;
	}

	public List<String> getBusinessTitleList() throws Exception {
		String response = getRestAPI("/v1/paycurve/-1/assignment/list?assignmentType=TITLE");
		JSONArray objectInfo = JsonPath.read(response, "$..name");
		List<String> titleList = new ArrayList<String>();
		for (int i = 0; i < objectInfo.size(); i++)
			titleList.add(objectInfo.get(i).toString());
		return titleList;
	}

	public List<String> getBusinessNumericFormulaList() throws Exception {
		String response = getRestAPI("/v1/ruleutil/formulas?formulaType=0");
		JSONArray objectInfo = JsonPath.read(response, "$..name");
		List<String> formulaList = new ArrayList<String>();
		for (int i = 0; i < objectInfo.size(); i++)
			formulaList.add(objectInfo.get(i).toString());
		return formulaList;
	}

	public Response putResetQueue(String path, String rbody) {
		String url = LoginToApplication.getRestAssuredBaseURI().substring(0,
				LoginToApplication.getRestAssuredBaseURI().length()) + path;
		url = url.replace("https", "http");
		logger.info("PUT API for : " + url);
		// logger.info("Response Body :"+rbody);
		Response resp = RestAssured.given().request().contentType(ContentType.JSON).body(rbody).when().expect()
				.statusCode(200).put(url);

		logger.info("The Response of the API : " + resp);
		return resp;
	}

	/**
	 * @param path
	 * @param statusCodeExpected
	 * @return
	 */
	public String getRestAPI(String path, int statusCodeExpected) {
		logger.info("Getting API for : " + Constants.restAPIPath + path);
		logger.info(LoginToRestAPI.loginresponse.getCookies());
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.when().expect().statusCode(statusCodeExpected).get(Constants.restAPIPath + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public String postRestAPIforUploadError(String path, File fileName,int errorCode) throws IOException {
		// String filepath = org.apache.commons.io.IOUtils.toString(fileName);
		// logger.info("I am uploading : "+fileName);
		logger.info("Posting API for : " + Constants.restAPIPath + path);
		String resp = RestAssured
				// .given().multiPart(new File(filepath))
				.given().multiPart(fileName).relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				// .contentType(ContentType.JSON)
				// .body(rbody)
				.when().expect().statusCode(errorCode).post(Constants.restAPIPath + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;

	}
	//Added the following simple Post and get http methods for xmdr . For XMDR we do not require any login  with cookies

	public Response postHttpRestCall(String postPathURI,String body){

		Response resp = RestAssured
				.given()
				.contentType(ContentType.JSON)
				.with().body(body)
				.when().post(postPathURI);
		return resp;

	}
	public Response postHttpRestCall(String postPathURI){

		Response resp = RestAssured
				.given().log().all()
				.contentType(ContentType.JSON)
				.when().post(postPathURI);

		return resp;

	}
	public Response getHttpRestCall(String pathURI){
		Response resp = RestAssured
				.given().log().all()
				.when().get(pathURI);

		return resp;

	}
	public Response getHttpRestCall(String pathURI,HashMap<String,String> queryParams){
		Response resp = RestAssured
				.given()
				.log().all()
				.parameters(queryParams)
				.when().get(pathURI);

		return resp;

	}
	public Response putHttpRestCallNoLogin(String pathURI,HashMap<String,Object> queryParams){
		Response resp = RestAssured
				.given().contentType(ContentType.JSON)
				.log().all()
				.parameters(queryParams)
				.when().put(pathURI);

		return resp;

	}
	
	public String putRestAPI(String path, String rbody, String charset) {

		logger.info("PUT API for : " + Constants.restAPIPath + path);
		// logger.info("Response Body :"+rbody);
		String resp = RestAssured.given()
								 .relaxedHTTPSValidation()
								 .cookies(LoginToRestAPI.loginresponse.getCookies())
								 .contentType("application/json;charset="+charset)
								 .body(rbody)
								 .when()
		.expect().statusCode(200).put(Constants.restAPIPath + path).asString();

		logger.info("The Response of the API : " + resp);
		return resp;
	}
	
	public Response getRestAPIWithoutBaseURI(String path, String baseURI) {

		logger.info("Getting API for : " + baseURI + path);

		logger.info(LoginToRestAPI.loginresponse.getCookies());

		Response resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())

				.when().expect().statusCode(200).get(baseURI + path);

		logger.info("The Response of the API : " + resp);

		return resp;

	}
	
	public Response getRestAPIStatusCode(String path, Response response)throws Exception {
		logger.info("Getting API for : " + Constants.restAPIPath + path);
		// logger.info(response.getCookies());
		Response resp = RestAssured.given().relaxedHTTPSValidation().cookies(response.getCookies()).when().expect()
				.get(Constants.restAPIPath + path);
		logger.info("The Response of the API : " + resp.asString());

		return resp;
	}
	
	public String postRestAPI(String path, String rbody,String charset) {
		logger.info("Posting API for : " + Constants.restAPIPath + path);
		String resp = RestAssured.given()
		.relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies()).contentType("application/json;charset="+charset)
				.body(rbody).when().expect().statusCode(200).post(Constants.restAPIPath + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}
	
	public String deleteRestAPI400(String path) {
		logger.info("Deleting API for : " + RestAssured.baseURI + ":" + RestAssured.port + RestAssured.basePath + path);
		String resp = RestAssured.given().log().everything(true).relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON).when().log()
				.everything(true).then().expect().statusCode(400).delete(Constants.restAPIPath + path).asString();
		return resp;
	}
	// For xlsx file down load as byte array

			public byte[] getRestAPIObieexlsx(String path, String rbody) {
				path = PreSetupRestAPI.analyticsBaseUriObiee + path;
				logger.info("Getting API for : " + path);
				Map<String, String> cookies = new HashMap<String, String>();
				cookies.putAll(LoginToRestAPI.analyticsLoginResponse.getCookies());
				cookies.putAll(LoginToRestAPI.obieeLoginResponse.getCookies());
				logger.info("GET URL:" + path);
				logger.info("COOKIES:" + cookies);
				byte[] resopnse;
				resopnse = RestAssured.given().relaxedHTTPSValidation().cookies(cookies).when().expect().statusCode(200)
						.get(path).asByteArray();

				return resopnse;
			}

	public Response getRestAPIResponseUsingBaseURI(String path) {
		logger.info("Getting API for : " + Constants.restAPIPath + path);
		logger.info(LoginToRestAPI.loginresponse.getCookies());
		Response resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.when().expect().statusCode(200).get(Constants.envBaseUri + path);
		logger.info("The Response of the API getRestAPIResponse: " + resp.asString());
		return resp;
	}
	
	// This method used to post request without cookies
    public String postRestAPIWithoutCookies(String path,String body) {
        String resp = RestAssured.given().relaxedHTTPSValidation().contentType(ContentType.JSON).body(body).expect()
                .statusCode(200).when().post(path).asString();
        return resp;
    }
    
    // THis Method is used to get response with out login and cookies
	public String getRestAPIwithoutCookies(String path)
	{
		logger.info("Getting API for : "+path);
		String resp = RestAssured.given().relaxedHTTPSValidation().when().expect()
				.statusCode(200).get(path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}
	
    // THis Method is used to get response with out login and cookies and accept response as 500
	public String getRestAPIwithoutCookies400Response(String path)
	{
		logger.info("Getting API for : "+path);
		String resp = RestAssured.given().relaxedHTTPSValidation().when().expect()
				.statusCode(400).get(path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}
	
    // THis Method is used to get response with out login and cookies and accept response as 400
	public String getRestAPIwithoutCookies500Response(String path)
	{
		logger.info("Getting API for : "+path);
		String resp = RestAssured.given().relaxedHTTPSValidation().when().expect()
				.statusCode(500).get(path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}
	
    // THis Method is used to get response with out login and cookies but with BaseURI
	public Response getRestAPIwithBaseURI(String path)
	{
		logger.info("Getting API for : "+path);
		Response resp = RestAssured.given().relaxedHTTPSValidation().when().expect().statusCode(200).get(Constants.envBaseUri + path);
		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public String getRestAPIForProfiles(String path) {
		logger.info("Getting API for : " + Constants.envBaseUri + path);
		String resp = RestAssured.given().relaxedHTTPSValidation()
				.header("Content-Type", "application/json;charset=UTF-8")
				.cookies(LoginToRestAPI.loginresponse.getCookies()).when().expect().statusCode(200)
				.get(Constants.envBaseUri + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}

	public String putRestAPIWithCharsetUTF(String path, String rbody) {

		logger.info("PUT API for : " + Constants.envBaseUri + path);
		logger.info("Request Body :"+rbody);
		String resp = RestAssured.given()
				.relaxedHTTPSValidation()
				.header("Content-Type", "application/json;charset=UTF-8")
				.body(rbody)
				.cookies(LoginToRestAPI.loginresponse.getCookies()).when().expect().statusCode(200).put(Constants.envBaseUri + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}
	
// For IMC Admin UI
	public String putHttpRestCallNoLoginIMC(String pathURI,String rbody){
		Response resp = RestAssured
				.given().contentType(ContentType.JSON)
				.log().all()
				.body(rbody)
				.when().put(pathURI);
		logger.info("The Response of the API : " + resp.toString());
		return resp.toString();
	}

	public Response getRestAPINoLoginIMC(String path) {
		logger.info("Getting API for : "+path);
		Response resp = RestAssured.given()
				.log().all()
				.when().get(path);
		logger.info("The Response of the API : " + resp.toString());
		return resp;
	}
	
	public Response getRequest(String cookieName, String cookieVal, String path) {
		Response resp = RestAssured.given().relaxedHTTPSValidation().cookie(cookieName, cookieVal)
				.when().expect().statusCode(200).get(path).prettyPeek();
		return resp;
	}
	
	public Response postRest_BaseURL(String path, String rbody) {

		logger.info("Posting API for : " + Constants.envBaseUri + path);
		Response resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.contentType(ContentType.JSON).body(rbody).when().expect()
				.post(Constants.envBaseUri + path);

		logger.info("The Response of the API : " + resp);
		return resp;
	}
	
	public Response getPutRestAPIBody(String path,String rbody)

	{
		logger.info("Getting API for : " + LoginToApplication.getRestAssuredBaseURI() + path);
		RestAssured.baseURI = LoginToApplication.getRestAssuredBaseURI();
		String JSESSIONID = LoginToRestAPI.getLoginresponse().getCookie("JSESSIONID");
		Response response = RestAssured.given().header("Authorization", JSESSIONID)
				.log().everything(true).relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON+";charset=UTF-8")
				.body(rbody).when().expect().put(LoginToApplication.getRestAssuredBaseURI() + path); 
		logger.info("Response for Post Rest API is "+response.asString());
		 return response;
	}
	
	public Response getdeleteAPI(String path) {
		logger.info("Getting API for : " + LoginToApplication.getRestAssuredBaseURI() + path);
		RestAssured.baseURI = LoginToApplication.getRestAssuredBaseURI();
		String JSESSIONID = LoginToRestAPI.getLoginresponse().getCookie("JSESSIONID");
		Response resp = RestAssured.given().log().everything(true).relaxedHTTPSValidation()
				.cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON).when().log()
				.everything(true).then().delete(LoginToApplication.getRestAssuredBaseURI() + path);
		return resp;
	}
	
	public Response getPostRestAPIBody(String path,Object rbody) {
		logger.info("Getting API for : " + LoginToApplication.getRestAssuredBaseURI() + path);
		RestAssured.baseURI = LoginToApplication.getRestAssuredBaseURI();
		String JSESSIONID = LoginToRestAPI.getLoginresponse().getCookie("JSESSIONID");
		Response response = RestAssured.given().header("Authorization", JSESSIONID)
				.log().everything(true).relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies()).contentType(ContentType.JSON+";charset=UTF-8")
				.body(rbody).when().expect().post(LoginToApplication.getRestAssuredBaseURI() + path); 
		logger.info("Response for Post Rest API is "+response.asString());
		 return response;
	}

	public Response ApploginToComputeAdmin(String propertypath, String adminurlpath) throws Exception {

		RestAPIHelperClass rest = new RestAPIHelperClass();
		String userdetails = PreSetupRestAPI.userProPath.getProperty(propertypath);
		String[] user = userdetails.split(":");
		LoginToRestAPI.setUsername(user[0]);
		LoginToRestAPI.setPassword(user[1]);
		logger.info(user[0]);
		logger.info(user[1]);
		logger.info("Logging into Incent :" + user[0]);
		Response respo = null;
		respo = LoginToRestAPI.loginComputeAdminui(user[0], user[1], adminurlpath);

		return respo;
	}
	
	public Response getRestAPIResponseWithStatus(String path, Response response) {
		logger.info("Getting API for : " + Constants.restAPIPath + path);
		Response resp = RestAssured.given().relaxedHTTPSValidation().cookies(response.getCookies()).when().expect()
				.get(Constants.restAPIPath + path);
		logger.info("The Response of the API : " + resp.asString());
		return resp;
	}

	public String deleteRestAPI(String path, boolean isExpectStatusCodeReq) {
		logger.info("Deleting API for: " + RestAssured.baseURI + ":" + RestAssured.port + RestAssured.basePath + path);
		logger.info("isExpectStatusCodeReqired="+isExpectStatusCodeReq);
		
		String resp = RestAssured
						.given()
							.log()
							.everything(true)
							.relaxedHTTPSValidation()
							.cookies(LoginToRestAPI.loginresponse.getCookies())
							.contentType(ContentType.JSON)
						.when()
							.log()
							.everything(true)
						.then()
							.delete(Constants.restAPIPath + path)
							.asString();
		return resp;
	}
	
	public String getRestAPIResponseForError(String path) {
		logger.info("Getting API for : " + Constants.restAPIPath + path);
		String resp = RestAssured.given().relaxedHTTPSValidation().cookies(LoginToRestAPI.loginresponse.getCookies())
				.when().expect().get(Constants.restAPIPath + path).asString();
		logger.info("The Response of the API : " + resp);
		return resp;
	}

}