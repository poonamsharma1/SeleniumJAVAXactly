package com.xactly.xcommons.javahelper;

import java.util.List;

public class CommonJava {

	public static boolean isInteger(String s){
		
		try { 
	        Integer.parseInt(s); 
	    } catch(NumberFormatException e) { 
	        return false; 
	    } catch(NullPointerException e) {
	        return false;
	    }
	    // only got here if we didn't return false
	    return true;
	}
	
	public static boolean isDouble(String s){
		try {
			Double.parseDouble(s);
			return true;
		} catch(NumberFormatException e){
			return false;
		} catch(NullPointerException e){
			return false;
		}
	}
	
	public static String appendQuotesToStringArray(String[] strArray){
		StringBuilder str = new StringBuilder();
		str.append("[");
		for(String s : strArray){
			str.append("\""+s+"\",");
		}
		
		str.deleteCharAt(str.length()-1);
		str.append("]");
		return str.toString();
	}
	
	public  static boolean compareList(List ls1,List ls2){
		boolean res = false;
		if(ls1 != null && ls2 != null && (ls1.size() == ls2.size())){
	        ls1.removeAll(ls2);
	        if(ls1.isEmpty()){
	             res = true;
	        }     
		}
		 return res;
	}
	
}
