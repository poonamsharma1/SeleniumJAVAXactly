package com.xactly.xcommons.presetup;

public class ReportPortalJob implements Comparable{

	private String name;
	private String ownerName;
	private String ownerId;
	private String bugId="";
	private String id;
	private String status;
	private String totalCount;
	private String expectedTotalCount;
	private String differenceTotalCount;
	private String passCount;
	private String failCount;
	private String skipCount;
	private Integer toInvestigateCount;
	private long startTime;
	private long executionTime;

	public long getExecutionTime() {
		return executionTime;
	}

	public void setExecutionTime(long executionTime) {
		this.executionTime = executionTime;
	}

	public long getStartTime() {
		return startTime;
	}

	public void setStartTime(long startTime) {
		this.startTime = startTime;
	}

	public long getEndTime() {
		return endTime;
	}

	public void setEndTime(long endTime) {
		this.endTime = endTime;
	}

	private long endTime;

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getBugId() {
		return bugId;
	}

	public void setBugId(String bugId) {
		this.bugId = bugId;
	}

	public Integer getToInvestigateCount() {
		return toInvestigateCount;
	}

	public void setToInvestigateCount(Integer toInvestigateCount) {
		this.toInvestigateCount = toInvestigateCount;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(String totalCount) {
		this.totalCount = totalCount;
	}

	public String getExpectedTotalCount() {
		return expectedTotalCount;
	}

	public void setExpectedTotalCount(String expectedTotalCount) {
		this.expectedTotalCount = expectedTotalCount;
	}

	public String getPassCount() {
		return passCount;
	}

	public void setPassCount(String passCount) {
		this.passCount = passCount;
	}

	public String getFailCount() {
		return failCount;
	}

	public void setFailCount(String failCount) {
		this.failCount = failCount;
	}

	public String getSkipCount() {
		return skipCount;
	}

	public void setSkipCount(String skipCount) {
		this.skipCount = skipCount;
	}

	public boolean isBuildable() {
		return isBuildable;
	}

	public void setBuildable(boolean isBuildable) {
		this.isBuildable = isBuildable;
	}

	public String getDifferenceTotalCount() {
		return differenceTotalCount;
	}

	public void setDifferenceTotalCount(String differenceTotalCount) {
		this.differenceTotalCount = differenceTotalCount;
	}

	private boolean isBuildable;

	public int compareTo(Object o) {
		  String diffCountStr1=((ReportPortalJob)o).getDifferenceTotalCount();
		  int diffCount1 = Integer.parseInt(diffCountStr1);
		  int diffCount2 = Integer.parseInt(this.getDifferenceTotalCount());
		  return diffCount2-diffCount1;
	}
}
