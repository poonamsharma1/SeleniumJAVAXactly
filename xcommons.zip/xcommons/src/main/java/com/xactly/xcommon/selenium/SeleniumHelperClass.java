package com.xactly.xcommons.selenium;

import static org.openqa.selenium.support.locators.RelativeLocator.with;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.log4j.Logger;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.google.common.base.Function;
import com.xactly.xcommons.app.LoginToApplication;
import com.xactly.xcommons.restapi.LoginToRestAPI;

public class SeleniumHelperClass {
	public static Logger logger = Logger.getLogger(SeleniumHelperClass.class.getName());
	public static int timeout = 120;
	public static int pollingTime = 5;
	public static String lastFrame = null;
	public static HashMap<String, String> frameMap;
	public static int system_SpeedlimitMAX = 6000;
	public static int system_SpeedlimitMIN = 3000;
	public static XSSFSheet ExcelWSheet;
	public static XSSFWorkbook ExcelWBook;
	public static XSSFCell Cell;
	public static XSSFRow Row;
	public static WebDriverWait wait;


	public static WebElement clickProfilePic() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("profile_pic_outer", "headerFrame"));
	}

	public static WebElement clickUIToggle() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@class='slider round']", "profileFrame"));
	}


	public static void switchUI() throws Exception {
		SeleniumHelperClass.click(clickProfilePic());
		SeleniumHelperClass.waitForElmentToBeReady(clickUIToggle());
		SeleniumHelperClass.click(clickUIToggle());
		SeleniumHelperClass.waitForPageToLoad("mainFrame");
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	public static void waitForSpinner(String framename) throws Exception {

		Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
				.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofMillis(500))
				.ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);

		goToFrame(framename);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".k-loading-image")));
		wait.until(ExpectedConditions
				.not(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector(".k-loading-image"))));

	}

	public static String fetchCurrentFrame() {
		try {
			JavascriptExecutor jsExecutor = (JavascriptExecutor) SetWebDrivers.getDriver();
			String currentFrame = (String) jsExecutor.executeScript("return self.name");
			return currentFrame;
		} catch (WebDriverException e) {
			logger.warn("Failed at fetchCurrentFrame due to " + e.getMessage());
			return "";
		}
	}
	public static boolean doesWebElementContainStringByAttribute(WebElement element, String attribute, String contains) {
		return element.getAttribute(attribute).contains(contains);
	}

	public static void goToFrame(String frame) throws Exception {
		WebDriver driver = SetWebDrivers.getDriver();
		String currentFrame = fetchCurrentFrame();
		if (currentFrame != null && fetchCurrentFrame().equalsIgnoreCase(frame)) {
			return;
		}

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout * 2));
		frame = frame.toLowerCase();
		if (!frame.equals("") && !frame.equals("none") && !frame.equals("default")) {

			String val = (String) frameMap.get(frame);
			// logger.info(val);
			String[] set = val.split(" : ");
			driver.switchTo().defaultContent();

			for (String frm : set) {
				wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frm));
				logger.debug("Switching to the Frame " + frm);
			}
		}
	}

	public static boolean waitForElmentToBeReady(WebElement ele) {
		ele.isEnabled();
		ele.isDisplayed();
		return isVisible(ele, 10);
	}

	public static WebElement findWebElement(String locator, String locatorValue, String frameName) throws Exception {
		return findWebElement(locator, locatorValue, frameName, timeout);
	}

	public static WebElement findWebElement(String locator, String locatorValue, String frameName, int timeout)
			throws Exception {
		if (locator.equalsIgnoreCase(Constants.LOCATOR_ID)) {
			return findWebElementbyid(locatorValue, frameName, timeout);
		} else if (locator.equalsIgnoreCase(Constants.LOCATOR_NAME)) {
			return findWebElementbyName(locatorValue, frameName, timeout);
		} else if (locator.equalsIgnoreCase(Constants.LOCATOR_XPATH)) {
			return findWebElementbyXpath(locatorValue, frameName, timeout);
		} else if (locator.equalsIgnoreCase(Constants.LOCATOR_CSS)) {
			return findWebElementbyCssSelector(locatorValue, frameName, timeout);
		} else if (locator.equalsIgnoreCase(Constants.LOCATOR_CLASSNAME)) {
			return findWebElementbyclass(locatorValue, frameName, timeout);
		} else if (locator.equalsIgnoreCase(Constants.LOCATOR_LINKTEXT)) {
			return findWebElementbyLink(locatorValue, frameName, timeout);
		} else if (locator.equalsIgnoreCase(Constants.LOCATOR_TAGNAME)) {
			return findWebElementbyTagName(locatorValue, frameName, timeout);
		}
		return null;
	}

	public static WebElement findWebElementbyid(final String idString, String frameName, int timeout) throws Exception {

		goToFrame(frameName);
		waitInMS(system_SpeedlimitMIN / 2);
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
					.ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);

			WebElement obj = wait.until(new ExpectedCondition<WebElement>() {
				public WebElement apply(WebDriver d) {
					return d.findElement(By.id(idString));
				}
			});

			waitForElmentToBeReady(obj);
			return obj;
		} catch (Exception e) {
			logger.info("Exception in findWebElementbyid() :: String ID" + idString + " : " + e.toString());
			throw e;
		}
	}

	private static void waitInMS(long timeInMS) {
		try {
			Thread.sleep(timeInMS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void clearElement(WebElement element) {
		try {
			scrollElementIntoViewUsingJS(element);
			new Actions(SetWebDrivers.getDriver()).click(element).sendKeys(Keys.END).keyDown(Keys.SHIFT)
					.sendKeys(Keys.HOME).keyUp(Keys.SHIFT).sendKeys(Keys.BACK_SPACE).sendKeys("").perform();
		} catch (Exception e) {
			logger.info("clear element failed using actions class");
		}
		try {
			element.clear();
		} catch (Exception e) {
			logger.info("clear element failed using normal click");
		}
	}

	public static WebElement findWebElementbyid(final String idString) throws Exception {

		return findWebElementbyid(idString, "none", timeout);
	}

	public static WebElement findWebElementbyid(final String idString, String frameName) throws Exception {
		return findWebElementbyid(idString, frameName, timeout);
	}

	public static WebElement findWebElementbyLink(final String linktext, String frameName) throws Exception {
		return findWebElementbyLink(linktext, frameName, timeout);
	}

	public static WebElement findWebElementbyLink(final String linktext, String frameName, int timeout)
			throws Exception {
		goToFrame(frameName);
		waitInMS(system_SpeedlimitMIN / 2);
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
					.ignoring(NoSuchElementException.class);

			WebElement obj = wait.until(new ExpectedCondition<WebElement>() {

				public WebElement apply(WebDriver d) {

					return d.findElement(By.linkText(linktext));
				}
			});

			waitForElmentToBeReady(obj);
			return obj;

		} catch (Exception e) {
			logger.info("Exception in findWebElementbylink() :: linktext " + linktext + " : " + e.toString());
			throw e;
		}

	}

	public static WebElement findWebElementbyLink(final String linktext) throws Exception {

		return findWebElementbyLink(linktext, "none");
	}

	public static WebElement findWebElementbyTagName(final String tag, String frameName) throws Exception {
		return findWebElementbyTagName(tag, frameName, timeout);
	}

	public static WebElement findWebElementbyTagName(final String tag, String frameName, int timeout) throws Exception {
		goToFrame(frameName);
		waitInMS(system_SpeedlimitMIN / 2);
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
					.ignoring(NoSuchElementException.class);

			WebElement obj = wait.until(new ExpectedCondition<WebElement>() {

				public WebElement apply(WebDriver d) {

					return d.findElement(By.tagName(tag));
				}
			});

			waitForElmentToBeReady(obj);
			return obj;
		} catch (Exception e) {
			logger.info("Exception in findWebElementbylink() :: tag  " + tag + " : " + e.toString());
			throw e;
		}

	}

	public static WebElement findWebElementbyTagName(final String tag) throws Exception {

		return findWebElementbyTagName(tag, "none");
	}

	public static WebElement findWebElementbyName(final String name, String frameName) throws Exception {
		return findWebElementbyName(name, frameName, timeout);
	}

	public static WebElement findWebElementbyName(final String name, String frameName, int timeout) throws Exception {
		goToFrame(frameName);
		waitInMS(system_SpeedlimitMIN / 2);
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
					.ignoring(NoSuchElementException.class);

			WebElement obj = wait.until(new ExpectedCondition<WebElement>() {
				public WebElement apply(WebDriver d) {
					return d.findElement(By.name(name));
				}
			});

			waitForElmentToBeReady(obj);
			return obj;
		} catch (Exception e) {
			logger.info("Exception in FindWebElementbyName() :: name " + name + " : " + e.toString());
			throw e;
		}
	}

	public static WebElement findWebElementbyName(final String name) throws Exception {

		return findWebElementbyName(name, "none");
	}

	public static WebElement findWebElementbyXpath(final String xpathString, String frameName, int timeout)
			throws Exception {
		goToFrame(frameName);
		try {
			waitInMS(system_SpeedlimitMIN / 2);
			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
					.ignoring(NoSuchElementException.class);

			WebElement obj = wait.until(new ExpectedCondition<WebElement>() {
				public WebElement apply(WebDriver d) {
					return d.findElement(By.xpath(xpathString));
				}
			});

			waitForElmentToBeReady(obj);
			return obj;
		} catch (Exception e) {
			logger.info("Exception in findWebElementbyxpath() :: xpath " + xpathString + " : " + e.toString());
			throw e;
		}
	}

	public static WebElement findWebElementbyXpath(final String xpathString) throws Exception {

		return findWebElementbyXpath(xpathString, "none", timeout);
	}

	public static WebElement findWebElementbyXpath(final String xpathString, String frameName) throws Exception {
		return findWebElementbyXpath(xpathString, frameName, timeout);
	}

	public static WebElement findWebElementbyclass(final String idString, String frameName) throws Exception {
		return findWebElementbyclass(idString, frameName, timeout);
	}

	public static WebElement findWebElementbyclass(final String idString, String frameName, int timeout)
			throws Exception {
		goToFrame(frameName);
		waitInMS(system_SpeedlimitMIN / 2);
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
					.ignoring(NoSuchElementException.class);

			WebElement obj = wait.until(new ExpectedCondition<WebElement>() {
				public WebElement apply(WebDriver d) {
					return d.findElement(By.className(idString));
				}
			});

			waitForElmentToBeReady(obj);
			return obj;
		} catch (Exception e) {
			logger.info("Exception in findWebElementClass() :: Class Name" + idString + " : " + e.toString());
			throw e;
		}
	}

	public static WebElement findWebElementbyclass(final String idString) throws Exception {

		return findWebElementbyclass(idString, "none");
	}

	public static WebElement findWebElementbyCssSelector(final String css, String frameName) throws Exception {
		return findWebElementbyCssSelector(css, frameName, timeout);
	}

	public static WebElement findWebElementbyCssSelector(final String css, String frameName, int timeout)
			throws Exception {
		goToFrame(frameName);
		waitInMS(system_SpeedlimitMIN / 2);
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
					.ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);

			WebElement obj = wait.until(new ExpectedCondition<WebElement>() {
				public WebElement apply(WebDriver d) {
					return d.findElement(By.cssSelector(css));
				}
			});

			waitForElmentToBeReady(obj);
			return obj;
		} catch (Exception e) {
			logger.info("Exception in findWebElementbyCssSelector() :: css " + css + " : " + e.toString());
			throw e;
		}
	}

	public static WebElement findWebElementbyCssSelector(final String css) throws Exception {

		return findWebElementbyCssSelector(css, "none");
	}

	/**
	 * This method switch the driver control to the Recent Pop Up window
	 */
	public static String switchToPopupWindow() {
		WebDriver driver = SetWebDrivers.getDriver();
		String parentWindow = driver.getWindowHandle();
		logger.info("Parent window : " + parentWindow);
		String recentWindow = "";
		Set<String> windowHandlers = new LinkedHashSet<String>();
		windowHandlers = driver.getWindowHandles();
		logger.info("Total no. of windows : " + windowHandlers.size());
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				recentWindow = windowHandle;
			}
		}
		logger.info("Switching to new window : " + recentWindow);
		driver.switchTo().window(recentWindow);
		return parentWindow;
	}

	/**
	 * This method switch the driver control to the Parent window
	 */
	public static void switchToWindow(String windowHandle) {
		SetWebDrivers.getDriver().switchTo().window(windowHandle);
	}

	public static void findWebElementAndEnableDisplay(final String classStringToHover, String frameName, String index)
			throws Exception {
		goToFrame(frameName);
		try {
			WebDriver driver = SetWebDrivers.getDriver();
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("document.getElementsByClassName('" + classStringToHover + "')[" + index
					+ "].style.display='block';");

		} catch (Exception e) {
			logger.info("Exception in findWebElementbyxpath() :: xpath " + classStringToHover + " : " + e.toString());
			logger.info(e.toString());
			throw e;
		}
	}

	public static void closeCurrentWindow() {
		SetWebDrivers.getDriver().close();

	}

	public static void switchToChildWindow() throws InterruptedException {
		WebDriver driver = SetWebDrivers.getDriver();
		String parent = driver.getWindowHandle();
		Set<String> windows = driver.getWindowHandles();
		for (String window : windows) {
			if (!window.contains(parent)) {
				driver.switchTo().window(window);
			}
		}
		Thread.sleep(1000);
	}

	public static void switchToChildWindow(String pageTitle) throws InterruptedException {
		WebDriver driver = SetWebDrivers.getDriver();
		String parent = driver.getWindowHandle();
		Set<String> windows = driver.getWindowHandles();
		for (String window : windows) {
			if (!window.contains(parent)) {
				driver.switchTo().window(window);
				if (SetWebDrivers.getDriver().getTitle().equalsIgnoreCase(pageTitle)) {
					break;
				}
			}
		}
		Thread.sleep(1000);
	}

	public static void switchToChildWindow(String pageTitle, int expectedCount) throws InterruptedException {
		WebDriver driver = SetWebDrivers.getDriver();
		logger.info("Current window Title :" + SetWebDrivers.getDriver().getTitle());
		int count = 0;
		Set<String> windows = driver.getWindowHandles();
		while (windows.size() != expectedCount && count < 3) {
			windows = driver.getWindowHandles();
			count++;
		}
		for (String window : windows) {
			driver.switchTo().window(window);
			logger.info("Switching to window with Title :" + SetWebDrivers.getDriver().getTitle());
			if (SetWebDrivers.getDriver().getTitle().equalsIgnoreCase(pageTitle)) {
				logger.info("Found Desired Title of Page :" + SetWebDrivers.getDriver().getTitle());
				break;
			}
		}
		Thread.sleep(1000);
	}

	public static String getParentWindow() throws InterruptedException {
		WebDriver driver = SetWebDrivers.getDriver();
		String parent = driver.getWindowHandle();
		Thread.sleep(1000);
		return parent;
	}

	public static void closeChildWindowAndSwitchToParent(String parent) throws Exception {
		WebDriver driver = SetWebDrivers.getDriver();
		Set<String> windows = driver.getWindowHandles();
		for (String window : windows) {
			if (!window.contains(parent)) {
				driver.switchTo().window(window);
				driver.close();
			}
		}
		Thread.sleep(1000);
		driver.switchTo().window(parent);
		Thread.sleep(1000);
	}

	public static void closeChildWindow() throws Exception {
		WebDriver driver = SetWebDrivers.getDriver();
		String parent = driver.getWindowHandle();
		Set<String> windows = driver.getWindowHandles();
		for (String window : windows) {
			if (!window.contains(parent)) {
				driver.switchTo().window(window);
				driver.close();
			}
		}
		Thread.sleep(1000);
		driver.switchTo().window(parent);
		Thread.sleep(1000);
	}

	public static WebElement findWebElementInWebElement(WebElement ele, final String how, final String value,
														String frameName) throws Exception {
		goToFrame(frameName);
		try {
			Wait<WebElement> wait = new FluentWait<WebElement>(ele).withTimeout(Duration.ofSeconds(timeout))
					.pollingEvery(Duration.ofSeconds(pollingTime)).ignoring(NoSuchElementException.class);

			WebElement obj = wait.until(new Function<WebElement, WebElement>() {
				public WebElement apply(WebElement d) {
					WebElement e = null;
					if (how.equals("xpath"))
						e = d.findElement(By.xpath(value));
					else if (how.equals("id"))
						e = d.findElement(By.id(value));
					else if (how.equals("css"))
						e = d.findElement(By.cssSelector(value));
					else if (how.equals("class"))
						e = d.findElement(By.className(value));
					else if (how.equals("tag"))
						e = d.findElement(By.tagName(value));

					return e;
				}
			});
			logger.info("Found element with  " + how + " : " + value);
			return obj;
		} catch (Exception e) {
			logger.info("Exception in findWebElementbyxpath() :: " + how + " ->" + value + " : " + e.toString());
			throw e;
		}
	}

	public static List<WebElement> findWebElementsInWebElement(WebElement ele, final String how, final String value,
															   String frameName) throws Exception {
		goToFrame(frameName);
		try {
			Wait<WebElement> wait = new FluentWait<WebElement>(ele).withTimeout(Duration.ofSeconds(timeout))
					.pollingEvery(Duration.ofSeconds(pollingTime)).ignoring(NoSuchElementException.class);

			List<WebElement> obj = wait.until(new Function<WebElement, List<WebElement>>() {
				public List<WebElement> apply(WebElement d) {
					List<WebElement> list = null;
					if (how.equals("xpath"))
						list = d.findElements(By.xpath(value));
					else if (how.equals("id"))
						list = d.findElements(By.id(value));
					else if (how.equals("css"))
						list = d.findElements(By.cssSelector(value));
					else if (how.equals("class"))
						list = d.findElements(By.className(value));
					else if (how.equals("tag"))
						list = d.findElements(By.tagName(value));
					else if (how.equals("innerhtml"))
						list = d.findElements(By.className(value));

					return list;
				}
			});

			return obj;
		} catch (Exception e) {
			logger.info("Exception in findWebElementbyxpath() :: " + how + " ->" + value + " : " + e.toString());
			throw e;
		}
	}

	public static List<WebElement> findWebElementsInWebElement(String ele, final String how, final String value)
			throws Exception {
		// goToFrame(frameName);
		WebElement el = SeleniumHelperClass.findWebElementbyid(ele);
		try {
			Wait<WebElement> wait = new FluentWait<WebElement>(el).withTimeout(Duration.ofSeconds(timeout))
					.pollingEvery(Duration.ofSeconds(pollingTime)).ignoring(NoSuchElementException.class)
					.ignoring(StaleElementReferenceException.class);

			List<WebElement> obj = wait.until(new Function<WebElement, List<WebElement>>() {
				public List<WebElement> apply(WebElement d) {
					List<WebElement> list = null;
					if (how.equals("xpath"))
						list = d.findElements(By.xpath(value));
					else if (how.equals("id"))
						list = d.findElements(By.id(value));
					else if (how.equals("css"))
						list = d.findElements(By.cssSelector(value));
					else if (how.equals("class"))
						list = d.findElements(By.className(value));

					return list;
				}
			});

			return obj;
		} catch (Exception e) {
			logger.info("Exception in findWebElementsInWebElement() :: " + how + " ->" + value + " : " + e.toString());
			throw e;
		}
	}

	public static List<WebElement> findWebElementsInTag(final String tagName, String frameName) throws Exception {
		goToFrame(frameName);
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
					.ignoring(NoSuchElementException.class);
			List<WebElement> obj = wait.until(new ExpectedCondition<List<WebElement>>() {
				public List<WebElement> apply(WebDriver d) {
					return d.findElements(By.tagName(tagName));
				}
			});

			return obj;
		} catch (Exception e) {
			logger.info("Exception in findWebElements() :: xpath " + tagName + " : " + e.toString());
			throw e;
		}
	}

	public static List<WebElement> findWebElements(final String xpathString, String frameName) throws Exception {
		goToFrame(frameName);
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
					.ignoring(NoSuchElementException.class);

			List<WebElement> obj = wait.until(new ExpectedCondition<List<WebElement>>() {
				public List<WebElement> apply(WebDriver d) {
					return d.findElements(By.xpath(xpathString));
				}
			});

			return obj;
		} catch (Exception e) {
			logger.info("Exception in findWebElements() :: xpath " + xpathString + " : " + e.toString());
			throw e;
		}
	}

	public static List<WebElement> findWebElementsById(final String id, String frameName) throws Exception {
		return findWebElementsById(id, frameName, timeout);
	}

	public static List<WebElement> findWebElementsById(final String id, String frameName, int timeout)
			throws Exception {
		goToFrame(frameName);
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
					.ignoring(NoSuchElementException.class);

			List<WebElement> obj = wait.until(new ExpectedCondition<List<WebElement>>() {
				public List<WebElement> apply(WebDriver d) {
					return d.findElements(By.id(id));
				}
			});

			return obj;
		} catch (Exception e) {
			logger.info("Exception in findWebElements() :: id " + id + " : " + e.toString());
			throw e;
		}
	}

	public static List<WebElement> findWebElementsByCss(final String css, String frameName) throws Exception {
		goToFrame(frameName);
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
					.ignoring(NoSuchElementException.class);

			List<WebElement> obj = wait.until(new ExpectedCondition<List<WebElement>>() {
				public List<WebElement> apply(WebDriver d) {
					return d.findElements(By.cssSelector(css));
				}
			});

			return obj;
		} catch (Exception e) {
			logger.info("Exception in findWebElements() :: id " + css + " : " + e.toString());
			throw e;
		}
	}

	public static List<WebElement> findWebElementsInClass(final String className, String frameName) throws Exception {
		return findWebElementsInClass(className, frameName, timeout);
	}

	public static List<WebElement> findWebElementsInClass(final String className, String frameName, int timeout)
			throws Exception {
		goToFrame(frameName);
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
					.ignoring(NoSuchElementException.class);
			List<WebElement> obj = wait.until(new ExpectedCondition<List<WebElement>>() {
				public List<WebElement> apply(WebDriver d) {
					return d.findElements(By.className(className));
				}
			});

			return obj;
		} catch (Exception e) {
			logger.info("Exception in findWebElements() :: xpath " + className + " : " + e.toString());
			throw e;
		}
	}

	public static List<WebElement> findWebElementsInXpath(final String xpathString, String frameName) throws Exception {
		return findWebElementsInXpath(xpathString, frameName, timeout);
	}

	public static List<WebElement> findWebElementsInXpath(final String xpathString, String frameName, int timeout)
			throws Exception {
		goToFrame(frameName);
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
					.ignoring(NoSuchElementException.class);
			List<WebElement> obj = wait.until(new ExpectedCondition<List<WebElement>>() {
				public List<WebElement> apply(WebDriver d) {
					return d.findElements(By.xpath(xpathString));
				}
			});

			return obj;
		} catch (Exception e) {
			logger.info("Exception in findWebElements() :: xpath " + xpathString + " : " + e.toString());
			throw e;
		}
	}

	public static Select selectFromDropdown(String objectID, String frameName) throws Exception {
		Select select = new Select(findWebElementbyName(objectID, frameName));
		return select;

	}

	public static Select selectFromDropdownwithelements(String how, String objectID, String frameName)
			throws Exception {
		Select select = null;
		if (how.equals("id"))
			select = new Select(findWebElementbyid(objectID, frameName));
		else if (how.equals("xpath"))
			select = new Select(findWebElementbyXpath(objectID, frameName));
		else if (how.equals("css"))
			select = new Select(findWebElementbyCssSelector(objectID, frameName));
		else if (how.equals("name"))
			select = new Select(findWebElementbyName(objectID, frameName));

		return select;

	}

	public static Select selectFromRadioButton(String objectID, String frameName) throws Exception {
		Select select = new Select(findWebElementbyid(objectID, frameName));
		return select;

	}

	public static WebElement get_delete_conf_button() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("confirm-button", "mainframe");
	}

	public static void acceptDeleteConfirmation() throws Exception {
		WebElement deleteButton = get_delete_conf_button();
		waitInMS(2000);
		deleteButton.click();
		// waitInMS(2000);
	}

	public static void selectFromPopup(String popupLinkId, String searchFieldId, String searchString, String frame)
			throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		SeleniumHelperClass.findWebElementbyid(popupLinkId, frame).click();
		waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		System.out.println("Windows opened :" + windowHandlers.size());
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				try {
					SetWebDrivers.getDriver().switchTo().window(windowHandle);
					logger.info("Switched to Child window");
					waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
					WebElement nameTextField = SeleniumHelperClass
							.findWebElementbyXpath("//input[starts-with(@id, '" + searchFieldId + "')]");
					SeleniumHelperClass.clearElement(nameTextField);
					nameTextField.sendKeys(searchString);
					WebElement searchButton = SeleniumHelperClass.findWebElementbyXpath("//*[@id=\"searchButton\"]");
					SeleniumHelperClass.isClickable(searchButton, 10);
					searchButton.click();
					// waitInMS(3000);
					waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
					WebElement table = SeleniumHelperClass.findWebElementbyXpath("//*[@id=\"tableFixed\"]");
					// .findWebElementbyid("tableFixed");

					// logger.info(getNumberOfResultsFromUI("none"));

					clickFirstRowOfTable(table);

					// clickFirstRowOfTable();
					// SeleniumHelperClass.findWebElementbyXpath("//td/div").click();
					SeleniumHelperClass.findWebElementbyXpath("//*[@id=\"okButton\"]").click();
				} catch (Exception e) {
					Thread.currentThread().interrupt();
					SetWebDrivers.getDriver().close();
					logger.info("Closed the child window");
					// SeleniumHelperClass.findWebElementbyid("cancelButton").click();
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}

		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
	}

	/*
	 * Select first row from the popup without performing any search
	 */
	public static void selectFirstRowFromPopup() throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				SetWebDrivers.getDriver().switchTo().window(windowHandle);
				try {
					logger.info("Switched to Child window");
					waitInMS(3000);
					WebElement table = SeleniumHelperClass.findWebElementbyid("tableFixed");

					clickFirstRowOfTable(table);

					SeleniumHelperClass.findWebElementbyid("okButton").click();
				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the child window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}

		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
	}

	/*
	 * to search a value from pop-up list where pop up does not have search field
	 */
	public static void selectFromPopupxpath(String searchFieldId, String searchString) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				SetWebDrivers.getDriver().switchTo().window(windowHandle);
				try {
					logger.info("Switched to Child window");
					SeleniumHelperClass.findWebElementbyid(searchFieldId).sendKeys(searchString);
					WebElement searchButton = SeleniumHelperClass.findWebElementbyid("searchButton");
					searchButton.click();
					waitInMS(3000);
					WebElement table = SeleniumHelperClass.findWebElementbyid("tableFixed");

					// logger.info(getNumberOfResultsFromUI("none"));

					clickFirstRowOfTable(table);
					// clickFirstRowOfTable();
					// SeleniumHelperClass.findWebElementbyXpath("//td/div").click();
					SeleniumHelperClass.findWebElementbyid("okButton").click();
				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the child window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}

		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
	}

	public static void selectFromPopupwithoutsearch(String searchString) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				try {
					SetWebDrivers.getDriver().switchTo().window(windowHandle);
					waitInMS(3000);
					logger.info("Switched to Child window");
					WebElement table = SeleniumHelperClass
							.findWebElementbyXpath("html/body/table[4]/tbody/tr[1]/td/form/div/table/tbody");
					List<WebElement> rows_table = table.findElements(By.tagName("tr"));
					int rows_count = rows_table.size();
					for (int row = 0; row < rows_count; row++) {
						logger.info("Row: " + row);
						List<WebElement> Columns_row = rows_table.get(row).findElements(By.tagName("td"));
						for (int column = 0; column < 1; column++) {
							String celtext = Columns_row.get(column).getText();
							if (celtext.equals(searchString)) {
								int rw = row + 1;
								SeleniumHelperClass.findWebElementbyXpath(
												"html/body/table[4]/tbody/tr[1]/td/form/div/table/tbody/tr[" + rw
														+ "]/td[1]/div")
										.click();
								break;
							}

						}
					}
					SeleniumHelperClass.findWebElementbyid("okButton").click();
				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the child window");
					// SeleniumHelperClass.findWebElementbyid("cancelButton").click();
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}

		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
	}

	public static void deleteFromPopupWithComment(String commentId, String deleteComment) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				SetWebDrivers.getDriver().switchTo().window(windowHandle);
				try {
					logger.info("Switched to Child window");
					SeleniumHelperClass.findWebElementbyid(commentId).sendKeys(deleteComment);
					/*
					 * WebElement deleteButton = SeleniumHelperClass
					 * .findWebElementbyXpath(".//*[@onclick='doDelete()']"); deleteButton.click();
					 */

					// Workaround for clicking the Delete button
					WebElement deleteButton = SeleniumHelperClass
							.findWebElementbyXpath("//center/table/tbody/tr[3]/td/button");
					deleteButton.sendKeys("");
					deleteButton.click();

					waitInMS(2000);
				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the child window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}

		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
	}

	public static void secondaryClick(WebElement element) {
		JavascriptExecutor executor = (JavascriptExecutor) SetWebDrivers.getDriver();
		executor.executeScript("arguments[0].click();", element);
	}

	public static void dragAndDropFromPopup() throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		logger.info("Windows" + windowHandlers);
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				SetWebDrivers.getDriver().switchTo().window(windowHandle);
				try {
					logger.info("Switched to Child window");
					WebElement moveAll = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='moveAllLeft_']/img");
					moveAll.click();
					WebElement okButton = SeleniumHelperClass.findWebElementbyXpath(".//input[@value=' OK ']");
					okButton.click();
					waitInMS(3000);
				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the child window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}

		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
	}

	public static void downloadTemplate(String uploadButtonId, String frame) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		SeleniumHelperClass.findWebElementbyid(uploadButtonId, frame).click();
		waitInMS(2000);
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				SetWebDrivers.getDriver().switchTo().window(windowHandle);
				try {
					SeleniumHelperClass.findWebElementbyLink("Click here", "uploadPeopleFrame").click();
					logger.info("File Download is in progress");
					waitInMS(10000);
					SeleniumHelperClass.findWebElementbyXpath(".//*[@onclick='doCancel()']", "uploadPeopleFrame")
							.click();
				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the child window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}
		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
	}

	public static void uploadFiles(WebElement uploadElement, String url, String uploadFrame) throws Exception {
		// logger.info(url.getPath());
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		click(uploadElement);
		waitInMS(4000);
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		logger.info(windowHandlers);
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {

				SetWebDrivers.getDriver().switchTo().window(windowHandle);
				try {

					waitInMS(SeleniumHelperClass.system_SpeedlimitMAX * 2);
					SetWebDrivers.getDriver().switchTo().frame(uploadFrame);
					WebElement uploadField = SeleniumHelperClass.findWebElementbyXpath("//input[@type='file']");
					uploadField.sendKeys(url);
					waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
					click(SeleniumHelperClass.findWebElementbyXpath(".//*[@type='submit']"));
					waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
					SeleniumHelperClass.isVisible(SeleniumHelperClass.findWebElementbyTagName("body"), 10);
					String bodyText = SeleniumHelperClass.findWebElementbyTagName("body", "").getText();
					logger.info(bodyText);

					if (bodyText.contains("File was uploaded successfully")) {
						logger.info("sync upload was successfull");
						WebElement ok = SeleniumHelperClass.findWebElementbyXpath(".//*[@onclick='done()']");
						click(ok);

					} else if (bodyText.contains(
							"Your upload request is being processed and when completed will appear in the myUploads page.")) {
						logger.info("async upload was successfull");
						SeleniumHelperClass.findWebElementbyXpath(".//*[@type='button']").click();
						/*
						 * WebElement OK=SeleniumHelperClass.findWebElementbyXpath
						 * (".//*[@onclick='doOk()']"); OK.click();
						 */
						// SeleniumHelperClass.findWebElementbyXpath(".//*[@type='button']").click();
					} else if (bodyText.contains("This import process is now running in the background.")) {
						logger.info("Upload was successfull");
						SeleniumHelperClass.findWebElementbyXpath(".//*[@type='button']").click();
					}

				} catch (Exception e) {
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}

			}
		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);

	}

	public static WebElement getTableData(WebElement tableElement, String element, int elementposition)
			throws Exception {

		// create empty table object and iterate through all rows of the found table
		// element
		ArrayList<HashMap<String, WebElement>> userTable = new ArrayList<HashMap<String, WebElement>>();
		ArrayList<WebElement> rowElements = (ArrayList<WebElement>) tableElement.findElements(By.xpath(".//tr"));

		// get column names of table from table headers
		ArrayList<String> columnNames = new ArrayList<String>();
		ArrayList<WebElement> headerElements = (ArrayList<WebElement>) rowElements.get(0)
				.findElements(By.xpath(".//th"));
		for (WebElement headerElement : headerElements) {
			columnNames.add(headerElement.getText());
			// logger.info("Headers :"+headerElement.getText());
			logger.info("Headers :" + headerElement.getText());
		}
		// iterate through all rows and add their content to table array
		for (WebElement rowElement : rowElements) {

			HashMap<String, WebElement> row = new HashMap<String, WebElement>();
			// add table cells to current row
			int columnIndex = 0;
			ArrayList<WebElement> cellElements = (ArrayList<WebElement>) rowElement.findElements(By.xpath(".//td"));
			for (WebElement cellElement : cellElements) {
				row.put(columnNames.get(columnIndex), cellElement);
				logger.info("columnIndex :" + columnIndex + " cellElement :" + cellElement.getText());
				// logger.info("cellElement :"+cellElement.getText());
				columnIndex++;
			}
			userTable.add(row);
		}
		WebElement columnelement = userTable.get(elementposition).get(element);
		logger.info("columnElement :" + columnelement.getText());
		// logger.info("columnElement : " + columnelement.getText());
		return columnelement;
	}

	public static void clickFirstRowOfTable(WebElement tableElement) throws Exception {
		WebElement firstRow = null;
		ArrayList<WebElement> rowElements = (ArrayList<WebElement>) tableElement.findElements(By.xpath(".//tr"));
		if (rowElements.size() > 1)
			firstRow = rowElements.get(1);
		else
			throw new Exception("Required row is not found");
		SeleniumHelperClass.click(firstRow);
	}

	public static void clickSecondRowOfTable(WebElement tableElement) throws Exception {
		WebElement secondRow = null;
		ArrayList<WebElement> rowElements = (ArrayList<WebElement>) tableElement.findElements(By.xpath(".//tr"));
		if (rowElements.size() > 1)
			secondRow = rowElements.get(2);
		else
			throw new Exception("Required row is not found");
		SeleniumHelperClass.click(secondRow);
	}

	public static WebElement getTableRow(WebElement tableElement, int row) throws Exception {
		WebElement row1 = null;
		ArrayList<WebElement> rowElements = (ArrayList<WebElement>) tableElement.findElements(By.xpath(".//tr"));
		if (rowElements.size() > row)
			row1 = rowElements.get(row);
		else
			throw new Exception("Required row is not found");
		return row1;
	}

	public static int getTableRowCount(WebElement tableElement) throws Exception {
		WebElement row1 = null;
		ArrayList<WebElement> rowElements = (ArrayList<WebElement>) tableElement.findElements(By.xpath(".//tr"));
		return rowElements.size();
	}

	public static WebElement getTableCell(WebElement tableElement, String headerName, int row) throws Exception {
		WebElement cell = null;
		WebElement headerRow = getTableRow(tableElement, 0);
		WebElement requiredRow = getTableRow(tableElement, row);
		ArrayList<WebElement> headerCells = (ArrayList<WebElement>) headerRow.findElements(By.xpath(".//th"));
		ArrayList<WebElement> requiredCells = (ArrayList<WebElement>) requiredRow.findElements(By.xpath(".//td"));
		int rowIndex = 0;
		for (WebElement header : headerCells) {
			if (header.getText().equals(headerName)) {
				cell = requiredCells.get(rowIndex);
				logger.info("Header Name: " + header.getText() + "Element Text: " + cell.getText());
			}
			rowIndex++;
		}

		return cell;
	}

	public static ArrayList<String> getTableHeaders_NewUI(String frameName) throws Exception { // New UI
		ArrayList<String> headers = new ArrayList<String>();
		waitInMS(2000);
		WebElement div = null;
		SeleniumHelperClass.findWebElementbyXpath(".//*[contains(@class,'list-item-header')]", frameName);
		List<WebElement> divTags = SeleniumHelperClass.findWebElements(".//*[contains(@class,'list-item-header')]",
				frameName);
		for (WebElement divTag : divTags) {
			div = divTag;
		}

		List<WebElement> list = SeleniumHelperClass.findWebElementsInWebElement(div, "tag", "span", frameName);
		for (WebElement ele : list) {
			String className = ele.getAttribute("class");
			// String style=ele.getAttribute("style");
			String s = SeleniumHelperClass.FindAttribute("innerhtml", ele);
			if (className.contains("-select-column")) {
				headers.add("select");
			} else if ((!s.contains("</") && !s.equals(""))) {
				headers.add(s);
			}
		}
		return headers;
	}

	public static List<WebElement> get_table_list_obj(String tblelistObj, String frameName) throws Exception {
		return SeleniumHelperClass.findWebElements(".//*[@class='" + tblelistObj + "']", frameName);
	}

	public static WebElement getTableCell_NewUI(String headerName, int rowNum, String tablelistObj, String frameName)
			throws Exception {
		// possible values for tblelistObj are ".//*[@class='list']" ,
		// ".//*[@class='list ui-sortable']"
		WebElement requiredCell = null;
		ArrayList<String> headers = getTableHeaders_NewUI(frameName);
		// logger.info(headers);
		int colIndex = 0;
		for (String header : headers) {
			if (header.equalsIgnoreCase(headerName)) {
				logger.info(header + " matched");
				break;
			}

			colIndex++;
			logger.info("colIndex:" + colIndex);
		}

		if (colIndex == headers.size())
			colIndex = -1;
		List<WebElement> classLists = get_table_list_obj(tablelistObj, frameName);
		logger.info("classList:" + classLists);
		WebElement dataList = null;
		for (WebElement classList : classLists)
			dataList = classList;
		List<WebElement> rows = null;
		WebElement requiredRow = null;
		if (dataList != null) {
			rows = SeleniumHelperClass.findWebElementsInWebElement(dataList, "tag", "li", frameName);
			logger.info("rows:" + rows);
			int rowNo = 1;
			for (WebElement row : rows) {
				if (rowNo == rowNum) {
					requiredRow = row;
					break;
				}
				rowNo++;
			}
		}
		List<WebElement> cols = null;
		if (requiredRow != null) {
			cols = SeleniumHelperClass.findWebElementsInWebElement(requiredRow, "tag", "span", frameName);
			logger.info("cols size:" + cols.size());
			int colNo = 0;
			for (WebElement col : cols) {
				logger.info("Col" + colNo + " innerhtml:" + SeleniumHelperClass.FindAttribute("innerhtml", col));
				if (!SeleniumHelperClass.FindAttribute("innerhtml", col).equals("")) {
					// &&!SeleniumHelperClass.FindAttribute("innerhtml",
					// col).contains("<span")
					if (colNo == colIndex) {
						if (headerName.equalsIgnoreCase("select")) {
							requiredCell = SeleniumHelperClass.findWebElementInWebElement(col, "xpath",
									".//*[@type='checkbox']", frameName);
						} else {
							requiredCell = col;
							break;
						}
					}
					colNo++;
				}
			}
		}
		logger.info("Required Cell:" + requiredCell);
		logger.info("req cell data:" + SeleniumHelperClass.FindAttribute("innerhtml", requiredCell));
		return requiredCell;
	}

	public static WebElement getTableCell_NewUI_getrow(String headerName, int rowNum, String tablelistObj,
													   String frameName) throws Exception {
		// possible values for tblelistObj are ".//*[@class='list']" ,
		// ".//*[@class='list ui-sortable']"
		ArrayList<String> headers = getTableHeaders_NewUI(frameName);
		int colIndex = 0;
		for (String header : headers) {
			if (header.equalsIgnoreCase(headerName))
				break;
			colIndex++;
		}
		if (colIndex == headers.size())
			colIndex = -1;
		List<WebElement> classLists = get_table_list_obj(tablelistObj, frameName);
		WebElement dataList = null;
		for (WebElement classList : classLists)
			dataList = classList;
		List<WebElement> rows = null;
		WebElement requiredRow = null;
		if (dataList != null) {
			rows = SeleniumHelperClass.findWebElementsInWebElement(dataList, "tag", "li", frameName);
			int rowNo = 1;
			for (WebElement row : rows) {
				// logger.info("rows:"+row+" row text: "+row.getText());
				if (rowNo == rowNum) {
					requiredRow = row;
					break;
				}
				rowNo++;
			}
		}
		return requiredRow;
	}

	public static void waitUntilLoaderDisappears() throws Exception {
		waitInMS(1000);
		final String frameBefore = SeleniumHelperClass.lastFrame;
		Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
				.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
				.ignoring(NoSuchElementException.class);
		// WebDriverWait wait=new WebDriverWait(SetWebDrivers.getDriver(),
		// timeout);
		wait.until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				try {
					if (!SeleniumHelperClass.findWebElementbyXpath(".//iframe[@id='pFrame']", "default")
							.isDisplayed()) {
						goToFrame(frameBefore);
						return true;

					} else {
						logger.info("Waiting for loader to disappear ");
						goToFrame(frameBefore);
						return false;
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					logger.info("Loader not found");
					try {
						goToFrame(frameBefore);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					return true;
					// e.printStackTrace();
				}
			}
		});

	}

	// Used to check whether the page has been loaded
	public static void waitforPageToLoad(String how, String value, String frame) throws Exception {
		waitInMS(2000);

		for (int i = 0; i < 2; i++) {
			if (!isElementPresent(how, value, frame, 2)) {
				logger.info("Waiting for page to Load ...");
				waitInMS(3000);

			} else {
				logger.info("Page Loaded ...");
				break;
			}
		}
	}

	public static void switchingWaitforPageToLoad(String how, String value, String frame) throws Exception {
		waitInMS(2000);
		for (int i = 0; i < 10; i++) {
			if (isElementPresentSwitching(how, value, frame, 2)) {
				logger.info("Waiting for page to Load ...");
				waitInMS(2000);

			} else {
				logger.info("Page Loaded ...");
				break;
			}
		}
	}

	public static void waitForText(WebElement ele, String text) {
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(timeout));
		wait.until(ExpectedConditions.textToBePresentInElement(ele, text));
		logger.info("WebElement contains the text \"" + text + "\"");
		// logger.info("WebElement contains the text \""+text+"\"");
	}

	public static void waitForAttribute(final String how, final String value, final String attr, final String text) {
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
				.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
				.ignoring(NoSuchElementException.class);

		Function<WebDriver, Boolean> f = new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver driver) {
				WebElement element = null;
				if (how.equals("id"))
					element = SetWebDrivers.getDriver().findElement(By.id(value));
				else if (how.equals("xpath"))
					element = SetWebDrivers.getDriver().findElement(By.xpath(value));

				String attrValue = element.getAttribute(attr);
				logger.info("Actual Value in the attribute" + attr + ":" + attrValue);
				logger.info("Expected Value in the attribute" + attr + ":" + text);
				if (attrValue.equals(text))
					return true;
				else
					return false;
			}
		};
		wait.until(f);
	}

	public static boolean isElementPresent(final String how, final String value, String frame, int sec) {

		WebDriver driver = SetWebDrivers.getDriver();
		// driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); // clearing
		// the
		// implicit
		// wait
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(sec));
		try {
			goToFrame(frame);
			if (how.equalsIgnoreCase("xpath")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(value)));
			} else if (how.equalsIgnoreCase("id")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id(value)));
			} else if (how.equalsIgnoreCase("class")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.className(value)));
			} else if (how.equalsIgnoreCase("link")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(value)));
			} else if (how.equalsIgnoreCase("name")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.name(value)));
			} else if (how.equalsIgnoreCase("css")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(value)));
			}
			// driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			return true;
		} catch (Exception e) {
			// driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			return false;
		}

	}

	public static boolean isElementPresentSwitching(final String how, final String value, String frame, int sec) {

		WebDriver driver = SetWebDrivers.getDriver();
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); // clearing
		// the
		// implicit
		// wait
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(sec));
		try {
			goToFrame(frame);
			if (how.equalsIgnoreCase("xpath")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(value)));
			} else if (how.equalsIgnoreCase("id")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id(value)));
			} else if (how.equalsIgnoreCase("class")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.className(value)));
			} else if (how.equalsIgnoreCase("link")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(value)));
			} else if (how.equalsIgnoreCase("name")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.name(value)));
			} else if (how.equalsIgnoreCase("css")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(value)));
			}
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			return true;
		} catch (Exception e) {
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			return false;
		}

	}

	public static boolean isElementPresent(final String how, final String value) {

		Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
				.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(2))
				.ignoring(NoSuchElementException.class);
		try {

			if (how.equalsIgnoreCase("xpath")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(value)));
			} else if (how.equalsIgnoreCase("id")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id(value)));
			} else if (how.equalsIgnoreCase("class")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.className(value)));
			} else if (how.equalsIgnoreCase("link")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(value)));
			} else if (how.equalsIgnoreCase("name")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.name(value)));
			} else if (how.equalsIgnoreCase("css")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(value)));
			}
			// driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			return true;
		} catch (Exception e) {
			// driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			return false;
		}

	}

	public static WebElement waitForElement(final String how, final String value, String frame, int sec)
			throws Exception {
		goToFrame(frame);

		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(sec));

		if (how.equalsIgnoreCase("xpath")) {
			return wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(value)));
		} else if (how.equalsIgnoreCase("id")) {
			return wait.until(ExpectedConditions.presenceOfElementLocated(By.id(value)));
		} else if (how.equalsIgnoreCase("class")) {
			return wait.until(ExpectedConditions.presenceOfElementLocated(By.className(value)));
		} else if (how.equalsIgnoreCase("link")) {
			return wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(value)));
		} else if (how.equalsIgnoreCase("name")) {
			return wait.until(ExpectedConditions.presenceOfElementLocated(By.name(value)));
		} else if (how.equalsIgnoreCase("css")) {
			return wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(value)));
		} else {
			return null;
		}
	}

	public static void waitForElementVisibility(final String how, final String value, String frame, int sec)
			throws Exception {
		WebElement element = waitForElement(how, value, frame, sec);
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(sec));
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	public static boolean isClickable(WebElement e, int sec) {
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(sec));
		try {
			wait.until(ExpectedConditions.elementToBeClickable(e));
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	public static boolean isSelected(WebElement e, int sec) {
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(sec));
		try {
			wait.until(ExpectedConditions.elementToBeSelected(e));
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	public static boolean isVisible(WebElement e, int sec) {
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(sec));
		try {
			wait.until(ExpectedConditions.visibilityOf(e));

			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	public static boolean isVisible(Select s, int sec) {
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(sec));
		try {
			wait.until(ExpectedConditions.visibilityOf((WebElement) s));

			return true;
		} catch (Exception ex) {
			return false;
		}

	}

	public static ArrayList<String> FindAttributes(String object, String attribute) throws Exception {
		ArrayList<String> array_list_values = new ArrayList<String>();
		if (attribute == "innerhtml") {
			List<WebElement> list_values_elements = SeleniumHelperClass.findWebElements(object, "none");
			for (WebElement elements_in_list : list_values_elements) {
				String AR_object = (String) ((JavascriptExecutor) SetWebDrivers.getDriver())
						.executeScript("return arguments[0].innerHTML;", elements_in_list);
				array_list_values.add(AR_object);
				logger.info("Element - Added Array Object for object :" + object + " and the element is " + AR_object
						+ " ");

			}
			return array_list_values;
		} else {
			List<WebElement> list_values_elements = SeleniumHelperClass.findWebElements(object, "none");
			for (WebElement elements_in_list : list_values_elements) {

				array_list_values.add(elements_in_list.getAttribute(attribute));
				logger.info("Element - Get Array List getAttribute for object :" + object + " and the element is "
						+ elements_in_list.getAttribute(attribute) + " ");
			}

			return array_list_values;
		}

	}

	public static String FindAttribute(String attribute, String xpath) throws Exception {
		String AR_object;
		WebElement get_object = SeleniumHelperClass.findWebElementbyXpath(xpath);
		if (attribute != "innerhtml") {
			AR_object = get_object.getAttribute(attribute);

			return AR_object;
		} else {
			// AR_object = (String) ((JavascriptExecutor)
			// SetWebDrivers.getDriver()).executeScript("return arguments[0].innerHTML;",
			// get_object);
			AR_object = get_object.getAttribute("innerHTML");
			return AR_object;
		}

	}

	public static String FindAttribute(String attribute, WebElement ele) throws Exception {
		String AR_object;

		if (attribute != "innerhtml") {
			AR_object = ele.getAttribute(attribute);

			return AR_object;
		} else {
			AR_object = (String) ((JavascriptExecutor) SetWebDrivers.getDriver())
					.executeScript("return arguments[0].innerHTML;", ele);
			return AR_object;
		}

	}

	public static boolean isAlertPresent() {
		try {
			SetWebDrivers.getDriver().switchTo().alert();
			return true;
		} catch (NoAlertPresentException Ex) {
			return false;
		}
	}

	public static void AcceptAlerts(String text) {
		String alertText = "Failed to get alert";
		try {
			WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(2));
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = SetWebDrivers.getDriver().switchTo().alert();
			alertText = alert.getText();
			logger.info(alertText + " and " + text);
			if (alert.getText().equalsIgnoreCase(text)) {
				logger.info("both are equal accepting alert");
				alert.accept();
				logger.info("accepted");
			} else {
				logger.info("Alert Message don't match");
				logger.info("Given: " + text);
				logger.info("Got: " + alertText);
			}

		} catch (Exception e) {
			logger.info(alertText);
			// logger.info("Given: "+text);
			// logger.info("Got: " +alertText);
		}
	}

	public static void acceptAnyAlert() {
		String alertText = "Failed to get alert";
		try {
			WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(2));
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = SetWebDrivers.getDriver().switchTo().alert();
			alertText = alert.getText();
			alert.accept();
		} catch (Exception e) {
			logger.info(alertText);
		}
	}

	/**
	 * Click the elements, Use this method to ensure the click works on multi
	 * browser
	 *
	 * @param element
	 */
	public static void click(WebElement element) {
		try {
			element.click();
		} catch (ElementNotInteractableException e) {
			logger.info("Failed to click webelement due to " + e.getMessage() + ", trying with Actions click...");
			try {
				((JavascriptExecutor) SetWebDrivers.getDriver()).executeScript("arguments[0].scrollIntoView(true);",
						element);
			} catch (Exception se) {
				logger.info("Scroll to element failed" + se.getMessage());
			}
			try {
				Actions action = new Actions(SetWebDrivers.getDriver());
				action.click(element).build().perform();
			} catch (Exception ae) {
				logger.info("trying with Actions as a Retry..Ignore the message..." + ae.getMessage());

			}
			try {
				SeleniumHelperClass.secondaryClick(element);
			} catch (Exception es) {
				logger.info("trying with JSClick as a Retry..Ignore themessage..." + es.getMessage());
			}
		} catch (Exception e) {
			logger.info("Failed to click webelement due to " + e.getMessage() + ", trying with JSClick...");
			SeleniumHelperClass.secondaryClick(element);
		}
	}

	public static void clickOffset(WebElement element, int offsetx, int offsety) {
		try {
			new Actions(SetWebDrivers.getDriver()).moveToElement(element, offsetx, offsety);
			new Actions(SetWebDrivers.getDriver()).click();
		} catch (ElementNotInteractableException e) {
			logger.info("Failed to click webelement due to " + e.getMessage() + ", trying with Actions click...");
			try {
				((JavascriptExecutor) SetWebDrivers.getDriver()).executeScript("arguments[0].scrollIntoView(true);",
						element);
			} catch (Exception se) {
				logger.info("Scroll to element failed" + se.getMessage());
			}
			try {
				Actions action = new Actions(SetWebDrivers.getDriver());
				action.click(element).build().perform();
			} catch (Exception ae) {
				logger.info("trying with Actions as a Retry..Ignore the message..." + ae.getMessage());

			}
			try {
				SeleniumHelperClass.secondaryClick(element);
			} catch (Exception es) {
				logger.info("trying with JSClick as a Retry..Ignore themessage..." + es.getMessage());
			}
		} catch (Exception e) {
			logger.info("Failed to click webelement due to " + e.getMessage() + ", trying with JSClick...");
			SeleniumHelperClass.secondaryClick(element);
		}
	}

	public static void click(String elementXpath, String frameName) throws Exception {
		goToFrame(frameName);
		WebElement button = (WebElement) SetWebDrivers.getDriver().findElement(By.xpath(elementXpath));

		try {
			button.click();
		} catch (Exception e) {
			List<WebElement> availables = button.findElements(By.tagName("div"));
			availables.addAll(button.findElements(By.tagName("span")));
			tryClick(availables);
		}
	}

	public static void tryClick(List<WebElement> availables) {
		for (WebElement elementToBeClicked : availables) {
			try {
				elementToBeClicked.click();
				return;
			} catch (WebDriverException e) {
				continue;
			}
		}
	}

	public static void acceptAlert() {

		try {
			WebDriver driver = SetWebDrivers.getDriver();
			WebDriverWait wait11 = new WebDriverWait(driver, Duration.ofSeconds(3));
			wait11.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			alert.accept();
		} catch (Exception e) {
			logger.info("No alert");
		}

	}

	public static void doubleClick(WebElement e) {

		new Actions(SetWebDrivers.getDriver()).doubleClick(e).perform();

	}

	public static void moveToElement(WebElement element) {
		try {
			String browser = SetWebDrivers.getBrowser();
			logger.info("browser value is " + browser);
			if (browser.equalsIgnoreCase("chrome")) {
				logger.info("performing move to element in chrome.");
				new Actions(SetWebDrivers.getDriver()).moveToElement(element).build().perform();
			} else {
				logger.info("performing move to element in firefox.");
				try {
					((JavascriptExecutor) SetWebDrivers.getDriver()).executeScript("arguments[0].scrollIntoView();",
							element);
				} catch (Exception e) {
					logger.info("failed at scrolling to view.." + e.getMessage());
				}
				new Actions(SetWebDrivers.getDriver())
						.moveByOffset(element.getLocation().getX(), element.getLocation().getY()).moveToElement(element)
						.build().perform();
			}
		} catch (Exception ex) {
			logger.info("move to element failed, and retrying again with alternative approach..");
			((JavascriptExecutor) SetWebDrivers.getDriver()).executeScript("arguments[0].scrollIntoView();", element);
			new Actions(SetWebDrivers.getDriver()).moveToElement(element).build().perform();
		}
	}

	public static void clickOnWebElementWithAction(WebElement e) {

		new Actions(SetWebDrivers.getDriver()).click(e).perform();

	}

	public static void dragAndDrop(WebElement source, WebElement target) {
		//new Actions(SetWebDrivers.getDriver()).dragAndDrop(source, target).perform();
		new Actions(SetWebDrivers.getDriver()).clickAndHold(source).moveByOffset(-1, -1).moveToElement(target).release(target).build().perform();
	}

	public static void dragAndDropUsingJavaScriptExecutor(WebElement sourceElement, WebElement targetElement) {

		JavascriptExecutor executor = (JavascriptExecutor) SetWebDrivers.getDriver();

		// Performing Drag and Drop using JS-
		executor.executeScript(
				"function createEvent(typeOfEvent) {\n" + "var event =document.createEvent(\"CustomEvent\");\n"
						+ "event.initCustomEvent(typeOfEvent,true, true, null);\n" + "event.dataTransfer = {\n"
						+ "data: {},\n" + "setData: function (key, value) {\n" + "this.data[key] = value;\n" + "},\n"
						+ "getData: function (key) {\n" + "return this.data[key];\n" + "}\n" + "};\n"
						+ "return event;\n" + "}\n" + "\n" + "function dispatchEvent(element, event,transferData) {\n"
						+ "if (transferData !== undefined) {\n" + "event.dataTransfer = transferData;\n" + "}\n"
						+ "if (element.dispatchEvent) {\n" + "element.dispatchEvent(event);\n"
						+ "} else if (element.fireEvent) {\n" + "element.fireEvent(\"on\" + event.type, event);\n"
						+ "}\n" + "}\n" + "\n" + "function simulateHTML5DragAndDrop(element, destination) {\n"
						+ "var dragStartEvent =createEvent('dragstart');\n"
						+ "dispatchEvent(element, dragStartEvent);\n" + "var dropEvent = createEvent('drop');\n"
						+ "dispatchEvent(destination, dropEvent,dragStartEvent.dataTransfer);\n"
						+ "var dragEndEvent = createEvent('dragend');\n"
						+ "dispatchEvent(element, dragEndEvent,dropEvent.dataTransfer);\n" + "}\n" + "\n"
						+ "var source = arguments[0];\n" + "var destination = arguments[1];\n"
						+ "simulateHTML5DragAndDrop(source,destination);",
				sourceElement, targetElement);

	}

	public static void rightClick(WebElement e) throws Exception {
		try {
			Actions actions = new Actions(SetWebDrivers.getDriver()).contextClick(e);
			actions.build().perform();
		} catch (StaleElementReferenceException exception) {
			logger.info(exception.getStackTrace());
		} catch (Exception excep) {
			logger.info(excep.getStackTrace());
		}

	}

	public static void Logout() throws Exception {
		if (SetWebDrivers.getNavigationType().equalsIgnoreCase("gui")) {
			findWebElementbyid("down", "topFrame").click();
			findWebElementbyid("logoutlnk", "profileFrame").click();
		} else {
			LoginToApplication login = new LoginToApplication();
			login.getProfileIconImage().click();
			findWebElementbyid("logoutlnk", "profileFrame").click();
		}
	}

	public static void search(String tableName, String colName, String value, String ExpectedResult) throws Exception {

		SoftAssert Assert = new SoftAssert();
		/*
		 * waitInMS(system_SpeedlimitMIN); //int
		 * DBResult=getNumberOfResultsFromDB(tableName,colName,value); logger.info
		 * ("Number of Records meeting the search criteria from DB"+DBResult ,true);
		 * waitInMS(system_SpeedlimitMIN);
		 */
		int UIResult = getNumberOfResultsFromUI(SeleniumHelperClass.lastFrame);
		logger.info("Number of Records meeting the search criteria from DB = " + ExpectedResult);
		logger.info("Number of Records meeting the search criteria from UI = " + UIResult);
		String ActualResult = Integer.toString(UIResult);
		Assert.assertEquals(ExpectedResult, ActualResult, "Searching is failed for '" + value + "' DB Result: "
				+ ExpectedResult + " and UI Result: " + ActualResult);
		Assert.assertAll();

	}

	public static int getNumberOfResultsFromUI(String frame) throws Exception {
		int rows = 0;
		logger.info("current frame is " + frame);
		if (frame.equalsIgnoreCase("mainFrame")) {
			SeleniumHelperClass.waitForText(findWebElementbyid("results-total", frame), "(");

			String num = findWebElementbyid("results-total", frame).getText();
			num = num.substring(num.indexOf('(') + 1, num.indexOf(')'));
			// num=num.replaceAll("[()]", "");
			rows = Integer.parseInt(num);
		} /*
		 * else if(frame.equalsIgnoreCase("contentFrame")){ String
		 * num=findWebElementbyid("title", frame).getText().split(":")[1].trim();
		 * rows=Integer.parseInt(num); }
		 */ else if (frame.equalsIgnoreCase("editFrame") || frame.equals("none")
				|| frame.equalsIgnoreCase("contentFrame")) {

			WebDriver driver = SetWebDrivers.getDriver();
			int totPages = 0;
			if (frame.equalsIgnoreCase("editFrame"))
				goToFrame("listFrame");
			String text = driver.findElement(By.id("pagination_table")).getText();
			logger.info(text);
			String ar[] = text.split(" ");
			totPages = Integer.parseInt(ar[ar.length - 2]);
			logger.info("Tot pages " + totPages);
			if (totPages > 1) {
				findWebElementbyid("pagination_goToPageNumber", "none").clear();
				;
				findWebElementbyid("pagination_goToPageNumber", "none").sendKeys("" + totPages);
				findWebElementbyid("pagination_goToButton", "none").click();

			}
			int numberOfRows = 0;
			findWebElementbyXpath("//img[@src='images/pagination/inactive_last.gif']", "none");

			WebElement table = findWebElementbyid("tableFixed", "none");

			waitInMS(4000);// This is to be replaced with the method to wait
			// until the loader disappears
			List<WebElement> rowList = table.findElements(By.tagName("tr"));

			numberOfRows = rowList.size();
			numberOfRows--;// header row also included in the rowList

			rows = (totPages - 1) * 20 + numberOfRows;
			logger.info("Number of rows " + rows);
		}
		return rows;
	}

	public static int getNumberOfResultsFromDB(String tableName, String colName, String value)
			throws ClassNotFoundException, SQLException, InterruptedException {
		DBConnections db = new DBConnections();
		waitInMS(system_SpeedlimitMIN);
		ArrayList<String> result = db.connect_Db("SELECT * FROM " + tableName + " WHERE " + colName + " LIKE '%" + value
				+ "%' AND BUSINESS_ID=" + getBusinessId(), colName);

		return result.size();
	}

	public static int getNumberOfResultsFromDB(String email, String tableName, String colName, String value)
			throws ClassNotFoundException, SQLException, InterruptedException {
		DBConnections db = new DBConnections();
		waitInMS(system_SpeedlimitMIN);
		ArrayList<String> result = db.connect_Db("SELECT * FROM " + tableName + " WHERE " + colName + " = '" + value
				+ "' AND BUSINESS_ID=" + getBusinessId(email), colName);

		return result.size();
	}

	public static long getNumberOfRecordsFromDBTable(String tableName, String email) throws Exception {
		String business_id;
		if (email != null || !email.equals("")) {
			business_id = SeleniumHelperClass.getBusinessId(email);
		} else {
			business_id = SeleniumHelperClass.getBusinessId();
		}
		logger.info("Business_id = " + business_id);

		String query = "select count(*) from " + tableName + " where business_id = " + business_id;
		DBConnections db = new DBConnections();
		String values = db.connect_Db_string(query, "count(*)");
		logger.info("count = " + values);
		return Long.parseLong(values);
	}

	public static String getResultIDFromDB(String tableName, String rID, String colName, String value)
			throws ClassNotFoundException, SQLException, InterruptedException {
		DBConnections db = new DBConnections();
		waitInMS(system_SpeedlimitMIN);
		String result = db.connect_Db_string("SELECT * FROM " + tableName + " WHERE " + colName + " = '" + value
				+ "' AND BUSINESS_ID=" + getBusinessId(), rID);
		logger.info(result);
		return result;
	}

	public static String getResultIDFromDB(String tableName, String rID)
			throws ClassNotFoundException, SQLException, InterruptedException {
		DBConnections db = new DBConnections();
		waitInMS(system_SpeedlimitMIN);
		String result = db.connect_Db_string("SELECT * FROM " + tableName + " WHERE BUSINESS_ID=" + getBusinessId(),
				rID);
		logger.info(result);
		return result;
	}

	public static String getRestLoginResultIDFromDB(String tableName, String rID)
			throws ClassNotFoundException, SQLException, InterruptedException {
		DBConnections db = new DBConnections();
		waitInMS(system_SpeedlimitMIN);
		String result = db.connect_Db_string(
				"SELECT * FROM " + tableName + " WHERE BUSINESS_ID=" + getRestLoginBusinessId(), rID);
		logger.info(result);
		return result;
	}

	public static String getBusinessId() throws ClassNotFoundException, SQLException, InterruptedException {
		String email = LoginToApplication.getUsername();
		DBConnections db = new DBConnections();
		waitInMS(system_SpeedlimitMIN);
		return db.connect_Db_string("SELECT * FROM XC_USER WHERE EMAIL='" + email + "'", "BUSINESS_ID");
	}

	public static String getRestLoginBusinessId() throws ClassNotFoundException, SQLException, InterruptedException {
		String email = LoginToRestAPI.getUsername();
		DBConnections db = new DBConnections();
		waitInMS(system_SpeedlimitMIN);
		return db.connect_Db_string("SELECT * FROM XC_USER WHERE EMAIL='" + email + "'", "BUSINESS_ID");
	}

	public static String getResultIDFromDB(String email, String tableName, String rID, String colName, String value,
										   String dbname) throws ClassNotFoundException, SQLException, InterruptedException {
		DBConnections db = new DBConnections();
		waitInMS(system_SpeedlimitMIN);
		String result = db.connect_Db_string("SELECT * FROM " + tableName + " WHERE " + colName + " = '" + value
				+ "' AND BUSINESS_ID=" + getBusinessId(email), rID, dbname);
		logger.info(result);
		return result;
	}

	public static String getRequiredColumnID(String email, String tableName, String rID, String dbName)
			throws ClassNotFoundException, SQLException, InterruptedException {
		DBConnections db = new DBConnections();
		String result = db.connect_Db_string("SELECT * FROM " + tableName + " WHERE BUSINESS_ID=" + getBusinessId(email)
				+ " AND ROWNUM=1 ORDER BY created_date asc", rID, dbName);
		logger.info(result);
		return result;
	}

	public static String getLoginIP(String email, String columnName, String dbName)
			throws ClassNotFoundException, SQLException, InterruptedException {
		DBConnections db = new DBConnections();

		String result = db.connect_Db_string("SELECT * FROM (select * from XG_LOGIN WHERE EMAIL='" + email
				+ "'  ORDER BY login_time desc) where rownum=1", columnName, dbName);
		logger.info(result);

		return result;
	}

	public static ArrayList<String> getMDRValidationFixInMins(String fix_in_mins, String dbName,
															  String mDR_REFRESH_STATUS_ID) throws ClassNotFoundException, SQLException, InterruptedException {
		DBConnections db = new DBConnections();

		ArrayList<String> result = db
				.connect_Db("SELECT MDR_REFRESH_JOB_TYPE, (CAST(END_TIME AS date) - CAST(START_TIME AS date))*24*60 AS "
						+ fix_in_mins + " FROM xdp2.XDP_MDR_REFRESH_JOB_AUDIT xmrja WHERE MDR_REFRESH_STATUS_ID='"
						+ mDR_REFRESH_STATUS_ID + "'", fix_in_mins);

		logger.info(result);

		return result;
	}

	public static void updateBatchRulePref(String bizID) throws ClassNotFoundException, SQLException, InterruptedException {
		DBConnections db = new DBConnections();
		db.executeUpdateQuery("update  xc_business_pref set value= 1 where business_id=" + bizID + " and name ='ENABLE_BATCH_RULE_DIAGNOSTICS'");

	}

	public static String getBusinessId(String email) throws ClassNotFoundException, SQLException, InterruptedException {
		DBConnections db = new DBConnections();
		waitInMS(system_SpeedlimitMAX);
		return db.connect_Db_string("SELECT * FROM XC_USER WHERE EMAIL='" + email + "'", "BUSINESS_ID");
	}

	public static void deleteFromDB(String email, String tableName)
			throws ClassNotFoundException, SQLException, InterruptedException {
		DBConnections db = new DBConnections();
		waitInMS(system_SpeedlimitMIN);
		logger.info("DELETE * FROM " + tableName + " WHERE BUSINESS_ID=" + getBusinessId(email));
		db.executeUpdateQuery("DELETE FROM " + tableName + " WHERE BUSINESS_ID=" + getBusinessId(email));
	}

	public static void updateCellValueInDB(String businessId, String tableName, String columnName, long newValue,
										   String existingValue) throws ClassNotFoundException, SQLException, InterruptedException {
		DBConnections db = new DBConnections();
		logger.info("UPDATE " + tableName + " SET " + columnName + "=" + newValue + " WHERE BUSINESS_ID=" + businessId
				+ " AND " + columnName + "=" + existingValue + "");
		db.executeUpdateQuery("UPDATE " + tableName + " SET " + columnName + "=" + newValue + " WHERE BUSINESS_ID="
				+ businessId + " AND " + columnName + "=" + existingValue + "");
		logger.info("successfully Updated the query");
	}

	public static String setUniqueId() {

		long currentTime = System.nanoTime();
		// logger.info(currentTime);
		String uniqueId = Long.toString(currentTime);
		return uniqueId;
	}

	/* To upload a file from windows prompt */
	public static void uploadfilefromwindowsprompt(String upath) throws AWTException {
		StringSelection path = new StringSelection(upath.toString());
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(path, null);

		Robot r = new Robot();

		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);

		r.keyPress(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_V);

		r.keyRelease(KeyEvent.VK_V);
		r.keyRelease(KeyEvent.VK_CONTROL);

		r.delay(3000);

		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);

	}

	/* To select date from date picker - mm/dd/yyyy */
	public static void selectReleaseDate(String rcDate) throws Exception {

		List<String> monthList = Arrays.asList("January", "February", "March", "April", "May", "June", "July", "August",
				"September", "October", "November", "December");
		int expMonth;
		int expYear;
		String expDate = null;
		String calMonth = null;
		String calYear = null;
		boolean dateNotFound = true;

		String relDate[] = rcDate.split("/");

		expDate = relDate[0];
		expMonth = Integer.parseInt(relDate[1]);
		expYear = Integer.parseInt(relDate[2]);

		while (dateNotFound) {

			calMonth = SeleniumHelperClass.findWebElementbyclass("ui-datepicker-month").getText();
			calYear = SeleniumHelperClass.findWebElementbyclass("ui-datepicker-year").getText();

			if (monthList.indexOf(calMonth) + 1 == expMonth && (expYear == Integer.parseInt(calYear))) {
				selectDate(expDate);
				dateNotFound = false;
			} else if (monthList.indexOf(calMonth) + 1 < expMonth && (expYear == Integer.parseInt(calYear))
					|| expYear > Integer.parseInt(calYear)) {

				SeleniumHelperClass.findWebElementbyXpath(".//*[@id='ui-datepicker-div']/div/a[2]/span").click();
			} else if (monthList.indexOf(calMonth) + 1 > expMonth && (expYear == Integer.parseInt(calYear))
					|| expYear < Integer.parseInt(calYear)) {
				SeleniumHelperClass.findWebElementbyXpath(".//*[@id='ui-datepicker-div']/div/a[1]/span").click();
			}
		}
		waitInMS(3000);
	}

	public static void selectDate(String date) throws Exception {
		WebElement datePicker = SeleniumHelperClass.findWebElementbyid("ui-datepicker-div");
		List<WebElement> noOfColumns = datePicker.findElements(By.tagName("td"));

		for (WebElement cell : noOfColumns) {

			if (cell.getText().equals(date)) {
				cell.findElement(By.linkText(date)).click();
				break;
			}
		}
	}

	public static void select2DropDownInHierarchy(String item) throws Exception {
		findWebElementbyXpath("//button[@type='button']").click();
		findWebElementbyLink(item).click();
		waitInMS(5000);
	}

	public static void selectDateHierarchy(String date) throws Exception {
		findWebElementbyid("periodSelectDate").click();
		findWebElementbyLink(date).click();
		waitInMS(5000);
	}

	public static void selectFromHierarchy(String period, String date, String name) throws Exception {
		goToFrame("reportframe");
		WebDriver driver = SetWebDrivers.getDriver();
		driver.switchTo().frame("");
		select2DropDownInHierarchy(period);
		selectDateHierarchy(date);
		findWebElementbyid("hierarchySearchInput").sendKeys(name);
		waitInMS(2000);
		findWebElementbyXpath("//ul[@id='ui-id-1']/li").click();
		waitInMS(3000);
	}

	public static void send() throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		SeleniumHelperClass.findWebElementbyid("sendForSignature", "planDocFrame").click();
		waitInMS(2000);
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				try {
					SetWebDrivers.getDriver().switchTo().window(windowHandle);
					SetWebDrivers.getDriver().switchTo().frame("sendForApprovalFrame");
					SeleniumHelperClass.findWebElementbyXpath("//input[@value='Send']").click();
					waitInMS(3000);
					AcceptAlerts(
							"Your request is being processed and the documents are being routed.\n\nTo check overall routing status, use the Document Mgmt > Route Documents > Status page.\nTo check individual document status, use the Document Mgmt > Status page.");
				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the child window");
					// SeleniumHelperClass.findWebElementbyid("cancelButton").click();
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}
		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
	}

	public static WebElement waitforpagetoloadtillobjectappears(final String xpathString, String frameName)
			throws Exception {

		Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
				.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
				.ignoring(NoSuchElementException.class);

		WebElement obj = wait.until(new ExpectedCondition<WebElement>() {
			public WebElement apply(WebDriver d) {
				return d.findElement(By.xpath(xpathString));
			}
		});
		// logger.info("Wait completed");
		return obj;

	}

	public static void waitForPopUp(int sec) {
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(sec));
		wait.until(new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver d) {
				return (d.getWindowHandles().size() != 1);
			}
		});

	}

	public static void uploadunreleaseFile(String popupLinkId, String filepath, String uploadFrame, String releasegroup)
			throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		SeleniumHelperClass.findWebElementbyid(popupLinkId).click();
		waitInMS(2000);
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		logger.info(windowHandlers);
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {

				SetWebDrivers.getDriver().switchTo().window(windowHandle);
				try {

					waitInMS(SeleniumHelperClass.system_SpeedlimitMAX * 2);
					SetWebDrivers.getDriver().switchTo().frame(uploadFrame);
					SeleniumHelperClass
							.findWebElementbyXpath(".//*[@id='bd']/center/form/table/tbody/tr[1]/td[2]/input")
							.sendKeys(releasegroup);
					WebElement uploadField = SeleniumHelperClass.findWebElementbyXpath("//input[@type='file']");
					uploadField.sendKeys(filepath);

					SeleniumHelperClass.findWebElementbyXpath(".//*[@type='submit']").click();
					String bodyText = SeleniumHelperClass.findWebElementbyTagName("body", "").getText();
					logger.info(bodyText);

					if (bodyText.contains("File was uploaded successfully")) {
						logger.info("sync upload was successfull");
						WebElement ok = SeleniumHelperClass.findWebElementbyXpath(".//*[@onclick='done()']");
						ok.click();

					} else if (bodyText.contains(
							"Your upload request is being processed and when completed will appear in the myUploads page.")) {
						logger.info("async upload was successfull");
						SeleniumHelperClass.findWebElementbyXpath(".//*[@type='button']").click();
					}

				} catch (Exception e) {
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}

			}
		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);

	}

	public boolean searchFromPopup(String searchFieldXpath, String searchString) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		int val = 0;

		// WebElement iFrame=
		// SetWebDrivers.getDriver().findElement(By.tagName("iframe"));
		// SetWebDrivers.getDriver().switchTo().frame(iFrame);

		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				SetWebDrivers.getDriver().switchTo().window(windowHandle);
				try {
					logger.info("Switched to Child window");
					if (SeleniumHelperClass.findWebElementbyXpath(searchFieldXpath).isDisplayed()) {
						val = 1;
					}
				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the child window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}

		}
		// SetWebDrivers.getDriver().switchTo().defaultContent();
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
		if (val == 1) {
			return true;
		} else
			return false;
	}

	public static WebElement getFirstRowOfTable(WebElement tableElement) throws Exception {
		WebElement firstRow = null;
		ArrayList<WebElement> rowElements = (ArrayList<WebElement>) tableElement.findElements(By.tagName("tr"));
		if (rowElements.size() > 0)
			firstRow = rowElements.get(1);
			// firstRow.getText();
		else
			throw new Exception("Required row is not found");

		return firstRow;

	}

	public static void mouseHover(WebElement element) throws Exception {
		Actions actions = new Actions(SetWebDrivers.getDriver());
		try {
			// WebElement elementHoverLink = element;
			actions.moveToElement(element).perform();

		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to mouse hover on element, trying alternative");
			SeleniumHelperClass.moveToElement(element);

		}
	}

	public static WebElement findWebElementbyXpathisDisabled(final String xpathString, String frameName)
			throws Exception {
		goToFrame(frameName);
		try {
			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
					.ignoring(NoSuchElementException.class);

			WebElement obj = wait.until(new ExpectedCondition<WebElement>() {
				public WebElement apply(WebDriver d) {
					return d.findElement(By.xpath("//span[text()='" + xpathString
							+ "']/parent::a/parent::div[contains(@class,'x-tree-node-disabled')]"));
				}
			});
			if (!obj.getText().equals(""))
				logger.info("Found element '" + obj.getText() + "' with xpath " + xpathString);
			else
				logger.info("Found element with xpath " + xpathString);
			return obj;
		} catch (Exception e) {
			logger.info("Exception in findWebElementbyxpath() :: xpath " + xpathString + " : " + e.toString());
			throw e;
		}
	}

	public static void waitForClassNameToAppear(WebElement ele, String className) {
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(timeout));
		// wait.until(ExpectedConditions.attributeContains(ele, "class",
		// className));
	}

	public static void waitForClassNameToDisappear(WebElement ele, String className) {
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(timeout));
		// wait.until(ExpectedConditions.not(ExpectedConditions.attributeContains(ele,
		// "class", className)));
	}

	public static boolean waitUntilElementDisplayed(final WebElement webElement, int sec) {
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(sec));
		ExpectedCondition<Boolean> elementIsDisplayed = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver arg0) {
				return webElement.isDisplayed();
			}
		};
		try {
			return wait.until(elementIsDisplayed);
		} catch (TimeoutException e) {
			return false;
		}
	}

	public static List<String> getSetupTabFirstColumnData(String field) throws Exception {

		List<String> dataElements = new ArrayList<String>();
		String pages = SeleniumHelperClass
				.findWebElementbyXpath(".//*[@id='pagination_table']/tbody/tr/td[8]", "listFrame").getText();
		String countString = pages.replace("of", " ").trim();
		int count = Integer.parseInt(countString);
		logger.info("Countttttttttttt" + count);
		for (int i = 0; i < count; i++) {
			List<WebElement> findWebElementsInXpath = SeleniumHelperClass
					.findWebElementsInXpath(".//*[@id='tableFixed']/tbody/tr/td", "listFrame");
			for (WebElement webElement : findWebElementsInXpath) {
				if (webElement.getAttribute("n").equalsIgnoreCase(field)) {
					List<WebElement> findWebElementsInWebElement = SeleniumHelperClass
							.findWebElementsInWebElement(webElement, "xpath", "div", "listFrame");
					for (WebElement webElement2 : findWebElementsInWebElement) {
						logger.info("DESCCCCCCCCCCC" + webElement2.getText());
						dataElements.add(webElement2.getText());
					}

				}

			}
			SeleniumHelperClass.findWebElementbyid("pagination_nextLink", "listFrame").click();
			waitInMS(3000);
		}

		return dataElements;

	}

	/**
	 * Checks the job status and downloads if Completed
	 *
	 * @return
	 * @throws Exception
	 */
	public String downLoadExportedFiles() throws Exception {
		SetWebDrivers.getDriver().manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);

		String entitiesExportStatus = ".//*[@id='listTable_import_export_status_list']/tr/td[5]/div";
		List<WebElement> exportStatusList = SeleniumHelperClass.findWebElementsInXpath(entitiesExportStatus,
				"listFrame");
		logger.info("Checking export status..");
		for (WebElement exportStatus : exportStatusList) {

			if (exportStatus.getText().equals("Completed")) {
				logger.info("Status is completed. Proceding to download");

				SeleniumHelperClass.findWebElementInWebElement(exportStatus, "xpath",
						"../preceding-sibling::td[4]/input", "listFrame").click();

			}

		}
		get_download_btn().click();
		return entitiesExportStatus;
	}

	public WebElement get_download_btn() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("downloadButton", "listFrame");
	}

	/**
	 * Switches to the given module
	 *
	 * @param targetModule
	 * @throws InterruptedException
	 * @throws Exception
	 */
	public void navigateToModule(String targetModule) throws InterruptedException, Exception {
		logger.info("Switching to Modeling module..");
		LoginToApplication login = new LoginToApplication();
		waitInMS(5000);
		login.getDropdown().click();
		logger.info("Target Module " + targetModule);
		String id = login.getModuleId(targetModule);
		waitInMS(2000);
		WebElement module = login.getModule(id);
		module.click();
	}

	/**
	 * Finds the latest file in given location and returns
	 *
	 * @param downloadLoc
	 * @return
	 * @throws InterruptedException
	 */
	public File findLatestFileInLocation(String downloadLoc) throws InterruptedException {
		SetWebDrivers.getDriver().manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
		logger.info("Waiting for 5 seconds");

		File latestFilefromDir = getLatestFilefromDir(downloadLoc);
		waitInMS(2000);
		return latestFilefromDir;
	}

	/**
	 * @param dirPath
	 * @return
	 */
	public static File getLatestFilefromDir(String dirPath) {
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			return null;
		}

		File lastModifiedFile = files[0];
		for (int i = 1; i < files.length; i++) {
			if (lastModifiedFile.lastModified() < files[i].lastModified()) {
				lastModifiedFile = files[i];
			}
		}

		System.out.println("lastModifiedFile is " + lastModifiedFile);
		return lastModifiedFile;
	}

	/**
	 * Clean Directory
	 *
	 * @param downloadLoc
	 * @throws IOException
	 */

	public static void cleanDir(String downloadLoc) throws IOException {
		logger.info("Cleaning files from : " + downloadLoc);
		File file = new File(downloadLoc);
		FileUtils.cleanDirectory(file);
	}

	/**
	 * Extracts the file from sourcePath and extracts to destPath
	 *
	 * @param sourcePath
	 * @param destPath
	 * @throws IOException
	 */
	public void unzip(String sourcePath, String destPath) throws IOException {
		File destDir = new File(destPath);
		if (!destDir.exists()) {
			destDir.mkdir();
		}
		ZipInputStream zipIn = new ZipInputStream(new FileInputStream(sourcePath));
		ZipEntry entry = zipIn.getNextEntry();
		while (entry != null) {
			String filePath = destPath + File.separator + entry.getName();
			if (!entry.isDirectory()) {
				// if the entry is a file, extracts it
				extractFile(zipIn, filePath);

			} else {
				// if the entry is a directory, make the directory
				File dir = new File(filePath);
				dir.mkdir();
			}
			zipIn.closeEntry();
			entry = zipIn.getNextEntry();
		}
		zipIn.close();

	}

	public void extractFile(ZipInputStream zipIn, String filePath) throws IOException {
		BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filePath));
		byte[] bytesIn = new byte[4096];
		int read = 0;
		while ((read = zipIn.read(bytesIn)) != -1) {
			bos.write(bytesIn, 0, read);
		}
		bos.close();

	}

	/**
	 * Recursively checks for any compressed file in the location and uncompresses
	 * it
	 *
	 * @param downloadLoc
	 * @throws IOException
	 */
	public void unCompressFilesFromZip(String downloadLoc) throws IOException {
		File folder = new File(downloadLoc);
		File[] listFiles = folder.listFiles();

		for (File file : listFiles) {
			if (file.isFile() && (getFileExtension(file).indexOf("zip") != -1)) {

				logger.info("Zip Files " + file.getName());
				if (!file.getName().startsWith("Modeling Export")) {
					logger.info("LLL" + file.getName());
					unzip(Constants.downloadLoc + "\\" + file.getName(), Constants.downloadLoc);
				}

			}
		}

	}

	public String getFileExtension(File f) {

		if (f.getName().indexOf(".") == -1)
			return "";
		else {
			return (f.getName().substring(f.getName().length() - 3, f.getName().length()));

		}
	}

	/**
	 * Renames and uncompress the downloaded file
	 *
	 * @param downloadLoc
	 * @return
	 * @throws IOException
	 */
	public HashMap<String, HashMap<String, ArrayList<String>>> readXMLFiles(String downloadLoc) throws Exception {

		HashMap<String, HashMap<String, ArrayList<String>>> readXMLContents = readXMLContents(downloadLoc);
		return readXMLContents;

	}

	/**
	 * Reads all the XML files from the location and stores in a map
	 *
	 * @param downloadLoc
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, HashMap<String, ArrayList<String>>> readXMLContents(String downloadLoc) throws Exception {

		File file = new File(downloadLoc);
		File[] files = file.listFiles();
		List<File> fileList = new ArrayList<File>();
		HashMap<String, HashMap<String, ArrayList<String>>> hMap = new HashMap<String, HashMap<String, ArrayList<String>>>();
		for (File f : files) {
			if (f.isFile() && (getFileExtension(f).indexOf("xml") != -1)) {
				fileList.add(f);
			}

		}

		ArrayList<String> valueList = null;
		for (File xmlFile : fileList) {
			ArrayList<String> keyList = fetchKeys(xmlFile);
			HashMap<String, ArrayList<String>> innerMap = new HashMap<String, ArrayList<String>>();
			for (String key : keyList) {
				valueList = parseXml(xmlFile, key);
				innerMap.put(key, valueList);
			}
			String fileNameWithoutExt = FilenameUtils.removeExtension(xmlFile.getName());
			String replace = fileNameWithoutExt.replace("_", " ");

			hMap.put(replace, innerMap);
		}
		printMapContents(hMap);
		return hMap;

	}

	public ArrayList<String> fetchKeys(File xmlFile) throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(xmlFile);
		doc.getDocumentElement().normalize();
		NodeList nList = doc.getElementsByTagName("imp:ColumnData");
		String key;
		ArrayList<String> list = new ArrayList<String>();
		for (int i = 0; i < nList.getLength(); i++) {
			NodeList childNodes = nList.item(i).getChildNodes();
			for (int j = 0; j < childNodes.getLength(); j++) {
				if (childNodes.item(j).getNodeName().equalsIgnoreCase("imp:Name")) {
					key = childNodes.item(j).getTextContent();

					if (!list.contains(key)) {
						list.add(key);
					}
				}
			}
		}
		return list;
	}

	public static ArrayList<String> parseXml(File xmlFile, String key)
			throws ParserConfigurationException, SAXException, IOException {
		ArrayList<String> valueList = new ArrayList<String>();

		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(xmlFile);
		doc.getDocumentElement().normalize();
		NodeList nList = doc.getElementsByTagName("imp:ColumnData");
		Node node = null;
		for (int i = 0; i < nList.getLength(); i++) {
			NodeList childNodes = nList.item(i).getChildNodes();
			for (int j = 0; j < childNodes.getLength(); j++) {
				if (childNodes.item(j).getNodeName().equalsIgnoreCase("imp:Name")) {
					if (childNodes.item(j).getTextContent().equalsIgnoreCase(key)) {
						node = nList.item(i);
						break;
					}
				}
			}
		}
		NodeList childNodes = node.getChildNodes();

		for (int i = 0; i < childNodes.getLength(); i++) {
			if (childNodes.item(i).getNodeName().equalsIgnoreCase("imp:ColValue")) {
				NodeList value = childNodes.item(i).getChildNodes();
				for (int j = 0; j < value.getLength(); j++) {
					if (value.item(j).getNodeName().equalsIgnoreCase("imp:Value")) {
						String val = value.item(j).getTextContent();
						valueList.add(val);
					}
				}

			}
		}
		return valueList;
	}

	public static void printMapContents(HashMap<String, HashMap<String, ArrayList<String>>> hMap) {

		String key, innerKey;

		Iterator<String> itr = hMap.keySet().iterator();
		HashMap<String, ArrayList<String>> innerMap;
		while (itr.hasNext()) {
			key = itr.next();
			logger.info("FILE ::: " + key);
			innerMap = hMap.get(key);
			Iterator<String> innerIterator = innerMap.keySet().iterator();
			while (innerIterator.hasNext()) {
				innerKey = innerIterator.next();
				logger.info("Key : " + innerKey);
				logger.info("Value : " + innerMap.get(innerKey));
				logger.info("");
			}
		}
	}

	public static void uploadFileFromThePopup(URL resource, String uploadFrame, String parentWindowHandle, int option)
			throws Exception {
		/*
		 * String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		 * getUploadQuotas().click();
		 */
		waitInMS(2000);
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		waitInMS(3000);
		logger.info(windowHandlers.size());
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindowHandle)) {
				SetWebDrivers.getDriver().switchTo().window(windowHandle);
				SetWebDrivers.getDriver().switchTo().frame(uploadFrame);
				try {

					logger.info("Switched to Child window");

					findWebElementbyXpath(".//*[@id='bd']/center/form/table/tbody/tr[1]/td[2]/input")
							.sendKeys(resource.toString());

					waitInMS(2000);
					if (option == 2) {
						try {
							findWebElementbyXpath("//*[@value='updateData']").click();
							findWebElementbyXpath(".//*[@id='bd']/center/form/p/button[1]").submit();
							waitInMS(2000);
							String bodyText = SeleniumHelperClass.findWebElementbyTagName("body", "").getText();
							logger.info(bodyText);

							if (bodyText.contains("File was uploaded successfully")) {
								logger.info("sync upload was successfull");
								WebElement ok = SeleniumHelperClass.findWebElementbyXpath(".//*[@onclick='done()']");
								ok.click();
								SetWebDrivers.getDriver().switchTo().window(parentWindowHandle);

							} else if (bodyText.contains(
									"Your upload request is being processed and when completed will appear in the myUploads page.")) {
								logger.info("async upload was successfull");
								SeleniumHelperClass.findWebElementbyXpath(".//*[@type='button']").click();

							}
						} catch (Exception e) {
							SetWebDrivers.getDriver().close();
							logger.info("Exception : " + e.getMessage());
							logger.info("Closed the child window");

							SetWebDrivers.getDriver().switchTo().window(parentWindowHandle);
							throw new Exception(e);
						}

					} else if (option == 3) {
						try {
							findWebElementbyXpath("//*[@value='both']").click();
							findWebElementbyXpath(".//*[@id='bd']/center/form/p/button[1]").submit();
							waitInMS(2000);
							String bodyText = SeleniumHelperClass.findWebElementbyTagName("body", "").getText();
							logger.info(bodyText);

							if (bodyText.contains("File was uploaded successfully")) {
								logger.info("sync upload was successfull");
								WebElement ok = SeleniumHelperClass.findWebElementbyXpath(".//*[@onclick='done()']");
								ok.click();
								SetWebDrivers.getDriver().switchTo().window(parentWindowHandle);

							} else if (bodyText.contains(
									"Your upload request is being processed and when completed will appear in the myUploads page.")) {
								logger.info("async upload was successfull");
								SeleniumHelperClass.findWebElementbyXpath(".//*[@type='button']").click();

							}
						} catch (Exception e) {
							SetWebDrivers.getDriver().close();
							logger.info("Exception : " + e.getMessage());
							logger.info("Closed the child window");

							SetWebDrivers.getDriver().switchTo().window(parentWindowHandle);
							throw new Exception(e);
						}

					} else
						findWebElementbyXpath(".//*[@id='bd']/center/form/p/button[1]").submit();
					waitInMS(2000);
					String bodyText = SeleniumHelperClass.findWebElementbyTagName("body", "").getText();
					logger.info(bodyText);

					if (bodyText.contains("File was uploaded successfully")) {
						logger.info("sync upload was successfull");
						WebElement ok = SeleniumHelperClass.findWebElementbyXpath(".//*[@onclick='done()']");
						ok.click();

					} else if (bodyText.contains(
							"Your upload request is being processed and when completed will appear in the myUploads page.")) {
						logger.info("async upload was successfull");
						SeleniumHelperClass.findWebElementbyXpath(".//*[@type='button']").click();

					}

				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Exception : " + e.getMessage());
					logger.info("Closed the child window");

					SetWebDrivers.getDriver().switchTo().window(parentWindowHandle);
					throw new Exception(e);
				}

			}
		}
		SetWebDrivers.getDriver().switchTo().window(parentWindowHandle);

	}

	public List<String> readExcelColumnForQuota(String field, File file) throws Exception {

		FileInputStream ExcelFile = new FileInputStream(file);
		ExcelWBook = new XSSFWorkbook(ExcelFile);
		ExcelWSheet = ExcelWBook.getSheetAt(0);
		int rowNum = ExcelWSheet.getLastRowNum();
		int noOfColumns = ExcelWSheet.getRow(1).getLastCellNum();
		String[] header = new String[noOfColumns];

		List<String> dataList = new ArrayList<String>();
		logger.info("Rows : " + rowNum + " Column : " + noOfColumns);
		for (int i = 0; i < noOfColumns; i++) {
			int cellType = ExcelWSheet.getRow(1).getCell(i).getCellType();
			if (cellType == org.apache.poi.ss.usermodel.Cell.CELL_TYPE_STRING) {
				header[i] = ExcelWSheet.getRow(1).getCell(i).getStringCellValue();
			} else if (cellType == org.apache.poi.ss.usermodel.Cell.CELL_TYPE_NUMERIC) {
				header[i] = Double.toString(ExcelWSheet.getRow(1).getCell(i).getNumericCellValue());
			}

		}

		for (int i = 0; i < header.length; i++) {
			try {
				if (header[i].contains(field.substring(0, 3))) {
					for (int k = 2; k < rowNum; k++) {
						int cellType = ExcelWSheet.getRow(k).getCell(i).getCellType();
						if (cellType == org.apache.poi.ss.usermodel.Cell.CELL_TYPE_STRING) {
							dataList.add(ExcelWSheet.getRow(k).getCell(i).getStringCellValue());

						} else if (cellType == org.apache.poi.ss.usermodel.Cell.CELL_TYPE_NUMERIC) {
							double numericCellValue = ExcelWSheet.getRow(k).getCell(i).getNumericCellValue();
							String string = Double.toString(numericCellValue);
							dataList.add(string);

						}
					}

				}

			} catch (Exception e) {
				logger.info("Missing Header");
			}

		}
		return dataList;

	}

	public static void scrollWebPage(String x, String y) {
		JavascriptExecutor jse = (JavascriptExecutor) SetWebDrivers.getDriver();
		jse.executeScript("window.scrollBy(" + x + "," + y + ")", "");
	}

	public List<String> VerifyTextPDFReports(String downloadLoc, String quotaSectionPrefix)
			throws IOException, InterruptedException {

		File file = new File(downloadLoc + "\\PlanDocument.pdf");
		PDDocument document = PDDocument.load(file);
		List<String> aList = new ArrayList<String>();
		PDFTextStripper pdfStripper = new PDFTextStripper();

		String text = pdfStripper.getText(document);
		String[] split = text.split(pdfStripper.getLineSeparator());

		for (int i = 0; i < split.length; i++) {
			if (split[i].startsWith(quotaSectionPrefix))
				aList.add(split[i]);

		}
		document.close();
		return aList;

	}

	public static ArrayList<String> fetchTableData(String xpathString, String trow, String tcol, String SectionName)
			throws Exception {

		ArrayList<String> tableData = new ArrayList<String>();
		WebElement table = SeleniumHelperClass.findWebElementbyXpath(xpathString);
		List<WebElement> rows = table.findElements(By.tagName(trow));
		Iterator<WebElement> i = rows.iterator();
		logger.info("Table has following content");
		while (i.hasNext()) {
			WebElement row = i.next();
			List<WebElement> columns = row.findElements(By.tagName(tcol));
			/*
			 * Iterator<WebElement> j = columns.iterator(); while(j.hasNext()){ WebElement
			 * column = j.next(); System.out.print("coloumn:"+column.getText());
			 * }logger.info("");
			 */

			for (WebElement element : columns) {

				tableData.add(element.getText());
				if (SectionName != "Bonus")

					while (tableData.contains("")) {
						tableData.remove("");
					}
				else {

					waitInMS(2000);
				}

			}
		}
		return tableData;

	}

	public static WebElement sFDCDownArrow() throws Exception {

		return SeleniumHelperClass.findWebElementbyXpath("//a[@id='globalHeaderNameMink']");
	}

	public static WebElement sFDCgetLogOut() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//a[@title='Logout']");

	}

	public static void sFDCLogout() throws Exception {
		sFDCDownArrow().click();
		waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
		sFDCgetLogOut().click();
		SetWebDrivers.getDriver().quit();

	}

	/**
	 * This method creates the directory for download file and cleans the directory
	 * recursively
	 *
	 * @throws IOException
	 */
	public static void createDownloadDir() throws IOException {
		String os = System.getProperty("os.name").toLowerCase();

		DateFormat dateFormat = new SimpleDateFormat("EEE_dd_yyyy_MMM_HH_mm_ss");
		String currentDate = dateFormat.format(new Date());
		String weeklyDirName = currentDate.substring(0, 6) + currentDate.substring(11, 15)
				+ currentDate.substring(6, 11);
		String downloadDirName = currentDate.substring(7, 15) + currentDate.substring(3, 6) + currentDate.substring(15);

		File xincentdownloadLoc = new File(File.separator + "XincentDownloadDir");

		if (os.indexOf("mac") != -1 || os.indexOf("darwin") != -1 || os.indexOf("nux") != -1) {
			xincentdownloadLoc = new File(new File(System.getProperty("java.io.tmpdir")).getAbsolutePath()
					+ File.separator + "XincentDownloadDir");
		}
		FileUtils.forceMkdir(xincentdownloadLoc);

		String xincentDownloadLoc = xincentdownloadLoc.getAbsolutePath();
		String weeklyDownloadLoc = xincentDownloadLoc + File.separator + weeklyDirName;
		String dailyDownloadLoc = weeklyDownloadLoc + File.separator + downloadDirName;

		File[] listOfFiles = xincentdownloadLoc.listFiles();

		boolean weeklyDirExists = false;
		File weeklyDirExistsDirName = null;

		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].getName().startsWith(weeklyDirName.substring(0, 4))) {
				weeklyDirExists = true;
				weeklyDirExistsDirName = listOfFiles[i];
				break;
			}
		}

		if (weeklyDirExists) {
			if (weeklyDirExistsDirName.getName().equals(weeklyDirName)) {
				// create child
				FileUtils.forceMkdir(new File(dailyDownloadLoc));

			} else if (weeklyDirExistsDirName.getName().startsWith(weeklyDirName.substring(0, 4))
					&& (!weeklyDirExistsDirName.getName().endsWith(weeklyDirName.substring(3)))) {
				// delete parent , Create parent and child
				FileUtils.forceDelete(new File(weeklyDirExistsDirName.getAbsolutePath()));
				FileUtils.forceMkdir(new File(dailyDownloadLoc));
			}
		} else {
			// create dir parent and child
			FileUtils.forceMkdir(new File(dailyDownloadLoc));
		}

		Constants.downloadLoc = dailyDownloadLoc;
	}

	public static void executeJavaScriptScroll(WebElement element) throws Exception {

		JavascriptExecutor js = (JavascriptExecutor) SetWebDrivers.getDriver();
		js.executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public static ArrayList<String> fetchTableData(WebElement table, String trow, String tcol, String SectionName)
			throws Exception {

		ArrayList<String> tableData = new ArrayList<String>();
		List<WebElement> rows = table.findElements(By.tagName(trow));
		logger.info("rows" + rows);
		Iterator<WebElement> i = rows.iterator();
		while (i.hasNext()) {
			WebElement row = i.next();
			List<WebElement> columns = row.findElements(By.tagName(tcol));
			logger.info("columns" + columns);
			for (WebElement element : columns) {

				tableData.add(element.getText());
				if (SectionName != "Bonus")

					while (tableData.contains("")) {
						tableData.remove("");
					}

			}
		}
		return tableData;

	}

	public static void waitForTextToAppear(WebElement element, String textToAppear, int timeoutsec) {
		try {

			WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(timeoutsec));
			wait.until(ExpectedConditions.textToBePresentInElement(element, textToAppear));
		} catch (StaleElementReferenceException e) {
			System.out.print(e);
		} catch (TimeoutException e) {
			System.out.print(e);
		}

	}

	/**
	 * Logout in GUI Mode
	 */
	public static void logout() {
		try {
			SeleniumHelperClass.Logout();
			waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
		} catch (UnhandledAlertException uae) {
			logger.info("-----Unhandled alert exception-----");
			SetWebDrivers.getDriver().switchTo().alert().accept();
			try {
				SeleniumHelperClass.Logout();
			} catch (Exception e) {
				// TODO Auto-generated catch block
			}
		} catch (Exception e) {
			logger.info("-----Issue while logging out-----");
			e.printStackTrace();
		}

	}

	public static String ExecuteJavaScript(String script) throws Exception {
		JavascriptExecutor js = (JavascriptExecutor) (SetWebDrivers.getDriver());
		waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
		String value = (String) js.executeScript(script);
		waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
		return value;

	}

	public static int generateRandomNumber() {
		Random r = new Random();
		int value = r.nextInt(50);
		return value;
	}

	public static int generateRandomNumber(int maximum, int minimum) {
		return ((int) (Math.random() * (maximum - minimum))) + minimum;
	}

	public static String getPageSource() {
		return (SetWebDrivers.getDriver().getPageSource());
	}

	/**
	 * @param xpathString
	 * @param frameName
	 * @return
	 * @throws Exception
	 */
	public static WebElement findWebElementbyNoWaitXpath(final String xpathString, String frameName) throws Exception {
		goToFrame(frameName);
		try {
			return SetWebDrivers.getDriver().findElement(By.xpath(xpathString));

		} catch (Exception e) {
			logger.info("Exception in findWebElementbyxpath() :: xpath " + xpathString + " : " + e.toString());
			throw e;
		}
	}

	/**
	 * @param frameName
	 * @return
	 * @throws Exception
	 */

	public static void waitForSpinnerToDisAppear(String frameName, int sec) throws Exception {
		goToFrame(frameName);
		Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver()).withTimeout(Duration.ofSeconds(sec))
				.pollingEvery(Duration.ofMillis(500)).ignoring(NoSuchElementException.class)
				.ignoring(WebDriverException.class);
		try {

			wait.until(ExpectedConditions.attributeContains(By.xpath(".//div[@class='k-loading-image']"), "style",
					"display: none;"));

		} catch (Exception e) {
			logger.info("Exception in waitForSpinnerToDisAppear() :: xpath " + " : " + e.toString());

		}
	}

	public static void waitForTextToAppear(String xpathString, String textToAppear, int timeoutsec) {
		try {
			WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(timeoutsec));
			wait.until(ExpectedConditions
					.textToBePresentInElement(SeleniumHelperClass.findWebElementbyXpath(xpathString), textToAppear));
		} catch (Exception e) {
			logger.info(e);
		}
	}

	public static void waitForFrame(String frameId, int timeoutsec) {
		try {
			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeoutsec)).pollingEvery(Duration.ofMillis(500))
					.ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id(frameId)));
		} catch (Exception e) {
			logger.info(e);
		}
	}

	public static void selectDateNew(String month, String year, String date) throws Exception {
		WebElement datePicker = SeleniumHelperClass.findWebElementbyid("ui-datepicker-div");
		Select yearNew = selectFromDropdownwithelements("xpath", "//select[@class='ui-datepicker-year']", "mainFrame");
		yearNew.selectByVisibleText(year);
		Select monthNew = selectFromDropdownwithelements("xpath", "//select[@class='ui-datepicker-month']",
				"mainFrame");
		monthNew.selectByVisibleText(month);
		List<WebElement> noOfColumns = datePicker.findElements(By.tagName("td"));

		for (WebElement cell : noOfColumns) {

			if (cell.getText().equals(date)) {
				cell.findElement(By.linkText(date)).click();
				break;
			}
		}
	}

	public static void waitUntilJobLoaderDisappears() throws Exception {
		waitInMS(1000);
		Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
				.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
				.ignoring(NoSuchElementException.class);
		// WebDriverWait wait=new WebDriverWait(SetWebDrivers.getDriver(),
		// timeout);
		wait.until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				try {
					if (!SeleniumHelperClass.findWebElementbyXpath("//img[@id='calc_icon']", "topFrame")
							.isDisplayed()) {

						return true;

					} else {
						logger.info("Waiting for loader to disappear");
						return false;
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					logger.info("Loader not found");
					try {
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					return true;
					// e.printStackTrace();
				}
			}
		});

	}

	public static void enableInputField(String Path, WebElement disableField, WebElement browseButton)
			throws Exception {
		JavascriptExecutor js = (JavascriptExecutor) SetWebDrivers.getDriver();
		js.executeScript("arguments[0].removeAttribute('disabled')", disableField);
		browseButton.sendKeys(Path);
		js.executeScript("arguments[0].value=arguments[1]", disableField, Path);
	}

	public static boolean isFileDownloaded(String downloc, String fileName) throws InterruptedException {
		boolean flag = false;
		File dir = new File(downloc);
		File[] dir_contents = dir.listFiles();
		int pollingInterval = 0;
		do {
			for (int i = 0; i < dir_contents.length; i++) {
				if (dir_contents[i].getName().equals(fileName)) {
					flag = true;
				}
			}
			if (flag == false) {
				logger.info("File downloaded is not successful. Waiting for some more time....");
				waitInMS(SeleniumHelperClass.system_SpeedlimitMAX * 2);
			} else {
				logger.info("File downloaded is successful.");
				break;
			}
			pollingInterval++;
		} while (pollingInterval < 4);

		return flag;
	}

	public static void pollAndClickWebElementXTimes(int numTimes, WebElement element) throws InterruptedException {
		for (int i = 1; i <= numTimes; i++) {
			try {
				element.click();
				break;
			} catch (WebDriverException driverException) {
				System.out.println("Click on element failed. Attempt: " + i + "/" + numTimes);
				waitInMS(1000);
			}
			if (i == numTimes) {
				System.out.println("Failed to click " + numTimes + " times");
			}
		}
	}

	/**
	 * Returns windows opened after polling for expected number of windows
	 *
	 * @param expectedNumber
	 * @return WindowsOpened
	 * @throws
	 */
	public static Set<String> windowsHandler(int expectedNumber) {
		Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
				.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
				.ignoring(NoSuchElementException.class).ignoring(WebDriverException.class);
		wait.until(ExpectedConditions.numberOfWindowsToBe(expectedNumber));

		return SetWebDrivers.getDriver().getWindowHandles();
	}

	// DataType Array should be either String, Integer
	public static String getResultIDFromDBFormultipleColumns(String email, String tableName, String rID,
															 String[] colNames, String[] values, String[] dataType, String dbname)
			throws ClassNotFoundException, SQLException, InterruptedException {
		DBConnections db = new DBConnections();
		waitInMS(system_SpeedlimitMIN);

		StringBuffer queryString = new StringBuffer("SELECT * FROM ");
		queryString.append(tableName).append(" WHERE BUSINESS_ID=").append(getBusinessId(email));

		if (colNames != null) {
			for (int i = 0; i < colNames.length; i++) {

				queryString.append(" AND ").append(colNames[i]).append("=");
				if ("String".equals(dataType[i])) {
					queryString.append("'").append(values[i]).append("'");
				} else {
					queryString.append(values[i]);
				}
			}
		}

		String result = db.connect_Db_string(queryString.toString(), rID, dbname);

		logger.info(result);
		return result;
	}

	public static void waitForPageToLoad(String frameName) {
		try {
			SeleniumHelperClass.waitForSpinner(frameName);
		} catch (Exception e) {
			logger.info("Spinner does not exist ...");
		}
	}

	public static boolean xlsxFileComparison(String expectedPPPFile, String expectedFileLocation) {
		boolean flag = true;
		try {

			File fielE = new File(expectedFileLocation);
			ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
			File fielA = new File(classLoader.getResource(expectedPPPFile).getFile());

			FileInputStream expectedFile = new FileInputStream(fielE);
			FileInputStream actualFile = new FileInputStream(fielA);
			List<String> actualFileHeaders = new ArrayList<String>();
			List<String> expectedFileHeaders = new ArrayList<String>();
			XSSFCell cellExpected;
			XSSFCell cellActual;
			XSSFWorkbook wBookActual = new XSSFWorkbook(actualFile);
			XSSFWorkbook wBookExpected = new XSSFWorkbook(expectedFile);
			XSSFSheet sheetA = wBookActual.getSheetAt(0);
			XSSFSheet sheetE = wBookExpected.getSheetAt(0);
			Iterator<Row> rowIteratorA = sheetA.iterator();
			Iterator<Row> rowIteratorE = sheetE.iterator();

			int count = 0;
			boolean isHeaderCompletes = false;
			while (rowIteratorA.hasNext() && count == 0) {
				XSSFRow headerA = (XSSFRow) rowIteratorA.next();
				Iterator<Cell> cellIteratorActual = headerA.cellIterator();
				cellActual = (XSSFCell) cellIteratorActual.next();
				while (cellIteratorActual.hasNext() && !isHeaderCompletes) {
					switch (cellActual.getCellType()) {
						case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_BLANK:
							isHeaderCompletes = true;
							break;
						default:
							actualFileHeaders.add(cellActual.getStringCellValue());
							break;
					}

					cellActual = (XSSFCell) cellIteratorActual.next();
				}
			}

			isHeaderCompletes = false;
			while (rowIteratorE.hasNext() && count == 0) {
				XSSFRow headerE = (XSSFRow) rowIteratorE.next();
				Iterator<Cell> cellIteratorExpected = headerE.cellIterator();
				cellExpected = (XSSFCell) cellIteratorExpected.next();
				while (cellIteratorExpected.hasNext() && !isHeaderCompletes) {
					switch (cellExpected.getCellType()) {
						case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_BLANK:
							isHeaderCompletes = true;
							break;
						default:
							expectedFileHeaders.add(cellExpected.getStringCellValue());
							break;
					}

					cellExpected = (XSSFCell) cellIteratorExpected.next();
				}
			}

			wBookActual.close();
			wBookExpected.close();

			logger.info("expectedFileHeader::" + expectedFileHeaders);
			logger.info("actualFileHeaders::" + actualFileHeaders);
			flag = actualFileHeaders.equals(expectedFileHeaders);

		} catch (Exception ioe) {
			ioe.printStackTrace();
		}
		return flag;
	}

	public static void clickElementUsingJavascriptExecutor(WebElement element) {
		WebDriver driver = SetWebDrivers.getDriver();
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", element);
		;
	}

	public static void clickElementUsingActions(WebElement ele) {
		WebDriver driver = SetWebDrivers.getDriver();
		Actions action = new Actions(driver);
		action.moveToElement(ele).click().build().perform();
	}

	public static void scrollElementIntoViewUsingJS(WebElement ele) {
		WebDriver driver = SetWebDrivers.getDriver();
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].scrollIntoView(true);", ele);
	}

	public static void selectFromPopupandClear(String popupLinkId, String searchFieldId, String searchString,
											   String frame) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		SeleniumHelperClass.findWebElementbyid(popupLinkId, frame).click();
		waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		System.out.println("Windows opened :" + windowHandlers.size());
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				try {
					SetWebDrivers.getDriver().switchTo().window(windowHandle);
					logger.info("Switched to Child window");
					waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
					WebElement nameTextField = SeleniumHelperClass
							.findWebElementbyXpath("//input[starts-with(@id, '" + searchFieldId + "')]");
					nameTextField.sendKeys(searchString);
					WebElement searchButton = SeleniumHelperClass.findWebElementbyXpath("//*[@id=\"searchButton\"]");
					SeleniumHelperClass.isClickable(searchButton, 10);
					searchButton.click();
					waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
					WebElement table = SeleniumHelperClass.findWebElementbyXpath("//*[@id=\"tableFixed\"]");
					clickFirstRowOfTable(table);
					SeleniumHelperClass.findWebElementbyXpath("//*[@id='clearButton']").click();
				} catch (Exception e) {
					Thread.currentThread().interrupt();
					SetWebDrivers.getDriver().close();
					logger.info("Closed the child window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}
		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
	}

	@SuppressWarnings("deprecation")
	public static void waitPageLoad() {
		WebDriver driver = SetWebDrivers.getDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver wdriver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
			}
		});
	}

	/**
	 * functionality to navigate to back window browser
	 */
	public static void clickOnBackButton() throws InterruptedException {
		WebDriver driver = SetWebDrivers.getDriver();
		driver.navigate().back();

	}

	/**
	 * @author ahanda
	 * @param tabNmbr = tab to which you want to switch to
	 * @function JavascriptExecutor wait for page to load
	 */
	public static ArrayList<String> newTabs;

	public static void openNewTab() {
		((JavascriptExecutor) SetWebDrivers.getDriver()).executeScript("window.open()");
	}

	public static void openNewUrl(String url) {
		SetWebDrivers.driver.get(url);
	}

	public static void switchTabs(String window) {
		newTabs = new ArrayList<String>(SetWebDrivers.getDriver().getWindowHandles());
		switch (window) {
			case "parent":
				SetWebDrivers.getDriver().switchTo().window(newTabs.get(0));
				break;
			case "child":
				SetWebDrivers.getDriver().switchTo().window(newTabs.get(1));
				break;
		}
	}

	public static String uniqueCharSequence() {
		return RandomStringUtils.randomAlphanumeric(20);
	}

	public static void clickHoldAndMoveTo(WebElement element1, WebElement element2) {

		new Actions(SetWebDrivers.getDriver()).clickAndHold(element1).moveToElement(element2).perform();

	}

	public static void MouseHoverclickHoldAndMoveByOffSet(WebElement element1, WebElement element2, int xOffset,
														  int yOffset) throws AWTException {

		new Actions(SetWebDrivers.getDriver()).moveToElement(element1).clickAndHold(element2)
				.dragAndDropBy(element2, xOffset, yOffset).build().perform();

	}

	public static void releaseHoldedElement(WebElement element) {

		new Actions(SetWebDrivers.getDriver()).release(element).perform();

	}

	public static void pageRefresh() {
		WebDriver driver = SetWebDrivers.getDriver();
		driver.navigate().refresh();
	}

	public static boolean isElementEnabled(WebElement ele) {
		return ele.isEnabled();
	}

	// Selenium 4 relative locators

	public static WebElement findWebElementAboveWebElement(final String tagname, String frameName,
														   String belowElementLocatorType, String belowElementLocatorValue, int timeout) throws Exception {
		if (frameName != "" && frameName != null)
			goToFrame(frameName);

		waitInMS(system_SpeedlimitMIN / 2);
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
					.ignoring(NoSuchElementException.class);

			WebElement obj = wait.until(new ExpectedCondition<WebElement>() {
				public WebElement apply(WebDriver d) {

					By b = null;
					if (belowElementLocatorType.equals("xpath"))
						b = By.xpath(belowElementLocatorValue);
					else if (belowElementLocatorType.equals("id"))
						b = By.id(belowElementLocatorValue);
					else if (belowElementLocatorType.equals("css"))
						b = By.cssSelector(belowElementLocatorValue);
					else if (belowElementLocatorType.equals("class"))
						b = By.className(belowElementLocatorValue);
					else if (belowElementLocatorType.equals("tag"))
						b = By.tagName(belowElementLocatorValue);

					return d.findElement(with(By.tagName(tagname)).above(b));
				}
			});

			waitForElmentToBeReady(obj);
			return obj;
		} catch (Exception e) {
			logger.info("Exception in FindWebElementbelow() :: tagname " + tagname + " : " + e.toString());
			throw e;
		}
	}

	public static WebElement findWebElementBelowWebElement(final String tagname, String frameName,
														   String aboveElementLocatorType, String aboveElementLocatorValue, int timeout) throws Exception {
		if (frameName != "" && frameName != null)
			goToFrame(frameName);

		waitInMS(system_SpeedlimitMIN / 2);
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
					.ignoring(NoSuchElementException.class);

			WebElement obj = wait.until(new ExpectedCondition<WebElement>() {
				public WebElement apply(WebDriver d) {

					By b = null;
					if (aboveElementLocatorType.equals("xpath"))
						b = By.xpath(aboveElementLocatorValue);
					else if (aboveElementLocatorType.equals("id"))
						b = By.id(aboveElementLocatorValue);
					else if (aboveElementLocatorType.equals("css"))
						b = By.cssSelector(aboveElementLocatorValue);
					else if (aboveElementLocatorType.equals("class"))
						b = By.className(aboveElementLocatorValue);
					else if (aboveElementLocatorType.equals("tag"))
						b = By.tagName(aboveElementLocatorValue);

					return d.findElement(with(By.tagName(tagname)).below(b));
				}
			});

			waitForElmentToBeReady(obj);
			return obj;
		} catch (Exception e) {
			logger.info("Exception in FindWebElementbelow() :: tagname " + tagname + " : " + e.toString());
			throw e;
		}
	}

	public static WebElement findWebElementToLeftOfWebElement(final String tagname, String frameName,
															  String rightElementLocatorType, String rightElementLocatorValue, int timeout) throws Exception {
		if (frameName != "" && frameName != null)
			goToFrame(frameName);

		waitInMS(system_SpeedlimitMIN / 2);
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
					.ignoring(NoSuchElementException.class);

			WebElement obj = wait.until(new ExpectedCondition<WebElement>() {
				public WebElement apply(WebDriver d) {

					By b = null;
					if (rightElementLocatorType.equals("xpath"))
						b = By.xpath(rightElementLocatorValue);
					else if (rightElementLocatorType.equals("id"))
						b = By.id(rightElementLocatorValue);
					else if (rightElementLocatorType.equals("css"))
						b = By.cssSelector(rightElementLocatorValue);
					else if (rightElementLocatorType.equals("class"))
						b = By.className(rightElementLocatorValue);
					else if (rightElementLocatorType.equals("tag"))
						b = By.tagName(rightElementLocatorValue);

					return d.findElement(with(By.tagName(tagname)).toLeftOf(b));
				}
			});

			waitForElmentToBeReady(obj);
			return obj;
		} catch (Exception e) {
			logger.info("Exception in FindWebElementbelow() :: tagname " + tagname + " : " + e.toString());
			throw e;
		}
	}

	public static WebElement findWebElementToRightOfWebElement(final String tagname, String frameName,
															   String leftElementLocatorType, String leftElementLocatorValue, int timeout) throws Exception {
		if (frameName != "" && frameName != null)
			goToFrame(frameName);

		waitInMS(system_SpeedlimitMIN / 2);
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
					.ignoring(NoSuchElementException.class);

			WebElement obj = wait.until(new ExpectedCondition<WebElement>() {
				public WebElement apply(WebDriver d) {

					By b = null;
					if (leftElementLocatorType.equals("xpath"))
						b = By.xpath(leftElementLocatorValue);
					else if (leftElementLocatorType.equals("id"))
						b = By.id(leftElementLocatorValue);
					else if (leftElementLocatorType.equals("css"))
						b = By.cssSelector(leftElementLocatorValue);
					else if (leftElementLocatorType.equals("class"))
						b = By.className(leftElementLocatorValue);
					else if (leftElementLocatorType.equals("tag"))
						b = By.tagName(leftElementLocatorValue);

					return d.findElement(with(By.tagName(tagname)).toRightOf(b));
				}
			});

			waitForElmentToBeReady(obj);
			return obj;
		} catch (Exception e) {
			logger.info("Exception in FindWebElementbelow() :: tagname " + tagname + " : " + e.toString());
			throw e;
		}
	}

	public static WebElement findWebElementNearByWebElement(final String tagname, String frameName,
															String nearElementLocatorType, String nearElementLocatorValue, int timeout) throws Exception {
		if (frameName != "" && frameName != null)
			goToFrame(frameName);

		waitInMS(system_SpeedlimitMIN / 2);
		try {

			Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
					.withTimeout(Duration.ofSeconds(timeout)).pollingEvery(Duration.ofSeconds(pollingTime))
					.ignoring(NoSuchElementException.class);

			WebElement obj = wait.until(new ExpectedCondition<WebElement>() {
				public WebElement apply(WebDriver d) {

					By b = null;
					if (nearElementLocatorType.equals("xpath"))
						b = By.xpath(nearElementLocatorValue);
					else if (nearElementLocatorType.equals("id"))
						b = By.id(nearElementLocatorValue);
					else if (nearElementLocatorType.equals("css"))
						b = By.cssSelector(nearElementLocatorValue);
					else if (nearElementLocatorType.equals("class"))
						b = By.className(nearElementLocatorValue);
					else if (nearElementLocatorType.equals("tag"))
						b = By.tagName(nearElementLocatorValue);

					return d.findElement(with(By.tagName(tagname)).near(b));
				}
			});

			waitForElmentToBeReady(obj);
			return obj;
		} catch (Exception e) {
			logger.info("Exception in FindWebElementbelow() :: tagname " + tagname + " : " + e.toString());
			throw e;
		}
	}

	public static void switchToDefaultContent() {
		SetWebDrivers.getDriver().switchTo().defaultContent();
	}

	public static void switchFrameByXpath(String frame) {
		WebElement element = SetWebDrivers.getDriver().findElement(By.xpath(frame));
		SetWebDrivers.getDriver().switchTo().frame(element);
	}

	public static String generateRandomString(int index) {
		return RandomStringUtils.randomAlphanumeric(index).toUpperCase();
	}

	public static void clearSomeCharacters(WebElement element, int numberOfChar) {
		int index = 0;
		while (index < numberOfChar) {
			element.sendKeys(Keys.BACK_SPACE);
			index++;
		}
	}

	public static WebElement waitForElement(final String how, final String value, int sec) throws Exception {

		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(sec));

		if (how.equalsIgnoreCase("xpath")) {
			return wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(value)));
		} else if (how.equalsIgnoreCase("id")) {
			return wait.until(ExpectedConditions.presenceOfElementLocated(By.id(value)));
		} else if (how.equalsIgnoreCase("class")) {
			return wait.until(ExpectedConditions.presenceOfElementLocated(By.className(value)));
		} else if (how.equalsIgnoreCase("link")) {
			return wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(value)));
		} else if (how.equalsIgnoreCase("name")) {
			return wait.until(ExpectedConditions.presenceOfElementLocated(By.name(value)));
		} else if (how.equalsIgnoreCase("css")) {
			return wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(value)));
		} else {
			return null;
		}
	}

	public static Boolean waitUntilInvisibilityOfLocatedElement(String xpath) {
		try {
			WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(30));
			return wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(xpath)));
		} catch (Exception e) {
			return false;
		}
	}

	public static void waitUntilVisibilityOfElementLocatedBy(String element) {
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element)));
	}

	public static String getCurrentTimeStamp(String pattern) {
		SimpleDateFormat simpleDateFormate = new SimpleDateFormat(pattern);
		String date = simpleDateFormate.format(new Date());
		return date;
	}

	public static void SelectElementByValue(WebElement element, String value) {
		Select select = new Select(element);
		select.selectByValue(value);
	}

	public static void SelectElementByVisibleText(WebElement element, String value) {
		Select select = new Select(element);
		select.selectByVisibleText(value);
	}

	public static void SelectElementByIndex(WebElement element, int index) {
		Select select = new Select(element);
		select.selectByIndex(index);
	}

	/**
	 * This function will return single selected drop down value
	 *
	 * @param element
	 * @return text of first selected dropdown value
	 */
	public static String getSelectedDropDownValue(WebElement element) {
		Select select = new Select(element);
		WebElement option = select.getFirstSelectedOption();
		String defaultItem = option.getText().trim();
		return defaultItem;
	}

	/**
	 * This method is used to select multiple checkboxes on page
	 *
	 * @throws Exception
	 */

	public static int selectMultipleCheckBoxes() throws Exception {
		int checkedCount = 0, uncheckedCount = 0;
		List<WebElement> checkBoxes = SeleniumHelperClass.findWebElements("//input[@type='checkbox']", "mainFrame");
		for (int i = 0; i < checkBoxes.size(); i = i + 2) {
			checkBoxes.get(i).click();
		}
		for (int i = 0; i < checkBoxes.size(); i++) {
			if (checkBoxes.get(i).isSelected()) {
				checkedCount++;
			} else {
				uncheckedCount++;
			}
		}

		return checkedCount;
	}

	/**
	 * This method is used to count selected checkboxes on page
	 *
	 * @throws Exception
	 */

	public static int countCheckedboxes() throws Exception {
		int selectedCheckBoxes = 0;
		List<WebElement> checkBoxes = SeleniumHelperClass.findWebElements("//input[@type='checkbox']", "mainFrame");
		for (int i = 0; i < checkBoxes.size(); i++) {
			if (checkBoxes.get(i).isSelected()) {
				selectedCheckBoxes++;
			}
		}
		return selectedCheckBoxes;

	}

	/**
	 * Method to wait untill element to invisible
	 * @param element
	 * @param timeout
	 * @return
	 */
	public static boolean waitForElementToBeInvisible(WebElement element,int timeout) {
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(timeout));
		return wait.until(ExpectedConditions.invisibilityOf(element));
	}

}
