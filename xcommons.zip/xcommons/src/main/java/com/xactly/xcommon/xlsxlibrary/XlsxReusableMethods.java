package com.xactly.xcommons.xlsxlibrary;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Assert;

import com.xactly.xcommons.selenium.Constants;
import com.xactly.xcommons.selenium.SeleniumHelperClass;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

public class XlsxReusableMethods {
	public static Logger logger = Logger.getLogger(XlsxReusableMethods.class.getName());
	public void updateExcelCellValue(String filePath,String sheetName,int rowNum,String columnName,String cellValue)
	{
		FileInputStream fis=null;
		XSSFWorkbook workbook=null;
		FileOutputStream outFile=null;
		XlsxReusableMethods xls=new XlsxReusableMethods();
		int columnNum=xls.getColumnNum(filePath, sheetName, columnName);
		try
		{
			fis=new FileInputStream(new File(filePath));
			workbook= new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);
			Row rw=sheet.getRow(rowNum);
	        Cell cell=rw.getCell(columnNum);
	        cell.setCellValue(cellValue);
	        fis.close();
	        outFile =new FileOutputStream(filePath);
	        workbook.write(outFile);
	        outFile.close();
		}    
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
     		try {
     			outFile.close();
				workbook.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public int getColumnNum(String filePath,String sheetName,String columnName)
	{
		FileInputStream fis=null;
		XSSFWorkbook workbook=null;
		int columnNum=-1;
		try
		{
			fis=new FileInputStream(new File(filePath));
			workbook= new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);
	        Row headerRow=sheet.getRow(0);
	        int headerColCount=headerRow.getLastCellNum();
	        for(int i=0;i<headerColCount-1;i++)
	        {
	        	String colName=headerRow.getCell(i).getStringCellValue();
	        	if(columnName.equalsIgnoreCase(colName))
	        	{
	        		columnNum=i;
	        		break;
	        	}
	        }
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
     		try {
				fis.close();
				workbook.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
        return columnNum;
	}
	
	public void updateExcelCellValueByIndex(String filePath,String sheetName,int rowNum,int columnNum,String cellValue)
	{
		FileInputStream fis=null;
		XSSFWorkbook workbook=null;
		FileOutputStream outFile=null;
		XlsxReusableMethods xls=new XlsxReusableMethods();
		try
		{
			fis=new FileInputStream(new File(filePath));
			workbook= new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName);
			Row rw=sheet.getRow(rowNum);
	        Cell cell=rw.getCell(columnNum);
	        cell.setCellValue(cellValue);
	        fis.close();
	        outFile =new FileOutputStream(filePath);
	        workbook.write(outFile);
	        outFile.close();
		}    
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
     		try {
     			outFile.close();
				workbook.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void updateCSV(String file, int row, String columnName, String cellValue) throws IOException {
		
		int colNum;
		
		File inputFile = new File(file);

		// Read existing file 
		CSVReader reader = new CSVReader(new FileReader(inputFile), ',');
		List<String[]> fileData = reader.readAll();		
		reader.close();
		
		List<String> header =new ArrayList<String>();
		
		for(int i=0;i<fileData.get(0).length;i++){
			header.add(fileData.get(0)[i]);
		}
		
		for (int j=0;j<header.size();j++) {
			if (header.get(j).equals(columnName)) {
				colNum = j;
				fileData.get(row)[colNum] = cellValue;
				reader.close();
			}
		}
		// Write to CSV file which is open
		CSVWriter writer = new CSVWriter(new FileWriter(inputFile), ',');
		writer.writeAll(fileData);
		writer.flush();
		writer.close();
		
		
	}
	
	public void txtAndCSVFileComparision(String filePath,String fileName)throws Exception{
		File expectedFile = new File(System.getProperty("user.dir")+filePath +fileName);
		logger.info("expectedReportFile:----"+expectedFile);
		String downloc = Constants.downloadLoc;
		logger.info("Download location:"+downloc);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		File actualFile = SeleniumHelperClass.getLatestFilefromDir(downloc);
		BufferedReader reader1 = new BufferedReader(new FileReader(expectedFile));  
	    BufferedReader reader2 = new BufferedReader(new FileReader(actualFile));
		      String line1 = reader1.readLine();    
		      String line2 = reader2.readLine();
		      int lineNum = 1;  
		      boolean areEqual = true;
		      while (line1 != null || line2 != null){
		         if(line1 == null || line2 == null){
		            areEqual = false; 
		            break;
		         } else if(! line1.equalsIgnoreCase(line2)) {
		            areEqual = false; 
		            break;
		         }
		         line1 = reader1.readLine();  
		         line2 = reader2.readLine();
		         lineNum++;
		      }
		      if(areEqual){
		    	  logger.info("Both the files have same content");
		    	  Assert.assertEquals(areEqual,true);
		      } else {
		    	  logger.info("Both the files have different content");
		    	  logger.info("In both files, there is a difference at line number: "+lineNum); 
		    	  logger.info("One file has "+line1+" and another file has "+line2+" at line "+lineNum);
		    	  Assert.assertEquals(areEqual,true);
		      }
		      reader1.close();
		      reader2.close();
	}
	
}
