package com.xactly.xcommons.selenium;

import java.sql.SQLException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import com.xactly.xcommons.app.LoginToApplication;
import com.xactly.xcommons.javahelper.Time;

import org.apache.log4j.Logger;

/**
 * Created by vsadipiralla on 10/31/2014.
 */
public class ObjectivesHelperClass {
	public static Logger logger = Logger.getLogger(ObjectivesHelperClass.class.getName());
	public static Properties symProPath = new Properties();
	public static Properties userProPath = new Properties();
	public static String url;
	public static String username;
	public static String password;
	public static int system_SpeedlimitMIN=2000;
	
	@BeforeClass (alwaysRun = true)
	@Parameters({"environment", "application"})
	public  void loginToObjectives(@Optional String environment,@Optional String application) throws Exception{
		environment=environment.toLowerCase();
		logger.info("environment : " + environment);
		logger.info("application : " + application);
		String propFile=environment+".properties";
		
		LoginToApplication appLogin = new LoginToApplication();

		LoginToApplication.setSystemPropertyInputStream(this.getClass()
				.getClassLoader()
				.getResourceAsStream(propFile));

		symProPath.load(LoginToApplication.getSystemPropertyInputStream());

		//LoginToApplication.setUrl(LoginToApplication.symProPath.getProperty("url"));
		logger.info(symProPath.getProperty("url"));
		
		new SetWebDrivers();
		//logger.info("Url:"+getUrl()+"\nUsername:"+getUsername()+"\nPassword:"+getPassword(),2,true);
		SeleniumHelperClass.findWebElementbyid("login").sendKeys(symProPath.getProperty(application+".username"));
		SeleniumHelperClass.findWebElementbyid("password").sendKeys(symProPath.getProperty(application+".password"));
		SeleniumHelperClass.findWebElementbyid("loginBtn").click();
		SetWebDrivers.getDriver().manage().timeouts()
		.implicitlyWait(30, TimeUnit.SECONDS);

	}

    public static boolean isElementPresent(String elementType, String element, int timeOut )
    {
        try{
            WebDriverWait wait=new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(timeOut));
            if (elementType.equalsIgnoreCase("css"))
                {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(element)));
                }
            if (elementType.equalsIgnoreCase("xpath"))
                {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(element)));
                }
            if  (elementType.equalsIgnoreCase("id"))
                {
                wait.until(ExpectedConditions.presenceOfElementLocated(By.id(element)));
                }

            return true;
            }
        catch(Exception e) {
            return false;
        }
    }

    public static void isPageLoading()throws Exception{
            //logger.info("Checking Page Loading");
    		 while (existsElement()) 
			 	{
            	 	Thread.sleep(1000);
			 	}
    }
    
    public static boolean existsElement() {
    	WebDriver driver=SetWebDrivers.getDriver();
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); //clearing the implicit wait
		Wait<WebDriver> wait = new FluentWait<WebDriver>(SetWebDrivers.getDriver())
				.withTimeout(Duration.ofSeconds(8))
				.pollingEvery(Duration.ofSeconds(2))
				.ignoring(NoSuchElementException.class);
        try {
        	wait.until(ExpectedConditions.presenceOfElementLocated(By.className("div.k-loading-image")));
        	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        	return true;
        } catch (Exception e) {
        	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        	return false;
        }
    }

    public static int countOfItemsInListPage() throws Exception{
        String count = SeleniumHelperClass.findWebElementbyCssSelector("span.count", "").getText();
        if (count == null || count.isEmpty()){
            return 0;
        }
        int count_length = count.length();
        count = count.substring(1, count_length-1);
        return Integer.parseInt(count);
    }

    public static WebElement get_profile_dropdown()throws Exception{
        return SeleniumHelperClass.findWebElementbyid("welcomeDD");
    }
    public static WebElement get_logout_link()throws Exception{
        return SeleniumHelperClass.findWebElementbyLink("Logout", "");
    }
    public static void logout()throws Exception{
        ObjectivesHelperClass.isPageLoading();
        get_profile_dropdown().click();
        get_logout_link().click();
        SetWebDrivers.getDriver().quit();
    }
    
    public static void windowScrollUp()
    {
    	WebDriver driver=SetWebDrivers.getDriver();
    	JavascriptExecutor jse = (JavascriptExecutor)driver;
    	jse.executeScript("window.scrollBy(0,-250)", "");
    }
    
    public static void windowScrollDown()
    {
    	WebDriver driver=SetWebDrivers.getDriver();
    	JavascriptExecutor jse = (JavascriptExecutor)driver;
    	jse.executeScript("window.scrollBy(0,250)", "");
    }
    
   
	public static String getParticipantIDfromDB(String name) throws ClassNotFoundException, SQLException, InterruptedException{
		DBConnections db=new DBConnections("gui","objectives");
		Thread.sleep(system_SpeedlimitMIN);
		String result=db.connect_Db_string("select PARTICIPANT_ID from XC_Participant where NAME like '"+name+"'","PARTICIPANT_ID");
		logger.info(result);
		return result;
	}
	
    
	public static int getRowCountfromDB(String templateName, String particapantID) throws ClassNotFoundException, SQLException, InterruptedException{
		DBConnections db=new DBConnections("gui","objectives");
		Thread.sleep(system_SpeedlimitMIN);
		ArrayList<String> result=db.connect_Db("select * from xo_plan where TITLE like '"+templateName+"' AND is_template like 'N' AND PARTICIPANT_ID = "+particapantID, "PLAN_ID");
		logger.info(result);
		return result.size();
	}

}

