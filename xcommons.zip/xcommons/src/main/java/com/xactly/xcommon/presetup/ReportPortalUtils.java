package com.xactly.xcommons.presetup;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;

import net.minidev.json.JSONArray;

public class ReportPortalUtils {

	public static String acessToken = null;
	public static final String _baseurl="http://qametrics01:8080";
	public static final String _url=_baseurl+"/api/v1/";
	public static String _username="smtpauth";
	public static String _password="qamailserver";
	public static final String _size="1000";
	private static ZoneId zoneId = ZoneId.systemDefault();
	
	public static void setAcessToken() {
		try {
			System.out.println(".....Generating Access Token");
			Response response = RestAssured.given().header("Content-Type", "application/x-www-form-urlencoded")
					.header("Authorization", "Basic dWk6dWltYW4=").formParam("grant_type", "password")
					.formParam("username", _username).formParam("password", _password).log().all()
					.post(_baseurl + "/uat/sso/oauth/token");
			String access_token = JsonPath.read(response.asString(), "$.access_token");
			System.out.println("AccessToken..." + access_token);
			ReportPortalUtils.acessToken = access_token;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void stopLaunch(String rpProject,String launchId) {
		String body="{\"end_time\" : \"2021\",\"msg\" : \"deleting\"}";
		Response resp = RestAssured.given().contentType("application/json").header("Accept", "application/json")
				.header("Authorization", "bearer " + getAccessToken())
				.body(body)
				.when().expect().statusCode(200)
				.put(_url + rpProject + "/launch/"+launchId+"/stop");
		System.out.println(resp.asString());
	}
	
	private static String getAccessToken() {
		if (acessToken == null) {
			setAcessToken();
		}
		return acessToken;
	}
	
	public static long getExecutionTime(long sTime,long eTime)
	{
		LocalDateTime start = LocalDateTime 
		        .ofInstant(Instant.ofEpochMilli(sTime), zoneId)
		        .truncatedTo(ChronoUnit.MINUTES);
		LocalDateTime stop = LocalDateTime
		        .ofInstant(Instant.ofEpochMilli(eTime), zoneId)
		        .truncatedTo(ChronoUnit.MINUTES);
		Duration duration = Duration.between(start, stop);
		return duration.toMinutes();
	}
	
	public HashMap<String, ReportPortalJob> getLaunchDetails(String rpProject, String filter) {
		HashMap<String, ReportPortalJob> launchData = new HashMap<String, ReportPortalJob>();
		Response resp = RestAssured.given().log().all().contentType("application/json").header("Accept", "application/json")
				.header("Authorization", "bearer " + getAccessToken()).when().expect().statusCode(200)
				.get(_url + rpProject + "/launch/latest?page.page=1&page.size=" + _size + "&filter.cnt.name=" + filter
						+ "&page.sort=start_time");
		String responseString = resp.asString();
		JSONArray content = JsonPath.read(responseString, "$.content");
		for (int i = 0; i < content.size(); i++) {
			ReportPortalJob job = new ReportPortalJob();
			String name = JsonPath.read(responseString, "$.content[" + i + "].name");
			String id = JsonPath.read(responseString, "$.content[" + i + "].id");
			String status = JsonPath.read(responseString, "$.content[" + i + "].status");
			String total = JsonPath.read(responseString, "$.content[" + i + "].statistics.executions.total");
			String passed = JsonPath.read(responseString, "$.content[" + i + "].statistics.executions.passed");
			Integer toInvestigateCount = JsonPath.read(responseString,
					"$.content[" + i + "].statistics.defects.to_investigate.total");
			long startTime = JsonPath.read(responseString, "$.content[" + i + "].start_time");
			long endTime = 0;
			try {
				endTime = JsonPath.read(responseString, "$.content[" + i + "].end_time");
			}
			catch(Exception e)
			{
				endTime = Instant.now().toEpochMilli();
			}
			job.setStartTime(startTime);
			job.setEndTime(endTime);
			job.setName(name);
			job.setId(id);
			job.setStatus(status);
			job.setTotalCount(total);
			job.setPassCount(passed);
			job.setToInvestigateCount(toInvestigateCount);
			job.setExecutionTime(getExecutionTime(job.getStartTime(),job.getEndTime()));
			launchData.put(name, job);
		}
		return launchData;
	}
}
