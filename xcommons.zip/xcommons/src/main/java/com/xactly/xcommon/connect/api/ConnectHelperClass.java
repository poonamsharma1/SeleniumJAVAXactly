package com.xactly.xcommons.connectapi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;

import net.minidev.json.parser.ParseException;

import org.testng.Reporter;

import au.com.bytecode.opencsv.CSVReader;

import com.xactly.icm.xtoolkit.service.XService;
import com.xactly.icm.xtoolkit.wso.CurrencyRateWSO;
import com.xactly.icm.xtoolkit.wso.DeleteResponse;
import com.xactly.icm.xtoolkit.wso.ErrorCode;
import com.xactly.icm.xtoolkit.wso.OrderStageWSO;
import com.xactly.icm.xtoolkit.wso.PersonWSO;
import com.xactly.icm.xtoolkit.wso.PositionWSO;
import com.xactly.icm.xtoolkit.wso.SearchResponse;
import com.xactly.icm.xtoolkit.wso.UserWSO;
import com.xactly.icm.xtoolkit.wso.XObject;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.json.JSONException;

import com.xactly.xcommons.selenium.SetWebDrivers;
import org.apache.log4j.Logger;

public class ConnectHelperClass {
public static Logger logger = Logger.getLogger(ConnectHelperClass.class.getName());
	private CSVReader reader;
	XService service;
	public DeleteResponse deleteResponse;

	public static byte[] getBytesFromFile(File file) throws Exception,
			IOException {
		InputStream is = new FileInputStream(file);
		/* Get the size of the file */
		long length = file.length();

		/*
		 * You cannot create an array using a long type. // It needs to be an
		 * int type. // Before converting to an int type, check // to ensure
		 * that file is not larger than Integer.MAX_VALUE.
		 */
		if (length > Integer.MAX_VALUE) {
			throw new Exception("File too large");
		}

		/* Create the byte array to hold the data */
		byte[] bytes = new byte[(int) length];

		// Read in the bytes
		int offset = 0;
		int numRead = 0;
		while (offset < bytes.length
				&& (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0) {
			offset += numRead;
		}
		// Ensure all the bytes have been read in
		if (offset < bytes.length) {
			throw new IOException("Could not completely read file "
					+ file.getName());
		}
		// Close the input stream and return bytes
		is.close();
		return bytes;
	}

	public static void waitForConnectService(int sec) throws SQLException,
			ClassNotFoundException, JSONException, IOException, ParseException {
		int responseCode;
		String url = PreSetupConnectAPI.symProPath
				.getProperty("Connect.baseURI")
				+ "/xiConnect/services/XService";
		URL urlObj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) urlObj.openConnection(); // optional
																				// default
																				// is
																				// GET
		con.setRequestMethod("GET"); // add request header

		while (sec > 0) {
			try {
				con = (HttpURLConnection) urlObj.openConnection(); // optional
																	// default
																	// is GET
				con.setRequestMethod("GET");
				// logger.info("Waiting for the response from connect service   \nStart Time:"+Time.currentTime());
				responseCode = con.getResponseCode();
				System.out
						.println("Recieved the response from connect service-"
								+ responseCode);
				if (responseCode == 200)
					break;
				else {
					logger.info("Waiting for Connect service");
				}

			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.info("Waiting for Connect service");
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			sec -= 1;
		}
		if (sec <= 0) {

			logger.info("Connect is down...Unable to proceed");
			SetWebDrivers.getDriver().close();
			System.exit(0);

		}

	}

	/**
	 * 
	 * Reads the CSV file at particular index
	 * 
	 * @param column
	 * @param uploadFile
	 * @return
	 * @throws IOException
	 */
	public List<String> ReadCSVColumnIndex(int index, File uploadFile)
			throws IOException {

		reader = new CSVReader(new FileReader(uploadFile));
		List<String> deleteList = new ArrayList<String>();
		List<String[]> csvBody = reader.readAll();
		for (int i = 1; i < csvBody.size(); i++) {
			String[] strings = csvBody.get(i);
			deleteList.add(strings[index]);

		}
		return deleteList;

	}

	public List<String> ReadCSVColumn(String field, File uploadFile)
			throws IOException {
		logger.info("Field in readExcel " + field);
		String formatField = formatField(field);
		logger.info("Formatted String = " + formatField);
		reader = new CSVReader(new FileReader(uploadFile));
		List<String[]> csvBody = reader.readAll();
		String[] header = csvBody.get(0);

		List<String> deleteList = new ArrayList<String>();
		for (int i = 0; i < header.length; i++) {
			if (header[i].contains(formatField)) {
				/* logger.info("Header : " + header[i] + "Index : " + i); */
				for (int j = 1; j < csvBody.size(); j++) {
					String[] strings = csvBody.get(j);
					if (!strings[i].equals("<EOF>")) {
						deleteList.add(strings[i]);

					}

				}

			}
		}
		deleteList.removeAll(Arrays.asList(null, ""));

		return deleteList;

	}

	public String formatField(String field) {
		StringBuilder s = new StringBuilder(field);

		for (int i = 1; i < s.length(); i++) {
			if (Character.isUpperCase(s.charAt(i))) {
				s.insert(i++, ' ');
			}
		}
		return s.toString();

	}

	public boolean deleteRecord(String field, String value, String entity,
			XService session) throws RemoteException, ParseException,
			java.text.ParseException {
		if (entity.equals("CurrencyRate")) {
			DeleteResponse deleteResponse = new DeleteResponse();
			CurrencyRateWSO currencyrateWSO = setCurrencyRateWSO(field, value);
			SearchResponse searchResponse = service.search(currencyrateWSO);

			XObject[] srXObjs = searchResponse.getSearchRecords();

			if (srXObjs != null) {
				for (int j = 0; j < srXObjs.length; j++) {
					currencyrateWSO = (CurrencyRateWSO) srXObjs[j];
					logger.info("ID:" + currencyrateWSO.getId() + "\n");
					logger.info("BaseCurrencyName:"
							+ currencyrateWSO.getBaseCurrencyName() + "\n");
					logger.info("ExchangeRate:"
							+ currencyrateWSO.getExchangeRate() + "\n");
					deleteResponse = session.delete(currencyrateWSO);

					ErrorCode[] errorCodes = deleteResponse.getErrorCodes();
					for (int i = 0; i < errorCodes.length; i++) {
						logger.info("errorCode: " + errorCodes[i].getCode()
								+ "\n");
						logger.info("errorMsg: " + errorCodes[i].getReason()
								+ "\n");
						logger.info("Stack Trace: "
								+ errorCodes[i].getStackTrace() + "\n");
					}
					logger.info("Expected response : true\n");
					if (deleteResponse.isResult()) {
						return true;
					} else {
						return false;
					}
				}
			} else if (srXObjs == null) {
				logger.info("Failed");
			}

		} else if (entity.equals("Position")) {
			deleteResponse = new DeleteResponse();

			PositionWSO positionWSO = setPositionWSO(field, value);
			SearchResponse searchResponse = service.search(positionWSO);

			XObject[] srXObjs = searchResponse.getSearchRecords();

			if (srXObjs != null) {
				for (int j = 0; j < srXObjs.length; j++) {
					positionWSO = (PositionWSO) srXObjs[j];

					deleteResponse = service.delete(positionWSO);

					ErrorCode[] errorCodes = deleteResponse.getErrorCodes();
					for (int i = 0; i < errorCodes.length; i++) {
						logger.info("errorCode: " + errorCodes[i].getCode()
								+ "\n");
						logger.info("errorMsg: " + errorCodes[i].getReason()
								+ "\n");
						logger.info("Stack Trace: "
								+ errorCodes[i].getStackTrace() + "\n");
					}
					logger.info("Expected response : true\n");
					if (deleteResponse.isResult()) {
						return true;
					} else {
						return false;
					}
				}
			} else if (srXObjs == null) {
				logger.info("Failed");
			}
		} else if (entity.equals("PersonXLSX")) {
			deleteResponse = new DeleteResponse();
			PersonWSO personWSO = setPersonWSO(field, value);

			SearchResponse searchResponse = service.search(personWSO);

			XObject[] srXObjs = searchResponse.getSearchRecords();

			if (srXObjs != null) {
				for (int j = 0; j < srXObjs.length; j++) {
					personWSO = (PersonWSO) srXObjs[j];

					deleteResponse = service.delete(personWSO);

					ErrorCode[] errorCodes = deleteResponse.getErrorCodes();
					for (int i = 0; i < errorCodes.length; i++) {
						logger.info("errorCode: " + errorCodes[i].getCode()
								+ "\n");
						logger.info("errorMsg: " + errorCodes[i].getReason()
								+ "\n");
						logger.info("Stack Trace: "
								+ errorCodes[i].getStackTrace() + "\n");
					}
					logger.info("Expected response : true\n");
					if (deleteResponse.isResult()) {
						return true;
					} else {
						return false;
					}
				}
			} else if (srXObjs == null) {
				logger.info("Failed");
			}

		} else if (entity.equals("User")) {
			deleteResponse = new DeleteResponse();
			UserWSO userWSO = setUserWSO(field, value);
			SearchResponse searchResponse = service.search(userWSO);

			XObject[] srXObjs = searchResponse.getSearchRecords();

			if (srXObjs != null) {
				for (int j = 0; j < srXObjs.length; j++) {
					userWSO = (UserWSO) srXObjs[j];

					deleteResponse = service.delete(userWSO);

					ErrorCode[] errorCodes = deleteResponse.getErrorCodes();
					for (int i = 0; i < errorCodes.length; i++) {
						logger.info("errorCode: " + errorCodes[i].getCode()
								+ "\n");
						logger.info("errorMsg: " + errorCodes[i].getReason()
								+ "\n");
						logger.info("Stack Trace: "
								+ errorCodes[i].getStackTrace() + "\n");
					}
					logger.info("Expected response : true\n");
					if (deleteResponse.isResult()) {
						return true;
					} else {
						return false;
					}
				}
			} else if (srXObjs == null) {
				logger.info("Failed");
			}
		} else if (entity.equals("OrderStageXLSX")) {
			deleteResponse = new DeleteResponse();
			OrderStageWSO oso = setOrderStageWSO(field, value);

			SearchResponse searchResponse = service.search(oso);

			XObject[] srXObjs = searchResponse.getSearchRecords();

			if (srXObjs != null) {
				for (int j = 0; j < srXObjs.length; j++) {
					oso = (OrderStageWSO) srXObjs[j];

					deleteResponse = service.delete(oso);

					ErrorCode[] errorCodes = deleteResponse.getErrorCodes();
					for (int i = 0; i < errorCodes.length; i++) {
						logger.info("errorCode: " + errorCodes[i].getCode()
								+ "\n");
						logger.info("errorMsg: " + errorCodes[i].getReason()
								+ "\n");
						logger.info("Stack Trace: "
								+ errorCodes[i].getStackTrace() + "\n");
					}
					logger.info("Expected response : true\n");
					if (deleteResponse.isResult()) {
						return true;
					} else {
						return false;
					}
				}
			} else if (srXObjs == null) {
				logger.info("Failed");
			}
		}

		return false;

	}

	public CurrencyRateWSO setCurrencyRateWSO(String field, String value) {

		if (field.equals("BaseCurrency")) {

			CurrencyRateWSO currencyrateWSO = new CurrencyRateWSO();

			currencyrateWSO.setBaseCurrencyName(value);
			return currencyrateWSO;

		} else if (field.equals("TargetCurrency")) {
			CurrencyRateWSO currencyrateWSO = new CurrencyRateWSO();

			currencyrateWSO.setTargetCurrencyName(value);
			return currencyrateWSO;

		} else if (field.equals("ExchangeRate")) {
			CurrencyRateWSO currencyrateWSO = new CurrencyRateWSO();

			currencyrateWSO.setExchangeRate(Double.parseDouble(value));
			return currencyrateWSO;
		}

		return null;

	}

	public UserWSO setUserWSO(String field, String value) {

		if (field.equals("Name")) {

			UserWSO userWSO = new UserWSO();

			userWSO.setName(value);
			return userWSO;

		} else if (field.equals("Email")) {
			UserWSO userWSO = new UserWSO();

			userWSO.setEmail(value);
			return userWSO;

		}

		return null;

	}

	public PositionWSO setPositionWSO(String field, String value) {

		if (field.equals("PositionName")) {

			PositionWSO positionWSO = new PositionWSO();

			positionWSO.setName(value);
			return positionWSO;

		} else if (field.equals("PositionDescription")) {
			PositionWSO positionWSO = new PositionWSO();
			positionWSO.setDescription(value);
			return positionWSO;

		} else if (field.equals("BusinessGroup")) {
			PositionWSO positionWSO = new PositionWSO();
			positionWSO.setBusinessGroupId(Long.parseLong(value));
			return positionWSO;

		}

		return null;
	}

	public PersonWSO setPersonWSO(String field, String value)
			throws ParseException, java.text.ParseException {
		logger.info("Setting the person object..");

		if (field.equals("FirstName")) {

			logger.info("Setting the person First Name with value " + value);

			PersonWSO personWSO = new PersonWSO();

			personWSO.setFirstName(value);
			return personWSO;

		} else if (field.equals("LastName")) {
			logger.info("Setting the person Last Name with value " + value);

			PersonWSO personWSO = new PersonWSO();
			personWSO.setLastName(value);
			return personWSO;

		} else if (field.equals("PersonalTarget")) {
			logger.info("Setting the Personal Target with value "
					+ value);
			logger.info("Setting the Personal Target with value " + value);

			PersonWSO personWSO = new PersonWSO();
			DecimalFormatSymbols symbols = new DecimalFormatSymbols();
			symbols.setDecimalSeparator('.');
			symbols.setGroupingSeparator(',');
			String pattern = "#,##0.0#";
			DecimalFormat decimalFormat = new DecimalFormat(pattern, symbols);
			decimalFormat.setParseBigDecimal(true);
			BigDecimal bigDecimal = (BigDecimal) decimalFormat.parse(value);
			personWSO.setPersonalTarget(bigDecimal);
			return personWSO;

		}

		return null;

	}

	public OrderStageWSO setOrderStageWSO(String field, String value) {
		if (field.equals("OrderCode")) {
			OrderStageWSO oso = new OrderStageWSO();
			oso.setOrderCode(value);
			return oso;
		}
		return null;

	}

	public boolean searchRecord(String field, String value, String entity,
			XService session) throws RemoteException, ParseException, java.text.ParseException {
		if (entity.equals("CurrencyRate")) {
			CurrencyRateWSO currencyrateWSO = setCurrencyRateWSO(field, value);
			SearchResponse searchResponse = session.search(currencyrateWSO);
			getSearchRecords(searchResponse);

			XObject[] srXObjs = searchResponse.getSearchRecords();

			return isFound(srXObjs);

		} else if (entity.equals("Position")) {
			PositionWSO positionWSO = setPositionWSO(field, value);
			SearchResponse searchResponse = session.search(positionWSO);

			XObject[] srXObjs = searchResponse.getSearchRecords();

			return isFound(srXObjs);
		} else if (entity.equals("PersonXLSX")) {
			PersonWSO personWSO = setPersonWSO(field, value);

			SearchResponse searchResponse = session.search(personWSO);

			XObject[] srXObjs = searchResponse.getSearchRecords();

			return isFound(srXObjs);
		} else if (entity.equals("User")) {
			UserWSO userWSO = setUserWSO(field, value);
			SearchResponse searchResponse = session.search(userWSO);

			XObject[] srXObjs = searchResponse.getSearchRecords();

			return isFound(srXObjs);
		} else if (entity.equals("OrderStageXLSX")) {
			OrderStageWSO orderWSO = setOrderStageWSO(field, value);

			SearchResponse searchResponse = session.search(orderWSO);

			XObject[] srXObjs = searchResponse.getSearchRecords();

			return isFound(srXObjs);
		}
		return false;

	}

	public boolean isFound(XObject[] srXObjs) {
		if (srXObjs != null) {
			logger.info("Search Successful!");
			return true;
		} else {
			logger.info("Search Failed");
			return false;
		}
	}

	public boolean getSearchRecords(SearchResponse searchResponse) {
		XObject[] srXObjs = searchResponse.getSearchRecords();

		return isFound(srXObjs);

	}
}
