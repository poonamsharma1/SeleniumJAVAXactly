/**
 * 17-Mar-2015
   com.xactly.xcommons.connect : ConnectHelperClass.java
   dpadmanabha
 */
package com.xactly.xcommons.connectapi;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.axis.client.Stub;
import org.testng.Reporter;
import com.xactly.icm.xtoolkit.service.DiscoveryServiceSoapBindingStub;
import com.xactly.icm.xtoolkit.service.XService;
import com.xactly.icm.xtoolkit.wso.LoginResponse;

import java.rmi.RemoteException;
import com.xactly.icm.xtoolkit.service.XServiceServiceLocator;
import com.xactly.xcommons.app.LoginToApplication;
import com.xactly.xcommons.restapi.PreSetupRestAPI;
import javax.xml.rpc.ServiceException;


public class LoginToConnect {

	/**
	 * dpadmanabha
	 */
	public static Logger logger = Logger.getLogger(LoginToConnect.class.getName());
	public LoginToConnect() {
		
		
	}

	public XService login(String application, String userCredentials) throws MalformedURLException, ServiceException, RemoteException,IOException
	{
		
	String username="", password="", url="";
	String credentials=PreSetupConnectAPI.userProPath.getProperty(userCredentials);
	logger.info("credentials:"+credentials);
	String[] userDetails = credentials.split(":");
	username=userDetails[0];
	password=userDetails[1];
	//url=PreSetupConnectAPI.symProPath.getProperty("Connect.baseURI")+"/icm/services/DiscoveryService";
	url=LoginToApplication.getConnectBaseURI()+"/icm/services/DiscoveryService";
	logger.info("connect url:"+url+"\nusername:"+username+"\nPassword:"+password);
		XService service = new XServiceServiceLocator().getDiscoveryService(new URL(url));
		((DiscoveryServiceSoapBindingStub) service).setMaintainSession(true);
		
		LoginResponse response = service.login(username, password, application);

		logger.info("isAuthenticated :" + response.isAuthenticated());
		logger.info("getSessionId :" + response.getSessionId());

		if (!response.isAuthenticated()) 
		{
			logger.info("Login failed : Unable to authenticate the service");
			
		} else {
			logger.info("Login successful : authenticated the service");
			
			((DiscoveryServiceSoapBindingStub) service).clearHeaders();

			String sessionId = response.getSessionId();
			String serverUrl = response.getServerUrl();

			logger.info("serverUrl Details :" + response.getServerUrl());

			((DiscoveryServiceSoapBindingStub) service)._setProperty(
					Stub.ENDPOINT_ADDRESS_PROPERTY, serverUrl);
			((DiscoveryServiceSoapBindingStub) service).setHeader(
					new XServiceServiceLocator().getServiceName()
							.getNamespaceURI(), "SessionId", sessionId);
			((DiscoveryServiceSoapBindingStub) service).setHeader(
					new XServiceServiceLocator().getServiceName()
							.getNamespaceURI(), "UserName", username);

		}
		return service;
	}
	
	
	public XService login() throws MalformedURLException, ServiceException, RemoteException,IOException
	{
		String url=LoginToApplication.getConnectBaseURI()+"/icm/services/DiscoveryService";
	//String url=LoginToApplication.getRestAssuredBaseURI()+"/icm/services/DiscoveryService";
	logger.info("connect url:"+url+"\nusername:"+LoginToApplication.getUsername()+"\nPassword:"+LoginToApplication.getPassword());
		XService service = new XServiceServiceLocator().getDiscoveryService(new URL(url));
		((DiscoveryServiceSoapBindingStub) service).setMaintainSession(true);
		
		LoginResponse response = service.login(LoginToApplication.getUsername(), LoginToApplication.getPassword(), LoginToApplication.getApplication());

		logger.info("isAuthenticated :" + response.isAuthenticated());
		logger.info("getSessionId :" + response.getSessionId());

		if (!response.isAuthenticated()) 
		{
			logger.info("Login failed : Unable to authenticate the service");
			
		} else {
			logger.info("Login successful : authenticated the service");
			
			((DiscoveryServiceSoapBindingStub) service).clearHeaders();

			String sessionId = response.getSessionId();
			String serverUrl = response.getServerUrl();

			logger.info("serverUrl Details :" + response.getServerUrl());

			((DiscoveryServiceSoapBindingStub) service)._setProperty(
					Stub.ENDPOINT_ADDRESS_PROPERTY, serverUrl);
			((DiscoveryServiceSoapBindingStub) service).setHeader(
					new XServiceServiceLocator().getServiceName()
							.getNamespaceURI(), "SessionId", sessionId);
			((DiscoveryServiceSoapBindingStub) service).setHeader(
					new XServiceServiceLocator().getServiceName()
							.getNamespaceURI(), "UserName", LoginToApplication.getUsername());

		}
		return service;
	}
	
}
