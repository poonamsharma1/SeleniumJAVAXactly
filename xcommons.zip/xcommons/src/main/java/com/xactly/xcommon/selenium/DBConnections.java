package com.xactly.xcommons.selenium;

import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.ByteBuffer;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Calendar;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;

import com.xactly.xcommons.app.LoginToApplication;
import com.xactly.xcommons.connectapi.PreSetupConnectAPI;
import com.xactly.xcommons.restapi.PreSetupRestAPI;

public class DBConnections {

    public static Logger logger = Logger.getLogger(DBConnections.class.getName());
	private static  String hostname = null;
	private static  String xgwHostName = null;
	
	public static String getHostnameIncent() {
		return hostname;
	}

	public static void setHostnameIncent(String hostname) {
		DBConnections.hostname = hostname;
	}
	
	public static String getHostnameGateway() {
		return xgwHostName;
	}

	public static void setHostnameGateway(String xgwHostName) {
		DBConnections.xgwHostName = xgwHostName;
	}

	public static String getPortnumberIncent() {
		return portnumber;
	}

	public static void setPortnumberIncent(String portnumber) {
		
		DBConnections.portnumber =portnumber;
	}

	public static String getServicenameIncent() {
		return Servicename;
	}

	public static void setServicenameIncent(String servicename) {
		Servicename = servicename;
	}

	public static String getUsernameIncent() {
		return username;
	}

	public static void setUsernameIncent(String username) {
		DBConnections.username = username;
	}

	public static String getPasswordIncent() {
		return password;
	}

	public static void setPasswordIncent(String password) {
		DBConnections.password = password;
	}
	public static String getPortnumberGateway() {
		return xgwportnumber;
	}

	public static void setPortnumberGateway(String xgwportnumber) {
		DBConnections.xgwportnumber = xgwportnumber;
	}

	public static String getServicenameGateway() {
		return xgwServicename;
	}

	public static void setServicenameGateway(String xgwServicename) {
		DBConnections.xgwServicename = xgwServicename;
	}

	public static String getUsernameGateway() {
		return xgwusername;
	}

	public static void setUsernameGateway(String xgwusername) {
		DBConnections.xgwusername = xgwusername;
	}

	public static String getPasswordGateway() {
		return xgwpassword;
	}

	public static void setPasswordGateway(String xgwpassword) {
		DBConnections.xgwpassword = xgwpassword;
	}
	
	private static String portnumber=null;
	private static String Servicename = null;
	private static String username = null;
	private static String password = null;
	private static String xgwportnumber=null;
	public static String getXsearchServicename() {
		return xsearchServicename;
	}

	public static void setXsearchServicename(String xsearchServicename) {
		DBConnections.xsearchServicename = xsearchServicename;
	}

	public static String getXsearchusername() {
		return xsearchusername;
	}

	public static void setXsearchusername(String xsearchusername) {
		DBConnections.xsearchusername = xsearchusername;
	}

	public static String getXsearchpassword() {
		return xsearchpassword;
	}

	public static void setXsearchpassword(String xsearchpassword) {
		DBConnections.xsearchpassword = xsearchpassword;
	}

	private static String xgwServicename = null;
	private static String xgwusername = null;
	private static String xgwpassword = null;
	
	private static String xsearchhostname=null;
	private static String xsearchportnumber=null;
	private static String xsearchServicename = null;
	private static String xsearchusername = null;
	private static String xsearchpassword = null;
	
	
	private static String snowflake_UserName = null;
	private static String snowflake_Password = null;
	private static String snowflake_AccountName = null;
	private static String snowflake_DatabaseName = null;
	private static String snowflake_SchemaName = null;
	
	
	private static String dis_hostName = null;
	private static String dis_serviceName = null;
	private static String dis_userName = null;
	private static String dis_Password = null;
	private static String dis_portNumber = null;
	
	
	
	public static String getDis_hostName() {
		return dis_hostName;
	}

	public static void setDis_hostName(String dis_hostName) {
		DBConnections.dis_hostName = dis_hostName;
	}

	public static String getDis_serviceName() {
		return dis_serviceName;
	}
	
	public static void setDis_serviceName(String dis_serviceName) {
		DBConnections.dis_serviceName = dis_serviceName;
	}

	public static String getDis_userName() {
		return dis_userName;
	}
	
	public static void setDis_userName(String dis_userName) {
		DBConnections.dis_userName = dis_userName;
	}

	public static String getDis_Password() {
		return dis_Password;
	}
	
	public static void setDis_Password(String dis_Password) {
		DBConnections.dis_Password = dis_Password;
	}

	public static String getDis_portNumber() {
		return dis_portNumber;
	}
	
	public static void setDis_portNumber(String dis_portNumber) {
		DBConnections.dis_portNumber = dis_portNumber;
	}

	public static String getSnowflake_UserName() {
		return snowflake_UserName;
	}

	public static void setSnowflake_UserName(String snowflake_UserName) {
		DBConnections.snowflake_UserName = snowflake_UserName;
	}

	public static String getSnowflake_Password() {
		return snowflake_Password;
	}

	public static void setSnowflake_Password(String snowflake_Password) {
		DBConnections.snowflake_Password = snowflake_Password;
	}

	public static String getSnowflake_AccountName() {
		return snowflake_AccountName;
	}

	public static void setSnowflake_AccountName(String snowflake_AccountName) {
		DBConnections.snowflake_AccountName = snowflake_AccountName;
	}

	public static String getSnowflake_DatabaseName() {
		return snowflake_DatabaseName;
	}

	public static void setSnowflake_DatabaseName(String snowflake_DatabaseName) {
		DBConnections.snowflake_DatabaseName = snowflake_DatabaseName;
	}

	public static String getSnowflake_SchemaName() {
		return snowflake_SchemaName;
	}

	public static void setSnowflake_SchemaName(String snowflake_SchemaName) {
		DBConnections.snowflake_SchemaName = snowflake_SchemaName;
	}
	
	
	public Connection connection = null;
	public String value;
	public PreparedStatement statement;
	public ResultSet rs = null;
	
	public DBConnections()
	{
		setHostnameIncent(LoginToApplication.symProPath.getProperty("db_incent_hostname"));
		setPortnumberIncent(LoginToApplication.symProPath.getProperty("db_incent_portnumber"));
		setServicenameIncent(LoginToApplication.symProPath.getProperty("db_incent_Servicename"));
		setUsernameIncent(LoginToApplication.symProPath.getProperty("db_incent_username"));
		setPasswordIncent(LoginToApplication.symProPath.getProperty("db_incent_password"));
		
		setHostnameGateway(LoginToApplication.symProPath.getProperty("db_gateway_hostname"));
		setPortnumberGateway(LoginToApplication.symProPath.getProperty("db_gateway_portnumber"));
		setServicenameGateway(LoginToApplication.symProPath.getProperty("db_gateway_Servicename"));
		setUsernameGateway(LoginToApplication.symProPath.getProperty("db_gateway_username"));
		setPasswordGateway(LoginToApplication.symProPath.getProperty("db_gateway_password"));
		
		setSnowflake_UserName(LoginToApplication.symProPath.getProperty("db_snowflake_user"));
		setSnowflake_Password(LoginToApplication.symProPath.getProperty("db_snowflake_password"));
		setSnowflake_AccountName(LoginToApplication.symProPath.getProperty("db_snowflake_account")); 
		setSnowflake_DatabaseName(LoginToApplication.symProPath.getProperty("db_snowflake_database")); 
		setSnowflake_SchemaName(LoginToApplication.symProPath.getProperty("db_snowflake_schema"));
		
		setDis_hostName(LoginToApplication.symProPath.getProperty("dis_hostName")); 
		setDis_serviceName(LoginToApplication.symProPath.getProperty("dis_serviceName")); 
		setDis_userName(LoginToApplication.symProPath.getProperty("dis_userName")); 
		setDis_Password(LoginToApplication.symProPath.getProperty("dis_Password")); 
		setDis_portNumber(LoginToApplication.symProPath.getProperty("dis_portNumber"));
		
	}
	
	
	public DBConnections(String api) {	
		
		if(api.equals("api")){
		setHostnameIncent(PreSetupRestAPI.symProPath.getProperty("db_incent_hostname"));
		setPortnumberIncent(PreSetupRestAPI.symProPath.getProperty("db_incent_portnumber"));
		setServicenameIncent(PreSetupRestAPI.symProPath.getProperty("db_incent_Servicename"));
		setUsernameIncent(PreSetupRestAPI.symProPath.getProperty("db_incent_username"));
		setPasswordIncent(PreSetupRestAPI.symProPath.getProperty("db_incent_password"));
		
		setHostnameGateway(PreSetupRestAPI.symProPath.getProperty("db_gateway_hostname"));
		setPortnumberGateway(PreSetupRestAPI.symProPath.getProperty("db_gateway_portnumber"));
		setServicenameGateway(PreSetupRestAPI.symProPath.getProperty("db_gateway_Servicename"));
		setUsernameGateway(PreSetupRestAPI.symProPath.getProperty("db_gateway_username"));
		setPasswordGateway(PreSetupRestAPI.symProPath.getProperty("db_gateway_password"));
		}
		
	}
	
	
	//Usage TestType accepted values gui,restapi,connect 
	//Usage applicationType objectices,tmca,incent,modeling .......
	public DBConnections(String testType, String applicationType) {	
				
		applicationType = applicationType.toLowerCase().replace(" ", "");
		testType = testType.toLowerCase();
		
			if(testType.equals("api")||testType.equals("restapi") ){
			setHostnameIncent(PreSetupRestAPI.symProPath.getProperty("db_"+applicationType+"_hostname"));
			setPortnumberIncent(PreSetupRestAPI.symProPath.getProperty("db_"+applicationType+"_portnumber"));
			setServicenameIncent(PreSetupRestAPI.symProPath.getProperty("db_"+applicationType+"_Servicename"));
			setUsernameIncent(PreSetupRestAPI.symProPath.getProperty("db_"+applicationType+"_username"));
			setPasswordIncent(PreSetupRestAPI.symProPath.getProperty("db_"+applicationType+"_password"));
			}
			if(testType.equals("gui") || testType.equals("gui-new") || testType.contains("gui")){
				setHostnameIncent(LoginToApplication.symProPath.getProperty("db_"+applicationType+"_hostname"));
				setPortnumberIncent(LoginToApplication.symProPath.getProperty("db_"+applicationType+"_portnumber"));
				setServicenameIncent(LoginToApplication.symProPath.getProperty("db_"+applicationType+"_Servicename"));
				setUsernameIncent(LoginToApplication.symProPath.getProperty("db_"+applicationType+"_username"));
				setPasswordIncent(LoginToApplication.symProPath.getProperty("db_"+applicationType+"_password"));
				}
			if(testType.equals("connect")){
				setHostnameIncent(PreSetupConnectAPI.symProPath.getProperty("db_"+applicationType+"_hostname"));
				setPortnumberIncent(PreSetupConnectAPI.symProPath.getProperty("db_"+applicationType+"_portnumber"));
				setServicenameIncent(PreSetupConnectAPI.symProPath.getProperty("db_"+applicationType+"_Servicename"));
				setUsernameIncent(PreSetupConnectAPI.symProPath.getProperty("db_"+applicationType+"_username"));
				setPasswordIncent(PreSetupConnectAPI.symProPath.getProperty("db_"+applicationType+"_password"));
				}
			
		}
	 
		public ArrayList<String> connect_Db(String query,String column_name) throws SQLException, ClassNotFoundException
		{
			ArrayList<String> AR_db_values= new ArrayList<String>();
		
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@//"+getHostnameIncent()+":"+getPortnumberIncent()+"/"+getServicenameIncent(), getUsernameIncent(),getPasswordIncent());
			logger.info(query);
			statement = connection.prepareStatement(query);
			rs = statement.executeQuery(query); 
			 while (rs.next()) 
			 {
		            value = rs.getString(column_name);
		            AR_db_values.add(value);
		     }
			 close_connection_db();
			 return AR_db_values;
		}
		
		public ArrayList<String> getMultipleRowsData(String query,String[] columnNames) throws SQLException, ClassNotFoundException
		{
			ArrayList<String> AR_db_values= new ArrayList<String>();
		
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@//"+getHostnameIncent()+":"+getPortnumberIncent()+"/"+getServicenameIncent(), getUsernameIncent(),getPasswordIncent());
			logger.info(query);
			statement = connection.prepareStatement(query);
			rs = statement.executeQuery(query); 
			String valueSet;
			 while (rs.next()) 
				 
			 {
				 StringBuffer sb = new StringBuffer();
				 valueSet = null;
				 for(int i = 0;i < columnNames.length;i ++){ 
				 
		            value = rs.getString(columnNames[i]);
		            valueSet= sb.append(value).append(",").toString();
		            
				 }
				 valueSet = valueSet.substring(0,valueSet.length()-1);
				 AR_db_values.add(valueSet);
		     }
			 close_connection_db();
			 return AR_db_values;
		}
		
		public String connect_Db_string(String query,String column_name) throws SQLException, ClassNotFoundException
		{
			String AR_db_values=null;
		
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@//"+getHostnameIncent()+":"+getPortnumberIncent()+"/"+getServicenameIncent(), getUsernameIncent(),getPasswordIncent());
			logger.info(query);
			statement = connection.prepareStatement(query);
			rs = statement.executeQuery(query); 
			 if(rs.next()) 
			 AR_db_values = rs.getString(column_name);
			 close_connection_db();
		     return AR_db_values;
		}
		
		public String connect_Db_string(String query,String column_name, String db) throws SQLException, ClassNotFoundException
		{
			String AR_db_values=null;
		
			Class.forName("oracle.jdbc.driver.OracleDriver");
			if(db.equalsIgnoreCase("incent"))
				connection = DriverManager.getConnection("jdbc:oracle:thin:@//"+getHostnameIncent()+":"+getPortnumberIncent()+"/"+getServicenameIncent(), getUsernameIncent(),getPasswordIncent());
			else if(db.equalsIgnoreCase("gateway"))
				connection = DriverManager.getConnection("jdbc:oracle:thin:@//"+getHostnameGateway()+":"+getPortnumberGateway()+"/"+getServicenameGateway(), getUsernameGateway(),getPasswordGateway());
			else if(db.equalsIgnoreCase("calc"))
				connection = DriverManager.getConnection("jdbc:oracle:thin:@//"+getHostnameIncent()+":"+getPortnumberIncent()+"/"+getServicenameIncent(),"calc","calc");
			logger.info(query);
			statement = connection.prepareStatement(query);
			rs = statement.executeQuery(query); 
			 if(rs.next()) 
			 AR_db_values = rs.getString(column_name);
			 close_connection_db();
		     return AR_db_values;
		}
		
		public String connectDBSettingOFF(String query,String column_name) throws SQLException, ClassNotFoundException
		{
			String AR_db_values=null;
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@//"+getHostnameIncent()+":"+getPortnumberIncent()+"/"+getServicenameIncent(), getUsernameIncent(),getPasswordIncent());
			logger.info(query);

			statement = connection.prepareStatement(query);
			logger.info(query);
			rs = statement.executeQuery(query); 
			 if(rs.next()) 
			 AR_db_values = rs.getString(column_name);
			 close_connection_db();
		     return AR_db_values;
		}
		
		
		public void connect_Db_string(String query) throws SQLException, ClassNotFoundException
		{
			String AR_db_values=null;
		
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@//"+getHostnameIncent()+":"+getPortnumberIncent()+"/"+getServicenameIncent(), getUsernameIncent(),getPasswordIncent());
			logger.info(connection);
			logger.info(query);
			statement = connection.prepareStatement(query);
			rs = statement.executeQuery(query); 
		}
		
		public ResultSet connect_Db_string1(String query) throws SQLException, ClassNotFoundException
		{		
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@//"+getHostnameIncent()+":"+getPortnumberIncent()+"/"+getServicenameIncent(), getUsernameIncent(),getPasswordIncent());
			logger.info(connection);
			logger.info(query);
			statement = connection.prepareStatement(query);
			ResultSet rs = statement.executeQuery(query);
			return rs; 
		}
	
		public void getPostgresDetails()
		{	
			logger.info("Setting DBs values : "+PreSetupRestAPI.symProPath.getProperty("db_xsearch_hostname"));
			setXsearchhostname(PreSetupRestAPI.symProPath.getProperty("db_xsearch_hostname"));
			setXsearchportnumber(PreSetupRestAPI.symProPath.getProperty("db_xsearch_portnumber"));
			setXsearchServicename(PreSetupRestAPI.symProPath.getProperty("db_xsearch_Servicename"));
			setXsearchusername(PreSetupRestAPI.symProPath.getProperty("db_xsearch_username"));
			setXsearchpassword(PreSetupRestAPI.symProPath.getProperty("db_xsearch_password"));
		}
		
		public ResultSet connectPostgres(String query) throws SQLException, ClassNotFoundException
		{
			
			getPostgresDetails();
			Class.forName("org.postgresql.Driver");
			logger.info(getXsearchhostname()+":"+getXsearchportnumber()+"/"+getXsearchServicename()+getXsearchusername()+getXsearchpassword());
			Connection connection = DriverManager.getConnection("jdbc:postgresql://"+getXsearchhostname()+":"+getXsearchportnumber()+"/"+getXsearchServicename(), getXsearchusername(),getXsearchpassword());
			logger.info(query);
			Statement statement = connection.createStatement();
			ResultSet rs = statement.executeQuery(query); 
			rs.next();
			return rs;
			
			//connection.close();

		}
		
		
		public void executeReportRefresh(int businessid) throws SQLException, ClassNotFoundException
		{		
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@//"+getHostnameIncent()+":"+getPortnumberIncent()+"/"+getServicenameIncent(), getUsernameIncent(),getPasswordIncent());
			String proc="{call xc_summary_tables.refresh_all_pro(?)}";		
			statement = connection.prepareCall(proc);
			statement.setInt(1, businessid);
			 statement.execute(); 
				statement.close();
				connection.close();
		     
		}
		
		public void executequery(String query) throws SQLException, ClassNotFoundException
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@//"+getHostnameIncent()+":"+getPortnumberIncent()+"/"+getServicenameIncent(), getUsernameIncent(),getPasswordIncent());
			statement = connection.prepareStatement(query);
			logger.info(query);
			rs = statement.executeQuery(query); 
			connection.commit();
			close_connection_db();
			
		}
		
		
		
		public void executeUpdateQuery(String query) throws SQLException, ClassNotFoundException
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@//"+getHostnameIncent()+":"+getPortnumberIncent()+"/"+getServicenameIncent(), getUsernameIncent(),getPasswordIncent());
			statement = connection.prepareStatement(query);
			 statement.executeUpdate();
			connection.commit();
			close_connection_db();
		}
		
		public void executeUpdateQuery(String query, String db) throws SQLException, ClassNotFoundException
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");

			if(db.equalsIgnoreCase("incent"))
				connection = DriverManager.getConnection("jdbc:oracle:thin:@//"+getHostnameIncent()+":"+getPortnumberIncent()+"/"+getServicenameIncent(), getUsernameIncent(),getPasswordIncent());
			else if(db.equalsIgnoreCase("gateway"))
				connection = DriverManager.getConnection("jdbc:oracle:thin:@//"+getHostnameGateway()+":"+getPortnumberGateway()+"/"+getServicenameGateway(), getUsernameGateway(),getPasswordGateway());
			statement = connection.prepareStatement(query);
			statement.executeUpdate();
			connection.commit();
			close_connection_db();
		}
		
		
		public void close_connection_db() throws SQLException
		{
			if(rs != null)
				rs.close();
			statement.close();
			connection.close();
		}

		public static String getXsearchhostname() {
			return xsearchhostname;
		}

		public static void setXsearchhostname(String xsearchhostname) {
			DBConnections.xsearchhostname = xsearchhostname;
		}

		public static String getXsearchportnumber() {
			return xsearchportnumber;
		}

		public static void setXsearchportnumber(String xsearchportnumber) {
			DBConnections.xsearchportnumber = xsearchportnumber;
		}
		
		
		public String connect_Db_withoutColumnName(String query) throws SQLException, ClassNotFoundException {
			ArrayList<String> AR_db_values = new ArrayList<String>();

			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@//" + getHostnameIncent() + ":"
					+ getPortnumberIncent() + "/" + getServicenameIncent(), getUsernameIncent(), getPasswordIncent());
			logger.info(connection);
			logger.info(query);
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			int colNum = rsmd.getColumnCount();
			while (rs.next()) {
				for (int i = 1; i <= colNum; i++) {
					String str = rs.getString(i);

					AR_db_values.add(str);
				}
			}
			String dbValues = AR_db_values.toString();
			connection.close();
			stmt.close();
			return dbValues;
		}

		
		/*public static void main(String args[]) throws ClassNotFoundException, SQLException
		{
			DBConnections DB = new DBConnections();
			ArrayList<String> actual_values_DB= new ArrayList<String>();
			actual_values_DB = DB.connect_Db("10.250.2.21","1521","volans","incent","incent","select * from xc_credit_type where business_id='5321' and lower(name) like '%ho%'","name");
			for (String renamed : actual_values_DB) 
			{
				logger.info("rename "+renamed);
			}
		}*/
		public int executeDeleteQuery(String query) throws SQLException, ClassNotFoundException
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");

			connection = DriverManager.getConnection("jdbc:oracle:thin:@//"+getHostnameIncent()+":"+getPortnumberIncent()+"/"+getServicenameIncent(), getUsernameIncent(),getPasswordIncent());
			connection.setAutoCommit(false);
			statement = connection.prepareStatement(query);
			int count = statement.executeUpdate();
			connection.commit();
			close_connection_db();
			return count;
		}

		public String getPeriodID(String business_id, String period_name) throws InterruptedException {
			String periodID = null;
			Thread.sleep(5000);
			try {
				periodID = connect_Db_string("select PERIOD_ID from XC_PERIOD where Business_ID ='"
						+ business_id + "' and NAME ='" + period_name + "'", "PERIOD_ID");

			} catch (SQLException | ClassNotFoundException e) {
				e.printStackTrace();
			}
			logger.info("periodID : " + periodID);

			return periodID;
		}

		public int getOrderStageCount(String business_id, String period_id) throws InterruptedException {
			String orderCount = null;
			Thread.sleep(5000);
			try {
				orderCount = connect_Db_string("select COUNT(*) from XC_ORDER_STAGE where Business_ID ='"
						+ business_id + "' and PERIOD_ID ='" + period_id + "'", "COUNT(*)");

			} catch (SQLException | ClassNotFoundException e) {
				e.printStackTrace();
			}
			logger.info("orderCount : " + orderCount);

			return Integer.parseInt(orderCount);
		}

		public void getDeleteOrderStage(String business_id, String period_id) throws InterruptedException {
			Thread.sleep(5000);
			try {
				executeDeleteQuery("delete from XC_ORDER_STAGE where Business_ID ='" + business_id
						+ "' and PERIOD_ID ='" + period_id + "'");

			} catch (SQLException | ClassNotFoundException e) {
				e.printStackTrace();
			}
			logger.info("orders deleted successfully");
		}
		
		public int getDefaultBatchCount(String business_id, String period_name) throws InterruptedException {
			String batchCount = null;
			Thread.sleep(5000);
			try {
				batchCount = connect_Db_string("select COUNT(*) from XC_USER_BATCH where Business_ID ='" + business_id
						+ "' and BATCH_NAME like 'DEFAULT-" + period_name + "-%" + "'", "COUNT(*)");

			} catch (SQLException | ClassNotFoundException e) {
				e.printStackTrace();
			}
			logger.info("batchCount : " + batchCount);

			return Integer.parseInt(batchCount);
		}

		public void getDeleteDefaultBatch(String business_id, String period_name) throws InterruptedException {
			Thread.sleep(5000);
			try {
				connect_Db_string("delete from XC_USER_BATCH where Business_ID ='" + business_id
						+ "' and BATCH_NAME like 'DEFAULT-" + period_name + "-%" + "'");

			} catch (SQLException | ClassNotFoundException e) {
				e.printStackTrace();
			}
			logger.info("Dafault Batches deleted successfully");
		}
		
		public PreparedStatement getPreparedStatement(String query) throws ClassNotFoundException, SQLException {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@//"+getHostnameIncent()+":"+getPortnumberIncent()+"/"+getServicenameIncent(), getUsernameIncent(),getPasswordIncent());
			logger.info(query);
			statement = connection.prepareStatement(query);
			return statement;
		}
		
		public void commitUpdateQuery() throws SQLException, ClassNotFoundException
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@//"+getHostnameIncent()+":"+getPortnumberIncent()+"/"+getServicenameIncent(), getUsernameIncent(),getPasswordIncent());
			connection.setAutoCommit(false);
			connection.commit();
			close_connection_db();
		}
		
		public static Date getGMTDate ()
		{
			Calendar calendar = Calendar.getInstance();
			int offset = calendar.get(Calendar.ZONE_OFFSET)/3600000 +
						 calendar.get(Calendar.DST_OFFSET)/3600000;
			calendar.add(Calendar.HOUR,-offset);
	        int minutesOffset = ((calendar.get(Calendar.ZONE_OFFSET)%3600000)/60000);
	        calendar.add(Calendar.MINUTE,-minutesOffset);
			return calendar.getTime();
		}
		
		public static Timestamp getCurrentTimeStamp()
		{
			Date currentDate = getGMTDate();
			return  new Timestamp(currentDate.getTime());
		}
		
		public static Timestamp getExpiryDateTimeStamp()
		{

			Date currentDate = getGMTDate();
			return  new Timestamp(currentDate.getTime()+172800000);
		}
		
        public long createUploadTransaction(HashMap<String, Object> uploadData, String businessId, String fileIdentifier) throws SQLException {
	        
			PreparedStatement pstmt = null;
	        long dms_id = 0;
	        try {
	            String idSql = "SELECT XC_DATA_MGMT_STATUS_SEQ.NEXTVAL FROM DUAL";
	            String uploadTxnSql = "INSERT INTO XC_DATA_MGMT_STATUS (DMS_ID, FILE_NAME, USER_ID, "
	                    + "FILE_IDENTIFIER, FILE_TYPE, STATUS, CONTENT_TYPE, BUSINESS_ID, CREATED_DATE, "
	                    + "CREATED_BY_ID, CREATED_BY_NAME, EXPIRY_DATE) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	            dms_id = Long.parseLong(connect_Db_string(idSql, "NEXTVAL"));
	            logger.info("dms_id :" + dms_id);
	            pstmt = getPreparedStatement(uploadTxnSql);
	            pstmt.setLong(1, dms_id); // DMS_ID
	            pstmt.setString(2, uploadData.get("fileName").toString());// FILE_NAME
	            pstmt.setLong(3, (Long) uploadData.get("userId"));// USER_ID
	            pstmt.setString(4, fileIdentifier);// FILE_IDENTIFIER
	            pstmt.setString(5, uploadData.get("objectType").toString());// FILE_TYPE
	            pstmt.setString(6, "UPLOAD_START");// STATUS
	            pstmt.setString(7, "application/vnd.ms-excel");// CONTENT_TYPE
	            pstmt.setString(8, businessId);// BUSINESS_ID
	            pstmt.setTimestamp(9, getCurrentTimeStamp()); // CREATED_DATE
	            pstmt.setLong(10, (Long) uploadData.get("userId")); // CREATED_BY_ID
	            pstmt.setString(11, uploadData.get("userName").toString()); // CREATED_BY_NAME
	            pstmt.setTimestamp(12, getExpiryDateTimeStamp()); // EXPIRY_DATE
	            pstmt.executeUpdate();
	            commitUpdateQuery();
	            return dms_id;
	        } catch (Exception ex) {
	            ex.printStackTrace();
	        } finally {
	        	close_connection_db();
	        }
	        return dms_id;
	 
	
	        }

        public long createTransactionForDownload(long transId, HashMap<String, Object> downloadData, String businessId, String fileName) throws Exception {
  
    PreparedStatement pstmt = null;
    long download_id = 0;
    try {
        String idSql = "SELECT XC_DOWNLOAD_INFO_SEQ.NEXTVAL FROM DUAL";
        String downloadTxnSql = "INSERT INTO XC_DOWNLOAD_INFO (DOWNLOAD_ID, BUSINESS_ID, FILE_NAME, "
                + "FILE_IDENTIFIER, DOWNLOAD_STATE, DOWNLOAD_TYPE, EXPIRY_DATE, DATA, USER_ID, "
                + "IS_ACTIVE,  CREATED_DATE, CREATED_BY_ID, CREATED_BY_NAME, MODIFIED_DATE, MODIFIED_BY_ID, "
                + "MODIFIED_BY_NAME, CHUNK_NUMBER, CONTENT_TYPE) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        download_id = Long.parseLong(connect_Db_string(idSql, "NEXTVAL"));
        logger.info("download_id :" + download_id);
        pstmt = getPreparedStatement(downloadTxnSql);
        pstmt.setObject(1, download_id); // DOWNLOAD_ID
        pstmt.setString(2, businessId); // BUSINESS_ID
        pstmt.setString(3, fileName); // FILE_NAME
        pstmt.setString(4, null); // FILE_IDENTIFIER
        pstmt.setString(5, "IN PROGRESS"); // DOWNLOAD_STATE
        pstmt.setObject(6, 8); // DOWNLOAD_TYPE
        pstmt.setTimestamp(7, getExpiryDateTimeStamp()); // EXPIRY_DATE
        pstmt.setString(8, null); // DATA
        pstmt.setLong(9, (Long) downloadData.get("userId")); // USER_ID
        pstmt.setString(10, "1"); // IS_ACTIVE
        pstmt.setTimestamp(11, getCurrentTimeStamp()); // CREATED_DATE
        pstmt.setLong(12, (Long) downloadData.get("userId")); // CREATED_BY_ID
        pstmt.setString(13, downloadData.get("userName").toString()); // CREATED_BY_NAME
        pstmt.setTimestamp(14, null); // MODIFIED_DATE
        pstmt.setString(15, null); // MODIFIED_BY_ID
        pstmt.setString(16, null); // MODIFIED_BY_NAME
        pstmt.setObject(17, 0); // CHUNK_NUMBER
        pstmt.setString(18, "text/csv"); // CONTENT_TYPE
        pstmt.executeUpdate();
        commitUpdateQuery();
        return download_id;
    } catch (Exception ex) {
        ex.printStackTrace();
    } finally {
        try {
        	close_connection_db();
        } catch (Exception e) {
        }
    }
    return download_id;
}

    public String getDownloadState(Long downloadID) throws InterruptedException {
    String downloadState = null;
    Thread.sleep(5000);
    try {
        downloadState = connect_Db_string("select DOWNLOAD_STATE from XC_DOWNLOAD_INFO where DOWNLOAD_ID ='" + downloadID +"'" ,"DOWNLOAD_STATE");

    } catch (SQLException | ClassNotFoundException e) {
        e.printStackTrace();
    }
    logger.info("downloadState : " + downloadState);

    return downloadState;
}

    public String getfileIdentifier(Long downloadID) throws InterruptedException {
    DBConnections connections = new DBConnections();
    String fileIdentifier = null;
    Thread.sleep(5000);
    try {
        fileIdentifier = connections.connect_Db_string("select FILE_IDENTIFIER from XC_DOWNLOAD_INFO where DOWNLOAD_ID ='" + downloadID +"'" ,"FILE_IDENTIFIER");

    } catch (SQLException | ClassNotFoundException e) {
        e.printStackTrace();
    }
    logger.info("fileIdentifier : " + fileIdentifier);

    return fileIdentifier;
     }

	/**
	 * This method is to get the business id for the given email id
	 *
	 * @param email
	 * @return
	 */
	public String getBusinessId(String email) {
		String businessId = null;
		try {
			businessId = connect_Db_string("select Business_ID from XC_USER where EMAIL like '" + email + "'", "BUSINESS_ID");
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		logger.info("Business ID: " + businessId);

		return businessId;
	}

	/**
	 * This method is used to delete the download info
	 *
	 * @param businessId
	 */
	public void deletePeopleFromDB(String businessId) {
		try {
			logger.info("Delete from xc_participant:  " + businessId);
			int result = executeDeleteQuery("Delete from xc_participant where BUSINESS_ID = '" + businessId + "'");
			logger.info("Delete result" + result);
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}


	/***
	 * @author mhussain
	 * @param DB_SNOWFLAKE_USER
	 * @param DB_SNOWFLAKE_PASSWORD
	 * @param DB_SNOWFLAKE_ACCOUNT
	 * @param DB_SNOWFLAKE_DATABASE
	 * @param DB_SNOWFLAKE_SCHEMA
	 * @return
	 * @throws SQLException
	 * 
	 * 
	 * Creates snowflake connection using JDBC driver
	 */
	@SuppressWarnings("static-access")
	public static Connection getConnection_SnowFlake(String DB_SNOWFLAKE_USER, String DB_SNOWFLAKE_PASSWORD , String DB_SNOWFLAKE_ACCOUNT , String DB_SNOWFLAKE_DATABASE , String DB_SNOWFLAKE_SCHEMA) throws SQLException
	  {
		try
	    {
			Class.forName("net.snowflake.client.jdbc.SnowflakeDriver");
	    }
	    catch (ClassNotFoundException ex)
	    {
	    	System.err.println("Driver not found"+ex.getMessage());
	    }
		
		/***
		 * building up snowflake properties details 
		 */

		Properties properties = new Properties();
//	    properties.put("user", getSnowflake_UserName());     
//	    properties.put("password", getSnowflake_Password()); 
//	    properties.put("account", getSnowflake_AccountName());  
//	    properties.put("db", getSnowflake_DatabaseName());      
//	    properties.put("schema", getSnowflake_SchemaName());   
		
		properties.put("user",DB_SNOWFLAKE_USER );     
	    properties.put("password",DB_SNOWFLAKE_PASSWORD ); 
	    properties.put("account",DB_SNOWFLAKE_ACCOUNT );  
	    properties.put("db", DB_SNOWFLAKE_DATABASE);      
	    properties.put("schema", DB_SNOWFLAKE_SCHEMA);   
	    
	    // create a new connection
	    String connectStr = System.getenv("SF_JDBC_CONNECT_STRING");
	    // use the default connection string if it is not set in environment
	    if(connectStr == null)
	    {
	     connectStr = "jdbc:snowflake://"+DB_SNOWFLAKE_ACCOUNT+".snowflakecomputing.com"; 
	    }
	    
	    return DriverManager.getConnection(connectStr, properties);
  }
	
	
	public ArrayList<String> connect_Db_withoutColumnName_SnowflakeDB(String query,String DB_SNOWFLAKE_USER, String DB_SNOWFLAKE_PASSWORD , String DB_SNOWFLAKE_ACCOUNT , String DB_SNOWFLAKE_DATABASE , String DB_SNOWFLAKE_SCHEMA) throws SQLException, ClassNotFoundException {
		
		ArrayList<String> AR_db_values = new ArrayList<String>();
		connection = getConnection_SnowFlake(DB_SNOWFLAKE_USER, DB_SNOWFLAKE_PASSWORD, DB_SNOWFLAKE_ACCOUNT, DB_SNOWFLAKE_DATABASE, DB_SNOWFLAKE_SCHEMA);
		logger.info(connection);
		logger.info(query);
		
		Statement stmt = connection.createStatement();
		rs = stmt.executeQuery(query);
		ResultSetMetaData rsmd = rs.getMetaData();
		int colNum = rsmd.getColumnCount();
		while (rs.next()) {
			for (int i = 1; i <= colNum; i++) {
				String str = rs.getString(i);

				AR_db_values.add(str);
			}
		}
		connection.close();
		stmt.close();
		return AR_db_values;
	}
	
	@SuppressWarnings("static-access")
	public  ArrayList<String> connect_DB_withoutColumnNam_OracleDB(String query)
			throws SQLException, ClassNotFoundException {
		
			ArrayList<String> AR_db_values = new ArrayList<String>();
			
			Statement statement = null;
			ResultSet result = null;
			Connection connection = null;
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				connection = DriverManager.getConnection("jdbc:oracle:thin:@//" + getHostnameIncent() + ":"
						+ getPortnumberIncent() + "/" + getServicenameIncent(), getUsernameIncent(), getPasswordIncent());
				logger.info(connection);
				logger.info(query);
				statement = connection.createStatement();
				result = statement.executeQuery(query);
				
			}
			catch(Exception e) {
				logger.info(e.getMessage());
			}
			
			
			ResultSetMetaData rsmd = result.getMetaData();
			int colNum = rsmd.getColumnCount();
			while (result.next()) {
				for (int i = 1; i <= colNum; i++) {
					String str = result.getString(i);

					AR_db_values.add(str);
				}
			}
			connection.close();
			statement.close();
			return AR_db_values;
	}
	
	/***
	 * @author mhussain
	 * 
	 * This retrieves the records in List<Map<String,Object>> format list would be holding the Map which would be key : column header and value : celll value
	 * for snowflake db
	 * 
	 */
	public List<Map<String, Object>> fetchDataFromDB(String query,String connectionName,String DB_SNOWFLAKE_USER, String DB_SNOWFLAKE_PASSWORD , String DB_SNOWFLAKE_ACCOUNT , String DB_SNOWFLAKE_DATABASE , String DB_SNOWFLAKE_SCHEMA) throws SQLException, ClassNotFoundException
	{
		//ArrayList<List<String>> AR_db_values = null;
		Connection connectionSnowflake = null;
		Statement stmt = null;
		ResultSet rs = null;
		//Map<String,Object> dataMap = null;

		List<Map<String,Object>> dataList = new LinkedList<Map<String,Object>>();
	   if(connectionName.equalsIgnoreCase("Snowflake")) {

		   connectionSnowflake = getConnection_SnowFlake(DB_SNOWFLAKE_USER, DB_SNOWFLAKE_PASSWORD , DB_SNOWFLAKE_ACCOUNT , DB_SNOWFLAKE_DATABASE , DB_SNOWFLAKE_SCHEMA);
			logger.info(connectionSnowflake);
			//logger.info(query);
			stmt = connectionSnowflake.createStatement();
			rs = stmt.executeQuery(query);

	   }
	   
		try {
			dataList = new LinkedList<Map<String,Object>>();
			ResultSetMetaData rsmd = rs.getMetaData();
			int colNum = rsmd.getColumnCount();
			Object value = "";
			while (rs.next()) {
				Map<String,Object> dataMap  = new LinkedHashMap<String,Object>();

				for (int i = 1; i < colNum; ++i) {//++i
					if(rsmd.getColumnTypeName(i).equalsIgnoreCase("BLOB")) {
						continue;
					}
					else {
						value = rs.getObject(i);
					}
					
					dataMap.put(rsmd.getColumnName(i), String.valueOf(value));
				}
				dataList.add(dataMap);
			}
						
		}catch(Exception e) {
	    	logger.info("Following error has occured "+e.getMessage());
	    }
		finally {
			connectionSnowflake.close();
			stmt.close();
		}
			return dataList;
	}
	
	/***
	 * @author mhussain
	 * 
	 * This retrieves the records in List<Map<String,Object>> format list would be holding the Map which would be key : column header and value : celll value
	 * for oracle db / incent db
	 * 
	 */
	public List<Map<String, Object>> fetchDataFromDB_Oracle(String query) throws SQLException, ClassNotFoundException
	{
		Connection connectionOracle = null;
		//ArrayList<List<String>> AR_db_values = null;
		Statement stmt = null;
		ResultSet rs = null;
		//Map<String,Object> dataMap = null;

		List<Map<String,Object>> dataList = new LinkedList<Map<String,Object>>();
	   
	   
	   
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connectionOracle = DriverManager.getConnection("jdbc:oracle:thin:@//" + getHostnameIncent() + ":"
					+ getPortnumberIncent() + "/" + getServicenameIncent(), getUsernameIncent(), getPasswordIncent());
			logger.info(connectionOracle);
			//logger.info(query);
			stmt = connectionOracle.createStatement();
			rs = stmt.executeQuery(query);
			
			dataList = new LinkedList<Map<String,Object>>();
			ResultSetMetaData rsmd = rs.getMetaData();
			int colNum = rsmd.getColumnCount();
			Object value = "";
			while (rs.next()) {
				Map<String,Object> dataMap  = new LinkedHashMap<String,Object>();

				for (int i = 1; i < colNum; ++i) {//++i
					if(rsmd.getColumnTypeName(i).equalsIgnoreCase("CLOB"))
					{
						Clob clob = rs.getClob(i);
				         Reader r = clob.getCharacterStream();
				         StringBuffer buffer = new StringBuffer();
				         int ch;
				         while ((ch = r.read())!=-1) {
				            buffer.append(""+(char)ch);
				         }
				         logger.info("Contents of clob converted to string: "+buffer.toString());
				         value = buffer.toString();	
					}
					else if(rsmd.getColumnTypeName(i).equalsIgnoreCase("BLOB")) {
						continue;
					}
					else {
						value = rs.getObject(i);
					}
					dataMap.put(rsmd.getColumnName(i), String.valueOf(value));
					
				}
				dataList.add(dataMap);
			}
			

			connectionOracle.close();
			stmt.close();
		}catch(Exception e) {
	    	logger.info("Following error has occured "+e.getMessage());
	    }
			return dataList;
	}
	
	public ResultSet connect_Db_string2(String query) throws SQLException, ClassNotFoundException
	{

		Class.forName("oracle.jdbc.driver.OracleDriver");
		connection = DriverManager.getConnection("jdbc:oracle:thin:@//" + "172.19.43.185" + ":"
				+ "1521" + "/" + "qaprdx_icm.devqe1db.devqe1.oraclevcn.com", "incent", "incent");
		logger.info(connection);
		logger.info(query);
		statement = connection.prepareStatement(query);
		ResultSet rs = statement.executeQuery(query);

		return rs;
	}
	
	public void deletePosition(String posName, String businessId){
		try {
			logger.info("Deleting position from XC_POSITION table " + businessId);
			int result = executeDeleteQuery("Delete from XC_POSITION where BUSINESS_ID = '" + businessId + "' and Name = '" + posName +"'");
			logger.info("Delete result" + result);
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	public HashMap<String,String> getPositionDetails(String businessId, String positionName) throws Exception{
		HashMap<String,String> posDetails = new HashMap<>();
		DBConnections db = new DBConnections();
		String query = "SELECT * FROM XC_POSITION WHERE NAME ='" + positionName + "' AND BUSINESS_ID = '" + businessId + "'";
		String [] columnNames = {"NAME","DESCR","BUSINESS_GROUP_ID","POSITION_ID","MASTER_POSITION_ID","INCENT_ST_DATE","INCENT_END_DATE"};
		ArrayList<String> dbRows = db.getMultipleRowsData(query, columnNames);
		String result[] = dbRows.get(0).split(",");
		logger.info(String.valueOf(result.length) + "Result");
		for(int i=0; i< result.length; i++){
			logger.info(String.valueOf(i));
			posDetails.put(columnNames[i],result[i]);
			logger.info(columnNames[i]);
			logger.info(result[i]);
		}
		return posDetails;
	}

	 
	}

	
	