package com.xactly.xcommons.selenium;

public class GetProperties {
	
	public static String businessgrouptable;
	public static String credittypetable;
	public static String ordertypetable;
	public static String unittypetable;
	public static String reasoncodetable;
	public static String errormsgtable;
	public static String eployeestatustable;
	public static String earninggrouptable;
	public static String peopletable;
	public static String calendartable;
	public static String orderStagetable;
    public static String tagtable;
	public static String plandoctable;
	public static String bonusrule;
	public static String draws;
	public static String customrule;
	public static String quota; 
	public static String ratetable;
	public static String reportcolumn;
	public static String incentivestatement;
	public static String incentivedetails;
	public static String paymentcustomlabel;
	public static String bonusruleresult;
	public static String podcustomization;
	public static String plansummary;
	public static String personfield;
    public static String releasegrouptable;
    public static String usertable;
    public static String suspendReportRef;
	
    public static String getSuspendReportRef() {
		return suspendReportRef;
	}

	public static void setSuspendReportRef(String suspendReportRef) {
		GetProperties.suspendReportRef = suspendReportRef;
	}

     public static void setCalendartable(String calendartable) {
		GetProperties.calendartable = calendartable;
	}
	
	public static String getReleasegrouptable() {
		return releasegrouptable;
	}

	public static void setReleasegrouptable(String releasegrouptable) {
		GetProperties.releasegrouptable = releasegrouptable;
	}

       public static String getUsertable() {
		return usertable;
	}

	public static void setUsertable(String usertable) {
		GetProperties.usertable = usertable;
	}

	public static String getPersonfield()
	{
		return personfield;
	}
	public static String getPlansummary() {
		return plansummary;
	}
	
	public static String getPodcustomtable() {
		return podcustomization;
	}
	
	public static String getCalendartable() {
		return calendartable;
	}
	
	public static String getPeopletable() {
		return peopletable;
	}
	
	public static String getEarninggrouptable(){
		return earninggrouptable;
	}

	public static String getErrormsgtable(){
		return errormsgtable;
	}
	
	public static String getEmployeestatus(){
		return eployeestatustable;
	}
	public static String getUnittypetable(){
		return unittypetable;
	}
	public static String getBusinessgrouptable() {
		return businessgrouptable;
	}
	
	public static String getCredittypetable() {
		return credittypetable;
	}
	
	public static String getOrdertypetable(){
		return ordertypetable;
	}
	
	public static String getReasoncodetable(){
		return reasoncodetable;
	}
	public static String getTagtable() {
		return tagtable;
	}
	
	public static String getPlanDocTable() {
		return plandoctable;
	}
		
	public static void setPeopletable(String peopletable) {
		GetProperties.peopletable = peopletable;
	}
	
	public static void setEarninggrouptable(String earninggrouptable){
		GetProperties.earninggrouptable = earninggrouptable;
	}
	
	public static void setErrormsgtable(String errormsgtable) {
		GetProperties.errormsgtable = errormsgtable;
	}
	
	public static void setEmployeestatustable(String employeestatustable){
		GetProperties.eployeestatustable = employeestatustable;
	}
	
	public static void setReasoncodetable(String reasoncodetable) {
		GetProperties.reasoncodetable = reasoncodetable;
	}

	public static void setBusinessgrouptable(String businessgrouptable) {
		GetProperties.businessgrouptable = businessgrouptable;
	}
	
	public static void setPlanDocumenttable(String plandoctable) {
		GetProperties.plandoctable = plandoctable;
	}
	
	public static void setCredittypetable(String credittypetable) {
		GetProperties.credittypetable = credittypetable;
	}
	

	
	public static void setOrdertypetable(String ordertypetable){
		GetProperties.ordertypetable = ordertypetable;
	}
	
	public static void setUnittypetable(String unittypetable){
		GetProperties.unittypetable=unittypetable;
	}
	
	public static void setOrderStagetable(String orderStagetable) {
		GetProperties.orderStagetable = orderStagetable;
	}
	
    public static String getOrderStagetable(String orderStagetable) {
    return orderStagetable;
    }
    
	public static void setTagtable(String Tagtable){
		GetProperties.tagtable=tagtable;
	}
	public static String getCustomrule() {
		return customrule;
	}

	public static void setCustomrule(String customrule) {
		GetProperties.customrule = customrule;
	}

	public static String getDraws() {
		return draws;
	}

	public static void setDraws(String draws) {
		GetProperties.draws = draws;
	}

	public static String getBonusrule() {
		return bonusrule;
	}

	public static void setBonusrule(String bonusrule) {
		GetProperties.bonusrule = bonusrule;
	}
	public static String getIncentiveDetails() {
		return incentivedetails;
	}
	public static void setIncentiveDetails(String incentivedetails) {
		GetProperties.incentivedetails = incentivedetails;
	}
	public static String getIncentiveStatement() {
		return incentivestatement;
	}

	public static void setIncentiveStatement(String incentivestatement) {
		GetProperties.incentivestatement = incentivestatement;
	}
	public static String getQuota() {
		return quota;
	}

	public static void setQuota(String quota) {
		GetProperties.quota = quota;
	}
	public static String getRateTables() {
		return ratetable;
	}

	public static void setRateTables(String ratetable) {
		GetProperties.ratetable = ratetable;
	}
	public static String getReportColumns() {
		return reportcolumn;
	}

	public static void setReportColumns(String reportcolumn) {
		GetProperties.reportcolumn = reportcolumn;
	}
	public static String getPaymentCustomLabel() {
		return paymentcustomlabel;
	}

	public static void setPaymentCustomLabel(String paymentcustom) {
		GetProperties.paymentcustomlabel = paymentcustomlabel;
	}
	
	public static String getBonusruleResult() {
		return bonusruleresult;
	}

	public static void setBonusruleResult(String bonusruleresult) {
		GetProperties.bonusruleresult = bonusruleresult;
	}
	
	public static void setPodcustomization(String podcustomization)
	{
		GetProperties.podcustomization=podcustomization;
	}
	
	public static void setPlansummary(String plansummary)
	{
		GetProperties.plansummary=plansummary;
	}
	
	public static void setPersonfield(String personfield)
	{
		GetProperties.personfield=personfield;
	}
	
	public GetProperties()
	{
	//	setBusinessgrouptable(SetWebDrivers.tableDet.getProperty("incent.setup.businessgroup"));
		
	}
}
