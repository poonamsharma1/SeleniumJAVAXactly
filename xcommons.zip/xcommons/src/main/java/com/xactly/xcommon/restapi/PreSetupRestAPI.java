package com.xactly.xcommons.restapi;

import java.io.File;
import java.io.InputStream;
import java.util.Properties;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.jayway.restassured.RestAssured;
import com.xactly.xcommons.presetup.PreSetup;

import org.apache.log4j.Logger;

public class PreSetupRestAPI {
public static Logger logger = Logger.getLogger(PreSetupRestAPI.class.getName());
	public static InputStream systemPropertyInputStream;
	public static InputStream systemUserPropertyInputStream;
	public static String baseuri;
	public static String analyticsBaseUriCustom;
	public static String analyticsBaseUriObiee;
	public static String grsBaseuri;


	public static String getGrsBaseuri() {
		return grsBaseuri;
	}
	public static void setGrsBaseuri(String grsBaseuri) {
		PreSetupRestAPI.grsBaseuri = grsBaseuri;
	}
	public static InputStream getSystemUserPropertyInputStream() {
		return systemUserPropertyInputStream;
	}
	public static void setSystemUserPropertyInputStream(
			InputStream systemUserPropertyInputStream) {
		PreSetupRestAPI.systemUserPropertyInputStream = systemUserPropertyInputStream;
	}
	public static Properties symProPath = new Properties();
	public static Properties userProPath = new Properties();

	public static InputStream getSystemPropertyInputStream() {
		return systemPropertyInputStream;
	}
	public static void setSystemPropertyInputStream(
			InputStream systemPropertyInputStream) {
		PreSetupRestAPI.systemPropertyInputStream = systemPropertyInputStream;
	}
	@BeforeSuite(alwaysRun = true)	
	@Parameters({"application","environment","grs"})
	public void preSetUp(@Optional String application,@Optional String environment,@Optional String grs) throws Exception 
	{	
		
		PreSetup.setApplication(application);
		logger.info("Running Before Suite Setup ");
		logger.info("Running Before Suite Setup ");
		String propFile="environment"+File.separator+environment+File.separator+environment+".properties";
		String userpropFile="environment"+File.separator+environment+File.separator+environment+"_api_users.properties";
		logger.info("propFile: "+propFile);
		logger.info("userpropFile :"+userpropFile);
		setSystemPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(propFile));
		setSystemUserPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(userpropFile));
		logger.info(PreSetupRestAPI.getSystemPropertyInputStream());
		symProPath.load(PreSetupRestAPI.getSystemPropertyInputStream());
		userProPath.load(PreSetupRestAPI.getSystemUserPropertyInputStream());
		setBaseuri(PreSetupRestAPI.symProPath.getProperty("RestAssured.baseURI"));	
		setGrsBaseuri(PreSetupRestAPI.symProPath.getProperty("rest.grs.baseUrl"));	
		LoginToRestAPI.setGrs(grs);
		if(application.equals("incent")||application.equals("xcommons"))
		{	
			RestAssured.baseURI = getBaseuri();
			RestAssured.basePath = "/xicm/icmadvanced/api";	
		}

		if(application.equals("objectives"))
		{	
			RestAssured.baseURI = baseuri;
		}
		if(application.equals("territories")) {
			RestAssured.baseURI =getBaseuri();
		}
		if(application.equals("tmca"))
		{	
			RestAssured.baseURI = baseuri;	
		}		

		if(application.equals("obero"))
		{	
			RestAssured.baseURI = baseuri;	
		}
		
		if(application.equals("orange")) {
			RestAssured.baseURI =getBaseuri();
		}
		
		if(application.equals("analytics")||application.equals("xcommons"))
		{	
			analyticsBaseUriCustom=getBaseuri();
			analyticsBaseUriObiee=getBaseuri();
			if(environment.equalsIgnoreCase("qaintx")||environment.equalsIgnoreCase("stgx")){
				//analyticsBaseUriCustom=baseuri.replaceAll("https", "http"); 
				analyticsBaseUriObiee=baseuri.replaceAll("https", "http"); 
				System.out.println("-----------https replace-----------");
			}

			if(environment.equalsIgnoreCase("ociqaintx") ||environment.equalsIgnoreCase("engapps01") ||environment.equalsIgnoreCase("appa01")||environment.equalsIgnoreCase("analytics01") ||environment.equalsIgnoreCase("qaintx")){
				analyticsBaseUriCustom+="/xianalytics/";
				analyticsBaseUriObiee+="/xanalytics/";
			}else{
				analyticsBaseUriCustom+="/xiadvanalytics/";
				analyticsBaseUriObiee+="/xadvanalytics/";
			}

		}				




	}
	public static String getBaseuri() {
		return baseuri;
	}
	public static void setBaseuri(String baseuri) {
		PreSetupRestAPI.baseuri = baseuri;
	}
	@AfterSuite(alwaysRun = true)	
	@Parameters("application")
	public void terminate(String application) throws Exception
	{
		//TODO : Need to get a logout feature

	}
}
