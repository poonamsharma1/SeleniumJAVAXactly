package com.xactly.xcommons.restapi;

import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jayway.jsonpath.JsonPath;

import net.minidev.json.JSONArray;

import com.xactly.WSO.*;
import com.xactly.xcommons.selenium.DBConnections;

public class IncentObjectHelperClass {
	RestAPIHelperClass rest = new RestAPIHelperClass();
	Random rand = new Random();
	
	public String getQuotaId(String quotaName) throws Exception{
		String path = "/v1/quotarelationship/quota/list";
		String resp = rest.getRestAPI(path);
		JSONArray quotaId = JsonPath.read(resp, "$.items[?(@.name ==" + quotaName + ")].id");
		try{
			return quotaId.get(0).toString();
		} catch (Exception e){
			throw new Exception("Failed to get quota id for: "+quotaName);
		}
		
	}
	
	public String getNumericFormulaId(String formulaName){
		String path = "/v1/ruleutil/formulas?formulaType=0";
		String resp = rest.getRestAPI(path);
		JSONArray formulaId = JsonPath.read(resp, "$.items[?(@.name ==" + formulaName + ")].formulaId");
		return formulaId.get(0).toString();
	}
	
	public String getTagId(String tagName) throws Exception{
		String path = "/setup/tags";
		String resp = rest.getRestAPI(path);
		JSONArray tagId = JsonPath.read(resp, "[?(@.name ==" + tagName + ")].id");
		if(tagId.size() != 1)
			throw new Exception("Not able to find tag: <"+tagName+">");
		return tagId.get(0).toString();
	}
	
	public String getPaycurveId(String name){
		String path = "/v1/paycurve/list";
		String resp = rest.getRestAPI(path);
		JSONArray objectInfo = JsonPath.read(resp, "items.[?(@payCurveName == "+name+")].id");
		return objectInfo.get(0).toString();
	}
	
	public String getPaycurveAssignmentId(String name, String assignmentName){
		String path = "/v1/paycurve/list?assignmentType=ALL&searchText="+name;
		String resp = rest.getRestAPI(path);
		JSONArray paycurveId = JsonPath.read(resp, "$items..[?(@.payCurveName == "+name+")].payCurveAssignmentListWSOList.[?(@.assignmentName == "+assignmentName+")].payCurveAssignmentId");
		return paycurveId.get(0).toString();
	}
	
	public String getQuotaRelationshipId(String name){
		String path = "/v1/quotarelationship/list?searchText="+name+"&showAssignment=N";
		String resp = rest.getRestAPI(path);
		try{
			JSONArray quotaRelationshipId = JsonPath.read(resp, "$items.[?(@.name == "+name+")].quotaRelationShipId");
			return quotaRelationshipId.get(0).toString();
		} catch (Exception e){
			return null;
		}
	}
	
	public String getQuotaRelationshipAssignmentId(String name, String assignmentName){
		String path = "/v1/quotarelationship/list?searchText="+name+"&showAssignment=Y";
		String resp = rest.getRestAPI(path);
		try{
			JSONArray quotaRelationshipId = JsonPath.read(resp, "$items.[?(@.name == "+name+")].qrAssignmentListWSOList.[?(@.assignmentName == "+assignmentName+")].qrAssignmentId");
			return quotaRelationshipId.get(0).toString();
		} catch (Exception e){
			return null;
		}
	}
	
	public List<String> getBusinessTagList(){
		String path = "/setup/tags";
		String resp = rest.getRestAPI(path);
		JSONArray objectInfo = JsonPath.read(resp, "$..name");
		List<String> tagList = new ArrayList<String>();
		for(int i=0;i<objectInfo.size();i++)
			tagList.add(objectInfo.get(i).toString());
		return tagList;
	}
	
	public List<String> getBusinessQuotaList(){
		String path = "/v1/quotarelationship/quota/list";
		String resp = rest.getRestAPI(path);
		JSONArray objectInfo = JsonPath.read(resp, "$.items..name");
		List<String> quotaList = new ArrayList<String>();
		for(int i=0; i<objectInfo.size(); i++)
			quotaList.add(objectInfo.get(i).toString());
		return quotaList;
	}
	
	public List<String> getBusinessNumericList(){
		String path = "/v1/ruleutil/formulas?formulaType=0";
		String resp = rest.getRestAPI(path);
		JSONArray objectInfo = JsonPath.read(resp, "$.items..name");
		List<String> numericForumlaList = new ArrayList<String>();
		for(int i=0; i<objectInfo.size();i++)
			numericForumlaList.add(objectInfo.get(i).toString());
		return numericForumlaList;
	}
	
	public List<String> getBusinessTitleList() throws Exception {
		String response = rest.getRestAPI("/v1/paycurve/-1/assignment/list?assignmentType=TITLE");
		JSONArray objectInfo = JsonPath.read(response, "$..name");
		List<String> titleList = new ArrayList<String>();
		for(int i=0;i<objectInfo.size();i++)
			titleList.add(objectInfo.get(i).toString());
		return titleList;
	}
	
	public List<String> getBusinessPositionList() throws Exception {
		String response = rest.getRestAPI("/v1/paycurve/-1/assignment/list?assignmentType=POSITION");
		JSONArray objectInfo = JsonPath.read(response, "$..name");
		List<String> positionList = new ArrayList<String>();
		for(int i=0;i<objectInfo.size();i++)
			positionList.add(objectInfo.get(i).toString());
		return positionList;
	}
	
	public String getTitleId(String name) throws Exception {
		String response = rest.getRestAPI("/v1/paycurve/-1/assignment/list?assignmentType=TITLE");
		JSONArray objectInfo = JsonPath.read(response, "items.[?(@name == "+name+")].assignmentId");
		return objectInfo.get(0).toString();
	}
	
	public String getPositionId(String name) throws Exception {
		String response = rest.getRestAPI("/v1/paycurve/-1/assignment/list?assignmentType=POSITION");
		JSONArray objectInfo = JsonPath.read(response, "items.[?(@name == "+name+")].assignmentId");
		return objectInfo.get(0).toString();
	}
	
	public String getMasterParticipantId(String name) throws Exception {
		String response = rest.getRestAPI("/v1/people?searchfield=name&searchtext="+name);
		JSONArray objectInfo = JsonPath.read(response, "$..id");
		return objectInfo.get(0).toString();
	}
	
	
	public LeafPeriodWSO getBusinessRandomVisiblePeriod(){
		String path = "/v1/periods/visibleleafperiods";
		String resp = rest.getRestAPI(path);
		JSONArray objectInfo = JsonPath.read(resp, "$.");
		
		Gson gson = new GsonBuilder().create();
		LeafPeriodWSO leafPeriod = new LeafPeriodWSO(); 
		int randomIndex = rand.nextInt(objectInfo.size());
		leafPeriod = gson.fromJson(objectInfo.get(randomIndex).toString(), LeafPeriodWSO.class);
		return leafPeriod;
	}
	
	public List<LeafPeriodWSO> getBusinessVisiblePeriods(){
		String path = "/v1/periods/visibleleafperiods";
		String resp = rest.getRestAPI(path);
		List<LeafPeriodWSO> leafPeriodsList = new ArrayList<LeafPeriodWSO>();
		JSONArray objectInfo = JsonPath.read(resp, "$.");
		
		for(Object obj : objectInfo){
			Gson gson = new GsonBuilder().create();
			LeafPeriodWSO leafPeriod = new LeafPeriodWSO();
			leafPeriod = gson.fromJson(obj.toString(), LeafPeriodWSO.class);
			leafPeriodsList.add(leafPeriod);
		}

		return leafPeriodsList;
	}

	public LeafPeriodWSO getPeriodByPeriodID(Long periodId){
		List<LeafPeriodWSO> leafPeriodsList = getBusinessVisiblePeriods();
		for(LeafPeriodWSO period : leafPeriodsList){
			if(period.getId() == periodId)
				return period;
		}
		return null;
	}
	
	public LeafPeriodWSO getPreviousPeriod(String period){
		List<LeafPeriodWSO> leafPeriodsList = getBusinessVisiblePeriods();
		for(int i=0; i<leafPeriodsList.size(); i++){
			if(leafPeriodsList.get(i).getName().equalsIgnoreCase(period))
				return leafPeriodsList.get(i-1);
		}
		
		return null;
	}

	public String getBusinessSOT(){
		String path = "/v1/periods/allLeafPeriods?showActiveOnly=false&showHidden=false";
		String resp = rest.getRestAPI(path);
		JSONArray SOT = JsonPath.read(resp, "[?(@.name == SOT)].id");
		return SOT.get(0).toString();
	}
	
	public String getPeriodId(String period){
		String path = "/v1/periods/allLeafPeriods?showActiveOnly=false&showHidden=false";
		String resp = rest.getRestAPI(path);
		JSONArray periodId = JsonPath.read(resp, "[?(@.name == "+period+")].id");
		return periodId.get(0).toString();
	}
	
	public String getYearPeriodId(String period){
		String path = "/v1/periods/yearperiods";
		String resp = rest.getRestAPI(path);
		JSONArray periodId = JsonPath.read(resp, "[?(@.name == "+period+")].id");
		return periodId.get(0).toString();
	}
	
	public String getBusinessEOT(){
		String path = "/v1/periods/allLeafPeriods?showActiveOnly=false&showHidden=false";
		String resp = rest.getRestAPI(path);
		JSONArray SOT = JsonPath.read(resp, "[?(@.name == EOT)].id");
		return SOT.get(0).toString();
	}

	public boolean isPeriodClosed(String period){
		String path = "/v1/periods/allLeafPeriods";
		String resp = rest.getRestAPI(path);
		JSONArray isOpen = JsonPath.read(resp, "[?(@.name == "+period+")].open");
		if(isOpen.get(0).toString().equalsIgnoreCase("false"))
			return true;
		return false;
	}

	public void resumeQueue(){
		String path = "/queue/?stateChange=Resumed";
		rest.postRestAPI(path, "");
	}
	
	public void unfinalize(String period){
		String periodId = getPeriodId(period);
		String rbody = "{\"periodId\":\""+periodId+"\",\"unfinalizeReason\":\"asd\"}";
		String path = "/queue/events/unfinalizeevents";
		resumeQueue();
		rest.postRestAPI(path, rbody);
	}
	
	public void finalize(String period){
		String periodId = getPeriodId(period);
		String rbody = "{\"periodId\":\""+periodId+"\",\"includeAll\":true,\"queueEventType\":\"Finalize\",\"businessGroupIdList\":[]}";
		String path = "/queue/events/finalizeevents";
		rest.postRestAPI(path, rbody);
	}
	
	public void waitForQueueEvents() throws InterruptedException{
		String path = "/queue/events";
		
		while(!rest.getRestAPI(path).equalsIgnoreCase("[]"))
			Thread.sleep(3000);
	}
	
	public void triggerSummaryRefresh() throws ClassNotFoundException, SQLException {
		DBConnections db = new DBConnections("api");
		
		db.connect_Db_string("BEGIN xc_summary_tables.refresh_all_pro; end;");
	}

	public String getUserDatePreference() throws Exception {
		String path = "/v1/users/preferences";
		
		String resp = rest.getRestAPI(path);
		String objectInfo = JsonPath.read(resp, "$['DATE_FORMAT']");
		return objectInfo;
	}
	
	public String getPeriodWithDate(String date, String format) throws Exception{
		String dateFormat = getUserDatePreference();
		DateFormat df = new SimpleDateFormat(dateFormat);
		DateFormat df2 = new SimpleDateFormat(format);
		
		List<LeafPeriodWSO> leafPeriodsList = getBusinessVisiblePeriods();
		for(LeafPeriodWSO period : leafPeriodsList){
			Date startDate = df.parse(period.getStartDateStr());
			Date endDate = df.parse(period.getEndDateStr());
			Date selectedDate = df2.parse(date);
			
			if(selectedDate.equals(startDate) || selectedDate.equals(endDate) || (selectedDate.before(endDate) && selectedDate.after(startDate))){
				return String.valueOf(period.getId());
			}
		}
		return null;
	}
	
	public String getTagIdUsingTagNameAndName(String tagName) throws Exception{
		String path = "/setup/tags?searchtext="+tagName+"&searchfield=name";
		String resp = rest.getRestAPI(path);
		JSONArray tagId = JsonPath.read(resp, "[?(@.name ==" + tagName + ")].id");
		if(tagId.size() != 1)
			throw new Exception("Not able to find tag: <"+tagName+">");
		return tagId.get(0).toString();
	}
	
}
