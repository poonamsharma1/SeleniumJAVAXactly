/**
 * 03-Mar-2015
   com.xactly.xcommons.java : ExcelConnector.java
   dpadmanabha
 */
package com.xactly.xcommons.javahelper;
import java.io.*;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Date;

import au.com.bytecode.opencsv.CSVReader;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Reporter;

import org.apache.log4j.Logger;

/**
 * @author dpadmanabha
 *
 */
public class ExcelConnector {

	/**
	 * 
	 */
	public static Logger logger = Logger.getLogger(ExcelConnector.class.getName());
	public ExcelConnector() {
		// TODO Auto-generated constructor stub
	}
	
	public ArrayList<String> excelReaderXLSX(String xlsxfilename) {
	    String data;
	    String value = null;
	    int Count = 0;
	    ArrayList<String> cellcontent = new ArrayList<String>();
	    try {
	    	logger.info("Reading this filename "+xlsxfilename);
	        InputStream is = new FileInputStream(xlsxfilename);
	        Workbook wb = WorkbookFactory.create(is);
	        Sheet sheet = wb.getSheetAt(0);
	        Iterator rowIter = sheet.rowIterator();
	        Row r = (Row)rowIter.next();
	        short lastCellNum = r.getLastCellNum();
	        int[] dataCount = new int[lastCellNum];
	        int col = 0;
	        rowIter = sheet.rowIterator();
	        while(rowIter.hasNext()) 
	        {
	            Iterator cellIter = ((Row)rowIter.next()).cellIterator();
	            while(cellIter.hasNext()) {
	                Cell cell = (Cell)cellIter.next();
	                col = cell.getColumnIndex();
	                
	                dataCount[col] += 1;
	                DataFormatter df = new DataFormatter();
	                data = df.formatCellValue(cell);
	               // logger.info("Data: " + data);
	                cellcontent.add(data.toString());
	            }
	        }
	        is.close();
	        Count=dataCount[0];
	        logger.info("col 0 : " + dataCount[0]);
	        for(int x = 0; x < dataCount.length; x++) 
	        {
	            
	        }
	    }
	    catch(Exception e) {
	        e.printStackTrace();
	        
	    }
		//return Count;
		return cellcontent;
	}
	
	public List<List<String>> excelTo2DArrayReader(String xlsxfilename) {
	    String data;
	    List<List<String>> rows = new ArrayList<List<String>>();
	    try {
	    	logger.info("Reading this filename "+xlsxfilename);
	        InputStream is = new FileInputStream(xlsxfilename);
	        Workbook wb = WorkbookFactory.create(is);
	        Sheet sheet = wb.getSheetAt(0);
	        Iterator<Row> rowIter = sheet.rowIterator();
	        while(rowIter.hasNext()) 
	        {
	            Iterator<Cell> cellIter = (rowIter.next()).cellIterator();
	            List<String> columns = new ArrayList<String>();
	            while(cellIter.hasNext()) {
	                Cell cell = (Cell)cellIter.next();
	                
	                DataFormatter df = new DataFormatter();
	                data = df.formatCellValue(cell);
	               // logger.info("Data: " + data);
	                columns.add(data.toString());
	            }
	            rows.add(columns);
	        }
	        is.close();
	    }
	    catch(Exception e) {
	        e.printStackTrace();
	        
	    }
		return rows;
	}
	
	/*public ArrayList<String> excelWriter(String xlsxfilename) {
	    try {
	        InputStream is = new FileInputStream(xlsxfilename);
	        Workbook wb = WorkbookFactory.create(is);
	        Sheet sheet = wb.getSheetAt(0);
	        Iterator rowIter = sheet.rowIterator();
	        Row r = (Row)rowIter.next();
	        Cell c = r.getCell(0);
	        c.setCellValue(value);
	        short lastCellNum = r.getLastCellNum();
	        int[] dataCount = new int[lastCellNum];
	        int col = 0;
	        rowIter = sheet.rowIterator();
	        
	    }
	    catch(Exception e) {
	        e.printStackTrace();
	        
	    }
		//return Count;
		return cellcontent;
	}*/
	
	public String[][] ReadXLSSheet(String filePath, String sheetName){
		FileInputStream fis = null ;
		String[][] sheetData = null ;

		try{
			fis = new FileInputStream(new File(filePath));
			HSSFWorkbook workbook = new HSSFWorkbook(fis);
			HSSFSheet sheet = workbook.getSheet(sheetName) ;
			int rowNum = sheet.getLastRowNum()+1;
			int colNum = sheet.getRow(0).getLastCellNum();
			sheetData = new String[rowNum][colNum];

			for (int i=0; i<rowNum; i++){
				HSSFRow row = sheet.getRow(i);
				for (int j=0; j<colNum; j++){
					HSSFCell cell = row.getCell(j);
					sheetData[i][j] = String.valueOf(cell);
				}
			}
			fis.close();
		}catch(IOException e){
			e.printStackTrace();
		}
		return sheetData;
	}
	
	/**
	 * This method reads the data in Excel workbook of the particular sheet
	 * @param Complete path of the Excel file and Sheet Name
	 * @return Sheet data in the form of 2-D array
	 */
	public static String[][] ReadXLSXSheet(String filePath, String sheetName){
		FileInputStream fis = null ;
		String[][] sheetData = null ;

		try{
			fis = new FileInputStream(new File(filePath));
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName) ;
			int rowNum = sheet.getLastRowNum()+1;
			int colNum = sheet.getRow(0).getLastCellNum();
			sheetData = new String[rowNum][colNum];

			for (int i=0; i<rowNum; i++){
				XSSFRow row = sheet.getRow(i);
				for (int j=0; j<colNum; j++){
					XSSFCell cell = row.getCell(j);
					sheetData[i][j] = String.valueOf(cell);
				}
			}
			fis.close();
		}catch(IOException e){
			e.printStackTrace();
		}
		return sheetData;
	}
	
	/**
	 * Converts each row of excel file to a map with headers as key  and row data as values and returns list of such maps
	 * @param file
	 * @return List of maps having header as key and row as value
	 * @throws Exception
	 */
	public List<Map<String, Object>> convertExcelRowToMap(File file) throws Exception {

		List<Map<String, Object>> mapList = new ArrayList<Map<String, Object>>();
		FileInputStream ExcelFile = new FileInputStream(file);
		XSSFWorkbook ExcelWBook = new XSSFWorkbook(ExcelFile);
		XSSFSheet ExcelWSheet = ExcelWBook.getSheetAt(0);
		int rowCount = ExcelWSheet.getLastRowNum();
		int colCount = ExcelWSheet.getRow(0).getLastCellNum();
		String[] header = new String[colCount];

		for (int i = 0; i < colCount; i++) {
			header[i] = ExcelWSheet.getRow(0).getCell(i).toString();
		}

		for (int i = 1; i <= rowCount; i++) {
			Map<String, Object> hmap = new HashMap<String, Object>();
	
			for (int j = 0; j < colCount; j++) {
				Object currentValue = "";
				int cellType = ExcelWSheet.getRow(i).getCell(j).getCellType();
				if (cellType == org.apache.poi.ss.usermodel.Cell.CELL_TYPE_STRING) {
					currentValue = ExcelWSheet.getRow(i).getCell(j).getStringCellValue();
				} else if ((HSSFDateUtil.isCellDateFormatted(ExcelWSheet.getRow(i).getCell(j)))) {
					currentValue = ExcelWSheet.getRow(i).getCell(j).getDateCellValue();
				} else if (cellType == org.apache.poi.ss.usermodel.Cell.CELL_TYPE_NUMERIC) {
					currentValue = ExcelWSheet.getRow(i).getCell(j).getNumericCellValue();
				}
				//logger.info("value is "+currentValue);
				if ((currentValue != "")) {
					hmap.put(header[j], currentValue);
				}
			}
			mapList.add(hmap);	
		}
		return mapList;
	}	
	
	
	public static void main(String[] args) {
		ExcelConnector ex = new ExcelConnector();
		ex.excelReaderXLSX("");
	}
	
	public void writeToExcel(String path,int row, int column,Integer value) throws InvalidFormatException, IOException{
		File src = new File(path);
		FileInputStream fis=new FileInputStream(src);
		XSSFWorkbook wb = new XSSFWorkbook(fis);		
		String sheetname = wb.getSheetName(0);
		Sheet sh=wb.getSheet(sheetname);
		XSSFSheet sheet1 = wb.getSheet(sheetname);		
		sheet1.getRow(row).createCell(column).setCellType(Cell.CELL_TYPE_NUMERIC);
		sheet1.getRow(row).createCell(column).setCellValue(value);
		logger.info(sheetname);		
		FileOutputStream fos=new FileOutputStream(src);
		wb.write(fos);
		fos.close();
		logger.info("Excel sheet updated");
	}
	
	public static String ReadXLSXSheet(String filePath, String sheetName,int r,int c){
		FileInputStream fis = null ;
		String value = null;

		try{
			fis = new FileInputStream(new File(filePath));
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName) ;
			DataFormatter formatter = new DataFormatter();
			Cell cell = sheet.getRow(r).getCell(c);
			 value = formatter.formatCellValue(cell);
			/*int rowNum = sheet.getLastRowNum()+1;
			int colNum = sheet.getRow(0).getLastCellNum();
			sheetData = new String[rowNum][colNum];

			for (int i=0; i<rowNum; i++){
				XSSFRow row = sheet.getRow(i);
				for (int j=0; j<colNum; j++){
					XSSFCell cell = row.getCell(j);
					sheetData[i][j] = String.valueOf(cell);
				}
			}
			fis.close();*/
		}catch(IOException e){
			e.printStackTrace();
		}
		return value;
	}
	
	/*
     *  This is the method to find the row number
     */
	  public static boolean findRow(String fileName, String sheetName,String cellContent) throws IOException{
	        
		  logger.info(fileName);
		  boolean value = false;
		  FileInputStream fis = new FileInputStream(new File(fileName));
		  XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet(sheetName) ;
		//	logger.info("sheetName" +sheet);
	        XSSFRow row;
	        XSSFCell cell;
	        Iterator rows = sheet.rowIterator();
	        while (rows.hasNext())
	        {
	        	row=(XSSFRow) rows.next();
	            Iterator cells = row.cellIterator();
	            while (cells.hasNext())
	            {
	                cell=(XSSFCell) cells.next();   
	                if (cell.getCellType() == XSSFCell.CELL_TYPE_STRING)
	                {
	                  //  System.out.print(cell.getStringCellValue()+" ");
	                    if(cell.getStringCellValue().equals(cellContent)) {
	                    	value = true;
	                    	return value;
	                    }
	                }
	            }
	            logger.info("");
	        }
			return value;
	    }   
	// This method will return the row number where the expected string match
	  
		  public static int findRowNum(String fileName, String sheetName,String cellContent) throws IOException{
		        
			  logger.info(fileName);
			  boolean value = false;
			  int rowNum=0;
			  FileInputStream fis = new FileInputStream(new File(fileName));
			  XSSFWorkbook workbook = new XSSFWorkbook(fis);
				XSSFSheet sheet = workbook.getSheet(sheetName) ;
			//	logger.info("sheetName" +sheet);
		        XSSFRow row;
		        XSSFCell cell;
		        Iterator rows = sheet.rowIterator();
		        while (rows.hasNext())
		        {
		        	row=(XSSFRow) rows.next();
		            Iterator cells = row.cellIterator();
		            while (cells.hasNext())
		            {
		                cell=(XSSFCell) cells.next();   
		                if (cell.getCellType() == XSSFCell.CELL_TYPE_STRING)
		                {
		                  //  System.out.print(cell.getStringCellValue()+" ");
		                    if(cell.getStringCellValue().equals(cellContent)) {
		                    	value = true;
		                    	rowNum=row.getRowNum();
		             	        return rowNum;
		                    	
		                    }
		                }
		            }
		            logger.info("");
		        }
				return rowNum ;
		    } 
	   
		  public static int GetlastRownum(String filePath, String sheetName) throws IOException{
				FileInputStream fis = null ;
				String value = null;

				
					fis = new FileInputStream(new File(filePath));
					XSSFWorkbook workbook = new XSSFWorkbook(fis);
					XSSFSheet sheet = workbook.getSheet(sheetName) ;
					int rowCount = sheet.getLastRowNum() + 1;
					System.out.println("Row Count :- " + rowCount);
					return rowCount;
					
					
				
			}
		  public int getLastRowNum(File file) throws IOException
		  {
			  FileInputStream ExcelFile = new FileInputStream(file);
			  XSSFWorkbook ExcelWBook = new XSSFWorkbook(ExcelFile);
			  XSSFSheet ExcelWSheet = ExcelWBook.getSheetAt(0);
			  int rowCount = ExcelWSheet.getLastRowNum();
			 return rowCount; 
		  }
		  
		  public int LastCellNum(File file) throws IOException
		  {
			  FileInputStream ExcelFile = new FileInputStream(file);
			  XSSFWorkbook ExcelWBook = new XSSFWorkbook(ExcelFile);
			  XSSFSheet ExcelWSheet = ExcelWBook.getSheetAt(0);
			  int colCount = ExcelWSheet.getRow(0).getLastCellNum();
			 return colCount; 
		  }
		  
		  public List<Map<String, Object>> convertExcelRowToMapEOF(File file) throws Exception {

				List<Map<String, Object>> mapList = new ArrayList<Map<String, Object>>();
				FileInputStream ExcelFile = new FileInputStream(file);
				XSSFWorkbook ExcelWBook = new XSSFWorkbook(ExcelFile);
				XSSFSheet ExcelWSheet = ExcelWBook.getSheetAt(0);
			  	int rowCount=getLastRowNum(file);
			  	int colCount=LastCellNum(file);
				String[] header = new String[colCount];

				for (int i = 0; i < colCount; i++) {
					header[i] = ExcelWSheet.getRow(0).getCell(i).toString();
				}

				for (int i = 1; i < rowCount; i++) {
					Map<String, Object> hmap = new HashMap<String, Object>();
			
					for (int j = 0; j < colCount; j++) {
						Object currentValue = "";
						int cellType = ExcelWSheet.getRow(i).getCell(j).getCellType();
						if (cellType == org.apache.poi.ss.usermodel.Cell.CELL_TYPE_STRING) {
							currentValue = ExcelWSheet.getRow(i).getCell(j).getStringCellValue();
						} else if ((HSSFDateUtil.isCellDateFormatted(ExcelWSheet.getRow(i).getCell(j)))) {
							currentValue = ExcelWSheet.getRow(i).getCell(j).getDateCellValue();
						} else if (cellType == org.apache.poi.ss.usermodel.Cell.CELL_TYPE_NUMERIC) {
							currentValue = ExcelWSheet.getRow(i).getCell(j).getNumericCellValue();
						}
						//logger.info("value is "+currentValue);
						if ((currentValue != "")) {
							hmap.put(header[j], currentValue);
						}
					}
					mapList.add(hmap);	
				}
				return mapList;
			}

	public String readFromExcel(File path, int rowNum, int columnNum) throws InvalidFormatException, IOException {
		FileInputStream fis = new FileInputStream(path);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		String sheetName = wb.getSheetName(0);
		Sheet sh = wb.getSheet(sheetName);
		XSSFSheet sheet1 = wb.getSheet(sheetName);
		Row row =sheet1.getRow(rowNum);
		Cell c = row.getCell(columnNum);
		return c.toString().trim();
	}

	public void writeStringToExcel(String path,int row, int column,String value) throws InvalidFormatException, IOException{
		File src = new File(path);
		FileInputStream fis=new FileInputStream(src);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		String sheetname = wb.getSheetName(0);
		Sheet sh=wb.getSheet(sheetname);
		XSSFSheet sheet1 = wb.getSheet(sheetname);
		sheet1.getRow(row).createCell(column).setCellType(Cell.CELL_TYPE_NUMERIC);
		sheet1.getRow(row).createCell(column).setCellValue(value);
		logger.info(sheetname);
		FileOutputStream fos=new FileOutputStream(src);
		wb.write(fos);
		fos.close();
		logger.info("Excel sheet updated");
	}

	/**
	 * Read CSV by row and column
	 *
	 * @param fileToUpdate CSV file path to update e.g. D:\\Mosin\\test.csv
	 * @param row Row for which need to update
	 * @param col Column for which you need to update
	 * @throws IOException
	 */
	public String readCSV(String fileToUpdate,int row, int col) throws IOException {
		File inputFile = new File(fileToUpdate);
		CSVReader reader = new CSVReader(new FileReader(inputFile), ',');
		List<String[]> csvBody = reader.readAll();
		String str = csvBody.get(row)[col].toString();
		reader.close();
		return str;
	}


}
