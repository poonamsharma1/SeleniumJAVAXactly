package com.xactly.xcommons.selenium;

import java.io.File;
import java.io.IOException;

import java.util.Properties;

import javax.net.ssl.SSLContext;
import javax.net.ssl.X509ExtendedTrustManager;

import org.apache.log4j.Logger;
import org.bson.Document;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;

import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;

import nl.altindag.ssl.SSLFactory;
import nl.altindag.ssl.util.PemUtils;
public class MongoDBConnection {

	public static Logger logger = Logger.getLogger("org.mongodb.driver");
	public static Properties dbProPath = new Properties();
	
	public static String portNumber=null;
	public static String databaseName=null;
	
	public static String getPortNumber() {
		return portNumber;
	}

	public static void setPortNumber(String portNumber) {
		MongoDBConnection.portNumber = portNumber;
	}

	public static String getDatabaseName() {
		return databaseName;
	}

	public static void setDatabaseName(String databaseName) {
		MongoDBConnection.databaseName = databaseName;
	}

	public MongoDBConnection()throws Exception
	{
		String propFile="environment"+File.separator+"orangedb"+File.separator+"orangedatabase.properties";
		dbProPath.load(this.getClass().getClassLoader().getResourceAsStream(propFile));
		setDatabaseName(dbProPath.getProperty("databaseName"));
		setPortNumber(dbProPath.getProperty("portNumber"));
		
	}

	public void connectToMongoDB(String collectionName, String searchKey, String searchValue, String updateKey, String updateValue, String updateValueType, String key, String environment) throws InterruptedException, IOException
	{
		String propFile="environment"+File.separator+"orangedb"+File.separator+"orangedatabase.properties";
		dbProPath.load(this.getClass().getClassLoader().getResourceAsStream(propFile));
		String connectionString="";
		
		if(environment.equalsIgnoreCase("alpha"))
		{
			connectionString=dbProPath.getProperty("alphaConnectionString");
		}
		
		else if(environment.equalsIgnoreCase("sandbox"))
		{
			connectionString=dbProPath.getProperty("sandboxConnectionString");
		}
		
		X509ExtendedTrustManager trustManager = PemUtils.loadTrustMaterial(dbProPath.getProperty("pemFileName"));
		SSLFactory sslFactory = SSLFactory.builder()
		          .withTrustMaterial(trustManager)
		          .build();

		SSLContext sslContext = sslFactory.getSslContext();
		
			
			MongoClientSettings settings = MongoClientSettings.builder()
				     .applyToSslSettings(builder -> {
				                 builder.enabled(true);
				                 builder.context(sslContext);
				                 builder.invalidHostNameAllowed(true);
				             }).applyConnectionString(new ConnectionString(connectionString))
				     .build();
			com.mongodb.client.MongoClient mongoClient = MongoClients.create(settings);
		
		
		MongoDatabase mongoDB=mongoClient.getDatabase(getDatabaseName());
		
		MongoCollection<Document> dbCollection=mongoDB.getCollection(collectionName);
		
		if(key.equalsIgnoreCase("update"))
		{
			if(updateValueType.equalsIgnoreCase("boolean"))
			{
				dbCollection.updateOne(Filters.eq(searchKey, searchValue), Updates.set(updateKey, Boolean.valueOf(updateValue)));
			}
			
			else if(updateValueType.equalsIgnoreCase("string"))
			{
				dbCollection.updateOne(Filters.eq(searchKey, searchValue), Updates.set(updateKey, updateValue));
			}
			
			else if(updateValueType.equalsIgnoreCase("int"))
			{
				dbCollection.updateOne(Filters.eq(searchKey, searchValue), Updates.set(updateKey, Integer.valueOf(updateValue)));
			}
		}
		
		if(key.equalsIgnoreCase("delete"))
		{
			
			Document docToDelete = new Document(updateKey, updateValue);
			dbCollection.findOneAndUpdate(new Document(searchKey, searchValue), new Document("$unset", docToDelete));
		}
		
		if(key.equalsIgnoreCase("insert"))
		{
			dbCollection.updateOne(new Document(searchKey, searchValue),
                    new Document("$set", new Document(updateKey, true)));
		}
		
		mongoClient.close();
	
		
	}
	
}
