package com.xactly.xcommons.xlsxlibrary;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.log4j.Logger;

public class xlsxcompare {
	public static Logger logger = Logger.getLogger(xlsxcompare.class.getName());
	public static boolean compareExcelFilesWithSkipRow(String ARdownloadLoc,String ARfileName,String ERdirectoryLoc, String ERfileName,int skiprow) throws Exception
	{
		
		FileInputStream ARfile = new FileInputStream(new File(""+ARdownloadLoc+"/"+ARfileName+""));
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();				
		FileInputStream ERfile = new FileInputStream(new File(classLoader.getResource(ERdirectoryLoc+ ERfileName).getFile()));
		XSSFWorkbook workbook1 = new XSSFWorkbook(ERfile);
		XSSFWorkbook workbook2 = new XSSFWorkbook(ARfile);        
		XSSFSheet sheet1 = workbook1.getSheetAt(0);
		XSSFSheet sheet2 = workbook2.getSheetAt(0);
		boolean result = compareTwoSheetsWithSkipRow(sheet1, sheet2,skiprow); 
		return result;
	}
	

	public static boolean compareTwoSheets(XSSFSheet sheet1, XSSFSheet sheet2) {
		int firstRow1 = sheet1.getFirstRowNum();
        int lastRow1 = sheet2.getLastRowNum();
        boolean equalSheets = true;
        for(int i=firstRow1; i <= lastRow1; i++) {
            
            logger.info("\n\nComparing Row "+i);
            
            XSSFRow row1 = sheet1.getRow(i);
            XSSFRow row2 = sheet2.getRow(i);
            if(!compareTwoRows(row1, row2)) {
                equalSheets = false;
                logger.info("Row "+i+" - Not Equal");
                break;
            } else {
                logger.info("Row "+i+" - Equal");
            }
        }
        return equalSheets;
    }
	//Compare two sheets by skipping any row which need not be compared
		public static boolean compareTwoSheetsWithSkipRow(XSSFSheet sheet1, XSSFSheet sheet2,int skiprownum) {
			int firstRow1 = sheet1.getFirstRowNum();
	        int lastRow1 = sheet2.getLastRowNum();
			int skipRow = skiprownum;
	        boolean equalSheets = true;
	        for(int i=firstRow1; i <= lastRow1; i++) {
	            
				if(i==skipRow)
				{
					logger.info("\n\nSkipping Row Number:"+skipRow);
					continue;
				}
	            logger.info("\n\nComparing Row "+i);
	            
	            XSSFRow row1 = sheet1.getRow(i);
	            XSSFRow row2 = sheet2.getRow(i);
	            if(!compareTwoRows(row1, row2)) {
	                equalSheets = false;
	                logger.info("Row "+i+" - Not Equal");
	                break;
	            } else {
	                logger.info("Row "+i+" - Equal");
	            }
	        }
	        return equalSheets;
	    }

    // Compare Two Rows
    public static boolean compareTwoRows(XSSFRow row1, XSSFRow row2) {
        if((row1 == null) && (row2 == null)) {
            return true;
        } else if((row1 == null) || (row2 == null)) {
            return false;
        }
        
        int firstCell1 = row1.getFirstCellNum();
        int lastCell1 = row1.getLastCellNum();
        boolean equalRows = true;
        
        // Compare all cells in a row
        for(int i=firstCell1; i <= lastCell1; i++) {
            XSSFCell cell1 = row1.getCell(i);
            XSSFCell cell2 = row2.getCell(i);
            if(!compareTwoCells(cell1, cell2)) {
                equalRows = false;
                System.err.println("       Cell "+i+" - NOt Equal");
                break;
            } else {
                logger.info("       Cell "+i+" - Equal");
            }
        }
        return equalRows;
    }

    // Compare Two Cells
    public static boolean compareTwoCells(XSSFCell cell1, XSSFCell cell2) {
        if((cell1 == null) && (cell2 == null)) {
            return true;
        } else if((cell1 == null) || (cell2 == null)) {
            return false;
        }
        
        boolean equalCells = false;
        int type1 = cell1.getCellType();
        int type2 = cell2.getCellType();
        if (type1 == type2) {
            if (cell1.getCellStyle().equals(cell2.getCellStyle())) {
                // Compare cells based on its type
                switch (cell1.getCellType()) {
                case HSSFCell.CELL_TYPE_FORMULA:
                    if (cell1.getCellFormula().equals(cell2.getCellFormula())) {
                        equalCells = true;
                    }
                    break;
                case HSSFCell.CELL_TYPE_NUMERIC:
                    if (cell1.getNumericCellValue() == cell2
                            .getNumericCellValue()) {
                        equalCells = true;
                    }
                    break;
                case HSSFCell.CELL_TYPE_STRING:
                    if (cell1.getStringCellValue().equals(cell2
                            .getStringCellValue())) {
                        equalCells = true;
                    }
                    break;
                case HSSFCell.CELL_TYPE_BLANK:
                    if (cell2.getCellType() == HSSFCell.CELL_TYPE_BLANK) {
                        equalCells = true;
                    }
                    break;
                case HSSFCell.CELL_TYPE_BOOLEAN:
                    if (cell1.getBooleanCellValue() == cell2
                            .getBooleanCellValue()) {
                        equalCells = true;
                    }
                    break;
                case HSSFCell.CELL_TYPE_ERROR:
                    if (cell1.getErrorCellValue() == cell2.getErrorCellValue()) {
                        equalCells = true;
                    }
                    break;
                default:
                    if (cell1.getStringCellValue().equals(
                            cell2.getStringCellValue())) {
                        equalCells = true;
                    }
                    break;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
        return equalCells;
        
        
    }
    
	public  boolean xlsxFileComparison (String  expectedFileLocation,String  actualFileLocation){
		boolean flag=true;
		try {
			File fielE = new File (expectedFileLocation);
			File fielA = new File(actualFileLocation);
	        
	        FileInputStream  expectedFile = new FileInputStream  (fielE);
	        FileInputStream  actualFile = new FileInputStream  (fielA);
	        List<String> actualFileHeaders = new ArrayList<String>();
	        List<String> expectedFileHeaders = new ArrayList<String>();
	        XSSFCell cellExpected;
	        XSSFCell cellActual;
			XSSFWorkbook wBookActual = new XSSFWorkbook(actualFile);
			XSSFWorkbook wBookExpected = new XSSFWorkbook(expectedFile);
			XSSFSheet sheetA = wBookActual.getSheetAt(0);
			XSSFSheet sheetE = wBookExpected.getSheetAt(0);
			Iterator<Row> rowIteratorA = sheetA.iterator();
			Iterator<Row> rowIteratorE =  sheetE.iterator();

			int count = 0;
			boolean isHeaderCompletes = false;
			while (rowIteratorA.hasNext() && count ==0)
			{
				XSSFRow headerA = (XSSFRow)rowIteratorA.next();
				 Iterator<Cell> cellIteratorActual= headerA.cellIterator();
				 cellActual = (XSSFCell)cellIteratorActual.next();
				 while (cellIteratorActual.hasNext() && !isHeaderCompletes)
				 {
					 switch (cellActual.getCellType()) {
		                    case Cell.CELL_TYPE_BLANK:
		                    	isHeaderCompletes=true;
		                        break;
		                    case Cell.CELL_TYPE_NUMERIC:
		                    	double doubleVal = cellActual.getNumericCellValue();
		                    	actualFileHeaders.add(String.valueOf(doubleVal));
		                    	break;
		                    case Cell.CELL_TYPE_STRING:
		                    	actualFileHeaders.add(cellActual.getStringCellValue());
		                    	break;
		                    case Cell.CELL_TYPE_FORMULA:
		                    	actualFileHeaders.add(cellActual.getCellFormula());
		                    	break;
		                    case Cell.CELL_TYPE_BOOLEAN:
		                    	actualFileHeaders.add(String.valueOf(cellActual.getBooleanCellValue()));
		                    	break;
		                    case Cell.CELL_TYPE_ERROR:
		                    	actualFileHeaders.add(String.valueOf(cellActual.getErrorCellValue()));
		                    	break;
//		                    default:
//		                    	actualFileHeaders.add(cellActual.getStringCellValue());
//		                    	break;
		                }
					 cellActual = (XSSFCell)cellIteratorActual.next();
				 }	 
			}
			isHeaderCompletes = false;
			while (rowIteratorE.hasNext() && count ==0)
			{
				XSSFRow headerE = (XSSFRow)rowIteratorE.next();
				 Iterator<Cell> cellIteratorExpected= headerE.cellIterator();
				 cellExpected = (XSSFCell)cellIteratorExpected.next();
				 while (cellIteratorExpected.hasNext() && !isHeaderCompletes)
				 {
					 switch (cellExpected.getCellType()) {
					 	case Cell.CELL_TYPE_BLANK:
	                    	isHeaderCompletes=true;
	                        break;
	                    case Cell.CELL_TYPE_NUMERIC:
	                    	double doubleVal = cellExpected.getNumericCellValue();
	                    	expectedFileHeaders.add(String.valueOf(doubleVal));
	                    	break;
	                    case Cell.CELL_TYPE_STRING:
	                    	expectedFileHeaders.add(cellExpected.getStringCellValue());
	                    	break;
	                    case Cell.CELL_TYPE_FORMULA:
	                    	expectedFileHeaders.add(cellExpected.getCellFormula());
	                    	break;
	                    case Cell.CELL_TYPE_BOOLEAN:
	                    	expectedFileHeaders.add(String.valueOf(cellExpected.getBooleanCellValue()));
	                    	break;
	                    case Cell.CELL_TYPE_ERROR:
	                    	expectedFileHeaders.add(String.valueOf(cellExpected.getErrorCellValue()));
	                    	break;
//		                    case Cell.CELL_TYPE_BLANK:
//		                    	isHeaderCompletes=true;
//		                        break;
//		                    default:
//		                    	expectedFileHeaders.add(cellExpected.getStringCellValue());
//		                    	break;
		                }
					 
					 cellExpected = (XSSFCell)cellIteratorExpected.next();
				 }	 
			}
			
			wBookActual.close();
			wBookExpected.close();
			
	       logger.info("expectedFileHeader::" +expectedFileHeaders);
	       logger.info("actualFileHeaders::" +actualFileHeaders);
	       flag =actualFileHeaders.equals(expectedFileHeaders);

		} catch (Exception ioe) {
	        ioe.printStackTrace();
	    }
		return flag;
	}
	
	public static boolean compareExcelFileWithSkipRow(String ARdownloadLoc,String ARfileName,String ERdirectoryLoc, String ERfileName,int skiprow) throws Exception
	{
		
		FileInputStream ARfile = new FileInputStream(new File(ARdownloadLoc));
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();				
		FileInputStream ERfile = new FileInputStream(new File(classLoader.getResource(ERdirectoryLoc+ ERfileName).getFile()));
		XSSFWorkbook workbook1 = new XSSFWorkbook(ERfile);
		XSSFWorkbook workbook2 = new XSSFWorkbook(ARfile);        
		XSSFSheet sheet1 = workbook1.getSheetAt(0);
		XSSFSheet sheet2 = workbook2.getSheetAt(0);
		boolean result = compareTwoSheetsWithSkipRow(sheet1, sheet2,skiprow); 
		return result;
	}
	
	//This method for sending 2 arguments: AR file name with the path and ER file name with the path  (advisable to use FileSeperator while appending filename to filepath)
	public static boolean compareExcelFilesWithSkipRow(String ARfileNameWithPath,String ERfileNameWithPath, int skiprow) throws Exception
	{
		
		FileInputStream AR = new FileInputStream(new File(ARfileNameWithPath));
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();				
		FileInputStream ER = new FileInputStream(new File(classLoader.getResource(ERfileNameWithPath).getFile()));
		XSSFWorkbook workbook1 = new XSSFWorkbook(ER);
		XSSFWorkbook workbook2 = new XSSFWorkbook(AR);        
		XSSFSheet sheet1 = workbook1.getSheetAt(0);
		XSSFSheet sheet2 = workbook2.getSheetAt(0);
		boolean result = xlsxcompare.compareTwoSheetsWithSkipRow(sheet1, sheet2,skiprow); 
		return result;
	}


	public static Boolean compareXLSXSheets(String expectedfile, String actualfile, int index) throws IOException {

		File fielE = new File (expectedfile);
		File fielA = new File(actualfile);
		FileInputStream  expectedFile = new FileInputStream  (fielE);
		FileInputStream  actualFile = new FileInputStream  (fielA);

		XSSFWorkbook wBookActual = new XSSFWorkbook(actualFile);
		XSSFWorkbook wBookExpected = new XSSFWorkbook(expectedFile);

		XSSFSheet sheetA = wBookActual.getSheetAt(index);
		XSSFSheet sheetE = wBookExpected.getSheetAt(index);

		Boolean compareResult = xlsxcompare.compareTwoSheets(sheetA, sheetE);
		return compareResult;
	}
	
	
	//This method is specific to the comparison of excel files which have Custom Date Format 
	public boolean xlsxFileComparisonWithDateCell(String expectedFileLocation, String actualFileLocation)
			throws IOException {
		boolean flag = true;
		xlsxcompare xl = new xlsxcompare();

		try {
			File fielE = new File(expectedFileLocation);
			File fielA = new File(actualFileLocation);

			FileInputStream expectedFile = new FileInputStream(fielE);
			FileInputStream actualFile = new FileInputStream(fielA);
			List<String> actualFileHeaders = new ArrayList<String>();
			List<String> actualFileHeaders1 = new ArrayList<String>();
			List<String> expectedFileHeaders = new ArrayList<String>();
			List<String> expectedFileHeaders1 = new ArrayList<String>();
			XSSFCell cellExpected;
			XSSFCell cellActual;
			XSSFWorkbook wBookActual = new XSSFWorkbook(actualFile);
			XSSFWorkbook wBookExpected = new XSSFWorkbook(expectedFile);
			XSSFSheet sheetA = wBookActual.getSheetAt(0);
			XSSFSheet sheetE = wBookExpected.getSheetAt(0);
			Iterator<Row> rowIteratorA = sheetA.iterator();
			Iterator<Row> rowIteratorE = sheetE.iterator();

			int count = 0;
			boolean isHeaderCompletes = false;
			while (rowIteratorA.hasNext() && count == 0) {

				XSSFRow headerA = (XSSFRow) rowIteratorA.next();
				Iterator<Cell> cellIteratorActual = headerA.cellIterator();
				cellActual = (XSSFCell) cellIteratorActual.next();
				while (cellIteratorActual.hasNext() && !isHeaderCompletes) {
					switch (cellActual.getCellType()) {
					case Cell.CELL_TYPE_BLANK:
						isHeaderCompletes = true;
						break;

					case Cell.CELL_TYPE_NUMERIC:
						logger.info("Actual file format is" +cellActual.getCellStyle().getDataFormatString());
						actualFileHeaders.add(cellActual.getDateCellValue().toString());
						actualFileHeaders1.add(cellActual.getCellStyle().getDataFormatString());

						break;

					default:
						actualFileHeaders.add(cellActual.getStringCellValue());
						break;
					}
					cellActual = (XSSFCell) cellIteratorActual.next();
				}
			}
			isHeaderCompletes = false;
			while (rowIteratorE.hasNext() && count == 0) {
				XSSFRow headerE = (XSSFRow) rowIteratorE.next();
				Iterator<Cell> cellIteratorExpected = headerE.cellIterator();
				cellExpected = (XSSFCell) cellIteratorExpected.next();
				while (cellIteratorExpected.hasNext() && !isHeaderCompletes) {
					switch (cellExpected.getCellType()) {
					case Cell.CELL_TYPE_BLANK:
						isHeaderCompletes = true;
						break;
					case Cell.CELL_TYPE_NUMERIC:
						logger.info("Expected file Format is" + cellExpected.getCellStyle().getDataFormatString());
						expectedFileHeaders.add(cellExpected.getDateCellValue().toString());
						expectedFileHeaders1.add(cellExpected.getCellStyle().getDataFormatString());
						
						break;
					default:

						expectedFileHeaders.add(cellExpected.getStringCellValue());
						break;
					}

					cellExpected = (XSSFCell) cellIteratorExpected.next();
				}
			}

			wBookActual.close();
			wBookExpected.close();

			logger.info("expectedFileHeader::" + expectedFileHeaders);
			logger.info("actualFileHeaders::" + actualFileHeaders);
			logger.info("Expected Format is ::" +expectedFileHeaders1);
			logger.info("actual Format is::" + actualFileHeaders1);
			flag = actualFileHeaders.equals(expectedFileHeaders);
			flag = actualFileHeaders1.equals(expectedFileHeaders1);

		} catch (Exception ioe) {
			ioe.printStackTrace();
		}
		return flag;
	}
	
	public int getXLSXSheetRowCount(String actualFileLocation, int sheetIndex) throws IOException {

		File fielA = new File(actualFileLocation);
		FileInputStream actualFile = new FileInputStream(fielA);
		XSSFWorkbook workbook = new XSSFWorkbook(actualFile);
		XSSFSheet sheet = workbook.getSheetAt(sheetIndex);
		Row header = sheet.getRow(0);
		//return header.getLastCellNum();
		return workbook.getSheetAt(0).getLastRowNum();
	}
	
	
}


