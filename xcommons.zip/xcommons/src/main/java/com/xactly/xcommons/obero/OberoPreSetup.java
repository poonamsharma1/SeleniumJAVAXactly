package com.xactly.xcommons.obero;

import java.io.File;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.UnhandledAlertException;
import org.testng.annotations.*;
import com.xactly.xcommons.selenium.Constants;

import com.xactly.xcommons.app.LoginToApplication;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;


public class OberoPreSetup {

	private static String environment;
	private static String application;
	private static InputStream systemPropertyInputStream;
	private static Properties symProPath = new Properties();

	public static String getEnvironment() {
		return environment;
	}
	public static void setEnvironment(String env) {
		environment = env;
	}
	public static String getApplication() {
		return application;
	}
	public static void setApplication(String app) {
		  application = app;
	}
	
	public static InputStream getSystemPropertyInputStream() {
		return systemPropertyInputStream;
	}
	public static void setSystemPropertyInputStream(
			InputStream stemPropertyInputStream) {
            systemPropertyInputStream = stemPropertyInputStream;
	}

	public static Logger logger = Logger.getLogger(OberoPreSetup.class.getName());

	LoginToApplication login = new LoginToApplication();
    OberoLogin oberoLogin = new OberoLogin();

	@BeforeTest(alwaysRun = true)
	@Parameters({"environment","application","mode", "browser"})
	public void preSetUp(@Optional String environment,@Optional String application,@Optional String mode,
			@Optional String browser ) throws Exception
	{
		setEnvironment(environment);
		//SalesForce -- //For LiveId Login credentials  //For Google Login credentials
		setApplication(application);
		SetWebDrivers.setBrowser(browser);
		
		String propFile=environment+File.separator+environment+".properties";
		System.out.println(propFile);
		setSystemPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(propFile));
		symProPath.load(getSystemPropertyInputStream());
		LoginToApplication.setApplication(application);
		LoginToApplication.setUrl(symProPath.getProperty("url"));
		logger.info("URL : "+LoginToApplication.getUrl());
		SeleniumHelperClass.createDownloadDir();
		logger.info("Download Location : "+Constants.downloadLoc);
	}


	@BeforeTest(alwaysRun = true)
	@Parameters({"application","environment","mode","browser","username","password"})
	public void preSetUpTest(@Optional String appname, @Optional String envname, @Optional String mode,@Optional String _browser,@Optional String userName,@Optional String password) throws Exception
	{		

		if(mode.equalsIgnoreCase("gui"))
		{
			new SetWebDrivers();
			/**DeleteAllCookies*/
			SetWebDrivers.getDriver().manage().deleteAllCookies();	
			Thread.sleep(5000);
	        JavascriptExecutor js = (JavascriptExecutor)SetWebDrivers.getDriver();		
	        js.executeScript("history.go(0)");
	    	Thread.sleep(5000);
			oberoLogin.selectApplicationandLogin(appname,userName,password);

		}
	}


	@AfterTest(groups = {"Positive Login scenarios - Obero","Smoke Test - Obero","Positive Login LIVEID - Obero","Positive Login NETSUITE - Obero","Positive Login AZURE - Obero"})
	@Parameters({"application","environment","mode","browser"})
	public void terminateTest(@Optional String appname, @Optional String envname, @Optional String mode,@Optional String _browser) throws Exception 
	{
		if(mode.equalsIgnoreCase("gui")){

			if(getApplication().equalsIgnoreCase(application))
			{
				try {
					oberoLogin.logoutOfObero();
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);				
				}catch(UnhandledAlertException uae){					
					SetWebDrivers.getDriver().switchTo().alert().accept();
					oberoLogin.logoutOfObero();
				}catch (Exception e) {								
					e.printStackTrace();					
				}
				finally
				{
					SetWebDrivers.getDriver().quit();
				}
			}
		}
	}


	@AfterTest(groups ={"Negative scenarios - Obero","Negative scenarios NetSuite - Obero","Negative scenarios LiveID - Obero"})
	@Parameters({"application","environment","mode","browser"})
	public void terminateTestForNegativeTest(@Optional String appname, @Optional String envname, @Optional String mode,@Optional String _browser) throws Exception {
		SetWebDrivers.getDriver().quit();

	}


	@AfterSuite(alwaysRun = true)
	@Parameters({"mode"})
	public void terminateSuite(@Optional String mode) throws Exception
	{
		if(mode.equalsIgnoreCase("gui")){		

			if(SetWebDrivers.OSDetector().equalsIgnoreCase("Mac") && SetWebDrivers.getBrowser().equalsIgnoreCase("chrome"))
			{
				Runtime.getRuntime().exec("killall chromedriver_mac");
			}
			if(SetWebDrivers.OSDetector().equalsIgnoreCase("Mac") && SetWebDrivers.getBrowser().equalsIgnoreCase("firefox"))
			{
				Runtime.getRuntime().exec("killall geckodriver_mac");
			}
		}
	}

}
