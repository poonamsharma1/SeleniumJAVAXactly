package com.xactly.xcommons.obero;

import org.apache.log4j.Logger;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.xactly.xcommons.app.LoginToApplication;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;
import org.testng.annotations.Optional;

public class OberoLogin {

	public static Logger logger = Logger.getLogger(OberoLogin.class.getName());


	enum app{
		XACTLY,
		SALESFORCE,
		LIVEID,
		GOOGLE,
		AZURE,
		NETSUITE,
		LDAP
	}

	public WebElement selectApplication(String type) throws Exception
	{
		return (SeleniumHelperClass.findWebElementbyXpath("//a[contains(@href,'"+type+"') and @class='btn btn-primary btn-rounded margin-top-none btn-login']"));
	}

	public WebElement getLoginWithXactly() throws Exception{
		return  SeleniumHelperClass.findWebElementbyXpath("//a[contains(.,'Login with Xactly')]");
	}

	public WebElement getLoginWithSalesForce() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//a[contains(.,'Login with Salesforce')]");
	}

	public  WebElement getLoginWithLiveId() throws Exception{
		return  SeleniumHelperClass.findWebElementbyXpath("//a[contains(.,'Login with Live ID')]");
	}

	public WebElement getLoginWithGoogle() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//a[contains(.,'Login with Google')]");
	}

	public WebElement getLoginWithAzure() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//a[contains(.,'Login with AD')]");
	}

	public WebElement getLoginWithNetSuite() throws Exception{
		return  SeleniumHelperClass.findWebElementbyXpath("//a[contains(.,'Login with NetSuite')]");
	}


	public WebElement getLoginWithLDAP() throws Exception{
		return  SeleniumHelperClass.findWebElementbyXpath("//a[contains(.,'Login with LDAP')]");
	}

	public WebElement getUserNameForLiveId() throws Exception{
		return  SeleniumHelperClass.findWebElementbyXpath("//input[@name='loginfmt']");
	}

	public WebElement getPasswordForLiveId() throws Exception{
		return  SeleniumHelperClass.findWebElementbyXpath("//input[@name='passwd']");
	}

	public WebElement getUserNameForGoogle() throws Exception {
		return  SeleniumHelperClass.findWebElementbyXpath("//input[@type='email']");
	}

	public WebElement getPasswordForGoogle() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//div[@class='Xb9hP']/input[@name='password']");
	}

	public WebElement getUserNameforXactly() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@name='username']");
	}

	public WebElement getPasswordforXactly() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@name='password']");
	}

	public WebElement getNextButtonForGoogle() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//span[contains(.,'Next')]");
	}

	public WebElement getNextButtonForLiveId() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@type='submit']");
	}

	public WebElement getLoginButtonForXactly() throws  Exception {
		return  SeleniumHelperClass.findWebElementbyXpath("//button[@type='submit']");
	}

	public  WebElement getUsernameForSalesForce() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@id='username']");
	}

	public WebElement getPassWordForSalesForce() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//div[@id='theloginform']//input[@id='password']");
	}

	public WebElement getLoginButtonForSalesForce() throws  Exception {
		return  SeleniumHelperClass.findWebElementbyXpath("//div[@id='theloginform']//input[@id='Login']");
	}

	public WebElement getUserNameForNetSuite() throws  Exception {
		return  SeleniumHelperClass.findWebElementbyXpath("//input[@id='UserName']");
	}

	public WebElement getPasswordForNetSuite() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@id='Password']");
	}

	public WebElement getLoginButtonForNetSuite() throws  Exception {
		return  SeleniumHelperClass.findWebElementbyXpath("//input[@value='Sign In']");
	}

	public WebElement getUserNameForLDAP() throws Exception {
		return  SeleniumHelperClass.findWebElementbyXpath("//input[@name='UserName']");
	}

	public WebElement getPasswordForLDAP() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@name='Pasword']");
	}

	public WebElement getSignInButtonForLDAP() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@type='Submit']");
	}

	public WebElement getUserNameForAzure() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@type='email']");
	}

	public WebElement getNextButtonForAzure() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@value='Next']");
	}

	public  WebElement getPasswordForAzure() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//div[@class='placeholderContainer']//input[@name='passwd']");
	}




	public WebElement getDoNotShowAgain() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@name='DontShowAgain']");
	}

	public  WebElement getNoButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@value='No']");
	}

	public WebElement getSignInButtonForAzure() throws  Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//input[@value='Sign in']");
	}

	public WebElement getdropDownForLogout() throws Exception {
		return  SeleniumHelperClass.findWebElementbyXpath("//div[@class='top-menu']//ul//li[@class='dropdown dropdown-user dropdown-dark']/a");
	}

	public WebElement getLogout() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//ul[@class='dropdown-menu dropdown-menu-default']/li[contains(.,'Log Out')]"));


	}

	public void LoginToXObero(@Optional String environment, @Optional String userName, @Optional String password, @Optional String url, @Optional String browser) throws Exception {
		SetWebDrivers.setSavedriver(SetWebDrivers.getDriver());
		SetWebDrivers.getDriver().manage().deleteAllCookies();
		SetWebDrivers.getDriver().get(url );
		environment=environment.toLowerCase();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);


	}


	public  void selectApplicationandLogin(String application, String userName,String password)  throws Exception{
		logger.info("Log in to ... " + application);
		app applications = app.valueOf(application);

		switch(applications) {
			case XACTLY:
				getLoginWithXactly().click();
				getUserNameforXactly().sendKeys(userName);
				getPasswordforXactly().sendKeys(password);
				getLoginButtonForXactly().click();
				break;

			case LIVEID:
				getLoginWithLiveId().click();
				getUserNameForLiveId().sendKeys(userName);
				getNextButtonForLiveId().click();
				getPasswordForLiveId().sendKeys(password);
				getNextButtonForLiveId().click();
				break;

			case GOOGLE:
				getLoginWithGoogle().click();
				getUserNameForGoogle().sendKeys(userName);
				getNextButtonForGoogle().click();
				getPasswordForGoogle().sendKeys(password);
				getNextButtonForGoogle().click();
				break;

			case SALESFORCE:
				getLoginWithSalesForce().click();
				getUsernameForSalesForce().clear();
				getUsernameForSalesForce().sendKeys(userName);
				getPassWordForSalesForce().sendKeys(password);
				getLoginButtonForSalesForce().click();
				break;

			case LDAP:
				getLoginWithLDAP().click();
				getUserNameForLDAP().clear();
				getUserNameForLDAP().sendKeys(userName);
				getPasswordForLDAP().clear();
				getPasswordForLDAP().sendKeys(password);
				getSignInButtonForLDAP().click();
				break;


			case AZURE:
				getLoginWithAzure().click();
				getUserNameForAzure().clear();
				getUserNameForAzure().sendKeys(userName);
				getNextButtonForAzure().click();
				getPasswordForAzure().sendKeys(password);
				getSignInButtonForAzure().click();
				getDoNotShowAgain().click();
				getNoButton().click();
				break;

			case NETSUITE:
				getLoginWithNetSuite().click();
				getUserNameForNetSuite().clear();
				getUserNameForNetSuite().sendKeys(userName);
				getPasswordForNetSuite().sendKeys(password);
				getLoginButtonForNetSuite().click();
				break;
		}
	}

	public void logoutOfObero() throws Exception{
		getdropDownForLogout().click();
		getLogout().click();

	}
}

