package com.xactly.xcommons.app;

import java.io.File;
import java.io.InputStream;
import java.time.Duration;
import java.util.Arrays;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.Optional;
import org.testng.asserts.SoftAssert;

import com.xactly.xcommons.selenium.Constants;
import com.xactly.xcommons.javahelper.Time;
import com.xactly.xcommons.restapi.LoginToRestAPI;
import com.xactly.xcommons.restapi.PreSetupRestAPI;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;
import com.xactly.xcommons.simplycomp.SimplyCompPreSetup;

import io.netty.util.Constant;

import org.apache.log4j.Logger;

public class LoginToApplication {
	
	private static Logger logger = Logger.getLogger(LoginToApplication.class.getName());
	private static InputStream systemPropertyInputStream;
	private static InputStream systemUserPropertyInputStream;
	private static InputStream systemGuiUserPropertyInputStream;
	public static Properties symProPath = new Properties();
	public static Properties userProPath = new Properties();
	public static Properties guiuserProPath = new Properties();
	public static String url;
	public static String application;
	public static String environment;
	public static String username;
	public static String password;
	public static String sysusername;
	public static String oldusername;
	public static String oldpassword;	
	public static String reloadusername;
	public static String reloadpassword;
	public static String RestAssuredBaseURI;
	public static String RestAssuredBasePath;
	public static String ConnectBaseURI;
	public static String RestAssuredPort;
	public static String Modeling;
	public static String Analytics;
	public static String Insights;
	public static String Objectives;
	public static String Quota;
	public static String CreditAssignment;
	public static String Delta;
	public static String AdvanceSearch;	
	public static String grs;
	private static String SFDCurl;
	private static String SFDCusername;
	private static String SFDCpassword;
	private static String NAVIGATION_TYPE_VERTICAL="gui-new";
	private static String NAVIGATION_TYPE_HORIZONTAL="gui";
	
	
	boolean isDirectAnalytics=false;
	
	public static String useIAM;

	public static String getUseIAM() {
		return useIAM;
	}

	public static void setUseIAM(String useIAM) {
		LoginToApplication.useIAM = useIAM;
	}

	public static String getGrs() {
		return grs;
	}

	public static void setGrs(String grs) {
		LoginToApplication.grs = grs;
	}
	

	public static InputStream getsystemGuiUserPropertyInputStream() {
		return systemGuiUserPropertyInputStream;
	}

	public static void setsystemGuiUserPropertyInputStream(InputStream systemGuiUserPropertyInputStream) {
		LoginToApplication.systemGuiUserPropertyInputStream = systemGuiUserPropertyInputStream;
	}


	public static InputStream getSystemPropertyInputStream() {
		return systemPropertyInputStream;
	}

	public static void setSystemPropertyInputStream(InputStream systemPropertyInputStream) {
		LoginToApplication.systemPropertyInputStream = systemPropertyInputStream;
	}

	public static InputStream getSystemUserPropertyInputStream() {
		return systemUserPropertyInputStream;
	}

	public static void setSystemUserPropertyInputStream(InputStream systemUserPropertyInputStream) {
		LoginToApplication.systemUserPropertyInputStream = systemUserPropertyInputStream;
	}

	public static String getUrl() {
		return url;
	}

	public static void setUrl(String url) {
		if(LoginToApplication.getUseIAM().equalsIgnoreCase("yes")) {
			LoginToApplication.url = url;
		}else {
			LoginToApplication.url = url.concat("?useLegacy=1");
		}
	}
	


	public static String getApplication() {
		return application;
	}

	public static void setApplication(String application) {
		LoginToApplication.application = application;
	}	

	public static String getEnvironment() {
		return environment;
	}

	public static void setEnvironment(String environment) {
		LoginToApplication.environment = environment;
	}

	public static String getUsername() {
		return username;
	}

	public static void setUsername(String username) {
		LoginToApplication.username = username;
	}

	public static String getPassword() {
		return password;
	}

	public static void setPassword(String password) {
		LoginToApplication.password = password;
	}

	public static String getsysUsername() {
		return sysusername;
	}

	public static void setsysUsername(String username) {
		LoginToApplication.sysusername=username;
	}

	public static String getoldUsername() {
		return oldusername;
	}

	public static void setoldUsername(String username) {
		LoginToApplication.oldusername=username;
	}

	public static String getOldPassword() {
		return oldpassword;
	}

	public static void setOldPassword(String oldPassword) {
		LoginToApplication.oldpassword = oldPassword;
	}

	public static String getReloadusername() {
		return reloadusername;
	}

	public static void setReloadusername(String reloadusername) {
		LoginToApplication.reloadusername = reloadusername;
	}

	public static String getReloadpassword() {
		return reloadpassword;
	}

	public static void setReloadpassword(String reloadpassword) {
		LoginToApplication.reloadpassword = reloadpassword;
	}

	public static String getRestAssuredBaseURI() {
		return RestAssuredBaseURI;
	}

	public static void setRestAssuredBaseURI(String restAssuredBaseURI) {
		RestAssuredBaseURI = restAssuredBaseURI;
	}

	public static String getRestAssuredBasePath() {
		return RestAssuredBasePath;
	}

	public static void setRestAssuredBasePath(String restAssuredBasePath) {
		RestAssuredBasePath = restAssuredBasePath;
	}

	public static String getConnectBaseURI() {
		return ConnectBaseURI;
	}

	public static void setConnectBaseURI(String connectBaseURI) {
		ConnectBaseURI = connectBaseURI;
	}

	public static String getRestAssuredPort() {
		return RestAssuredPort;
	}

	public static void setRestAssuredPort(String restAssuredPort) {
		RestAssuredPort = restAssuredPort;
	}

	public boolean getIsDirectAnalytics(){
		if(this.isDirectAnalytics)
			return true;
		else 
			return false;
	}

	public void setIsDirectAnalytics(boolean var){
		this.isDirectAnalytics=var;
	}


	public String getModelingProperty()  {		
		return (LoginToApplication.symProPath.getProperty("module"+".modeling"));
	}

	public String getAnalyticsProperty()  {		
		return (LoginToApplication.symProPath.getProperty("module"+".analytics"));
	}

	public String getInsightProperty()  {	
		return (LoginToApplication.symProPath.getProperty("module"+".Insights"));
	}

	public String getObjectiveProperty()  {	
		return (LoginToApplication.symProPath.getProperty("module"+".objectives"));
	}

	public String getQuotaProperty()  {
		return (LoginToApplication.symProPath.getProperty("module"+".Quota"));
	}	

	public String getcreditAssignmentProperty()  {	
		return (LoginToApplication.symProPath.getProperty("module"+".creditassignment"));
	}

	public String getTargetModuleProperty() {
		return (LoginToApplication.symProPath.getProperty("targetModule"));
	}

	public String getEntitiesToBeSelectedProperty() {
		return (LoginToApplication.symProPath.getProperty("entitiestoberead"));
	}


	public WebElement get_ousername() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("user","none"));
	}

	public WebElement get_userName_Label() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[contains(@name,'usernameLabel')]"));
		
	}
	
	public WebElement get_sc_username() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("userNameInput","none"));
	}
	public WebElement get_sc_username_submit() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("userNameSubmit","none"));
	}
	public WebElement get_sc_password() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("passwordInput","none"));
	}
	public WebElement get_sc_password_submit() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("submitPasswordButton","none"));
	}
	
	public WebElement get_sc_header() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("account-header","none"));
	}
	
	public WebElement get_opassword() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("pass","none"));
	}
	
	public WebElement get_Oktapassword() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("okta-signin-password","none"));
	}
	
	public WebElement get_sc_opassword() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("pass","none"));
	}

	public WebElement get_ologin() throws Exception {
		SeleniumHelperClass.waitForElementVisibility("id", "loginButton", "none", 30);
		return (SeleniumHelperClass.findWebElementbyid("loginButton","none"));
	}

	public WebElement get_ousername_analytics() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("login","none"));
	}

	public WebElement get_opassword_analytics() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("password","none"));
	}

	public WebElement get_ologin_analytics() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("loginBtn","none"));
	}

	public WebElement getDropdown() throws Exception{
		return (SeleniumHelperClass.findWebElementbyid("one","topFrame"));
	}

	public WebElement getPreferenceTab() throws Exception{
		return (SeleniumHelperClass.findWebElementbyid("TAB_MIDDLE_SECURITY_TAB","topFrame"));
		//return (SeleniumHelperClass.findWebElementbyclass("k-input"));
	}

	public WebElement getModule(String module) throws Exception{
		return (SeleniumHelperClass.findWebElementbyid(module,"appframe"));
	}

	
	
	public WebElement get_ousernameAS() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("username","none"));
	}

	public WebElement get_opasswordAS() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("password","none"));
	}

	public WebElement get_ologin_ASsubmit() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("Login","none"));
	}
	public WebElement get_ousernameSAML() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("userName","none"));
	}


	public WebElement get_osharedKeySAML() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("sharedKey","none"));
	}

	public WebElement get_ologin_SAMLsubmit() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//input[@value='Login']","none"));
	}

	public WebElement get_userName_Label_OCIQaintx() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*/label[text()='User Name']"));
		
	}

	public WebElement get_userName() throws Exception {	
		return (SeleniumHelperClass.findWebElementbyid("email","none"));
	}
	
	public WebElement get_Okta_userName() throws Exception {	
		return (SeleniumHelperClass.findWebElementbyid("okta-signin-username","none"));
	}

	public WebElement get_password() throws Exception {	
		return (SeleniumHelperClass.findWebElementbyid("password","none"));
	}

	public WebElement get_userNameNext() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("submitEmail","none"));
	}
	
	public WebElement get_Okta_userNameNext() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("okta-signin-submit","none"));
	}


	public WebElement get_passwordNext() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("submitPassword","none"));
	}
	
	public Select get_SelectEnvironment() throws Exception{
		return SeleniumHelperClass.selectFromDropdownwithelements("id", "enviromentsDropDown", "none");
	}

	public boolean isToggleLeftNavButtonExists() {
		try {
			SeleniumHelperClass.findWebElementbyXpath("//*[@onClick='switch2LeftNav()']","topFrame",60);
			return true;
		}catch (Exception e) {
			return false;
		}
	}

	public boolean isWelcomeNoteExists() {
		try {
			SeleniumHelperClass.findWebElementbyid("welcomelnk","topFrame",60);
			return true;
		}catch (Exception e) {
			return false;
		}
	}
	
	public boolean isNewNavigation() {
		try {
			SeleniumHelperClass.findWebElement(Constants.LOCATOR_ID,"HOME_NAV","topFrame",15);
			return true;
		}catch (Exception e) {
			return false;
		}
	}
	

	public WebElement getToggleLeftNavButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@onClick='switch2LeftNav()']","topFrame");
	}

	public WebElement getProfileIconImage() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("profile_pic_outer","headerFrame");
	}

	public WebElement getToggleNewNavigationSwitch() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='switch2TopNav']//label//span","profileframe");
	}

	public WebElement getToggleOldNavigationSwitch() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='switch2leftNav']//label//span","profileframe");
	}

	
	public static String getSFDCurl() {
		return SFDCurl;
	}

	public static void setSFDCurl(String sFDCurl) {
		SFDCurl = sFDCurl;

	}

	public static String getSFDCusername() {

		return SFDCusername;
	}

	public static void setSFDCusername(String sFDCusername) {
		SFDCusername = sFDCusername;
	}

	public static String getSFDCpassword() {
		return SFDCpassword;

	}

	public static void setSFDCpassword(String sFDCpassword) {

		SFDCpassword = sFDCpassword;

	}

	public WebElement get_ologin_SFDCsubmit() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("Login","none"));
	}
	
	public WebElement get_ousernameSFDC() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("username","none"));
	}

	public WebElement get_opasswordSFDC() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("password","none"));
	}

	public  void loginToSFDC( String userName,String password) throws Exception{	

		new SetWebDrivers();
		
		
		setSFDCurl(LoginToApplication.symProPath.getProperty("SFDCURI"));	
		setSFDCusername(userName);
		setSFDCpassword(password);
		
		System.out.println("SFDCURI: "+LoginToApplication.symProPath.getProperty("SFDCURI"));
		System.out.println("Environment : "+environment+"  sfdc.username : "+getSFDCusername()
		+"  Password : "+getSFDCpassword());	
		/**DeleteAllCookies*/
		SetWebDrivers.getDriver().manage().deleteAllCookies();
		SetWebDrivers.getDriver().get(getSFDCurl());	
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX );
		get_ousernameSFDC().sendKeys(LoginToApplication.getSFDCusername());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/2);
		get_opasswordSFDC().sendKeys(LoginToApplication.getSFDCpassword());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/2);
		get_ologin_SFDCsubmit().sendKeys(Keys.ENTER);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX *2);
	}


	public  void reloadloginToIncent(@Optional String environment,String variable) throws Exception	
	{	
		//Saving the state of the browser
		SetWebDrivers.setSavedriver(SetWebDrivers.getDriver());
		environment=environment.toLowerCase();		

		String propFile="environment"+File.separator+environment+File.separator+environment+".properties";
		String userpropFile="environment"+File.separator+environment+File.separator+environment+"_users.properties";
		setSystemPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(propFile));
		setSystemUserPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(userpropFile));

		symProPath.load(LoginToApplication.getSystemPropertyInputStream());
		userProPath.load(LoginToApplication.getSystemUserPropertyInputStream());

		//setUrl(LoginToApplication.symProPath.getProperty("url"));
		String userdetails = LoginToApplication.userProPath.getProperty(variable);
		String[] user = userdetails.split(":");

		setReloadusername(user[0]);
		setReloadpassword(user[1]);					

		logger.info("Url : "+getUrl()+"\nUsername : "+getReloadusername()+"\nPassword : "+getReloadpassword());
		SetWebDrivers.getDriver().switchTo().defaultContent();
		SetWebDrivers.getDriver().get(LoginToApplication.getUrl());
		
		if(getGrs().equalsIgnoreCase("OFF")) {
			if(getUseIAM().equalsIgnoreCase("yes")) {
				loginWithoutGRSIAM(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword() );
			}
			else {
				loginWithoutGRS(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword() );
			}
		}else {
			if(getUseIAM().equalsIgnoreCase("yes")) {
				loginWithGRSIAM(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword());
			}
			else {
				loginWithGRS(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword());
			}
		}
		
		
		Thread.sleep(1000);
		SeleniumHelperClass.waitforPageToLoad("id", "ddimagetabs", "topFrame");
		Thread.sleep(2000);
		//switchToNavigation(SetWebDrivers.getNavigationType());
	}
	
	public  void reloadloginToIncentIAM(@Optional String environment,String variable) throws Exception	
	{	
		//Saving the state of the browser
		SetWebDrivers.setSavedriver(SetWebDrivers.getDriver());
		environment=environment.toLowerCase();		

		String propFile="environment"+File.separator+environment+File.separator+environment+".properties";
		String userpropFile="environment"+File.separator+environment+File.separator+environment+"_users.properties";
		setSystemPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(propFile));
		setSystemUserPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(userpropFile));

		symProPath.load(LoginToApplication.getSystemPropertyInputStream());
		userProPath.load(LoginToApplication.getSystemUserPropertyInputStream());

		String userdetails = LoginToApplication.userProPath.getProperty(variable);
		String[] user = userdetails.split(":");

		setReloadusername(user[0]);
		setReloadpassword(user[1]);					

		logger.info("Url : "+getUrl()+"\nUsername : "+getReloadusername()+"\nPassword : "+getReloadpassword());
		SetWebDrivers.getDriver().switchTo().defaultContent();
		SetWebDrivers.getDriver().get(LoginToApplication.getUrl());		

		if(getGrs().equalsIgnoreCase("OFF")) {
			loginWithoutGRSIAM(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword() );
		}else {
			loginWithGRSIAM(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword());
		}
		Thread.sleep(1000);
		SeleniumHelperClass.waitforPageToLoad("id", "ddimagetabs", "topFrame");
		Thread.sleep(2000);
	}


	public  void reloadLoginToSAML(@Optional String environment,String variable) throws Exception{

		//Saving the state of the browser
		SetWebDrivers.setSavedriver(SetWebDrivers.getDriver());
		environment=environment.toLowerCase();

		String propFile="environment"+File.separator+environment+File.separator+environment+".properties";
		String userpropFile="environment"+File.separator+environment+File.separator+environment+"_users.properties";
		setSystemPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(propFile));
		setSystemUserPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(userpropFile));

		symProPath.load(LoginToApplication.getSystemPropertyInputStream());
		userProPath.load(LoginToApplication.getSystemUserPropertyInputStream());

		String userdetails = LoginToApplication.userProPath.getProperty(variable);
		String[] user = userdetails.split(":");

		setReloadusername(user[0]);
		setReloadpassword(user[1]);

		Reporter.log("Url : "+getUrl()+"\nUsername : "+getReloadusername()+"\nPassword : "+getReloadpassword(), 2, true);
		SetWebDrivers.getDriver().get(LoginToApplication.getUrl());

		if(getGrs().equalsIgnoreCase("OFF")) {
			loginWithoutGRS(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword() );
		}else {
			//samlLoginWithGRS(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword());
			loginWithGRS(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword());
		}

		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);

	}
	
	public  void reloadLoginToSAMLIAM(@Optional String environment,String variable) throws Exception{

		//Saving the state of the browser
		SetWebDrivers.setSavedriver(SetWebDrivers.getDriver());
		environment=environment.toLowerCase();

		String propFile="environment"+File.separator+environment+File.separator+environment+".properties";
		String userpropFile="environment"+File.separator+environment+File.separator+environment+"_users.properties";
		setSystemPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(propFile));
		setSystemUserPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(userpropFile));

		symProPath.load(LoginToApplication.getSystemPropertyInputStream());
		userProPath.load(LoginToApplication.getSystemUserPropertyInputStream());

		String userdetails = LoginToApplication.userProPath.getProperty(variable);
		String[] user = userdetails.split(":");

		setReloadusername(user[0]);
		setReloadpassword(user[1]);

		Reporter.log("Url : "+getUrl()+"\nUsername : "+getReloadusername()+"\nPassword : "+getReloadpassword(), 2, true);
		SetWebDrivers.getDriver().get(LoginToApplication.getUrl());

		if(getGrs().equalsIgnoreCase("OFF")) {
			loginWithoutGRSIAM(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword() );
		}else {
			loginWithGRSIAM(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword());
		}

		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);

	}


	public  void reloadloginToAllignstar(@Optional String environment,String variable) throws Exception	
	{	
		//Saving the state of the browser
		SetWebDrivers.setSavedriver(SetWebDrivers.getDriver());
		environment=environment.toLowerCase();		

		String propFile="environment"+File.separator+environment+File.separator+environment+".properties";
		String userpropFile="environment"+File.separator+environment+File.separator+environment+"_users.properties";
		setSystemPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(propFile));
		setSystemUserPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(userpropFile));

		symProPath.load(LoginToApplication.getSystemPropertyInputStream());
		userProPath.load(LoginToApplication.getSystemUserPropertyInputStream());

		//setUrl(LoginToApplication.symProPath.getProperty("url"));
		String userdetails = LoginToApplication.userProPath.getProperty(variable);
		String[] user = userdetails.split(":");

		setReloadusername(user[0]);
		setReloadpassword(user[1]);					

		logger.info("Url : "+getUrl()+"\nUsername : "+getReloadusername()+"\nPassword : "+getReloadpassword());
		SetWebDrivers.getDriver().switchTo().defaultContent();
		SetWebDrivers.getDriver().get(LoginToApplication.getUrl());		

		if(getGrs().equalsIgnoreCase("OFF")) {
			loginWithoutGRSAllignstar(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword() );
		}else {
			loginWithGRS(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword());
		}
		Thread.sleep(1000);
		SeleniumHelperClass.isElementPresent("id", "loginForm");
		Thread.sleep(2000);
	}

	public  void reloadloginToIncent(@Optional String environment,String user, String password) throws Exception	
	{	
		//Saving the state of the browser
		SetWebDrivers.setSavedriver(SetWebDrivers.getDriver());
		environment=environment.toLowerCase();		

		String propFile="environment"+File.separator+environment+File.separator+environment+".properties";
		String userpropFile="environment"+File.separator+environment+File.separator+environment+"_users.properties";
		setSystemPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(propFile));
		setSystemUserPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(userpropFile));

		symProPath.load(LoginToApplication.getSystemPropertyInputStream());
		userProPath.load(LoginToApplication.getSystemUserPropertyInputStream());	

		setReloadpassword(password);			

		logger.info("Url : "+getUrl()+"\nUsername : "+getReloadusername()+"\nPassword : "+getReloadpassword());
		SetWebDrivers.getDriver().switchTo().defaultContent();
		SetWebDrivers.getDriver().get(LoginToApplication.getUrl());
		Thread.sleep(1000);		

		if(getGrs().equalsIgnoreCase("OFF")) {
			if(getUseIAM().equalsIgnoreCase("yes")) {
				loginWithoutGRSIAM(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword() );
			}
			else {
				loginWithoutGRS(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword() );
			}
		}else {
			if(getUseIAM().equalsIgnoreCase("yes")) {
				loginWithGRSIAM(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword());
			}
			else {
				loginWithGRS(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword());
			}
		}

		Thread.sleep(1000);
		SeleniumHelperClass.waitforPageToLoad("id", "ddimagetabs", "topFrame");
		Thread.sleep(2000);

	}
	
	public  void reloadloginToIncentIAM(@Optional String environment,String user, String password) throws Exception	
	{	
		//Saving the state of the browser
		SetWebDrivers.setSavedriver(SetWebDrivers.getDriver());
		environment=environment.toLowerCase();		

		String propFile="environment"+File.separator+environment+File.separator+environment+".properties";
		String userpropFile="environment"+File.separator+environment+File.separator+environment+"_users.properties";
		setSystemPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(propFile));
		setSystemUserPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(userpropFile));

		symProPath.load(LoginToApplication.getSystemPropertyInputStream());
		userProPath.load(LoginToApplication.getSystemUserPropertyInputStream());	

		setReloadpassword(password);			

		logger.info("Url : "+getUrl()+"\nUsername : "+getReloadusername()+"\nPassword : "+getReloadpassword());
		SetWebDrivers.getDriver().switchTo().defaultContent();
		SetWebDrivers.getDriver().get(LoginToApplication.getUrl());
		Thread.sleep(1000);		

		if(getGrs().equalsIgnoreCase("OFF")) {
			loginWithoutGRSIAM(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword() );
		}else {
			loginWithGRSIAM(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword());
		}

		Thread.sleep(1000);
		SeleniumHelperClass.waitforPageToLoad("id", "ddimagetabs", "topFrame");
		Thread.sleep(2000);

	}


	public  void reloadloginToIncentEdocs(@Optional String environment,String variable) throws Exception	
	{	
		//Saving the state of the browser
		SetWebDrivers.setSavedriver(SetWebDrivers.getDriver());
		environment=environment.toLowerCase();
		
		String userpropFile="environment"+File.separator+environment+File.separator+environment+"_users.properties";		
		setSystemUserPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(userpropFile));

		userProPath.load(LoginToApplication.getSystemUserPropertyInputStream());
		String userdetails = LoginToApplication.userProPath.getProperty(variable);
		String[] user = userdetails.split(":");

		setReloadusername(user[0]);
		setReloadpassword(user[1]);	

		Boolean first= false ;
		int loginCounter = 0;

		do{
			loginCounter ++;			
			SetWebDrivers.getDriver().manage().deleteAllCookies();
			logger.info("Url : "+getUrl()+"\nUsername : "+getReloadusername()+"\nPassword : "+getReloadpassword());
			SetWebDrivers.getDriver().switchTo().defaultContent();
			SetWebDrivers.getDriver().get(LoginToApplication.getUrl());
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);

			if(getGrs().equalsIgnoreCase("OFF")) {
				loginWithoutGRS(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword() );
			}else {
				loginWithGRS(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword());
			}

			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);		

			first =SeleniumHelperClass.isElementPresent("id", "xactlyImage", "headerFrame", 5);

		}while(!first && loginCounter < 3);

		SeleniumHelperClass.waitforPageToLoad("id", "ddimagetabs", "topFrame");		
	}
	
	public  void reloadloginToIncentEdocsIAM(@Optional String environment,String variable) throws Exception	
	{	
		//Saving the state of the browser
		SetWebDrivers.setSavedriver(SetWebDrivers.getDriver());
		environment=environment.toLowerCase();
		
		String userpropFile="environment"+File.separator+environment+File.separator+environment+"_users.properties";		
		setSystemUserPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(userpropFile));

		userProPath.load(LoginToApplication.getSystemUserPropertyInputStream());
		String userdetails = LoginToApplication.userProPath.getProperty(variable);
		String[] user = userdetails.split(":");

		setReloadusername(user[0]);
		setReloadpassword(user[1]);	

		Boolean first= false ;
		int loginCounter = 0;

		do{
			loginCounter ++;			
			SetWebDrivers.getDriver().manage().deleteAllCookies();
			logger.info("Url : "+getUrl()+"\nUsername : "+getReloadusername()+"\nPassword : "+getReloadpassword());
			SetWebDrivers.getDriver().switchTo().defaultContent();
			SetWebDrivers.getDriver().get(LoginToApplication.getUrl());
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);

			if(getGrs().equalsIgnoreCase("OFF")) {
				loginWithoutGRSIAM(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword() );
			}else {
				loginWithGRSIAM(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword());
			}

			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);		

			first =SeleniumHelperClass.isElementPresent("id", "xactlyImage", "topFrame", 5);

		}while(!first && loginCounter < 3);

		SeleniumHelperClass.waitforPageToLoad("id", "ddimagetabs", "topFrame");		
	}


	public void setProperties(String environment,String application) throws Exception{
		environment=environment.toLowerCase();
		application=application.toLowerCase();

		String propFile="environment"+File.separator+environment+File.separator+environment+".properties";		
		String userpropFile="environment"+File.separator+environment+File.separator+environment+"_api_users.properties";
		String guiUserpropFile="environment"+File.separator+environment+File.separator+environment+"_users.properties";

		try{
			setSystemPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(propFile));
			setSystemUserPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(userpropFile));
			setsystemGuiUserPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(guiUserpropFile));
			symProPath.load(LoginToApplication.getSystemPropertyInputStream());
			userProPath.load(LoginToApplication.getSystemUserPropertyInputStream());
			guiuserProPath.load(LoginToApplication.getsystemGuiUserPropertyInputStream());
			setRestAssuredBaseURI(LoginToApplication.symProPath.getProperty("RestAssured.baseURI"));
			setRestAssuredPort(LoginToApplication.symProPath.getProperty("RestAssured.port"));
			setRestAssuredBasePath(LoginToApplication.symProPath.getProperty("RestAssured.basePath"));
			if (LoginToApplication.getGrs().equalsIgnoreCase("OFF")) {
				setUrl(LoginToApplication.symProPath.getProperty("url"));
			}else {
				setUrl(LoginToApplication.symProPath.getProperty("grsUrl"));
			}	
			System.out.println("xxx"+getUrl());
			setUsername(LoginToApplication.symProPath.getProperty(application+".username"));
			setPassword(LoginToApplication.symProPath.getProperty(application+".password"));
			LoginToRestAPI.setVusidtemplate(LoginToApplication.symProPath.getProperty("vusid"));
			setConnectBaseURI(LoginToApplication.symProPath.getProperty("connect.baseURI"));
			//logger.info("Vusid:" +LoginToRestAPI.getVusidtemplate());
			LoginToRestAPI.setEnvironmenttype(LoginToApplication.symProPath.getProperty("environment"));
			//logger.info("environment "+LoginToRestAPI.getEnvironmenttype());
			LoginToRestAPI.setUsername(LoginToApplication.symProPath.getProperty(application+".username"));
			LoginToRestAPI.setPassword(LoginToApplication.symProPath.getProperty(application+".password"));
			setEnvironment(environment);
			setApplication(application);

		}catch(Exception e)
		{
			logger.info("Unable to load properties file:"+propFile+e);
			throw new Exception(e.toString());
		}

		setApplication(application);
		setEnvironment(environment);
		//setUrl(LoginToApplication.symProPath.getProperty("url"));
		setUsername(LoginToApplication.symProPath.getProperty(application+".username"));
		setPassword(LoginToApplication.symProPath.getProperty(application+".password"));		
		setsysUsername(LoginToApplication.symProPath.getProperty("sys"+".username"));	
	}


	public  void loginToIncent() throws Exception{	

		new SetWebDrivers();
		logger.info("Url:"+getUrl()+"\nUsername:"+getUsername()+"\nPassword:"+getPassword());
		if(SetWebDrivers.getBrowser().equalsIgnoreCase("IE"))
		{
			SetWebDrivers.getDriver().get("javascript:document.getElementById('overridelink').click();");
		}

		if(getGrs().equalsIgnoreCase("OFF")) {
			if(getUseIAM().equalsIgnoreCase("yes")) {
				loginWithoutGRSIAM(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword() );
			}
			else {
				loginWithoutGRS(LoginToApplication.getUsername(), LoginToApplication.getPassword());
			}
		}else {
			if(getUseIAM().equalsIgnoreCase("yes")) {
				loginWithGRSIAM(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword());
			}
			else {
				loginWithGRS(LoginToApplication.getUsername(), LoginToApplication.getPassword());
			}
		}

		if(SetWebDrivers.getBrowser().equalsIgnoreCase("IE"))
		{
			SetWebDrivers.getDriver().get("javascript:document.getElementById('overridelink').click();");
		}
		SetWebDrivers.getDriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		SeleniumHelperClass.waitforPageToLoad("id", "ddimagetabs", "topFrame");
		Thread.sleep(2000);
		//switchToNavigation(SetWebDrivers.getNavigationType());
	}
	
	public  void loginToIncentWithIAM() throws Exception{	

		new SetWebDrivers();
		logger.info("Url:"+getUrl()+"\nUsername:"+getUsername()+"\nPassword:"+getPassword());
		if(SetWebDrivers.getBrowser().equalsIgnoreCase("IE"))
		{
			SetWebDrivers.getDriver().get("javascript:document.getElementById('overridelink').click();");
		}

		if(getGrs().equalsIgnoreCase("OFF")) {
			loginWithoutGRSIAM(LoginToApplication.getUsername(), LoginToApplication.getPassword() );
		}else {
			loginWithGRSIAM(LoginToApplication.getUsername(), LoginToApplication.getPassword());
		}

		if(SetWebDrivers.getBrowser().equalsIgnoreCase("IE"))
		{
			SetWebDrivers.getDriver().get("javascript:document.getElementById('overridelink').click();");
		}
		SetWebDrivers.getDriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		SeleniumHelperClass.waitforPageToLoad("id", "ddimagetabs", "topFrame");
		Thread.sleep(2000);
	}
	

	public  void loginToSimplyComp() throws Exception{	
		SimplyCompPreSetup sc = new SimplyCompPreSetup();
		SoftAssert m_assert = new SoftAssert();
		get_sc_username().sendKeys(SimplyCompPreSetup.getUserid());
		get_sc_username_submit().click();
		
		get_sc_password().sendKeys(SimplyCompPreSetup.getPassword());
		get_sc_password_submit().click();
		m_assert.assertEquals(get_sc_header().isDisplayed(), true,"Unable to login to SimplyComp");
		m_assert.assertAll();
		
		
	}
	
	public void loginToIncent(String propertypath) throws Exception {
		String userdetails = PreSetupRestAPI.userProPath.getProperty(propertypath);
		SetWebDrivers.setSavedriver(SetWebDrivers.getDriver());
		String[] user = userdetails.split(":");
		String userName = user[0];
		String password = user[1];

		SetWebDrivers.getDriver().manage().deleteAllCookies();

		SetWebDrivers.getDriver().get(LoginToApplication.getUrl() );

		if(SetWebDrivers.getBrowser().equalsIgnoreCase("IE"))
		{
			SetWebDrivers.getDriver().get("javascript:document.getElementById('overridelink').click();");
		}
		
		
		if(getGrs().equalsIgnoreCase("OFF")) {
			if(getUseIAM().equalsIgnoreCase("yes")) {
				loginWithoutGRSIAM(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword() );
			}
			else {
				loginWithoutGRS(LoginToApplication.getUsername(), LoginToApplication.getPassword());
			}
		}else {
			if(getUseIAM().equalsIgnoreCase("yes")) {
				loginWithGRSIAM(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword());
			}
			else {
				loginWithGRS(LoginToApplication.getUsername(), LoginToApplication.getPassword());
			}
		}

		if(SetWebDrivers.getBrowser().equalsIgnoreCase("IE"))
		{
			SetWebDrivers.getDriver().get("javascript:document.getElementById('overridelink').click();");
		}
		SetWebDrivers.getDriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	}
	
	public void loginToIncentWithIAM(String propertypath) throws Exception {
		String userdetails = PreSetupRestAPI.userProPath.getProperty(propertypath);
		SetWebDrivers.setSavedriver(SetWebDrivers.getDriver());
		String[] user = userdetails.split(":");
		String userName = user[0];
		String password = user[1];

		SetWebDrivers.getDriver().manage().deleteAllCookies();

		SetWebDrivers.getDriver().get(LoginToApplication.getUrl() );

		if(SetWebDrivers.getBrowser().equalsIgnoreCase("IE"))
		{
			SetWebDrivers.getDriver().get("javascript:document.getElementById('overridelink').click();");
		}
		if(getGrs().equalsIgnoreCase("OFF")) {
			loginWithoutGRSIAM(LoginToApplication.getUsername(), LoginToApplication.getPassword() );
		}else {
			loginWithGRSIAM(LoginToApplication.getUsername(), LoginToApplication.getPassword());
		}

		if(SetWebDrivers.getBrowser().equalsIgnoreCase("IE"))
		{
			SetWebDrivers.getDriver().get("javascript:document.getElementById('overridelink').click();");
		}
		SetWebDrivers.getDriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	}

	public  void loginVal(String uname,String password) throws Exception{		
		get_ousername().sendKeys(uname);
		get_opassword().sendKeys(password);
		get_ologin().submit();		
	}



	public  void switchToModule(String module) throws Exception{
		
		  if(SetWebDrivers.getNavigationType().equalsIgnoreCase("gui")){
			  int count=0;
			  boolean flag=true;
				while (!getPreferenceTab().getText().contains("Preferences")){
					Thread.sleep(100);
					if (count == 1000){
						break;
					}
					count++;
				}
				SeleniumHelperClass.switchingWaitforPageToLoad("id","TAB_MIDDLE_SECURITY_TAB","topFrame");
				//getPreferenceTab().click();
				Thread.sleep(10000);
				getDropdown().click();
				String id=getModuleId(module);
				Thread.sleep(3000);
				getModule(id).click();
				Thread.sleep(1000);
		   		SeleniumHelperClass.AcceptAlerts("You need Adobe Flash Player 8 (or above) to view the charts. It is a free and lightweight installation from Adobe.com. Please click on Ok to install the same.");   	  
			  
		  }
		
		  else {
			  String id = getModuleId(module);
		  logger.info("SetWebDrivers.getNavigationType() = " + SetWebDrivers.getNavigationType());
   		  logger.info("On new Incent UI");
   		  Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
   		  getAppsMenu().click();
   		  //Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
   		  //getModuleNewIncentUI(module).click();
   		 // getModuleNewIncentUI(getModuleId(module)).click();
   		  getModuleNewIncentUI(id).click();
   		  Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);}
   	  
	}
	
	public WebElement getAppsMenu() throws Exception {
  		return SeleniumHelperClass.findWebElementbyXpath("//div[@id='apps']", "headerFrame");
  	}
	
	public WebElement getModuleNewIncentUI(String module) throws Exception{
  		return SeleniumHelperClass.findWebElementbyid(module, "appIconsframe");
  	}
	

	public String getModuleId(String module){
		String id=null;
		module=module.toLowerCase();
		if(module.equals("analytics10g"))
			id="Analytics";
		else if(module.equals("analyticsbeta"))
			id="Analytics11g";
		else if(module.equals("quota"))
			id="Quota";
		else if(module.equals("analytics"))
			/*id="AnalyticsR9";*/
			id="Analytics12c";
		else if(module.equals("objectives"))
			id="Objectives";
		else if(module.equals("tmca"))
			id="CreditAssignment";
		else if(module.equals("insights"))
			id="Insights";
		else if(module.equals("modeling"))
			id="Modeling";
		else if(module.equals("incent"))
			id="Incent";
		else
			id=module;
		logger.info("id for the module "+module+" is "+id);

		return id;
	}


	

	private void loginWithGRSIAM(String uName, String pwd) throws Exception {
		SeleniumHelperClass.clearElement(get_Okta_userName());
		get_Okta_userName().sendKeys(uName);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/2);
		get_Okta_userNameNext().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/2);
		SeleniumHelperClass.clearElement(get_Oktapassword());

		get_Oktapassword().sendKeys(pwd);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/2);
		get_Okta_userNameNext().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}
	
	private void loginWithGRS(String uName, String pwd) throws Exception {
		//get_userName().clear();
		SeleniumHelperClass.clearElement(get_userName());
		get_userName().sendKeys(uName);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/2);
		get_userNameNext().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/2);
		//get_password().clear();
		SeleniumHelperClass.clearElement(get_password());

		get_password().sendKeys(pwd);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/2);
		get_passwordNext().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}
	
	private void loginWithGRSMultiSBEnvs(String uName, String pwd,String envVariable) throws Exception {
		SeleniumHelperClass.clearElement(get_userName());
		get_userName().sendKeys(uName);
		get_userNameNext().click();
		get_SelectEnvironment().selectByVisibleText(envVariable);
		get_userNameNext().click();
		SeleniumHelperClass.clearElement(get_password());
		get_password().sendKeys(pwd);
		get_passwordNext().click();
	}

	public String getCurrentNavigationType()
	{
		logger.info("checking the current navigation type..");
		String navigationType = "";
		if(isNewNavigation() == true)
		{
			navigationType =  NAVIGATION_TYPE_VERTICAL;
		}
		else
		{
			navigationType = NAVIGATION_TYPE_HORIZONTAL;
		}
		logger.info("current navigation is..."+navigationType);
		return navigationType;
	}


	@Deprecated
	public void switchToNavigation(String navigationType) throws Exception
	{
		
		/*logger.info("switching to navigation..."+navigationType);
		if(navigationType.equalsIgnoreCase(NAVIGATION_TYPE_HORIZONTAL))
		{
			if(!getCurrentNavigationType().equalsIgnoreCase(NAVIGATION_TYPE_HORIZONTAL))
			{
				getProfileIconImage().click();
				getToggleNewNavigationSwitch().click();
				SeleniumHelperClass.waitforPageToLoad("id", "ddimagetabs", "topFrame");
			}
		}*/
		try 
		{
			if(navigationType.equalsIgnoreCase(NAVIGATION_TYPE_VERTICAL))
			{
				if(!getCurrentNavigationType().equalsIgnoreCase(NAVIGATION_TYPE_VERTICAL))
				{
					userInfoOldUI().click();
					getToggleOldNavigationSwitch().click();
					SeleniumHelperClass.waitforPageToLoad("id", "ddimagetabs", "topFrame");
				}
			}
		}catch(Exception e) 
		{
			//Need to remove this try/catch after code merge on removal old nav
		}
		logger.info("switched to navigation..."+navigationType);
	}

	private void loginWithoutGRSIAM(String uName, String pwd) throws Exception {
		SeleniumHelperClass.clearElement(get_Okta_userName());
		get_Okta_userName().sendKeys(uName);
		get_Okta_userNameNext().click();
		SeleniumHelperClass.clearElement(get_Oktapassword());
		get_Oktapassword().sendKeys(pwd);
		get_Okta_userNameNext().click();
	}
	
	private void loginWithoutGRS(String uName, String pwd) throws Exception {
		WebElement userNameElement = get_ousername();
		SeleniumHelperClass.clearElement(userNameElement);
		userNameElement.sendKeys(uName);
		WebElement passwordElement = get_opassword();
		SeleniumHelperClass.clearElement(passwordElement);
		passwordElement.sendKeys(pwd);
		get_ologin().sendKeys(Keys.ENTER);
		Thread.sleep(1000);
	}

	private void loginWithoutGRSAllignstar(String uName, String pwd) throws Exception {
		SeleniumHelperClass.clearElement(get_ousername());
		get_ousername().sendKeys(uName);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/2);
		SeleniumHelperClass.clearElement(get_opassword());
		get_opassword().sendKeys(pwd);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/2);
		get_ologin().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	
	public  void loginToAlignStar() throws Exception {	

		new SetWebDrivers();		
		/**DeleteAllCookies*/
		SetWebDrivers.getDriver().manage().deleteAllCookies();		
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX );
		get_ousernameAS().sendKeys(getUsername());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/2);
		get_opasswordAS().sendKeys(getPassword());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/2);
		get_ologin_ASsubmit().sendKeys(Keys.ENTER);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX *2);
	}
	
	private  WebElement ASgetLogOut() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//a[@title='Logout']");		
	}
	private  WebElement ASDownArrow() throws Exception {		
		return SeleniumHelperClass.findWebElementbyid("userNavLabel", "");
	}
	
	public void logOutFromAlignStar() throws Exception {
		ASDownArrow().click();
		Thread.sleep(2000);
		ASgetLogOut().click();
	}
	
	public  void loginToIncentResetPWD(@Optional String environment,String variable) throws Exception	
	{	
		//Saving the state of the browser
		SetWebDrivers.setSavedriver(SetWebDrivers.getDriver());
		environment=environment.toLowerCase();		

		String propFile="environment"+File.separator+environment+File.separator+environment+".properties";
		String userpropFile="environment"+File.separator+environment+File.separator+environment+"_users.properties";
		setSystemPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(propFile));
		setSystemUserPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(userpropFile));

		symProPath.load(LoginToApplication.getSystemPropertyInputStream());
		userProPath.load(LoginToApplication.getSystemUserPropertyInputStream());

		//setUrl(LoginToApplication.symProPath.getProperty("url"));
		String userdetails = LoginToApplication.userProPath.getProperty(variable);
		String[] user = userdetails.split(":");

		setReloadusername(user[0]);
		setReloadpassword(user[1]);					

		logger.info("Url : "+getUrl()+"\nUsername : "+getReloadusername()+"\nPassword : "+getReloadpassword());
		SetWebDrivers.getDriver().switchTo().defaultContent();
		SetWebDrivers.getDriver().get(LoginToApplication.getUrl());		

		if(getGrs().equalsIgnoreCase("OFF")) {
			loginWithoutGRS(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword() );
		}else {
			loginWithGRS(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword());
		}
		Thread.sleep(1000);
		
	}
	
	public  void loginToIncentResetPWDIAM(@Optional String environment,String variable) throws Exception	
	{	
		//Saving the state of the browser
		SetWebDrivers.setSavedriver(SetWebDrivers.getDriver());
		environment=environment.toLowerCase();		

		String propFile="environment"+File.separator+environment+File.separator+environment+".properties";
		String userpropFile="environment"+File.separator+environment+File.separator+environment+"_users.properties";
		setSystemPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(propFile));
		setSystemUserPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(userpropFile));

		symProPath.load(LoginToApplication.getSystemPropertyInputStream());
		userProPath.load(LoginToApplication.getSystemUserPropertyInputStream());

		//setUrl(LoginToApplication.symProPath.getProperty("url"));
		String userdetails = LoginToApplication.userProPath.getProperty(variable);
		String[] user = userdetails.split(":");

		setReloadusername(user[0]);
		setReloadpassword(user[1]);					

		logger.info("Url : "+getUrl()+"\nUsername : "+getReloadusername()+"\nPassword : "+getReloadpassword());
		SetWebDrivers.getDriver().switchTo().defaultContent();
		SetWebDrivers.getDriver().get(LoginToApplication.getUrl());		

		if(getGrs().equalsIgnoreCase("OFF")) {
			loginWithoutGRSIAM(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword() );
		}else {
			loginWithGRSIAM(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword());
		}
		Thread.sleep(1000);
		
	}
	
	public  void reloadloginToIncentMultiSandBoxAccess(@Optional String environment,String variable,String envSelection) throws Exception	
	{	
		//Saving the state of the browser
		SetWebDrivers.setSavedriver(SetWebDrivers.getDriver());
		environment=environment.toLowerCase();		

		String propFile="environment"+File.separator+environment+File.separator+environment+".properties";
		String userpropFile="environment"+File.separator+environment+File.separator+environment+"_users.properties";
		setSystemPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(propFile));
		setSystemUserPropertyInputStream(this.getClass().getClassLoader().getResourceAsStream(userpropFile));

		symProPath.load(LoginToApplication.getSystemPropertyInputStream());
		userProPath.load(LoginToApplication.getSystemUserPropertyInputStream());

		//setUrl(LoginToApplication.symProPath.getProperty("url"));
		String userdetails = LoginToApplication.userProPath.getProperty(variable);
		String[] user = userdetails.split(":");

		setReloadusername(user[0]);
		setReloadpassword(user[1]);					

		logger.info("Url : "+getUrl()+"\nUsername : "+getReloadusername()+"\nPassword : "+getReloadpassword());
		SetWebDrivers.getDriver().switchTo().defaultContent();
		SetWebDrivers.getDriver().get(LoginToApplication.getUrl());		

		if(getGrs().equalsIgnoreCase("OFF")) {
			loginWithoutGRS(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword() );
		}else {
			loginWithGRSMultiSBEnvs(LoginToApplication.getReloadusername(), LoginToApplication.getReloadpassword(),envSelection);
		}
		SeleniumHelperClass.waitforPageToLoad("id", "ddimagetabs", "topFrame");
	}

	public WebElement userInfoOldUI() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("personInfo", "topFrame");
	}

	
	
}



