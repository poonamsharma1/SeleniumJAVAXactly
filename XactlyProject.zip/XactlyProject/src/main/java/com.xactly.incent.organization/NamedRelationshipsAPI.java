package com.xactly.incent.organization;

import java.net.URL;
import org.apache.axis.client.Stub;
import org.apache.log4j.Logger;

import com.xactly.icm.xtoolkit.service.DiscoveryServiceSoapBindingStub;
import com.xactly.icm.xtoolkit.service.XService;
import com.xactly.icm.xtoolkit.service.XServiceServiceLocator;
import com.xactly.icm.xtoolkit.wso.DeleteResponse;
import com.xactly.icm.xtoolkit.wso.LoginResponse;
import com.xactly.icm.xtoolkit.wso.PositionRelationTypeWSO;
import com.xactly.icm.xtoolkit.wso.SearchResponse;
import com.xactly.icm.xtoolkit.wso.XObject;


public class NamedRelationshipsAPI {
	public static Logger logger = Logger.getLogger(NamedRelationshipsAPI.class.getName());
	
	public String deleteNamedRelationship(String username, String password, String DISCOVERY_SERVICE_URL,String nrName, String comments) throws Exception{
	
		logger.info("Logging in using wsdl URL: "+DISCOVERY_SERVICE_URL);
		XService service = new XServiceServiceLocator().getDiscoveryService(new URL(DISCOVERY_SERVICE_URL));
		((DiscoveryServiceSoapBindingStub) service).setMaintainSession(true);

		LoginResponse response = service.login(username,password, "Incent");
		logger.info("isAuthenticated :" + response.isAuthenticated());
		logger.info("getSessionId :" + response.getSessionId());

		if (!response.isAuthenticated()) {
			logger.info("Login failed");
			return null;
		} else {
			logger.info("Login successful by user "+username);
			((DiscoveryServiceSoapBindingStub) service).clearHeaders();

			String sessionId = response.getSessionId();
			String serverUrl = response.getServerUrl();

			logger.info("serverUrl :" + response.getServerUrl());

			((DiscoveryServiceSoapBindingStub) service)._setProperty(Stub.ENDPOINT_ADDRESS_PROPERTY, serverUrl);
			((DiscoveryServiceSoapBindingStub) service)
					.setHeader(new XServiceServiceLocator().getServiceName().getNamespaceURI(), "SessionId", sessionId);
			((DiscoveryServiceSoapBindingStub) service).setHeader(
					new XServiceServiceLocator().getServiceName().getNamespaceURI(), "UserName", username);

		}
		DeleteResponse deleteResponse = null;
		SearchResponse sr = null;
		XObject[] srecords = null;

		PositionRelationTypeWSO relationTypeV1 = new PositionRelationTypeWSO();
		relationTypeV1.setName(nrName);
		relationTypeV1.setIsMaster(true);

		sr = service.search(relationTypeV1);
		srecords = sr.getSearchRecords();
		if ( srecords != null && srecords.length >= 1){
		relationTypeV1 = (PositionRelationTypeWSO)srecords[0];

		deleteResponse = service.deleteVersion(relationTypeV1, comments);
		}
		logger.info("API completed: "+deleteResponse);
		String resp = deleteResponse.toString();
		return resp;

	}
}
