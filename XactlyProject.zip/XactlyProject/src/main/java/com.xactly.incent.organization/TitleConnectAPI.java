package com.xactly.incent.organization;

import com.xactly.icm.xtoolkit.service.XService;
import com.xactly.icm.xtoolkit.wso.*;
import com.xactly.icm.xtoolkit.wso.TitleWSOPayPeriodType;
import org.apache.log4j.Logger;

import java.rmi.RemoteException;

/**
 * Author -Shubha
 * Date - 27/1/2020
 */

public class TitleConnectAPI extends TitleWSOPayPeriodType {
    public static Logger logger = Logger.getLogger(TitleConnectAPI.class.getName());

    protected TitleConnectAPI(String value)
    {
        super(value);
    }

    public TitleWSO createtitle( TitleWSOCategoryName accountExecutive,String name,TitleWSOPayPeriodType periodtyp ,XService service,String dis,TitleWSOLevel level,TitleWSOFunctionName funname,String fov,String cat_name,TitleWSOMarket mark) throws RemoteException {

        TitleWSO titlewso= new TitleWSO();
        titlewso.setPayPeriodType(periodtyp);
        titlewso.setName(name);
        titlewso.setDescription(dis);
        titlewso.setLevel(level);
        titlewso.setFunctionName(funname);
        titlewso.setFunctionOtherValue(fov);
        titlewso.setCategoryOtherValue(cat_name);
        titlewso.setMarket(mark);
        titlewso.setCategoryName(accountExecutive);
        SaveResponse saveResponse = service.save(titlewso);
        logger.info("Save User Result: "+saveResponse.isResult()+ "\n");
        ErrorCode[] errorCodes = saveResponse.getErrorCodes();
        if(errorCodes!=null){
            for (int i = 0; i < errorCodes.length; i++) {

                logger.info("Error Code: " + errorCodes[i].getCode()+"\n");
                logger.info("Error Msg: " + errorCodes[i].getReason()+"\n");
                logger.info("Stack Trace: " + errorCodes[i].getStackTrace()+"\n");

            }
        }

        if(saveResponse.isResult()){
            service.search(titlewso);
            logger.info("save successful"+saveResponse);
            return titlewso;
        }
        else{

            logger.info("save unsuccessful"+saveResponse);
            return null;
        }


    }

}
