package com.xactly.incent.organization;

import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.log4j.Logger;
import org.testng.annotations.Optional;

import com.xactly.icm.xtoolkit.service.XService;
import com.xactly.icm.xtoolkit.wso.DeleteResponse;
import com.xactly.icm.xtoolkit.wso.ErrorCode;
import com.xactly.icm.xtoolkit.wso.PositionHierarchyTypeWSO;
import com.xactly.icm.xtoolkit.wso.PositionHierarchyWSO;
import com.xactly.icm.xtoolkit.wso.SaveResponse;
import com.xactly.icm.xtoolkit.wso.SearchResponse;
import com.xactly.icm.xtoolkit.wso.XObject;
import com.xactly.xcommons.selenium.SeleniumHelperClass;

public class Hierarchy_API {
	private String EFFECTIVE_STARTcalender;
	public static Logger logger = Logger.getLogger(Hierarchy_API.class.getName());

	public static String NAME = "TestHierarchy" + SeleniumHelperClass.setUniqueId();

	public PositionHierarchyTypeWSO createHierarchy(String name, String description, XService service)
			throws RemoteException {
		logger.info("Creating Hierarchy");
		PositionHierarchyTypeWSO hierarchyWSO = new PositionHierarchyTypeWSO();
		hierarchyWSO.setName(name);
		hierarchyWSO.setDescription(description);
		System.out.println(" Hierarchy Name " + name);
		SaveResponse saveResponse = service.save(hierarchyWSO);
		logger.info("Save hierarchy Result: " + saveResponse.isResult() + "\n");
		ErrorCode[] errorCodes = saveResponse.getErrorCodes();
		if (errorCodes != null) {
			for (int i = 0; i < errorCodes.length; i++) {
				logger.info("Error Code: " + errorCodes[i].getCode() + "\n");
				logger.info("Error Msg: " + errorCodes[i].getReason() + "\n");
				logger.info("Stack Trace: " + errorCodes[i].getStackTrace() + "\n");
			}
		}
		logger.info("Expected response : true\n");
		if (saveResponse.isResult()) {
			logger.info(saveResponse);
		} else {
			logger.info(saveResponse);
		}

		return hierarchyWSO;
	}

	public PositionHierarchyTypeWSO addVersion(String name, Calendar EFFStartDate, XService service)
			throws RemoteException {
		logger.info("Adding version to the hierarchy");
		PositionHierarchyTypeWSO hierarchyType = new PositionHierarchyTypeWSO();
		// hierarchyWSO.setDisplayName(VersionName);
		hierarchyType.setName(name);

		SearchResponse sr = service.search(hierarchyType);
		XObject[] srecords = sr.getSearchRecords();
		if (srecords != null && srecords.length == 1) {
			hierarchyType = (PositionHierarchyTypeWSO) srecords[0];
			logger.info("PositionHierarchyTypeWSO found: " + hierarchyType.getName());
			hierarchyType.setDescription("Add Version via Connect API.");
			hierarchyType.setEffectiveStartDate(EFFStartDate);
			logger.info("Date is" + EFFStartDate);
			SaveResponse saveResponse = service.addVersion(hierarchyType, EFFStartDate);

			// SaveResponse saveResponse = service.save(hierarchyType);
			logger.info("add hierarchy version Result: " + saveResponse.isResult() + "\n");
			ErrorCode[] errorCodes = saveResponse.getErrorCodes();
			if (errorCodes != null) {
				for (int i = 0; i < errorCodes.length; i++) {
					logger.info("Error Code: " + errorCodes[i].getCode() + "\n");
					logger.info("Error Msg: " + errorCodes[i].getReason() + "\n");
					logger.info("Stack Trace: " + errorCodes[i].getStackTrace() + "\n");
				}
			}
			logger.info("Expected response : true\n");
			if (saveResponse.isResult()) {
				logger.info(saveResponse);
			} else {
				logger.info(saveResponse);
			}

			return hierarchyType;

		}
		return hierarchyType;

	}

	public PositionHierarchyTypeWSO editVersion(XService service, String description, String name)
			throws RemoteException {
		logger.info("Editing a version by changing the description");
		PositionHierarchyTypeWSO hierarchyType = new PositionHierarchyTypeWSO();
		hierarchyType.setName(name);
		SearchResponse sr = service.search(hierarchyType);
		XObject[] srecords = sr.getSearchRecords();
		logger.info("objects" + srecords);
		if (srecords != null) {
			hierarchyType = (PositionHierarchyTypeWSO) srecords[0];
			logger.info("PositionHierarchyTypeWSO found: " + hierarchyType.getName());
			hierarchyType.setDescription(description);
			SaveResponse saveResponse = service.saveVersion(hierarchyType);

			logger.info("Edit hierarchy version Result: " + saveResponse.isResult() + "\n");
			ErrorCode[] errorCodes = saveResponse.getErrorCodes();
			if (errorCodes != null) {
				for (int i = 0; i < errorCodes.length; i++) {
					logger.info("Error Code: " + errorCodes[i].getCode() + "\n");
					logger.info("Error Msg: " + errorCodes[i].getReason() + "\n");
					logger.info("Stack Trace: " + errorCodes[i].getStackTrace() + "\n");
				}
			}
			logger.info("Expected response : true\n");
			if (saveResponse.isResult()) {
				logger.info(saveResponse);
			} else {
				logger.info(saveResponse);
			}

			return hierarchyType;

		}
		return hierarchyType;

	}

	public PositionHierarchyTypeWSO deleteVersion(XService service, String Comments) throws Exception {
		logger.info("Deleting a created version");
		String resp = null;
		boolean flag = true;
		PositionHierarchyTypeWSO hierarchyType = new PositionHierarchyTypeWSO();
		hierarchyType.setDescription(Comments);
		DeleteResponse deleteResponse = new DeleteResponse();
		SearchResponse searchResponse = service.search(hierarchyType);
		XObject[] srXObjs = searchResponse.getSearchRecords();

		if (srXObjs != null) {
			if (srXObjs.length > 1) {
				hierarchyType = (PositionHierarchyTypeWSO) srXObjs[0];
				deleteResponse = service.deleteVersion(hierarchyType, Comments);
				logger.info("Delete hierarchy version Result: " + deleteResponse.isResult());
				logger.info("Deleted" + deleteResponse);
				ErrorCode[] errorCodes = deleteResponse.getErrorCodes();
				for (int i = 0; i < errorCodes.length; i++) {
					logger.info("Error Code: " + errorCodes[i].getCode() + "\n");
					logger.info("Error Text: " + errorCodes[i].getReason() + "\n");
					logger.info("Stack: " + errorCodes[i].getStackTrace() + "\n");
				}
				logger.info("Expected response : true\n");
				logger.info("API completed: " + deleteResponse);
				resp = deleteResponse.toString();

				PositionHierarchyTypeWSO versionafterdelete = new PositionHierarchyTypeWSO();
				versionafterdelete.setDescription(Comments);
				if (versionafterdelete.getVersion() != null) {
					logger.info("Version still exists , version not deleted....");
					flag = false;
				}
			} else {
				logger.info("Version does not exists : " + Comments);
				flag = true;
			}
		}
		return hierarchyType;

	}

	public String createhierarchyfromconnect(String environment, XService service) throws Exception {

		String DESCRIPTION = "Create hierarchy via connect API";
		String DESCRIPTION1 = "Delete";
		String VERSIONNAME = "versiontest";
		String POSITION1 = "PosA";
		String POSITION2 = "PosB";
		String POSITION3 = "PosC";
		String EDITEDDESCRIPTION = "Editing hierarchy via connect API";
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Calendar EFFSTARTDATE = Calendar.getInstance();

		java.util.Date EFFECTIVE_START_DATE = new java.util.Date();
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
		try {
			EFFECTIVE_START_DATE = sdf.parse(EFFSTARTDATE.toString());
		} catch (java.text.ParseException p) {
		}
		Calendar EFFECTIVE_STARTcalender = new GregorianCalendar();
		EFFECTIVE_STARTcalender.setTime(EFFECTIVE_START_DATE);

		String EMAIL;
		// EMAIL = "autoconnectuser1@grs01.com";
		EMAIL = "schand" + SeleniumHelperClass.setUniqueId() + "@xactlycorp.com";
		logger.info(EMAIL + " is the email id");

		PositionHierarchyTypeWSO hierarchyCreate = createHierarchy(NAME, DESCRIPTION, service);
		PositionHierarchyTypeWSO hierarchyVersion = addVersion(NAME, EFFECTIVE_STARTcalender, service);
		PositionHierarchyTypeWSO hierarchyedit = editVersion(service, EDITEDDESCRIPTION, NAME);
		PositionHierarchyTypeWSO hierarchydelelte = deleteVersion(service, DESCRIPTION1);
		// PositionHierarchyTypeWSO createrelation= createRelationship(NAME,
		// POSITION1,POSITION2, POSITION3, service);
		// PositionHierarchyWSO delelteRelationship= deleteRelationship(service,
		// DESCRIPTION1);
		return EMAIL;
	}

}
