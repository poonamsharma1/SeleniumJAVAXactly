package com.xactly.incent.organization;

import java.lang.reflect.Type;

import org.apache.log4j.Logger;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.xactly.metadata.wso.*;
import com.xactly.xbpm.services.docapproval.wso.DocApprovalsListResponse;
import com.xactly.xbpm.services.docapproval.wso.DocumentTemplateWSO;
import com.xactly.xcommons.restapi.RestAPIHelperClass;

public class ProfilesAPI {
	
	public static Logger logger = Logger.getLogger(ProfilesAPI.class.getName());
	private final RestAPIHelperClass restApiHelper = new RestAPIHelperClass();

	
	public static final String XICM = "/xicm";
    public static final String METADATA = "/metadata/v1";	
    public static final String CUSTOM_FIELDS = XICM + METADATA + "/custom-fields";

    
	public CustomFieldListResponse getCustomFieldsAPI(String objectType) throws JsonSyntaxException {
		Gson gson = new GsonBuilder().create();

        String requestURL = null;
        if (objectType != null) {
            requestURL = CUSTOM_FIELDS +"?object-type="+objectType;
        } else {
            requestURL = CUSTOM_FIELDS;
        }
        
        logger.info("Request URL for CustomFields API:" + requestURL);
        String response = restApiHelper.getRestAPIForProfiles(requestURL);
		@SuppressWarnings("serial")
        Type expectedType = new TypeToken<MetadataServiceListResponse<CustomFieldListResponse>>() {
		}.getType();
		CustomFieldListResponse customFieldsAcualResponse = gson.fromJson(response, CustomFieldListResponse.class);
        return customFieldsAcualResponse;
    }


}
