package com.xactly.incent.organization;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.xactly.incent.home.Home;
import com.xactly.incent.navigation.LeftNavigationUtil;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

public class Uploads {

	public static Logger logger = Logger.getLogger(HierarchyPage.class.getName());

	public Uploads(String testtype) throws Exception {

		if (testtype.equalsIgnoreCase("gui-new")) {
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX * 2);
			LeftNavigationUtil.clickOnMyUploadsTab();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX * 2);
		}
	}

	 public Uploads() {
	    }

	public WebElement get_statustable_firstresult() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//tbody[@id='listTable_uploadInfo_list']//tr[1]",
				"listFrame"));
	}

	public WebElement get_myuploads_errorlog() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("errorLogButton", "editFrame"));
	}

}
