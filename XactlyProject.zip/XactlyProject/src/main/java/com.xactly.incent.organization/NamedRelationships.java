package com.xactly.incent.organization;

import com.xactly.incent.navigation.LeftNavigationUtil;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import org.openqa.selenium.WebElement;

public class NamedRelationships {

    public NamedRelationships(String testtype) throws Exception

    {
        if(testtype.equalsIgnoreCase("gui"))
        {
            new Organization("gui");
            Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
            SeleniumHelperClass.findWebElementbyid("A_Named Relationships","topFrame").click();
            Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
        }
        else if(testtype.equalsIgnoreCase("gui-new"))
        {
            
            new Organization("gui-new");
            Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
			LeftNavigationUtil.clickOnNamedRelationTab();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
        }
    }

    public WebElement get_searchButton() throws Exception
    {
        return (SeleniumHelperClass.findWebElementbyid("searchButton","contentframe"));
    }

}
