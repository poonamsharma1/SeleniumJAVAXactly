package com.xactly.incent.organization;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.Response;
import com.xactly.incent.navigation.LeftNavigationUtil;
import com.xactly.xcommons.restapi.RestAPIHelperClass;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

import net.minidev.json.JSONArray;

public class HierarchyPage {
    public static Logger logger = Logger.getLogger(HierarchyPage.class.getName());
    private WebDriver drv;
    String path = "/xicm/api/xbase/commondata/v1";
    RestAPIHelperClass rest = new RestAPIHelperClass();
    String nbsp = "[\\s\\u00A0]+$"; //Used for removing &nbsp; from string value returned by web elements

    public WebElement get_ohierarchy_name() throws Exception {
        return (SeleniumHelperClass.findWebElementbyid("name","AddVersionFrame"));
    }

    public WebElement get_ohierarchy_startDate() throws Exception {
        return (SeleniumHelperClass.findWebElementbyid("a_eff_start","AddVersionFrame"));
    }

    public WebElement get_ohierarchy_firstActiveDate() throws Exception {
        return (SeleniumHelperClass.findWebElements("//*[@class='x-date-active']","AddVersionFrame").get(0));
    }

    public WebElement get_ohierarchy_description() throws Exception {
        return (SeleniumHelperClass.findWebElementbyid("description","AddVersionFrame"));
    }

    public WebElement get_ohierarchy_create_hierarchy() throws Exception {
        return (SeleniumHelperClass.findWebElementbyLink("Create Hierarchy","MainFrame"));
    }

    public WebElement get_ohierarchy_edit_hierarchy() throws Exception {
        return (SeleniumHelperClass.findWebElementbyLink("Edit Hierarchy","MainFrame"));
    }

    public WebElement get_ohierarchy_create_relationship() throws Exception {
        return (SeleniumHelperClass.findWebElementbyLink("Create Relationship","MainFrame"));
    }

    public WebElement getEditRelationship() throws Exception {
    	return (SeleniumHelperClass.findWebElementbyLink("Edit Relationship","MainFrame"));
    }


    public WebElement get_ohierarchy_parent_position() throws Exception {
        return (SeleniumHelperClass.findWebElementbyid("selectFromPositionButton","none"));
    }

    public WebElement get_ohierarchy_position() throws Exception {
        return (SeleniumHelperClass.findWebElementbyid("selectToPositionButton","none"));
    }


    public WebElement get_ohierarchy_search_position() throws Exception {
        return (SeleniumHelperClass.findWebElementbyid("name_edit_position","none"));
    }


    public WebElement get_ohierarchy_search() throws Exception {
        return (SeleniumHelperClass.findWebElementbyid("searchButton","contentFrame"));
    }

    public WebElement getSearchButtonOnPopup() throws Exception {
        return (SeleniumHelperClass.findWebElementbyid("searchButton"));
    }

    public WebElement getSearchPopupTableListDiv() throws Exception {
        return (SeleniumHelperClass.findWebElementbyid("listDiv"));
    }

    public WebElement getSearchPopupTableList(WebElement listDiv) throws Exception {
        return (listDiv.findElement(By.id("listTable_pos_list")));
    }

    public WebElement get_ohierarchy_clear() throws Exception
    {
        return (SeleniumHelperClass.findWebElementbyid("clearButton","contentframe"));
    }

    public WebElement get_ohierarchy_textBox() throws Exception{
        return (SeleniumHelperClass.findWebElementbyName("Position Name", "contentFrame"));
    }

    public WebElement get_ohierarchy_relationship_save() throws Exception {
        return (SeleniumHelperClass.findWebElementbyXpath("//button[contains(text(),'Save')]","none"));
    }
    
    public WebElement get_uploadhierarchy() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//a/span[contains(.,'Upload Hierarchy')]", "mainframe"));
	}

	public WebElement get_uploadhierarchypopup_choosefile() throws Exception {
		return (SeleniumHelperClass.findWebElementbyName("file", "uploadPositionFrame"));
	}

	public WebElement get_uploadhierarchypopup_versionname() throws Exception {
		return (SeleniumHelperClass.findWebElementbyName("versionName", "uploadPositionFrame"));
	}

	public WebElement get_uploadhierarchypopup_effectivestartdate() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("a_eff_start", "uploadPositionFrame"));
	}

	public WebElement get_uploadhierarchypopup_calenderselect_today() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//button[text()='Today']", "uploadPositionFrame"));
	}

	public WebElement get_uploadhierarchypopup_upload() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//button[@type='submit']", "uploadPositionFrame"));
	}

	public WebElement get_uploadhierarchypopup_ok() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@onclick='done()']", "uploadPositionFrame",5000));
	}

	public String getUploadFileLocation(String file) {
		File file11 = new File(System.getProperty("user.dir")+"/src/main/resources/com.xactly.incent.organization/HierarchyUpload/"+file);	
		return file11.getAbsoluteFile().getPath();
	}
	
    public WebElement get_ohierarchy_save() throws Exception {
        return (SeleniumHelperClass.findWebElementbyXpath("//button[contains(text(),'Save')]","AddVersionFrame"));
    }

    public WebElement get_ohierarchy_table() throws Exception {
        return (SeleniumHelperClass.findWebElementbyid("tableFixed","clistframe"));

    }



    public WebElement get_hierarchy_table() throws Exception{
        return (SeleniumHelperClass.findWebElementbyid("tableFixed","contentFrame"));
    }
    public WebElement getHierarchyTable(String columnName, int rowNum) throws Exception
    {
        Thread.sleep(1000);
        return (SeleniumHelperClass.getTableData(get_ohierarchy_table(), columnName,rowNum));
    }

    public WebElement getHierarchyTableNew(String columnName, int rowNum) throws Exception
    {
        Thread.sleep(1000);
        return (SeleniumHelperClass.getTableData(get_hierarchy_table(), columnName,rowNum));
    }


    public WebElement get_LatestVersion() throws Exception{
        return SeleniumHelperClass.findWebElementbyXpath("(//input[@type='radio'])[2]", "contentFrame");
    }

    public WebElement getAllVersionsRadioButtonSearchPage() throws Exception {
        return SeleniumHelperClass.findWebElementbyXpath("//*[@id=\"formDiv\"]/table/tbody/tr[3]/td/table/tbody/tr[2]/td/input", "contentFrame");
    }


    public WebElement getPositionNameFromRelationship(String positionName)  throws Exception{
    	return SeleniumHelperClass.findWebElementbyXpath("//td/div[text()='" + positionName + "']", "contentFrame");
    }


    public HierarchyPage(String testtype) throws Exception {
        if (testtype.equalsIgnoreCase("gui")) {

            new Organization("gui");
            SeleniumHelperClass.findWebElementbyid("A_Hierarchy", "topFrame")
                    .click();
            SeleniumHelperClass.acceptAlert();//this is added to handle the alert which comes when we click on the sublinks in organization,Can be removed once dev fix this issue.

        }
        else if (testtype.equalsIgnoreCase("gui-new")) {

 
            new Organization("gui-new");
			LeftNavigationUtil.clickOnHierarchyTab();
			SeleniumHelperClass.acceptAlert();
        }

    }

    /**
     *
     */
    public HierarchyPage() {
    }
    
    public void createHierarchy(String name, String desc) throws Exception {

        drv = SetWebDrivers.getDriver();
        String parentWindow = drv.getWindowHandle();
        get_ohierarchy_create_hierarchy().click();
        Set<String> windowHandlers = drv.getWindowHandles();
        for (String windowHandle : windowHandlers) {
            if (!windowHandle.equals(parentWindow)) {
                drv.switchTo().window(windowHandle);

            }
        }

        get_ohierarchy_name().sendKeys(name);
        get_ohierarchy_description().sendKeys(desc);
        get_ohierarchy_save().click();
        drv.switchTo().window(parentWindow);

    }

    public void switchToPopup() throws Exception {
        drv = SetWebDrivers.getDriver();
        String recentWindow = "";
        Set<String> windowHandlers = drv.getWindowHandles();
        for (String windowHandle : windowHandlers) {
            recentWindow = windowHandle;

        }
        drv.switchTo().window(recentWindow);

    }

    public void switchToDefaultWindow() throws Exception {
        drv = SetWebDrivers.getDriver();
        String recentWindow = "";
        Set<String> windowHandlers = drv.getWindowHandles();
        for (String windowHandle : windowHandlers) {
            recentWindow = windowHandle;

        }
        drv.switchTo().window(recentWindow);
        //SetWebDrivers.getDriver().switchTo().defaultContent();
    }

    public void createParentChildRelationship(String parentPos, String pos) throws Exception {
        switchToPopup();
        if (parentPos != ""){
        	get_ohierarchy_search_position().clear();
            get_ohierarchy_search_position().sendKeys(parentPos);
            getSearchButtonOnPopup().click();
            logger.info("parent position to select");
            SeleniumHelperClass.isVisible( SeleniumHelperClass.findWebElementbyCssSelector("td > div","none"), 5);
            SeleniumHelperClass.findWebElementbyCssSelector("td > div","none").click();
            get_ohierarchy_parent_position().click();
            
        }
        get_ohierarchy_search_position().clear();
        get_ohierarchy_search_position().sendKeys(pos);
        getSearchButtonOnPopup().click();
        SeleniumHelperClass.isVisible( SeleniumHelperClass.findWebElementbyCssSelector("td > div","none"), 5);
        SeleniumHelperClass.findWebElementbyCssSelector("td > div","none").click();
        SeleniumHelperClass.isVisible( get_ohierarchy_position(), 5);
        get_ohierarchy_position().click();
        get_ohierarchy_relationship_save().click();
        drv = SetWebDrivers.getDriver();
        switchToDefaultWindow();
        
    }

    public Object getParticipantId(String person,Response response)
    {
        RestAPIHelperClass rest = new RestAPIHelperClass();
        logger.info("Getting Participant ID..");
        Response res = rest.getRestAPIResponse("/v1/people/searchpeopleinhierarchy?searchfield=participantName&searchtext="+person+"&effectivedate=1201717800000&limit=20&offset=0&sortfield=participantName&order=asc&_=1435039568432",response);
        logger.info(res);
        JSONArray participantid = JsonPath.read(res.asString(), "$..participantId");

        logger.info(participantid.get(0));
        logger.info("Response from getParticipantId API : "+participantid);
        return participantid.get(0);
    }

    public WebElement getHierarchySearchPosition() throws Exception {
        return (SeleniumHelperClass.findWebElementbyXpath("//input[@class='basic_se']","contentFrame"));
    }

    public WebElement downloadHierarchy() throws Exception {

        return SeleniumHelperClass.findWebElementbyLink("Download Relationships", "mainFrame");

    }

    public void searchHierarchyPosition(String name) throws Exception	{
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
        getHierarchySearchPosition().sendKeys(name);
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
        get_ohierarchy_search().click();
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);

    }

    /**
     * calcualtes the display time for the positionName.
     * @param positionName
     * @return Totaltimetaken
     * @throws Exception
     */


    public List<WebElement> get_op_objectDropdown() throws Exception{
        return (SeleniumHelperClass.findWebElementsById("object_select", "contentFrame"));
    }

    public WebElement getEditHierarchyButton() throws Exception {
        return SeleniumHelperClass.findWebElementbyid("ext-gen142", "mainFrame");
    }

    public WebElement getAllHierarchyRelationshipsButton() throws Exception {
    	return SeleniumHelperClass.findWebElementbyid("ext-gen154", "mainFrame",120);
    }
    
    public WebElement getAllHierarchyRelationshipsButtonLink() throws Exception {
    	return SeleniumHelperClass.findWebElementbyLink("All Hierarchy Relationships", "mainFrame");
    }
    

    public WebElement getDownloadRelationshipsButton() throws Exception {
        return SeleniumHelperClass.findWebElementbyid("ext-gen347", "mainFrame",120);
    }

    public WebElement getAllVersionsRadioButton() throws Exception {
        return SeleniumHelperClass.findWebElementbyXpath("/html/body/form[1]/p/table[1]/tbody/tr[1]/td/table/tbody/tr[2]/td/input", "downloadFrame",120);
    }

    public WebElement getDownloadRadioButton() throws Exception {
        return SeleniumHelperClass.findWebElementbyXpath("/html/body/form[1]/p/table[2]/tbody/tr/td[2]/button", "downloadFrame",120);
    }

    public WebElement getHierarchyRow(int rowIndex) throws Exception {
        switchToHierarchyContainer();
        return SeleniumHelperClass.findWebElementbyXpath("//*[@id=\"is-content\"]/div/div/div["+rowIndex+"]/div");
    }

    public WebElement getRowExpandedArrow(WebElement hierarchyRow) throws Exception {
        return hierarchyRow.findElement(By.xpath("//span/i"));
    }

    public WebElement getHierarchyRowDetails(int rowIndex) throws Exception {
        return getHierarchyRow(rowIndex).findElements(By.tagName("span")).get(1);
    }

    //Get hierarchy node details using position id
    public WebElement getHierarchyNode(String positionId) throws Exception {
        switchToHierarchyContainer();
        return SeleniumHelperClass.findWebElementbyXpath("//*[@id=\""+positionId+"\"]");
    }

    public WebElement getHierarchyNodeDetails(String positionId) throws Exception {
        return getHierarchyNode(positionId).findElements(By.tagName("span")).get(1);
    }

    public WebElement getHierarchyNodeExpandArrow(String positionId) throws Exception {
        return getHierarchyNode(positionId).findElements(By.tagName("span")).get(0).findElement(By.tagName("i"));
    }

    public WebElement getHierarchyHeaderVersion() throws Exception {
        return SeleniumHelperClass.findWebElementbyid("versionName", "ceditframe");
    }

    public String getHierarchyHeaderText() throws Exception {
        return getHierarchyHeaderVersion().getText().replace("Use Flash UI (Legacy)", "").replaceAll(nbsp, "");
    }

    public WebElement getHierarchyHeaderObjectName() throws Exception {
        return SeleniumHelperClass.findWebElementbyid("objName", "ceditframe");
    }

    public WebElement getHierarchyHeaderTotalRelationships() throws Exception {
        return SeleniumHelperClass.findWebElementbyid("total", "ceditframe");
    }

    public int getTotalRelationshipsFromUI() throws Exception {
        String total = getHierarchyHeaderTotalRelationships().getText().split(":")[1].trim();
        return Integer.parseInt(total);
    }

    public WebElement getHierarchyViewContainer() throws Exception {
        return SeleniumHelperClass.findWebElementbyid("container", "ceditframe").findElement(By.tagName("iframe"));
    }

    public void switchToHierarchyContainer() throws Exception {
        SetWebDrivers.getDriver().switchTo().frame(getHierarchyViewContainer());
    }

    public WebElement getHierarchyEditRelationshipButton() throws Exception {
        return SeleniumHelperClass.findWebElementbyXpath("/html/body/div[3]/div[2]/div/div[3]/div[2]/div/ul/div/li[4]/div/a/span", "mainFrame");
    }

    public WebElement getHierarchyEditRelationshipPopupTable() throws Exception {
        return SeleniumHelperClass.findWebElementbyXpath("/html/body/table[2]/tbody/tr[1]/td/form");
    }

    public WebElement getHierarchySearchRelationshipPopupTable() throws Exception {
        return SeleniumHelperClass.findWebElementbyXpath("/html/body/table[4]/tbody/tr[1]/td/form");
    }

    public WebElement getHierarchyEditRelationshipPopupTableRow(int rowIndex) throws Exception {
        return getHierarchyEditRelationshipPopupTable().findElement(By.xpath("//div/table/tbody/tr[" + rowIndex + "]"));
    }

    public WebElement getHierarchySearchRelationshipPopupTableRow(int rowIndex) throws Exception {
        return getHierarchySearchRelationshipPopupTable().findElement(By.xpath("//div/table/tbody/tr[" + rowIndex + "]"));
    }

    public WebElement getHierarchySearchRelationshipPopupTextBox() throws Exception {
        return SeleniumHelperClass.findWebElementbyXpath("//*[@id=\"positionName_pos_list\"]");
    }

    public WebElement getHierarchySearchCancelButton() throws Exception {
        return SeleniumHelperClass.findWebElementbyid("cancelButton");
    }

    public WebElement getSelectParentButtonOnPopup() throws Exception {
        return SeleniumHelperClass.findWebElementbyid("selectFromPositionButton");
    }

    public WebElement getSelectPositionButtonOnPopup() throws Exception {
        return SeleniumHelperClass.findWebElementbyid("selectToPositionButton");
    }

    public WebElement getSaveButtonOnPopup() throws Exception {
        return SeleniumHelperClass.findWebElementbyid("saveButton");
    }

    public WebElement getHierarchyDeleteRelationshipButton() throws Exception {
        return SeleniumHelperClass.findWebElementbyXpath("/html/body/div[3]/div[2]/div/div[3]/div[2]/div/ul/div/li[7]/div/a/span", "mainFrame");
    }

    public WebElement getHierarchyCreateRelationshipButton() throws Exception {
        return SeleniumHelperClass.findWebElementbyXpath("/html/body/div[3]/div[2]/div/div[3]/div[2]/div/ul/div/li[2]/div/a/span", "mainFrame");
    }

    public WebElement getHierarchySearchPositionButton() throws Exception {
        return SeleniumHelperClass.findWebElementbyXpath("/html/body/div[3]/div[2]/div/div[5]/div[2]/div/ul/div/li[4]/div/a/span", "mainFrame");
    }

    public WebElement getHierarchySearchOKButton() throws Exception {
        return SeleniumHelperClass.findWebElementbyid("okButton");
    }

    public WebElement getHierarchyVersionTable() throws Exception {
        return SeleniumHelperClass.findWebElementbyid("listTable_hierarchy_list", "clistframe");
    }
    

    //Get hierarchy version details using versionName
    public WebElement getHierarchyVersionRow(String versionName) throws Exception {
        List<WebElement> versions = getHierarchyVersionTable().findElements(By.tagName("tr"));
        for(WebElement row : versions) {
            if(row.findElements(By.tagName("td")).get(2).getText().trim().equals(versionName)) {
                return row;
            }
        }
        return null;
    }

    //Get hierarchy version details using row index
    public WebElement getHierarchyVersionRow(int rowIndex) throws Exception {
        return getHierarchyVersionTable().findElements(By.tagName("tr")).get(rowIndex);
    }

    public String getVersionName(int rowIndex) throws Exception {
        return getHierarchyVersionRow(rowIndex).findElements(By.tagName("td")).get(2).getText().trim();
    }

    public List<WebElement> getLeftNavigationBarLinkList() throws Exception {
        return SeleniumHelperClass.findWebElements("//*[@class='x-tree-node']", "mainFrame");
    }

    public WebElement getLeftNavigationBarLinks(String linkName) throws Exception {
        for(WebElement we : getLeftNavigationBarLinkList()) {
            if(we.getText().trim().equals(linkName)) {
                logger.info("========== clicking on button");
                return we.findElement(By.tagName("a"));
            }
        }
        return null;
    }

    public void acceptAlert() throws Exception {
        SeleniumHelperClass.acceptAlert();
    }

    public WebElement getCommentsTextBoxOnDeleteHierarchyPopup() throws Exception {
        return SetWebDrivers.getDriver().findElement(By.id("comments"));
        //return SeleniumHelperClass.findWebElementbyid("comments", "none");
    }

    public WebElement getDeleteFormParentPositionOnDeleteHierarchyPopup() throws Exception {
        return SetWebDrivers.getDriver().findElement(By.xpath("/html/body/form/center/table/tbody/tr[4]/td[2]/input"));
        //return SeleniumHelperClass.findWebElementbyid("deleteForm", "none");
    }


    public WebElement getButtonOnDeleteHierarchyPopup(String buttonName) throws Exception {
        List<WebElement> buttonsList = SetWebDrivers.getDriver().findElements(By.tagName("button"));
        for(WebElement we : buttonsList) {
            if(we.getText().trim().equals(buttonName)) {
                logger.info("========== clicking on button = " + buttonName);
                return we;
            }
        }
        return null;
    }

    public void deleteHierarchyVersion() throws Exception {
        getLeftNavigationBarLinks("Delete Version").click();
        acceptAlert();
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
        switchToPopup();
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
        getCommentsTextBoxOnDeleteHierarchyPopup().sendKeys("Automation Delete");
        getButtonOnDeleteHierarchyPopup("Delete").click();
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
        switchToDefaultWindow();
    }

    public void addHierarchyVersion(String newVersionName) throws Exception {
        getLeftNavigationBarLinks("Add Version").click();
        switchToPopup();
        get_ohierarchy_name().sendKeys(newVersionName);
        get_ohierarchy_startDate().click();
        get_ohierarchy_firstActiveDate().click();
        get_ohierarchy_save().click();
        switchToDefaultWindow();
    }

    public void deleteRelationship() throws Exception {
    	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
        getLeftNavigationBarLinks("Delete Relationship").click();
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
        switchToPopup();
        SetWebDrivers.getDriver().switchTo().frame("addVersionframe");
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
        getCommentsTextBoxOnDeleteHierarchyPopup().sendKeys("Automation Delete");
        getButtonOnDeleteHierarchyPopup("Delete").click();
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
        switchToDefaultWindow();
    }


    // Deletes Relationship and Returns parent of the deleted position
    public String deleteRelationshipReturnParentString() throws Exception {
        String parentString = null;
        getLeftNavigationBarLinks("Delete Relationship").click();
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
        switchToPopup();
        SetWebDrivers.getDriver().switchTo().frame("addVersionframe");
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);

        parentString = getDeleteFormParentPositionOnDeleteHierarchyPopup().getAttribute("value");

        getCommentsTextBoxOnDeleteHierarchyPopup().sendKeys("Automation Delete");
        getButtonOnDeleteHierarchyPopup("Delete").click();
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
        switchToDefaultWindow();
        return parentString;
    }

    /****
     * Methods which are using Hierarchy API response
     ****/

    public int getTotalRelationshipCount(String xbaseSessionId, String endDate, Integer positionId) throws Exception {
        List<Integer> positionIdList = getAllPositionIdsFromHierarchy(xbaseSessionId, endDate, positionId);
        return positionIdList.size();
    }

    public Response getAllChildPositions(String xbaseSessionId, String endDate, Integer positionId) throws Exception {
        String requestURL = path + "/" + xbaseSessionId + "/hierarchy/" + endDate;
        if(positionId != null) {
            requestURL = requestURL + "/" + positionId;
        }
        Response response = rest.getRestAPIResponseUsingBaseURI(requestURL);
        return response;
    }

    public List<Integer> getAllPositionIdsFromHierarchy(String xbaseSessionId, String endDate, Integer positionId) throws Exception {
        Response response = getAllChildPositions(xbaseSessionId, endDate, positionId);
        List<Integer> positionIdList = response.jsonPath().getList("positionId");
        List<Integer> finalPositionIds = new ArrayList();
        finalPositionIds.addAll(positionIdList);
        for(Integer id : positionIdList) {
            finalPositionIds.addAll(getAllPositionIdsFromHierarchy(xbaseSessionId, endDate, id));
        }
        return finalPositionIds;
    }

    public ArrayList<HashMap<String, String>> getChildHierarchyNodeDetailsAsMap(String xbaseSessionId, String endDate, Integer positionId) throws Exception {
        Response response = getAllChildPositions(xbaseSessionId, endDate, positionId);
        List<Integer> positionIdList = response.jsonPath().getList("positionId");
        logger.info("Number of child positions = " + positionIdList.size());
        ArrayList<HashMap<String,String>> hierarchyNodeDetails = new ArrayList<HashMap<String, String>>();
        for (int i = 0; i < positionIdList.size(); i++) {
            logger.info("position id = " + i + " === " + response.jsonPath().getList("positionId").get(i).toString());
            HashMap<String,String> temp = new HashMap<String, String>();
            temp.put("positionId", "" + response.jsonPath().getList("positionId").get(i).toString());
            temp.put("masterPositionId", "" + response.jsonPath().getList("masterPositionId").get(i).toString());
            temp.put("positionName", response.jsonPath().getList("positionName").get(i).toString());
            temp.put("fullName", response.jsonPath().getList("participant.fullName").get(i).toString());
            temp.put("firstName", response.jsonPath().getList("participant.firstName").get(i).toString());
            temp.put("lastName", response.jsonPath().getList("participant.lastName").get(i).toString());
            temp.put("employeeId", response.jsonPath().getList("participant.employeeId").get(i).toString());
            temp.put("childrenCount", response.jsonPath().getList("hierarchyInfo.childrenCount").get(i).toString());
            hierarchyNodeDetails.add(temp);
        }

        return hierarchyNodeDetails;
    }

    public Boolean assertElementNotPresent(String xPath) {
        Boolean elementNotPresent = null;

        if (SetWebDrivers.getDriver().findElements(By.xpath(xPath)).size() < 1) {
            elementNotPresent = true;
        }

        return elementNotPresent;
    }



}
