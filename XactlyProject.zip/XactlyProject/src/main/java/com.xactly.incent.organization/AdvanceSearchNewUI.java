package com.xactly.incent.organization;
import java.util.ArrayList;

import java.util.List;
import org.apache.log4j.Logger;

import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;
import com.xactly.xcommons.selenium.SeleniumHelperClass;


public class AdvanceSearchNewUI {
	
	public static Logger logger = Logger.getLogger(HierarchyPage.class.getName());
	SoftAssert softAssert = new SoftAssert();
	static int num=0;
	static List <WebElement> list= new ArrayList<WebElement>();


	public WebElement advanceSearchButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@class='externalFilter']//child::button[contains(@class,'btn-bareIcon')]", "MainFrame"));
	}
	
	public WebElement selectFieldInAdvSearch() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[text()='Select Field']", "MainFrame"));
	}
	public WebElement selectParentPositionOption(String selectedBy, String getDataFromCol,int i) throws Exception {
		return(SeleniumHelperClass.findWebElementbyXpath("(//button[@id='"+getDataFromCol+"']//div[text()='"+selectedBy+"'])["+i+"]","MainFrame"));
	}
	public WebElement selectOperator(String operator, int i) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[text()='Select Operator']//following::button[@id='"+operator+"']", "MainFrame"));
	}
	public WebElement clickSelectOperator() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[text()='Select Operator']", "MainFrame"));
	}
	public WebElement enterValueOption(int i) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("(//*[contains(@placeholder, 'Enter')])["+i+"]", "MainFrame"));
	}
	public WebElement clickAddRowButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[text()='Add Row']", "MainFrame"));
	}
	public WebElement clickApplyButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[text()='Apply']", "MainFrame"));
	}
	public WebElement clickCancelButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[text()='Cancel']", "MainFrame"));
	}
	public WebElement resetButtonInAdvanceSearch() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[text()='Reset']", "MainFrame"));
	}
	public WebElement selectOptionList() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[contains(@id,'1_logicalOp_dropdownValue_value')]", "MainFrame"));
	}
	public WebElement selectOption(String option) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[@id='"+option+"']", "MainFrame"));
	}
	public WebElement getHierarchyCount() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[contains(@class,'h-3')]", "MainFrame"));
	}
	public List<WebElement> getValueFromcellist(String colName) throws Exception {
		return (List<WebElement>) (SeleniumHelperClass.findWebElements("//*[@col-id='"+colName+"' and contains(@class,'ag-cell')]", "MainFrame"));
	}

	public WebElement getValueFromcel(String colName,int i) throws Exception {
		
		return (SeleniumHelperClass.findWebElementbyXpath("(//*[@col-id='"+colName+"' and contains(@class,'ag-cell')])["+i+"]", "MainFrame"));
	}
	public WebElement getValueFromcell(String colName) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@col-id='"+colName+"' and contains(@class,'ag-cell')]", "MainFrame"));
	}

	public WebElement selectCheckBox(String check, int i) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[text()='"+check+"']//preceding::div[1]", "MainFrame"));		
	}
	public WebElement selectParentListButton(int i) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("(//button[contains(@class,'btn-bareIcon')])["+i+"]", "MainFrame"));
	}
	public WebElement clickSelectButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[text()='Select']", "MainFrame"));
	}
	public WebElement getFirstName(int i) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("(//*[@col-id='SelectAll']//following::div[@col-id='firstName'])["+i+"]", "MainFrame"));
	}
	public WebElement selectPersonName(int i) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("(//input[contains(@placeholder, 'Search')])["+i+"]", "MainFrame"));
	}
	public WebElement clickEnter(int i) throws Exception {
			return (SeleniumHelperClass.findWebElementbyXpath("(//*[@data-testid='search-icon'])["+i+"]", "MainFrame"));
		}
	public WebElement clearButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@title='clear']", "MainFrame"));
	}	
	
	/**
	 * In this method I am testing multiple records or condition but using the same
	 * select field option(Equals/Not Equals/ Contains/In) with same operator in a set of condition.
	 * Max conditions we can test in on set of query =10
	 * So I tested till 10 conditions with different data.
	 * @param noOfCondition
	 * @param selectedBy
	 * @param getDataFromCol
	 * @param operator
	 * @param option
	 * @param searchingText1
	 * @param searchingText2
	 * @param searchingText3
	 * @param searchingText4
	 * @param searchingText5
	 * @param searchingText6
	 * @param searchingText7
	 * @param searchingText8
	 * @param searchingText9
	 * @param searchingText10
	 * @return
	 * @throws Exception
	 */
	public boolean advanceSearchTabWithSameField(int noOfCondition, String selectedBy,String dropDownId, String getDataFromCol,String operator,String option,String searchingText1,String searchingText2, String searchingText3, String searchingText4, String searchingText5,String searchingText6,String searchingText7,String searchingText8,String searchingText9,String searchingText10) throws Exception
	{
			boolean flag=true;
			String opt=operator;
			num=getSearchedHirarchyCount();
				logger.info("NUM   "+num);
		if(noOfCondition==1)
		{
			if(operator.equalsIgnoreCase("Equals") || operator.equalsIgnoreCase("NotEquals"))
			{
			selectFieldInAdvSearch().click();
			SeleniumHelperClass.waitForElmentToBeReady(clickApplyButton());
			selectParentPositionOption(selectedBy,dropDownId,1).click();
			
			clickSelectOperator().click();
			
			selectOperator(operator,1).click();
		
			enterValueOption(1).sendKeys(searchingText1);
			clickApplyButton().click();
			
			flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);

			logger.info(operator+"   "+flag);
			}
			else if(operator.equalsIgnoreCase("In"))
			{
				logger.info("IN    NoOfCondition 1");
				selectFieldInAdvSearch().click();
				SeleniumHelperClass.waitForElmentToBeReady(clickApplyButton());

					selectParentPositionOption(selectedBy,dropDownId,1).click();
					clickSelectOperator().click();
					selectOperator(operator,1).click();
					selectParentListButton(2).click();
					selectPersonName(2).sendKeys(searchingText1);
					clickEnter(2).click();
					
					selectCheckBox(searchingText1,1).click();
					clickSelectButton().click();
					clickApplyButton().click();	
					flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);
					
				}
			else if(operator.equalsIgnoreCase("Contains"))
			{
				selectFieldInAdvSearch().click();
				SeleniumHelperClass.waitForElmentToBeReady(clickApplyButton());
				selectParentPositionOption(selectedBy,dropDownId,1).click();
				clickSelectOperator().click();
				
				selectOperator(operator,1).click();
			
				enterValueOption(1).sendKeys(searchingText1);
				clickApplyButton().click();
				SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());
				
				list=getValueFromcellist(getDataFromCol);
				flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);
			}
		}
						
		if(noOfCondition==2)
			{
			logger.info("Option   "+option);
		
				if(opt.equalsIgnoreCase("Equals") || opt.equalsIgnoreCase("NotEquals") || opt.equalsIgnoreCase("Contains"))
				{
					logger.info("Condition 2 : Equals : Not Equals : Contains");
				
					selectFieldInAdvSearch().click();
					SeleniumHelperClass.waitForElmentToBeReady(clickApplyButton());
					selectParentPositionOption(selectedBy,dropDownId,1).click();
					clickSelectOperator().click();
			
					selectOperator(opt,1).click();
		
					enterValueOption(1).sendKeys(searchingText1);
					clickAddRowButton().click();
					selectOptionList().click();
					SeleniumHelperClass.waitForElmentToBeReady(clickApplyButton());
					selectOption(option).click();
			
					selectFieldInAdvSearch().click();
					SeleniumHelperClass.waitForElmentToBeReady(clickApplyButton());
					selectParentPositionOption(selectedBy,dropDownId,2).click();
					clickSelectOperator().click();
			
					selectOperator(opt,2).click();
		
					enterValueOption(2).sendKeys(searchingText2);
					clickApplyButton().click();	
					
					SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());
					list=getValueFromcellist(getDataFromCol);
					flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);

			}
				else if (opt.equalsIgnoreCase("In"))
				{
					logger.info("IN    NoOfCondition 2");
					selectFieldInAdvSearch().click();
					SeleniumHelperClass.waitForElmentToBeReady(clickApplyButton());
					selectParentPositionOption(selectedBy,dropDownId,1).click();
					clickSelectOperator().click();
					selectOperator(opt,1).click();
					selectParentListButton(2).click();
					selectPersonName(2).sendKeys(searchingText1);
					clickEnter(2).click();
					
					selectCheckBox(searchingText1,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText2);
					clickEnter(2).click();
					
					selectCheckBox(searchingText2,1).click();
					clickSelectButton().click();
					clickApplyButton().click();	
					SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());
					
					list=getValueFromcellist(getDataFromCol);
		
					flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);
					
				}
			}
			if(noOfCondition==3)
			{
				if(opt.equalsIgnoreCase("Equals") || opt.equalsIgnoreCase("NotEquals") || opt.equalsIgnoreCase("Contains"))
				{
					logger.info("noOfCondition   3");
					selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,1).click();
				clickSelectOperator().click();
				
				selectOperator(opt,1).click();
			
				enterValueOption(1).sendKeys(searchingText1);
				clickAddRowButton().click();
				selectOptionList().click();
				selectOption(option).click();
				
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,2).click();
				clickSelectOperator().click();
				
				selectOperator(opt,2).click();
			
				enterValueOption(2).sendKeys(searchingText2);
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,3).click();
				clickSelectOperator().click();
				
				selectOperator(opt,3).click();
			
				enterValueOption(3).sendKeys(searchingText3);
				clickApplyButton().click();
				SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());		
				list=getValueFromcellist(getDataFromCol);		
				int size=list.size();
				logger.info("SIZE   "+size);
				flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);

				}
				else if (opt.equalsIgnoreCase("In"))
				{
					logger.info("IN    noOfCondition==3");
					selectFieldInAdvSearch().click();
					selectParentPositionOption(selectedBy,dropDownId,1).click();
					clickSelectOperator().click();
					selectOperator(opt,1).click();
					selectParentListButton(2).click();
					selectPersonName(2).sendKeys(searchingText1);
					clickEnter(2).click();
					
					selectCheckBox(searchingText1,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText2);
					clickEnter(2).click();
					selectCheckBox(searchingText2,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText3);
					clickEnter(2).click();
					selectCheckBox(searchingText3,1).click();
					clickSelectButton().click();
					clickApplyButton().click();	
					//SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());
					SeleniumHelperClass.waitForPageToLoad("MainFrame");
					
					list=getValueFromcellist(getDataFromCol);
		
					flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);
					
				}
			}
			else if(noOfCondition==4)
			{
				if(opt.equalsIgnoreCase("Equals") || opt.equalsIgnoreCase("NotEquals") || opt.equalsIgnoreCase("Contains"))
				{
					logger.info("noOfCondition   4");
					selectFieldInAdvSearch().click();
					selectParentPositionOption(selectedBy,dropDownId,1).click();
					clickSelectOperator().click();
					selectOperator(opt,1).click();
					enterValueOption(1).sendKeys(searchingText1);
					clickAddRowButton().click();
					selectOptionList().click();
					selectOption(option).click();
					
					selectFieldInAdvSearch().click();
					selectParentPositionOption(selectedBy,dropDownId,2).click();
					clickSelectOperator().click();
					selectOperator(opt,2).click();
					enterValueOption(2).sendKeys(searchingText2);
					clickAddRowButton().click();
					
					selectFieldInAdvSearch().click();
					selectParentPositionOption(selectedBy,dropDownId,3).click();
					clickSelectOperator().click();
					selectOperator(opt,3).click();
					enterValueOption(3).sendKeys(searchingText3);
					clickAddRowButton().click();
					selectFieldInAdvSearch().click();
					selectParentPositionOption(selectedBy,dropDownId,4).click();
					clickSelectOperator().click();
					selectOperator(opt,4).click();
					enterValueOption(4).sendKeys(searchingText4);
					clickApplyButton().click();
					SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());
					list=getValueFromcellist(getDataFromCol);				
					flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);

				}
				else
				{
					logger.info("IN    noOfCondition==4");
					selectFieldInAdvSearch().click();
					selectParentPositionOption(selectedBy,dropDownId,1).click();
					clickSelectOperator().click();
					selectOperator(opt,1).click();
					selectParentListButton(2).click();
					selectPersonName(2).sendKeys(searchingText1);
					clickEnter(2).click();
					
					selectCheckBox(searchingText1,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText2);
					clickEnter(2).click();
					selectCheckBox(searchingText2,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText3);
					clickEnter(2).click();
					selectCheckBox(searchingText3,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText4);
					clickEnter(2).click();
					selectCheckBox(searchingText4,1).click();
					
					clickSelectButton().click();
					clickApplyButton().click();	
					SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());
					
					list=getValueFromcellist(getDataFromCol);
		
					flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);
					
				}
			}
			else if(noOfCondition==5)
			{
				if(opt.equalsIgnoreCase("Equals") || opt.equalsIgnoreCase("NotEquals") || opt.equalsIgnoreCase("Contains"))
				{
					logger.info("noOfCondition   5");
					selectFieldInAdvSearch().click();
					selectParentPositionOption(selectedBy,dropDownId,1).click();
					clickSelectOperator().click();
					selectOperator(opt,1).click();
					enterValueOption(1).sendKeys(searchingText1);
					clickAddRowButton().click();
					selectOptionList().click();
					selectOption(option).click();
					
					selectFieldInAdvSearch().click();
					selectParentPositionOption(selectedBy,dropDownId,2).click();
					clickSelectOperator().click();
					selectOperator(opt,2).click();
					enterValueOption(2).sendKeys(searchingText2);
					clickAddRowButton().click();
					
					selectFieldInAdvSearch().click();
					selectParentPositionOption(selectedBy,dropDownId,3).click();
					clickSelectOperator().click();
					selectOperator(opt,3).click();
					enterValueOption(3).sendKeys(searchingText3);
					clickAddRowButton().click();
					selectFieldInAdvSearch().click();
					selectParentPositionOption(selectedBy,dropDownId,4).click();
					clickSelectOperator().click();
					selectOperator(opt,4).click();
					enterValueOption(4).sendKeys(searchingText4);
					clickAddRowButton().click();
					selectFieldInAdvSearch().click();
					selectParentPositionOption(selectedBy,dropDownId,5).click();
					clickSelectOperator().click();
					selectOperator(opt,5).click();
					enterValueOption(5).sendKeys(searchingText5);
					
					clickApplyButton().click();
					
					SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());		
					list=getValueFromcellist(getDataFromCol);		
					
					flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);

				}
				else
				{
					logger.info("IN    noOfCondition==5");
					selectFieldInAdvSearch().click();
					selectParentPositionOption(selectedBy,dropDownId,1).click();
					clickSelectOperator().click();
					selectOperator(opt,1).click();
					selectParentListButton(2).click();
					selectPersonName(2).sendKeys(searchingText1);
					clickEnter(2).click();
					
					selectCheckBox(searchingText1,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText2);
					clickEnter(2).click();
					selectCheckBox(searchingText2,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText3);
					clickEnter(2).click();
					selectCheckBox(searchingText3,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText4);
					clickEnter(2).click();
					selectCheckBox(searchingText4,1).click();
					
					clickSelectButton().click();
					clickApplyButton().click();
					
					SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());
					
					list=getValueFromcellist(getDataFromCol);
					
					flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);
					
				}
			}

			
			else if(noOfCondition==6)
			{
				if(opt.equalsIgnoreCase("Equals") || opt.equalsIgnoreCase("NotEquals") || opt.equalsIgnoreCase("Contains"))
				{
					
					selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,1).click();
				clickSelectOperator().click();
				
				selectOperator(opt,1).click();
			
				enterValueOption(1).sendKeys(searchingText1);
				clickAddRowButton().click();
				selectOptionList().click();
				selectOption(option).click();
				
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,2).click();
				clickSelectOperator().click();
				
				selectOperator(opt,2).click();
			
				enterValueOption(2).sendKeys(searchingText2);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,3).click();
				clickSelectOperator().click();
				
				selectOperator(opt,3).click();
			
				enterValueOption(3).sendKeys(searchingText3);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,4).click();
				clickSelectOperator().click();
				
				selectOperator(opt,4).click();
			
				enterValueOption(4).sendKeys(searchingText4);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,5).click();
				clickSelectOperator().click();
				
				selectOperator(opt,5).click();
			
				enterValueOption(5).sendKeys(searchingText5);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,6).click();
				clickSelectOperator().click();
				
				selectOperator(opt,6).click();
			
				enterValueOption(6).sendKeys(searchingText6);
				clickApplyButton().click();	
				SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());
				list=getValueFromcellist(getDataFromCol);
				logger.info("LIST SIZE "+list.size());
				flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);

				}
				else
				{
					logger.info("IN    NoOfCondition 6");
					selectFieldInAdvSearch().click();
					selectParentPositionOption(selectedBy,dropDownId,1).click();
					clickSelectOperator().click();
					
					selectOperator(opt,1).click();
					selectParentListButton(2).click();
					selectPersonName(2).sendKeys(searchingText1);
					clickEnter(2).click();
					
					selectCheckBox(searchingText1,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText2);
					clickEnter(2).click();
					selectCheckBox(searchingText2,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText3);
					clickEnter(2).click();
					selectCheckBox(searchingText3,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText4);
					clickEnter(2).click();
					selectCheckBox(searchingText4,1).click();
					clearButton().click();	
					selectPersonName(2).sendKeys(searchingText5);
					clickEnter(2).click();
					selectCheckBox(searchingText5,1).click();
					clearButton().click();
					
					selectPersonName(2).sendKeys(searchingText6);
					clickEnter(2).click();
					selectCheckBox(searchingText6,1).click();
					clearButton().click();
					
					
					clickSelectButton().click();
					clickApplyButton().click();	
					SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());
					list=getValueFromcellist(getDataFromCol);
					flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);
	
				}
			}

			
			else if(noOfCondition==7)
			{
				if(opt.equalsIgnoreCase("Equals") || opt.equalsIgnoreCase("NotEquals") || opt.equalsIgnoreCase("Contains"))
				{
					
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,1).click();
				clickSelectOperator().click();
				
				selectOperator(opt,1).click();
			
				enterValueOption(1).sendKeys(searchingText1);
				clickAddRowButton().click();
				selectOptionList().click();
				selectOption(option).click();
				
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,2).click();
				clickSelectOperator().click();
				
				selectOperator(opt,2).click();
			
				enterValueOption(2).sendKeys(searchingText2);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,3).click();
				clickSelectOperator().click();
				
				selectOperator(opt,3).click();
			
				enterValueOption(3).sendKeys(searchingText3);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,4).click();
				clickSelectOperator().click();
				
				selectOperator(opt,4).click();
			
				enterValueOption(4).sendKeys(searchingText4);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,5).click();
				clickSelectOperator().click();
				
				selectOperator(opt,5).click();
				enterValueOption(5).sendKeys(searchingText5);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,6).click();
				clickSelectOperator().click();
				
				selectOperator(opt,6).click();
				enterValueOption(6).sendKeys(searchingText6);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,7).click();
				clickSelectOperator().click();
				
				selectOperator(opt,7).click();
			
				enterValueOption(7).sendKeys(searchingText7);
				clickApplyButton().click();	
			
				SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());
				list=getValueFromcellist(getDataFromCol);
				
				logger.info("List1:::"+list.size());
		
				flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);

				}
				else
				{
					logger.info("IN    NoOfCondition 7");
					selectFieldInAdvSearch().click();
					
					selectParentPositionOption(selectedBy,dropDownId,1).click();
					clickSelectOperator().click();
					
					selectOperator(opt,1).click();
					selectParentListButton(2).click();
					
					selectPersonName(2).sendKeys(searchingText1);
					clickEnter(2).click();
					
					selectCheckBox(searchingText1,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText2);
					clickEnter(2).click();
					selectCheckBox(searchingText2,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText3);
					clickEnter(2).click();
					selectCheckBox(searchingText3,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText4);
					clickEnter(2).click();
					selectCheckBox(searchingText4,1).click();
					clearButton().click();
					
					selectPersonName(2).sendKeys(searchingText5);
					clickEnter(2).click();
					selectCheckBox(searchingText5,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText6);
					clickEnter(2).click();
					selectCheckBox(searchingText6,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText7);
					clickEnter(2).click();
					selectCheckBox(searchingText7,1).click();

					clickSelectButton().click();
					clickApplyButton().click();	
					SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());
					list=getValueFromcellist(getDataFromCol);
					flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);
				}
			}
		
			else if(noOfCondition==8)
			{
				if(opt.equalsIgnoreCase("Equals") || opt.equalsIgnoreCase("NotEquals") || opt.equalsIgnoreCase("Contains"))
				{
					
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,1).click();
				clickSelectOperator().click();
				
				selectOperator(opt,1).click();
			
				enterValueOption(1).sendKeys(searchingText1);
				clickAddRowButton().click();
				selectOptionList().click();
				selectOption(option).click();
				
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,2).click();
				clickSelectOperator().click();
				
				selectOperator(opt,2).click();
			
				enterValueOption(2).sendKeys(searchingText2);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,3).click();
				clickSelectOperator().click();
				
				selectOperator(opt,3).click();
			
				enterValueOption(3).sendKeys(searchingText3);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,4).click();
				clickSelectOperator().click();
				
				selectOperator(opt,4).click();
			
				enterValueOption(4).sendKeys(searchingText4);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,5).click();
				clickSelectOperator().click();
				
				selectOperator(opt,5).click();
				enterValueOption(5).sendKeys(searchingText5);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,6).click();
				clickSelectOperator().click();
				
				
				selectOperator(opt,6).click();
				enterValueOption(6).sendKeys(searchingText6);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,7).click();
				clickSelectOperator().click();
				
				selectOperator(opt,7).click();
			
				enterValueOption(7).sendKeys(searchingText7);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,8).click();
				clickSelectOperator().click();
				
				selectOperator(opt,8).click();
			
				enterValueOption(8).sendKeys(searchingText8);
				
				clickApplyButton().click();	
			
				SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());
				list=getValueFromcellist(getDataFromCol);
				
				logger.info("List1:::"+list.size());
		
				flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);

				}
				else
				{
					logger.info("IN    NoOfCondition 8");
					selectFieldInAdvSearch().click();
					
					selectParentPositionOption(selectedBy,dropDownId,1).click();
					clickSelectOperator().click();
					
					selectOperator(opt,1).click();
					selectParentListButton(2).click();
					
					selectPersonName(2).sendKeys(searchingText1);
					clickEnter(2).click();
					
					selectCheckBox(searchingText1,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText2);
					clickEnter(2).click();
					selectCheckBox(searchingText2,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText3);
					clickEnter(2).click();
					selectCheckBox(searchingText3,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText4);
					clickEnter(2).click();
					selectCheckBox(searchingText4,1).click();
					clearButton().click();
					
					selectPersonName(2).sendKeys(searchingText5);
					clickEnter(2).click();
					selectCheckBox(searchingText5,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText6);
					clickEnter(2).click();
					selectCheckBox(searchingText6,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText7);
					clickEnter(2).click();
					selectCheckBox(searchingText7,1).click();
					
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText8);
					clickEnter(2).click();
					selectCheckBox(searchingText8,1).click();


					clickSelectButton().click();
					clickApplyButton().click();	
					SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());
					list=getValueFromcellist(getDataFromCol);
					flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);
				}
			}
		
			else if(noOfCondition==9)
			{
				if(opt.equalsIgnoreCase("Equals") || opt.equalsIgnoreCase("NotEquals") || opt.equalsIgnoreCase("Contains"))
				{
					
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,1).click();
				clickSelectOperator().click();
				
				selectOperator(opt,1).click();
			
				enterValueOption(1).sendKeys(searchingText1);
				clickAddRowButton().click();
				selectOptionList().click();
				selectOption(option).click();
				
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,2).click();
				clickSelectOperator().click();
				
				selectOperator(opt,2).click();
			
				enterValueOption(2).sendKeys(searchingText2);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,3).click();
				clickSelectOperator().click();
				
				selectOperator(opt,3).click();
			
				enterValueOption(3).sendKeys(searchingText3);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,4).click();
				clickSelectOperator().click();
				
				selectOperator(opt,4).click();
			
				enterValueOption(4).sendKeys(searchingText4);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,5).click();
				clickSelectOperator().click();
				
				selectOperator(opt,5).click();
				enterValueOption(5).sendKeys(searchingText5);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,6).click();
				clickSelectOperator().click();
				
				selectOperator(opt,6).click();
				enterValueOption(6).sendKeys(searchingText6);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,7).click();
				clickSelectOperator().click();
				
				selectOperator(opt,7).click();
			
				enterValueOption(7).sendKeys(searchingText7);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,8).click();
				clickSelectOperator().click();
				
				selectOperator(opt,8).click();
			
				enterValueOption(8).sendKeys(searchingText8);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,9).click();
				clickSelectOperator().click();
				
				selectOperator(opt,9).click();
			
				enterValueOption(9).sendKeys(searchingText9);
				
				clickApplyButton().click();	
			
				SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());
				list=getValueFromcellist(getDataFromCol);
				
				logger.info("List1:::"+list.size());
		
				flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);

				}
				else
				{
					logger.info("IN    NoOfCondition 9");
					selectFieldInAdvSearch().click();
					
					selectParentPositionOption(selectedBy,dropDownId,1).click();
					clickSelectOperator().click();
					
					selectOperator(opt,1).click();
					selectParentListButton(2).click();
					
					selectPersonName(2).sendKeys(searchingText1);
					clickEnter(2).click();
					
					selectCheckBox(searchingText1,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText2);
					clickEnter(2).click();
					selectCheckBox(searchingText2,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText3);
					clickEnter(2).click();
					selectCheckBox(searchingText3,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText4);
					clickEnter(2).click();
					selectCheckBox(searchingText4,1).click();
					clearButton().click();
					
					selectPersonName(2).sendKeys(searchingText5);
					clickEnter(2).click();
					selectCheckBox(searchingText5,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText6);
					clickEnter(2).click();
					selectCheckBox(searchingText6,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText7);
					clickEnter(2).click();
					selectCheckBox(searchingText7,1).click();
					
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText8);
					clickEnter(2).click();
					selectCheckBox(searchingText8,1).click();

					clearButton().click();
					selectPersonName(2).sendKeys(searchingText9);
					clickEnter(2).click();
					selectCheckBox(searchingText9,1).click();


					clickSelectButton().click();
					clickApplyButton().click();	
					SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());
					list=getValueFromcellist(getDataFromCol);
					flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);
				}
			}
		
		
			else if(noOfCondition==10)
			{
				if(opt.equalsIgnoreCase("Equals") || opt.equalsIgnoreCase("NotEquals") || opt.equalsIgnoreCase("Contains"))
				{
					
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,1).click();
				clickSelectOperator().click();
				
				selectOperator(opt,1).click();
			
				enterValueOption(1).sendKeys(searchingText1);
				clickAddRowButton().click();
				selectOptionList().click();
				selectOption(option).click();
				
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,2).click();
				clickSelectOperator().click();
				
				selectOperator(opt,2).click();
			
				enterValueOption(2).sendKeys(searchingText2);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,3).click();
				clickSelectOperator().click();
				
				selectOperator(opt,3).click();
			
				enterValueOption(3).sendKeys(searchingText3);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,4).click();
				clickSelectOperator().click();
				
				selectOperator(opt,4).click();
			
				enterValueOption(4).sendKeys(searchingText4);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,5).click();
				clickSelectOperator().click();
				
				selectOperator(opt,5).click();
				enterValueOption(5).sendKeys(searchingText5);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,6).click();
				clickSelectOperator().click();
				
				selectOperator(opt,6).click();
				enterValueOption(6).sendKeys(searchingText6);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,7).click();
				clickSelectOperator().click();
				
				selectOperator(opt,7).click();
			
				enterValueOption(7).sendKeys(searchingText7);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,8).click();
				clickSelectOperator().click();
				
				selectOperator(opt,8).click();
			
				enterValueOption(8).sendKeys(searchingText8);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,9).click();
				clickSelectOperator().click();
				selectOperator(opt,9).click();
				enterValueOption(9).sendKeys(searchingText9);
				
				clickAddRowButton().click();
				selectFieldInAdvSearch().click();
				selectParentPositionOption(selectedBy,dropDownId,10).click();
				clickSelectOperator().click();
				selectOperator(opt,10).click();
				enterValueOption(10).sendKeys(searchingText10);
				clickApplyButton().click();	
			
				SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());
				list=getValueFromcellist(getDataFromCol);
				
				logger.info("List1:::"+list.size());
		
				flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);

				}
				else
				{
					logger.info("IN    NoOfCondition 10");
					selectFieldInAdvSearch().click();
					
					selectParentPositionOption(selectedBy,dropDownId,1).click();
					clickSelectOperator().click();
					
					selectOperator(opt,1).click();
					selectParentListButton(2).click();
					
					selectPersonName(2).sendKeys(searchingText1);
					clickEnter(2).click();
					
					selectCheckBox(searchingText1,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText2);
					clickEnter(2).click();
					selectCheckBox(searchingText2,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText3);
					clickEnter(2).click();
					selectCheckBox(searchingText3,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText4);
					clickEnter(2).click();
					selectCheckBox(searchingText4,1).click();
					clearButton().click();
					
					selectPersonName(2).sendKeys(searchingText5);
					clickEnter(2).click();
					selectCheckBox(searchingText5,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText6);
					clickEnter(2).click();
					selectCheckBox(searchingText6,1).click();
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText7);
					clickEnter(2).click();
					selectCheckBox(searchingText7,1).click();
					
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText8);
					clickEnter(2).click();
					selectCheckBox(searchingText8,1).click();
					
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText9);
					clickEnter(2).click();
					selectCheckBox(searchingText9,1).click();
					
					clearButton().click();
					selectPersonName(2).sendKeys(searchingText10);
					clickEnter(2).click();
					selectCheckBox(searchingText10,1).click();

					clickSelectButton().click();
					clickApplyButton().click();	
					SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());
					list=getValueFromcellist(getDataFromCol);
					flag=verifyMultipleConditionRecord(noOfCondition,selectedBy,getDataFromCol,opt,option,searchingText1,searchingText2,searchingText3,searchingText4,searchingText5,searchingText6,searchingText7,searchingText8,searchingText9,searchingText10);
				}
			}
		
		return flag;
		}
		
		/**
		 * In this method I am verify all condition of advanceSearchTabWithSameField()
		 * and sending the final result to test class for assertion.
		 * @param noOfCondition
		 * @param selectedBy
		 * @param getDataFromCol
		 * @param operator
		 * @param option
		 * @param searchingText1
		 * @param searchingText2
		 * @param searchingText3
		 * @param searchingText4
		 * @param searchingText5
		 * @param searchingText6
		 * @param searchingText7
		 * @param searchingText8
		 * @param searchingText9
		 * @param searchingText10
		 * @return
		 * @throws Exception
		 */
		public boolean verifyMultipleConditionRecord(int noOfCondition, String selectedBy,String getDataFromCol,String operator,String option, String searchingText1, String searchingText2,String searchingText3, String searchingText4, String searchingText5,String searchingText6,String searchingText7,String searchingText8, String searchingText9, String searchingText10) throws Exception
		{
			boolean flag=true;
			int size=list.size();
			logger.info("SIZEccc   "+size);
			
			switch(noOfCondition){
			case 1:num=getSearchedHirarchyCount();
			logger.info("No of searched Records 1:"+"     "+operator);
			if(operator.equalsIgnoreCase("Equals"))//|| (operator.equalsIgnoreCase("In")))
			{
				String ExpectedparentPos=getValueFromcell(getDataFromCol).getText();
				logger.info("EQUAL::"+searchingText1+"::"+ExpectedparentPos);
					if(!searchingText1.equalsIgnoreCase(ExpectedparentPos))
					{
						flag=false;
						logger.info("Verification Case1 failed : Equals");
						break;
					}
			}
			else if(operator.equalsIgnoreCase("NotEquals"))
			{
				list=getValueFromcellist(getDataFromCol);
				for(int i=0;i<list.size();i++)
				{
					
					if(list.get(i).getText().equalsIgnoreCase(searchingText1))
					{
						flag=false;
						logger.info("Verification Case1 failed : NotEquals "+list.get(i).getText());
						break;
					}
				}
			}
			else if(operator.equalsIgnoreCase("Contains"))
			{
				logger.info("Contains   "+list.size());
				for(int i=0;i<list.size();i++)
				{
					if(!list.get(i).getText().contains(searchingText1))
					{
						flag=false;	
						logger.info("Verification Case1 failed : Contains");
						break;
					}
				}
			}
				else if (operator.equalsIgnoreCase("In"))
				{
					logger.info("VerifyIn");
					list=getValueFromcellist(getDataFromCol);
						for(int i=0;i<size;i++)
						{
							
							if(!(list.get(i).getText().equalsIgnoreCase(searchingText1)) && !(list.get(i).getText().equalsIgnoreCase(searchingText2)) && !(list.get(i).getText().equalsIgnoreCase(searchingText3)))
							{
								
								flag=false;
								logger.info("Case 1 with IN option");
								break;
							
							}
						}
			}
			break;
			
			case 2: for(int i=0;i<size;i++)
					{
					if((operator.equalsIgnoreCase("Equals")) || (operator.equalsIgnoreCase("In")) || (operator.equalsIgnoreCase("Contains")))// && (option.equalsIgnoreCase("Or")))
					{
						logger.info("Number of conditions 2 with Operator (Equal or In) with Option 'OR'");
					
						if(!list.get(i).getText().equalsIgnoreCase(searchingText1) && !list.get(i).getText().equalsIgnoreCase(searchingText2))
							{
							flag=false;
							logger.info("Case 2 Equals or IN with OR Option::False111");
							break;
						
						
							}
					}
					else if ((operator.equalsIgnoreCase("NotEquals")))// && (option.equalsIgnoreCase("Or")))
					{
						if(list.contains(searchingText1) || list.contains(searchingText2))
						{
							flag=false;
							logger.info("Case 2 Not Equals with OR Option::False");
							break;
						
						}
					}
					else if((operator.equalsIgnoreCase("Contains")))// && (option.equalsIgnoreCase("Or")))
					{
						if(!list.get(i).getText().contains(searchingText1) || !list.get(i).getText().contains(searchingText2))
						{
							flag=false;
							logger.info("Case 2 Contains with OR Option::False");
							break;
						}
					}
					
					else if((operator.equalsIgnoreCase("Equals")) || (operator.equalsIgnoreCase("In")))// && (operator.equalsIgnoreCase("Contains"))// && (option.equalsIgnoreCase("And")))
					{
						logger.info("Number of conditions 2 with Operator (Equal or In) with Option 'AND'");
												
						if(!(list.contains(searchingText1)) && !(list.contains(searchingText2)))
						{
							flag=false;
							logger.info("Case 2 Equals or IN with AND Option::False");
							break;
						
						}
					}
					else if ((operator.equalsIgnoreCase("NotEquals")))// && (option.equalsIgnoreCase("And")))
					{
						if(list.contains(searchingText1) && list.contains(searchingText2))
						{
							flag=false;
							logger.info("Case 2 Not Equals with AND Option::False");
							break;
						}
					}
					else if((operator.equalsIgnoreCase("Contains")))// && (option.equalsIgnoreCase("And")))
					{
						if(!list.contains(searchingText1) && !list.get(i).getText().contains(searchingText2))
						{
							flag=false;
							logger.info("Case 2 Contains with AND Option::False");
							break;
						}
					}
					}
			
			break;
			case 3:for(int i=0;i<size;i++)
				{
				logger.info("With 3 conditions"+":"+list.size());
				if((operator.equalsIgnoreCase("Equals")) || (operator.equalsIgnoreCase("In")) && (option.equalsIgnoreCase("Or")))
				{
					if(!(list.get(i).getText().equalsIgnoreCase(searchingText1)) && !(list.get(i).getText().equalsIgnoreCase(searchingText2)) && !(list.get(i).getText().equalsIgnoreCase(searchingText3)))

					{
						flag=false;
						logger.info("Case 3 Equals or IN with OR Option::False");
						break;
				
					}
			}
			else if ((operator.equalsIgnoreCase("NotEquals")) && (option.equalsIgnoreCase("Or")))
			{
				if(list.get(i).getText().equalsIgnoreCase(searchingText1) || list.get(i).getText().equalsIgnoreCase(searchingText2) || (list.get(i).getText().equalsIgnoreCase(searchingText3)))
				{
					flag=false;
					logger.info("Case 3 Not Equals with OR Option::False");
					break;
				
				}
			}
			else if((operator.equalsIgnoreCase("Contains")) && (option.equalsIgnoreCase("Or")))
			{
				
				if(!list.get(i).getText().contains(searchingText1) && !list.get(i).getText().contains(searchingText2) && !(list.get(i).getText().contains(searchingText3)))
				{
					flag=false;
					logger.info("Case 3 Contains with OR Option::False");
					break;
				}
			}
				
			
			else if((operator.equalsIgnoreCase("Equals")) || (operator.equalsIgnoreCase("In")) && (option.equalsIgnoreCase("And")))
			{
				logger.info("Number of conditions 3 with Operator (Equal or In) with Option 'AND'");
				
				if(!(list.get(i).getText().equalsIgnoreCase(searchingText1)) && !(list.get(i).getText().equalsIgnoreCase(searchingText2))&& !(list.get(i).getText().equalsIgnoreCase(searchingText3)))
				{
					flag=false;
					logger.info("Case 3 Equals or In with And Option::False");
					break;
				
				}
			}
			else if ((operator.equalsIgnoreCase("NotEquals")) && (option.equalsIgnoreCase("And")))
			{
				if(list.get(i).getText().equalsIgnoreCase(searchingText1) && list.get(i).getText().equalsIgnoreCase(searchingText2) && (list.get(i).getText().equalsIgnoreCase(searchingText3)))
				{
					flag=false;
					logger.info("Case 3 Not Equals with And Option::False");
					break;
				}
			}
			else if((operator.equalsIgnoreCase("Contains")) && (option.equalsIgnoreCase("And")))
			{
				if(!list.get(i).getText().contains(searchingText1) && !list.get(i).getText().contains(searchingText2) && !list.get(i).getText().contains(searchingText3))
				{
					flag=false;
					logger.info("Case 3 Contains with And Option::False");
					break;
				
				}
			}		
	
			}
			break;
			case 4:for(int i=0;i<size;i++)
			{
				logger.info("With 4 conditions");
			if((operator.equalsIgnoreCase("Equals")) || (operator.equalsIgnoreCase("In")) && (option.equalsIgnoreCase("Or")))
			{
				if(!(list.get(i).getText().equalsIgnoreCase(searchingText1)) && !(list.get(i).getText().equalsIgnoreCase(searchingText2)) && !(list.get(i).getText().equalsIgnoreCase(searchingText3)) && !(list.get(i).getText().equalsIgnoreCase(searchingText4)))
				{
					flag=false;
					logger.info("Case4: Equals or IN with OR option failed");
					break;
			
				}
		}
		else if ((operator.equalsIgnoreCase("NotEquals")) && (option.equalsIgnoreCase("Or")))
		{
			if(list.get(i).getText().equalsIgnoreCase(searchingText1) || list.get(i).getText().equalsIgnoreCase(searchingText2) || (list.get(i).getText().equalsIgnoreCase(searchingText3)) || (list.get(i).getText().equalsIgnoreCase(searchingText4)))
			{
				flag=false;
				logger.info("Case4: Not Equals with OR option failed");
				break;
			
			}
		}
		else if ((operator.equalsIgnoreCase("Contains")) && (option.equalsIgnoreCase("Or")))
		{
			if(!list.get(i).getText().contains(searchingText1) && !list.get(i).getText().contains(searchingText2) && !(list.get(i).getText().contains(searchingText3)) && !(list.get(i).getText().contains(searchingText4)))
			{
				flag=false;
				logger.info("Case4: Contains with OR option failed");
				break;
			}
		}
			
			
			else if((operator.equalsIgnoreCase("Equals")) || (operator.equalsIgnoreCase("In")) && (option.equalsIgnoreCase("And")))
			{
				logger.info("Number of conditions 4 with Operator (Equal or In) with Option 'AND'");
				
				if(!(list.get(i).getText().equalsIgnoreCase(searchingText1)) && !(list.get(i).getText().equalsIgnoreCase(searchingText2)) && !(list.get(i).getText().equalsIgnoreCase(searchingText3)) && !(list.get(i).getText().equalsIgnoreCase(searchingText4)))
				{
					flag=false;
					logger.info("Case 4 Equals or In with And Option::False");
					break;
				
				}
			}
			else if ((operator.equalsIgnoreCase("NotEquals")) && (option.equalsIgnoreCase("And")))
			{
				if(list.get(i).getText().equalsIgnoreCase(searchingText1) && list.get(i).getText().equalsIgnoreCase(searchingText2) && (list.get(i).getText().equalsIgnoreCase(searchingText3)) && (list.get(i).getText().equalsIgnoreCase(searchingText4)))
				{
					flag=false;
					logger.info("Case 4 Not Equals with And Option::False");
					break;
				}
			}
			else if((operator.equalsIgnoreCase("Contains")) && (option.equalsIgnoreCase("And")))
			{
				if(!list.get(i).getText().contains(searchingText1) && !list.get(i).getText().contains(searchingText2) && !list.get(i).getText().contains(searchingText3) && !(list.get(i).getText().contains(searchingText4)))
				{
					flag=false;
					logger.info("Case 4 Contains with And Option::False");
					break;
				
				}
			}
			
		}
			break;
			case 5:for(int i=0;i<size;i++)
			{
				logger.info("With 5 conditions");
			if((operator.equalsIgnoreCase("Equals")) || (operator.equalsIgnoreCase("In")) && (option.equalsIgnoreCase("Or")))
			{
				if(!(list.get(i).getText().equalsIgnoreCase(searchingText1)) && !(list.get(i).getText().equalsIgnoreCase(searchingText2)) && !(list.get(i).getText().equalsIgnoreCase(searchingText3)) && !(list.get(i).getText().equalsIgnoreCase(searchingText4)) && !(list.get(i).getText().equalsIgnoreCase(searchingText5)))
				{
					flag=false;
					logger.info("VALUE:  "+list.get(i).getText());
					logger.info("Case5: Equals or IN with OR option failed");
					break;
				}
		}
		else if ((operator.equalsIgnoreCase("NotEquals")) && (option.equalsIgnoreCase("Or")))
		{
			if(list.get(i).getText().equalsIgnoreCase(searchingText1) || list.get(i).getText().equalsIgnoreCase(searchingText2) || (list.get(i).getText().equalsIgnoreCase(searchingText3)) || (list.get(i).getText().equalsIgnoreCase(searchingText4)) || (list.get(i).getText().equalsIgnoreCase(searchingText5)))
			{
				flag=false;
				logger.info("Case5: Not Equals with OR option failed");
				break;
			}
		}
		else if((operator.equalsIgnoreCase("Contains")) && (option.equalsIgnoreCase("Or")))
		{
			if(!list.get(i).getText().contains(searchingText1) && !list.get(i).getText().contains(searchingText2) && !(list.get(i).getText().contains(searchingText3)) && !(list.get(i).getText().contains(searchingText4)) && !(list.get(i).getText().contains(searchingText5)))
			{
				flag=false;
				logger.info("Case5: Contains with OR option failed");
				break;
			}
		}
			
			
		else if((operator.equalsIgnoreCase("Equals")) || (operator.equalsIgnoreCase("In")) && (option.equalsIgnoreCase("And")))
		{
			logger.info("Number of conditions 5 with Operator (Equal or In) with Option 'AND'");
			
			if(!(list.get(i).getText().equalsIgnoreCase(searchingText1)) && !(list.get(i).getText().equalsIgnoreCase(searchingText2)) && !(list.get(i).getText().equalsIgnoreCase(searchingText3)) && !(list.get(i).getText().equalsIgnoreCase(searchingText4)) && !(list.get(i).getText().equalsIgnoreCase(searchingText5)))
			{
				flag=false;
				logger.info("Case 5 Equals or In with And Option::False");
				break;
			
			}
		}
		else if ((operator.equalsIgnoreCase("NotEquals")) && (option.equalsIgnoreCase("And")))
		{
			if(list.get(i).getText().equalsIgnoreCase(searchingText1) && list.get(i).getText().equalsIgnoreCase(searchingText2) && (list.get(i).getText().equalsIgnoreCase(searchingText3)) && (list.get(i).getText().equalsIgnoreCase(searchingText4)) && (list.get(i).getText().equalsIgnoreCase(searchingText5)))
			{
				flag=false;
				logger.info("Case 5 Not Equals with And Option::False");
				break;
			}
		}
		else if((operator.equalsIgnoreCase("Contains")) && (option.equalsIgnoreCase("And")))
		{
			if(!list.get(i).getText().contains(searchingText1) && !list.get(i).getText().contains(searchingText2) && !list.get(i).getText().contains(searchingText3) && !list.get(i).getText().contains(searchingText4) && !(list.get(i).getText().contains(searchingText5)))
			{
				flag=false;
				logger.info("Case 5 Contains with And Option::False");
				break;
			
			}
		}
		}
			break;
		case 6:for(int i=0;i<size;i++)
			{
				logger.info("With 6 conditions");
			if((operator.equalsIgnoreCase("Equals")) || (operator.equalsIgnoreCase("In")) && (option.equalsIgnoreCase("Or")))
			{
				if(!(list.get(i).getText().equalsIgnoreCase(searchingText1)) && !(list.get(i).getText().equalsIgnoreCase(searchingText2)) && !(list.get(i).getText().equalsIgnoreCase(searchingText3)) && !(list.get(i).getText().equalsIgnoreCase(searchingText4)) && !(list.get(i).getText().equalsIgnoreCase(searchingText5)) && !(list.get(i).getText().equalsIgnoreCase(searchingText6)))
				{
					flag=false;
					logger.info("Case6: Equals or IN with OR option failed");
					break;
			
				}
		}
		else if ((operator.equalsIgnoreCase("NotEquals")) && (option.equalsIgnoreCase("Or")))
		{
			if(list.get(i).getText().equalsIgnoreCase(searchingText1) || list.get(i).getText().equalsIgnoreCase(searchingText2) ||(list.get(i).getText().equalsIgnoreCase(searchingText3)) || (list.get(i).getText().equalsIgnoreCase(searchingText4)) || (list.get(i).getText().equalsIgnoreCase(searchingText5)) || (list.get(i).getText().equalsIgnoreCase(searchingText6)))
			{
				flag=false;
				logger.info("Case6: Not Equals with OR option failed");
				break;
			
			}
		}
		else if ((operator.equalsIgnoreCase("Contains")) && (option.equalsIgnoreCase("Or")))
		{
			if(!list.get(i).getText().contains(searchingText1) && !list.get(i).getText().contains(searchingText2) && !(list.get(i).getText().contains(searchingText3)) && !(list.get(i).getText().contains(searchingText4)) && !(list.get(i).getText().contains(searchingText5)) && !(list.get(i).getText().contains(searchingText6)))
			{
				flag=false;
				logger.info("Case6: Contains with OR option failed");
				break;
			
			}
		}
		
			
		else if((operator.equalsIgnoreCase("Equals")) || (operator.equalsIgnoreCase("In")) && (option.equalsIgnoreCase("And")))
		{
			logger.info("Number of conditions 6 with Operator (Equal or In) with Option 'AND'");
			
			if(!(list.get(i).getText().equalsIgnoreCase(searchingText1)) && !(list.get(i).getText().equalsIgnoreCase(searchingText2)) && !(list.get(i).getText().equalsIgnoreCase(searchingText3)) && !(list.get(i).getText().equalsIgnoreCase(searchingText4)) && !(list.get(i).getText().equalsIgnoreCase(searchingText5)) && !(list.get(i).getText().equalsIgnoreCase(searchingText6)))
			{
				flag=false;
				logger.info("Case 6 Equals or In with And Option::False");
				break;
			
			}
		}
		else if ((operator.equalsIgnoreCase("NotEquals")) && (option.equalsIgnoreCase("And")))
		{
			if(list.get(i).getText().equalsIgnoreCase(searchingText1) && list.get(i).getText().equalsIgnoreCase(searchingText2) && (list.get(i).getText().equalsIgnoreCase(searchingText3)) && (list.get(i).getText().equalsIgnoreCase(searchingText4)) && (list.get(i).getText().equalsIgnoreCase(searchingText5)) && (list.get(i).getText().equalsIgnoreCase(searchingText6)))
			{
				flag=false;
				logger.info("Case 6 Not Equals with And Option::False");
				break;
			}
		}
		else if((operator.equalsIgnoreCase("Contains")) && (option.equalsIgnoreCase("And")))
		{
			if(!list.get(i).getText().contains(searchingText1) && !list.get(i).getText().contains(searchingText2) && !list.get(i).getText().contains(searchingText3) && !list.get(i).getText().contains(searchingText4) && !(list.get(i).getText().contains(searchingText5)) && !(list.get(i).getText().contains(searchingText6)))
			{
				flag=false;
				logger.info("Case 6 Contains with And Option::False");
				break;
			
			}
		}
		}
			break;
		
		case 7:for(int i=0;i<size;i++)
		{
			logger.info("With 7 conditions"+"  "+size);
		if((operator.equalsIgnoreCase("Equals")) || (operator.equalsIgnoreCase("In")) && (option.equalsIgnoreCase("Or")))
		{
		
			if(!(list.get(i).getText().equalsIgnoreCase(searchingText1)) && !(list.get(i).getText().equalsIgnoreCase(searchingText2)) && !(list.get(i).getText().equalsIgnoreCase(searchingText3)) &&!(list.get(i).getText().equalsIgnoreCase(searchingText4)) && !(list.get(i).getText().equalsIgnoreCase(searchingText5)) && !(list.get(i).getText().equalsIgnoreCase(searchingText6)) && !(list.get(i).getText().equalsIgnoreCase(searchingText7)))
			{
				flag=false;
				logger.info("Case 7 Equals or IN with OR Option::False");
				break;
			}
	}
	else if ((operator.equalsIgnoreCase("NotEquals")) && (option.equalsIgnoreCase("Or")))
	{
		if(list.get(i).getText().equalsIgnoreCase(searchingText1) && list.get(i).getText().equalsIgnoreCase(searchingText2) && (list.get(i).getText().equalsIgnoreCase(searchingText3)) && (list.get(i).getText().equalsIgnoreCase(searchingText4)) && (list.get(i).getText().equalsIgnoreCase(searchingText5)) && (list.get(i).getText().equalsIgnoreCase(searchingText6)) && (list.get(i).getText().equalsIgnoreCase(searchingText7)))
		{
			flag=false;
			logger.info("Case 7 Not Equals with OR Option::False");
			break;
		
		}
	}
	else if ((operator.equalsIgnoreCase("Contains")) && (option.equalsIgnoreCase("Or")))
	{
		if(!list.get(i).getText().contains(searchingText1) && !list.get(i).getText().contains(searchingText2) && !(list.get(i).getText().contains(searchingText3)) && !(list.get(i).getText().contains(searchingText4)) && !(list.get(i).getText().contains(searchingText5)) && !(list.get(i).getText().contains(searchingText6)) && !(list.get(i).getText().contains(searchingText7)))
		{
			flag=false;
			logger.info("Case 7 Not Contains with OR Option::False");
			break;
		
		}
	}
		
	
		else if((operator.equalsIgnoreCase("Equals")) || (operator.equalsIgnoreCase("In")) && (option.equalsIgnoreCase("And")))
		{
			logger.info("Number of conditions 7 with Operator (Equal or In) with Option 'AND'");
			
			if(!(list.get(i).getText().equalsIgnoreCase(searchingText1)) && !(list.get(i).getText().equalsIgnoreCase(searchingText2)) && !(list.get(i).getText().equalsIgnoreCase(searchingText3)) && !(list.get(i).getText().equalsIgnoreCase(searchingText4)) && !(list.get(i).getText().equalsIgnoreCase(searchingText5)) && !(list.get(i).getText().equalsIgnoreCase(searchingText6)) && !(list.get(i).getText().equalsIgnoreCase(searchingText7)))
			{
				flag=false;
				logger.info("Case 7 Equals or In with And Option::False");
				break;
			
			}
		}
		else if ((operator.equalsIgnoreCase("NotEquals")) && (option.equalsIgnoreCase("And")))
		{
			if(list.get(i).getText().equalsIgnoreCase(searchingText1) && list.get(i).getText().equalsIgnoreCase(searchingText2) && (list.get(i).getText().equalsIgnoreCase(searchingText3)) && (list.get(i).getText().equalsIgnoreCase(searchingText4)) && (list.get(i).getText().equalsIgnoreCase(searchingText5)) && (list.get(i).getText().equalsIgnoreCase(searchingText6)) && (list.get(i).getText().equalsIgnoreCase(searchingText7)))
			{
				flag=false;
				logger.info("Case 7 Not Equals with And Option::False");
				break;
			}
		}
		else if((operator.equalsIgnoreCase("Contains")) && (option.equalsIgnoreCase("And")))
		{
			if(!list.get(i).getText().contains(searchingText1) && !list.get(i).getText().contains(searchingText2) && !list.get(i).getText().contains(searchingText3) && !list.get(i).getText().contains(searchingText4) && !(list.get(i).getText().contains(searchingText5)) && !(list.get(i).getText().contains(searchingText6)) && !(list.get(i).getText().contains(searchingText7)))
			{
				flag=false;
				logger.info("Case 7 Contains with And Option::False");
				break;
			
			}
		}
	}
	break;
	
	
case 8:for(int i=0;i<size;i++)
{
	logger.info("With 8 conditions"+"  "+size);
	if((operator.equalsIgnoreCase("Equals")) || (operator.equalsIgnoreCase("In")) && (option.equalsIgnoreCase("Or")))
		{
			if(!(list.get(i).getText().equalsIgnoreCase(searchingText1)) && !(list.get(i).getText().equalsIgnoreCase(searchingText2)) && !(list.get(i).getText().equalsIgnoreCase(searchingText3)) && !(list.get(i).getText().equalsIgnoreCase(searchingText4)) && !(list.get(i).getText().equalsIgnoreCase(searchingText5)) && !(list.get(i).getText().equalsIgnoreCase(searchingText6)) && !(list.get(i).getText().equalsIgnoreCase(searchingText7)) && !(list.get(i).getText().equalsIgnoreCase(searchingText8)))
			{
				flag=false;
				logger.info("Case 8 Equals or IN with OR Option::False");
				break;
			}
	}
	else if ((operator.equalsIgnoreCase("NotEquals")) && (option.equalsIgnoreCase("Or")))
	{
		if(list.get(i).getText().equalsIgnoreCase(searchingText1) && list.get(i).getText().equalsIgnoreCase(searchingText2) && (list.get(i).getText().equalsIgnoreCase(searchingText3)) && (list.get(i).getText().equalsIgnoreCase(searchingText4)) && (list.get(i).getText().equalsIgnoreCase(searchingText5)) && (list.get(i).getText().equalsIgnoreCase(searchingText6)) && (list.get(i).getText().equalsIgnoreCase(searchingText7)) && (list.get(i).getText().equalsIgnoreCase(searchingText8)))
		{
			flag=false;
			logger.info("Case 8 Not Equals with OR Option::False");
			break;
		
		}
	}
	else if ((operator.equalsIgnoreCase("Contains")) && (option.equalsIgnoreCase("Or")))
	{
		if(!list.get(i).getText().contains(searchingText1) && !list.get(i).getText().contains(searchingText2) && !(list.get(i).getText().contains(searchingText3)) && !(list.get(i).getText().contains(searchingText4)) && !(list.get(i).getText().contains(searchingText5)) && !(list.get(i).getText().contains(searchingText6)) && !(list.get(i).getText().contains(searchingText7)) && !(list.get(i).getText().contains(searchingText8)))
		{
			flag=false;
			logger.info("Case 8 Not Contains with OR Option::False");
			break;
		
		}
	}
	else if((operator.equalsIgnoreCase("Equals")) || (operator.equalsIgnoreCase("In")) && (option.equalsIgnoreCase("And")))
	{
		logger.info("Number of conditions 8 with Operator (Equal or In) with Option 'AND'");
		if(!(list.get(i).getText().equalsIgnoreCase(searchingText1)) && !(list.get(i).getText().equalsIgnoreCase(searchingText2)) && !(list.get(i).getText().equalsIgnoreCase(searchingText3)) && !(list.get(i).getText().equalsIgnoreCase(searchingText4)) && !(list.get(i).getText().equalsIgnoreCase(searchingText5)) && !(list.get(i).getText().equalsIgnoreCase(searchingText6)) && !(list.get(i).getText().equalsIgnoreCase(searchingText7)) && !(list.get(i).getText().equalsIgnoreCase(searchingText8)))
			{
				flag=false;
				logger.info("Case 8 Equals or In with And Option::False");
				break;
			
			}
		}
		else if ((operator.equalsIgnoreCase("NotEquals")) && (option.equalsIgnoreCase("And")))
		{
			if(list.get(i).getText().equalsIgnoreCase(searchingText1) && list.get(i).getText().equalsIgnoreCase(searchingText2) && (list.get(i).getText().equalsIgnoreCase(searchingText3)) && (list.get(i).getText().equalsIgnoreCase(searchingText4)) && (list.get(i).getText().equalsIgnoreCase(searchingText5)) && (list.get(i).getText().equalsIgnoreCase(searchingText6)) && (list.get(i).getText().equalsIgnoreCase(searchingText7)) && (list.get(i).getText().equalsIgnoreCase(searchingText8)))
			{
				flag=false;
				logger.info("Case 8 Not Equals with And Option::False");
				break;
			}
		}
		else if((operator.equalsIgnoreCase("Contains")) && (option.equalsIgnoreCase("And")))
		{
			if(!list.get(i).getText().contains(searchingText1) && !list.get(i).getText().contains(searchingText2) && !list.get(i).getText().contains(searchingText3) && !list.get(i).getText().contains(searchingText4) && !(list.get(i).getText().contains(searchingText5)) && !(list.get(i).getText().contains(searchingText6)) && !(list.get(i).getText().contains(searchingText7)) && !(list.get(i).getText().contains(searchingText8)))
			{
				flag=false;
				logger.info("Case 8 Contains with And Option::False");
				break;
			
			}
		}
	}
	break;
	
case 9:for(int i=0;i<size;i++)
{
	logger.info("With 9 conditions"+"  "+size);
	if((operator.equalsIgnoreCase("Equals")) || (operator.equalsIgnoreCase("In")) && (option.equalsIgnoreCase("Or")))
		{
			if(!(list.get(i).getText().equalsIgnoreCase(searchingText1)) && !(list.get(i).getText().equalsIgnoreCase(searchingText2)) && !(list.get(i).getText().equalsIgnoreCase(searchingText3)) && !(list.get(i).getText().equalsIgnoreCase(searchingText4)) && !(list.get(i).getText().equalsIgnoreCase(searchingText5)) && !(list.get(i).getText().equalsIgnoreCase(searchingText6)) && !(list.get(i).getText().equalsIgnoreCase(searchingText7)) && !(list.get(i).getText().equalsIgnoreCase(searchingText8)) && !(list.get(i).getText().equalsIgnoreCase(searchingText9)))
			{
				flag=false;
				logger.info("Case 9 Equals or IN with OR Option::False");
				break;
			}
	}
	else if ((operator.equalsIgnoreCase("NotEquals")) && (option.equalsIgnoreCase("Or")))
	{
	
		if(list.get(i).getText().equalsIgnoreCase(searchingText1) && list.get(i).getText().equalsIgnoreCase(searchingText2) && (list.get(i).getText().equalsIgnoreCase(searchingText3)) && (list.get(i).getText().equalsIgnoreCase(searchingText4)) && (list.get(i).getText().equalsIgnoreCase(searchingText5)) && (list.get(i).getText().equalsIgnoreCase(searchingText6)) && (list.get(i).getText().equalsIgnoreCase(searchingText7)) && (list.get(i).getText().equalsIgnoreCase(searchingText8))  && (list.get(i).getText().equalsIgnoreCase(searchingText9)))
		{
			flag=false;
			logger.info("Case 9 Not Equals with OR Option::False");
			break;
		
		}
	}
	else if ((operator.equalsIgnoreCase("Contains")) && (option.equalsIgnoreCase("Or")))
	{
		if(!list.get(i).getText().contains(searchingText1) && !list.get(i).getText().contains(searchingText2) && !(list.get(i).getText().contains(searchingText3)) && !(list.get(i).getText().contains(searchingText4)) && !(list.get(i).getText().contains(searchingText5)) && !(list.get(i).getText().contains(searchingText6)) && !(list.get(i).getText().contains(searchingText7)) && !(list.get(i).getText().contains(searchingText8)) && !(list.get(i).getText().contains(searchingText9)))
		{
			flag=false;
			logger.info("Case 9 Not Contains with OR Option::False");
			break;
		
		}
	}
	else if((operator.equalsIgnoreCase("Equals")) || (operator.equalsIgnoreCase("In")) && (option.equalsIgnoreCase("And")))
	{
		logger.info("Number of conditions 9 with Operator (Equal or In) with Option 'AND'");
		if(!(list.get(i).getText().equalsIgnoreCase(searchingText1)) && !(list.get(i).getText().equalsIgnoreCase(searchingText2)) && !(list.get(i).getText().equalsIgnoreCase(searchingText3)) && !(list.get(i).getText().equalsIgnoreCase(searchingText4)) && !(list.get(i).getText().equalsIgnoreCase(searchingText5)) && !(list.get(i).getText().equalsIgnoreCase(searchingText6)) && !(list.get(i).getText().equalsIgnoreCase(searchingText7)) && !(list.get(i).getText().equalsIgnoreCase(searchingText8)) && !(list.get(i).getText().equalsIgnoreCase(searchingText9)))
			{
				flag=false;
				logger.info("Case 9 Equals or In with And Option::False");
				break;
			
			}
		}
		else if ((operator.equalsIgnoreCase("NotEquals")) && (option.equalsIgnoreCase("And")))
		{
			if(list.get(i).getText().equalsIgnoreCase(searchingText1) && list.get(i).getText().equalsIgnoreCase(searchingText2) && (list.get(i).getText().equalsIgnoreCase(searchingText3)) && (list.get(i).getText().equalsIgnoreCase(searchingText4)) && (list.get(i).getText().equalsIgnoreCase(searchingText5)) && (list.get(i).getText().equalsIgnoreCase(searchingText6)) && (list.get(i).getText().equalsIgnoreCase(searchingText7)) && (list.get(i).getText().equalsIgnoreCase(searchingText8))  && (list.get(i).getText().equalsIgnoreCase(searchingText9)))
			{
				flag=false;
				logger.info("Case 9 Not Equals with And Option::False");
				break;
			}
		}
		else if((operator.equalsIgnoreCase("Contains")) && (option.equalsIgnoreCase("And")))
		{
			if(!list.get(i).getText().contains(searchingText1) && !list.get(i).getText().contains(searchingText2) && !list.get(i).getText().contains(searchingText3) && !list.get(i).getText().contains(searchingText4) && !(list.get(i).getText().contains(searchingText5)) && !(list.get(i).getText().contains(searchingText6)) && !(list.get(i).getText().contains(searchingText7)) && !(list.get(i).getText().contains(searchingText8))  && !(list.get(i).getText().contains(searchingText9)))
			{
				flag=false;
				logger.info("Case 9 Contains with And Option::False");
				break;
			
			}
		}
	}
	break;
	
case 10:for(int i=0;i<size;i++)
{
	logger.info("With 10 conditions"+"  "+size);
	if((operator.equalsIgnoreCase("Equals")) || (operator.equalsIgnoreCase("In")) && (option.equalsIgnoreCase("Or")))
		{
			if(!(list.get(i).getText().equalsIgnoreCase(searchingText1)) && !(list.get(i).getText().equalsIgnoreCase(searchingText2)) && !(list.get(i).getText().equalsIgnoreCase(searchingText3)) &&!(list.get(i).getText().equalsIgnoreCase(searchingText4)) && !(list.get(i).getText().equalsIgnoreCase(searchingText5)) && !(list.get(i).getText().equalsIgnoreCase(searchingText6)) && !(list.get(i).getText().equalsIgnoreCase(searchingText7)) && !(list.get(i).getText().equalsIgnoreCase(searchingText8)) && !(list.get(i).getText().equalsIgnoreCase(searchingText9)) && !(list.get(i).getText().equalsIgnoreCase(searchingText10)))
			{
				flag=false;
				logger.info("Case 10 Equals or IN with OR Option::False");
				break;
			}
	}
	else if ((operator.equalsIgnoreCase("NotEquals")) && (option.equalsIgnoreCase("Or")))
	{
		if(list.get(i).getText().equalsIgnoreCase(searchingText1) && list.get(i).getText().equalsIgnoreCase(searchingText2) && (list.get(i).getText().equalsIgnoreCase(searchingText3)) && (list.get(i).getText().equalsIgnoreCase(searchingText4)) && (list.get(i).getText().equalsIgnoreCase(searchingText5)) && (list.get(i).getText().equalsIgnoreCase(searchingText6)) && (list.get(i).getText().equalsIgnoreCase(searchingText7)) && (list.get(i).getText().equalsIgnoreCase(searchingText8)) && (list.get(i).getText().equalsIgnoreCase(searchingText9)) && (list.get(i).getText().equalsIgnoreCase(searchingText10)))
		{
			flag=false;
			logger.info("Case 10 Not Equals with OR Option::False");
			break;
		
		}
	}
	else if ((operator.equalsIgnoreCase("Contains")) && (option.equalsIgnoreCase("Or")))
	{
		if(!list.get(i).getText().contains(searchingText1) && !list.get(i).getText().contains(searchingText2) && !(list.get(i).getText().contains(searchingText3)) && !(list.get(i).getText().contains(searchingText4)) && !(list.get(i).getText().contains(searchingText5)) && !(list.get(i).getText().contains(searchingText6)) && !(list.get(i).getText().contains(searchingText7)) && !(list.get(i).getText().contains(searchingText8)) && !(list.get(i).getText().contains(searchingText9)) && !(list.get(i).getText().contains(searchingText10)))
		{
			flag=false;
			logger.info("Case 10 Contains with OR Option::False" + list.get(i).getText());
			break;
		
		}
	}
	else if((operator.equalsIgnoreCase("Equals")) || (operator.equalsIgnoreCase("In")) && (option.equalsIgnoreCase("And")))
	{
		logger.info("Number of conditions 10 with Operator (Equal or In) with Option 'AND'");
		if(!(list.get(i).getText().equalsIgnoreCase(searchingText1)) && !(list.get(i).getText().equalsIgnoreCase(searchingText2)) && !(list.get(i).getText().equalsIgnoreCase(searchingText3)) && !(list.get(i).getText().equalsIgnoreCase(searchingText4)) && !(list.get(i).getText().equalsIgnoreCase(searchingText5)) && !(list.get(i).getText().equalsIgnoreCase(searchingText6)) && !(list.get(i).getText().equalsIgnoreCase(searchingText7)) && !(list.get(i).getText().equalsIgnoreCase(searchingText8)) && !(list.get(i).getText().equalsIgnoreCase(searchingText9)) && !(list.get(i).getText().equalsIgnoreCase(searchingText10)))
			{
				flag=false;
				logger.info("Case 10 Equals or In with And Option::False");
				break;
			
			}
		}
		else if ((operator.equalsIgnoreCase("NotEquals")) && (option.equalsIgnoreCase("And")))
		{
			if(list.get(i).getText().equalsIgnoreCase(searchingText1) && list.get(i).getText().equalsIgnoreCase(searchingText2) && (list.get(i).getText().equalsIgnoreCase(searchingText3)) && (list.get(i).getText().equalsIgnoreCase(searchingText4)) && (list.get(i).getText().equalsIgnoreCase(searchingText5)) && (list.get(i).getText().equalsIgnoreCase(searchingText6)) && (list.get(i).getText().equalsIgnoreCase(searchingText7)) && (list.get(i).getText().equalsIgnoreCase(searchingText8))  && (list.get(i).getText().equalsIgnoreCase(searchingText9)) && (list.get(i).getText().equalsIgnoreCase(searchingText10)))
			{
				flag=false;
				logger.info("Case 10 Not Equals with And Option::False");
				break;
			}
		}
		else if((operator.equalsIgnoreCase("Contains")) && (option.equalsIgnoreCase("And")))
		{
			if(!list.get(i).getText().contains(searchingText1) && !list.get(i).getText().contains(searchingText2) && !list.get(i).getText().contains(searchingText3) && !list.get(i).getText().contains(searchingText4) && !(list.get(i).getText().contains(searchingText5)) && !(list.get(i).getText().contains(searchingText6)) && !(list.get(i).getText().contains(searchingText7)) && !(list.get(i).getText().contains(searchingText8))  && !(list.get(i).getText().contains(searchingText9)) && !(list.get(i).getText().contains(searchingText10)))
			{
				flag=false;
				logger.info("Case 10 Contains with And Option::False");
				break;
			
			}
		}
	}
	break;
				
	}
	return flag;
}
		/**
		 * This method is used to test the condition where Set filed is Equals
		 * With AND operator. 
		 * @param noOfCondition
		 * @param selectedByPosName
		 * @param selectedByPerName
		 * @param selectedByParentPos
		 * @param selectedByParentPer
		 * @param getDataPosName
		 * @param getDataPerName
		 * @param getDataParentPos
		 * @param getDataParentPer
		 * @param operator
		 * @param option
		 * @param searchingText1
		 * @param searchingText2
		 * @param searchingText3
		 * @param searchingText4
		 * @throws Exception
		 */
	public void advanceSearchTabWithAndOption(int noOfCondition, String selectedByPosName, String selectedByPerName, String selectedByParentPos, String selectedByParentPer,String dropDownIdPositionName,String dropDownIdPerson,String dropDownIdParentPosition,String dropDownIdParentPerson,String getDataPosName, String getDataPerName,String getDataParentPos,String getDataParentPer,String operator, String  option, String searchingText1, String searchingText2, String searchingText3, String searchingText4) throws Exception
	{
		if(noOfCondition==4)
		{
			if(operator.equalsIgnoreCase("Equals") || operator.equalsIgnoreCase("NotEquals") || operator.equalsIgnoreCase("Contains"))
			{
				selectFieldInAdvSearch().click();
			selectParentPositionOption(selectedByPosName,dropDownIdPositionName,1).click();
			clickSelectOperator().click();
			
			selectOperator(operator,1).click();
		
			enterValueOption(1).sendKeys(searchingText1);
			clickAddRowButton().click();
			selectOptionList().click();
			selectOption(option).click();
			
			selectFieldInAdvSearch().click();
			selectParentPositionOption(selectedByPerName,dropDownIdPerson,2).click();
			clickSelectOperator().click();
			
			selectOperator(operator,2).click();
		
			enterValueOption(2).sendKeys(searchingText2);

			clickAddRowButton().click();
			selectFieldInAdvSearch().click();
			selectParentPositionOption(selectedByParentPos,dropDownIdParentPosition,3).click();
			clickSelectOperator().click();
			
			selectOperator(operator,3).click();
		
			enterValueOption(3).sendKeys(searchingText3);
			
			clickAddRowButton().click();
			selectFieldInAdvSearch().click();
			selectParentPositionOption(selectedByParentPer,dropDownIdParentPerson,4).click();
			clickSelectOperator().click();
			
			selectOperator(operator,4).click();
		
			enterValueOption(4).sendKeys(searchingText4);

			clickApplyButton().click();
			
			SeleniumHelperClass.waitForElmentToBeReady(resetButtonInAdvanceSearch());
		}
	}
}
	
	public int getSearchedHirarchyCount() throws Exception
	{
		String count=getHierarchyCount().getText();
		count=count.substring(1, count.length()-1);
		int recCount=Integer.valueOf(count);
		return recCount;		
	}
}