package com.xactly.incent.organization;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
//import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.asserts.SoftAssert;

import com.xactly.incent.navigation.LeftNavigationUtil;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

public class Positions {
	public static Logger logger = Logger.getLogger(Positions.class.getName());

	public WebElement get_oposition_name() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("name_position_edit", "ceditframe"));
	}

	public Select get_oposition_business_group() throws Exception {
		return (SeleniumHelperClass.selectFromDropdown("businessGroupId_position_edit", "ceditframe"));
	}

	public WebElement get_oposition_description() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("description_position_edit", "ceditframe"));
	}

	public WebElement get_oposition_search_position_name() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//input[@name='Position Name']", "contentframe"));
	}

	public WebElement get_search_position_Name() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//tbody[@id='listTable_search_list']//td[1]", "contentFrame");
	}

	public WebElement get_oposition_save() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("saveButton", "ceditframe"));
	}

	public WebElement get_oposition_save_version() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("menuSave_a_0", "ceditframe"));
	}

	public WebElement get_oposition_save_add_new_version() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("menuSave_a_1", "ceditframe"));
	}

	public WebElement get_oposition_search() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("searchButton", "contentframe"));
	}

	public WebElement get_oposition_clear() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("clearButton", "contentframe"));
	}

	public WebElement get_oposition_textBox() throws Exception {
		return (SeleniumHelperClass.findWebElementbyName("Position Name", "contentFrame"));
	}

	public WebElement get_SearchResultTotal() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("total", "contentFrame"));
	}

	public WebElement get_oposition_audit_modifiedDt(WebElement row) throws Exception {
		return (SeleniumHelperClass.findWebElementInWebElement(row, "xpath", "//td[@n='modifiedDate']", "none"));
	}

	public WebElement get_oposition_audit_modifiedBy(WebElement row) throws Exception {
		return (SeleniumHelperClass.findWebElementInWebElement(row, "xpath", "//td[@n='modifiedByName']", "none"));
	}

	public String get_SearchResultCount() throws Exception {
		String count = SeleniumHelperClass.findWebElementbyid("total", "contentFrame").getText();
		count = count.split(":")[1];
		return count.trim();
	}

	public WebElement get_oposition_create_position() throws Exception {
		return (SeleniumHelperClass.findWebElementbyLink("Create Position", "MainFrame"));
	}

	public WebElement get_oposition_edit_position() throws Exception {
		return (SeleniumHelperClass.findWebElementbyLink("Edit Position", "MainFrame"));
	}

	public WebElement get_oposition_delete_position() throws Exception {
		return (SeleniumHelperClass.findWebElementbyLink("Delete Position", "MainFrame"));
	}

	public WebElement get_oposition_new_search() throws Exception {
		return (SeleniumHelperClass.findWebElementbyLink("New Search", "MainFrame"));
	}

	public WebElement get_oposition_all_positions() throws Exception {
		return (SeleniumHelperClass.findWebElementbyLink("All Positions", "MainFrame"));
	}

	public WebElement clickOnEntityInAdvSearchTableByRow(int row, String entity) {
		try {
			row = row + 3;
			int col = -1;
			switch (entity.toLowerCase()) {
			case "field":
				col = 3;
				break;
			case "value":
				col = 5;
				break;
			default:
				throw new Exception(
						entity + " which is given in script is not a valid entity. Please give valid entity");
			}
			return (SeleniumHelperClass.findWebElementbyXpath(
					"//table[contains(@id,'advanced_search')]//tr[" + row + "]/td[" + col + "]/button",
					"contentFrame"));
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public WebElement selectFieldEntityInSelectFieldWindow(String fieldEntity) {
		try {
			return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(text(),'" + fieldEntity + "')]"));
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public void selectOperatorTypeInAdvSearchByRow(int row, String operatorType) {
		try {
			row = row + 3;
			WebElement ele = SeleniumHelperClass.findWebElementbyXpath(
					"//table[contains(@id,'advanced_search')]//tr[" + row + "]/td[4]/select", "contentFrame");
			Select select = new Select(ele);
			select.selectByVisibleText(operatorType);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selectConditionalOperatorTypeInAdvSearchByRow(int row, String operatorType) {
		try {
			row = row + 3;
			WebElement ele = SeleniumHelperClass.findWebElementbyXpath(
					"//table[contains(@id,'advanced_search')]//tr[" + row + "]//select[contains(@class,'andor')]",
					"contentFrame");
			Select select = new Select(ele);
			select.selectByVisibleText(operatorType);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickPositionPage() throws Exception {

		SeleniumHelperClass.findWebElementbyid("TAB_MIDDLE_ORGANIZATION_TAB", "TopFrame").click();
		SeleniumHelperClass.findWebElementbyid("A_Positions", "topFrame").click();
		// SeleniumHelperClass.acceptAlert();//this is added to handle the alert which
		// comes when we click on the sublinks in organization,Can be removed once dev
		// fix this issue.
		Thread.sleep(1000);
	}

	public WebElement get_oposition_table() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("tableFixed", "contentframe"));
	}

	public WebElement get_oposition_version_table() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("tableFixed", "clistframe"));
	}

	public WebElement get_oposition_audit_version() throws Exception {
//		return (SeleniumHelperClass.findWebElementbyLink("Audit Version","MainFrame"));
		return (SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'Audit Version')]", "MainFrame"));
	}

	public WebElement get_oposition_Audit_Desc() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//td[4]/div[1]"));
	}

	public WebElement get_oposition_Audit_ModifiedDate() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//td[1]/div[1]"));
	}

	public WebElement get_oposition_Audit_ModifiedBy() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//td[2]/div[1]"));
	}

	public WebElement get_oposition_Audit_PositionName() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//td[5]/div[1]"));
	}

	public WebElement get_oposition_Audit_Title() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//td[8]/div[1]"));
	}

	public WebElement get_oposition_Audit_defaultBusinessGroup() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//td[9]/div[1]"));
	}

	public WebElement selectTitle() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[@id='b_title_position_edit']", "ceditFrame"));
	}

	public WebElement get_All_Positions() throws Exception {
		//return (SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'All Positions')]", "mainFrame"));
        return (SeleniumHelperClass.findWebElementbyXpath("//div[@class='x-tree-node-el xcAllNode x-tree-node-leaf']//span[contains(text(),'All Positions')]", "mainFrame"));
	}

	public WebElement selectTitleName() throws Exception {
		logger.info("Selecting the first Title");
		return SeleniumHelperClass.findWebElementbyXpath("//tbody[@id='listTable_edit_title']//td[1]//div");
	}

	public WebElement clickOkButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@id='okButton']");
	}

	public WebElement okButtonInSelectFieldWindow() {
		try {
			return SeleniumHelperClass.findWebElementbyid("okButton");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public WebElement businessGroupSelect1() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='businessGroupId_position_edit']/option[1]");
	}

	public Positions(String testtype) throws Exception

	{
		if (testtype.equalsIgnoreCase("gui")) {
			new Organization("gui");
			Thread.sleep(1000);
			SeleniumHelperClass.findWebElementbyid("A_Positions", "topFrame").click();
			SeleniumHelperClass.isVisible(get_oposition_create_position(), SeleniumHelperClass.system_SpeedlimitMAX);
			Thread.sleep(2000);
		} else if (testtype.equalsIgnoreCase("gui-new")) {
			new Organization("gui-new");
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
			LeftNavigationUtil.clickOnPositionTab();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		}else if (testtype.equalsIgnoreCase("Redesign")){

				new Organization("Redesign");
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
				LeftNavigationUtil.clickOnPositionTab();
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*2);
	            Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
			}

		
		
	}

	public void createPosition(String name, String title, String businessGroup) throws Exception {
		get_oposition_create_position().click();
		Thread.sleep(3000);
		get_oposition_name().sendKeys(name);
		SeleniumHelperClass.selectFromPopup("b_title_position_edit", "name_edit_title", title, "ceditframe");
		get_oposition_business_group().selectByVisibleText(businessGroup);
		get_oposition_save().click();
		get_oposition_save_version().click();
		Thread.sleep(3000);
	}

	public void createPositionwithPersonWithVersion(String name, String title, String businessGroup, String Personid)
			throws Exception {
		get_oposition_create_position().click();
		Thread.sleep(3000);
		get_oposition_name().sendKeys(name);
		SeleniumHelperClass.selectFromPopup("b_title_position_edit", "name_edit_title", title, "ceditframe");
		get_oposition_business_group().selectByVisibleText(businessGroup);
		Thread.sleep(3000);
		// get_oposition_person_popup().click();
		SeleniumHelperClass.selectFromPopup("b_participant_position_edit", "employeeId_edit_participant", Personid,
				"ceditframe");
		SeleniumHelperClass.isClickable(get_oposition_save(), 10);
		get_oposition_save().click();
		SeleniumHelperClass.isVisible(get_oposition_save_add_new_version(), 10);
		SeleniumHelperClass.isClickable(get_oposition_save_add_new_version(), 10);
		get_oposition_save_add_new_version().click();
		Thread.sleep(3000);
		selectFromVersionPopup("eff_start");
		SeleniumHelperClass.selectFromPopup("b_participant_position_edit", "employeeId_edit_participant", Personid,
				"ceditframe");
		Thread.sleep(3000);
		SeleniumHelperClass.isClickable(get_oposition_save(), 10);
		get_oposition_save().click();
		get_oposition_save_version().click();
		Thread.sleep(3000);

	}

	/* to search a value from pop-up list where pop up does not have search field */
	public static void selectFromVersionPopup(String searchFieldId, String dateStatus) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		Set<String> windowHandlers = SeleniumHelperClass.windowsHandler(2);
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				SeleniumHelperClass.switchToWindow(windowHandle);
				try {
					logger.info("Switched to Child window");
					SeleniumHelperClass.findWebElementbyCssSelector("img.dateImg", "addVersionframe").click();
					;
					if (dateStatus.equalsIgnoreCase("Today")) {
						SeleniumHelperClass.findWebElementbyid("ext-gen34", "addVersionframe").click();
					} else if (dateStatus.equalsIgnoreCase("ActiveDate")) {
						WebElement ele = SeleniumHelperClass
								.findWebElementbyXpath("//td[@class='x-date-active  x-date-selected']/a/em/span");
						SeleniumHelperClass.waitForElement(windowHandle, ele.toString(), "addVersionframe", 60);
						ele.click();
					}
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
					SeleniumHelperClass.findWebElementbyXpath("//button[@type='submit']", "addVersionframe").click();

				} catch (Exception e) {
					SeleniumHelperClass.closeCurrentWindow();
					logger.info("Closed the child window");
					SeleniumHelperClass.switchToWindow(parentWindow);
					throw new Exception(e);
				}
			}

		}
		SeleniumHelperClass.switchToWindow(parentWindow);
	}

	public static void selectFromVersionPopup(String searchFieldId) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		Set<String> windowHandlers = SeleniumHelperClass.windowsHandler(2);
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				SetWebDrivers.getDriver().switchTo().window(windowHandle);
				try {
					logger.info("Switched to Child window");
					SeleniumHelperClass.findWebElementbyCssSelector("img.dateImg", "addVersionframe").click();
					;
					Thread.sleep(2000);
					SeleniumHelperClass.findWebElementbyid("ext-gen34", "addVersionframe").click();
					Thread.sleep(2000);
					// SeleniumHelperClass.findWebElementbyid(searchFieldId,"addVersionframe").sendKeys(searchString);
					// WebElement
					// searchButton=SeleniumHelperClass.findWebElementbyid("searchButton");
					// searchButton.click();
					// Thread.sleep(3000);
					// WebElement table=SeleniumHelperClass.findWebElementbyid("tableFixed");

					// logger.info(getNumberOfResultsFromUI("none"));

					// clickFirstRowOfTable(table);
					// clickFirstRowOfTable();
					// SeleniumHelperClass.findWebElementbyXpath("//td/div").click();
					SeleniumHelperClass.findWebElementbyXpath("//button[@type='submit']", "addVersionframe").click();
					Thread.sleep(3000);
				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the child window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}

		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
	}

	public void searchPosition(String name) throws Exception {
		if (isNewSearchPresent()) {
			get_oposition_New_Search().click();
		}
		SeleniumHelperClass.isVisible(get_oposition_search_position_name(),
				SeleniumHelperClass.system_SpeedlimitMAX * 3);
		get_oposition_search_position_name().sendKeys(name);
		get_oposition_search().click();
		SeleniumHelperClass.isVisible(get_oposition_table(), SeleniumHelperClass.system_SpeedlimitMAX * 2);

	}

	public Boolean isNewSearchPresent() throws Exception {
		Boolean isPresent = SeleniumHelperClass.findWebElements("(//span[contains(text(),'New Search')])", "mainFrame")
				.size() > 0;
		return isPresent;
	}

	public WebElement get_oposition_New_Search() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("(//span[contains(text(),'New Search')])", "mainFrame");
	}

	/*
	 * public void NewSearch(String name) throws Exception {
	 * get_oposition_New_Search().click();
	 * Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	 * get_oposition_search_position_name().sendKeys(name);
	 * get_oposition_search().click();
	 * Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX); }
	 */

	public void deleteFirstPosition(String name) throws Exception {
		searchPosition(name);
		if (Integer.parseInt(get_SearchResultCount()) > 0) {
			SeleniumHelperClass.findWebElementbyCssSelector("#listTable_search_list > tr", "contentFrame").click();
			Thread.sleep(1000);
			get_oposition_delete_position().click();
			Thread.sleep(3000);
			SeleniumHelperClass
					.AcceptAlerts("All versions of this position will be deleted.  Do you wish to continue?");
		}
	}

	public void deletePosition(String name) throws Exception {
		searchPosition(name);
		if (Integer.parseInt(get_SearchResultCount()) > 0) {
			getPositionTable("Position Name", 1).click();
			Thread.sleep(3000);
			get_oposition_delete_position().click();
			SeleniumHelperClass
					.AcceptAlerts("All versions of this position will be deleted.  Do you wish to continue?");
			Thread.sleep(2000);

		}
	}

	public void NodeletePosition(String name) throws Exception {
		searchPosition(name);
		if (Integer.parseInt(get_SearchResultCount()) > 0) {
			getPositionTable("Position Name", 1).click();
			Thread.sleep(3000);
			get_oposition_delete_position().click();
			SeleniumHelperClass
					.AcceptAlerts("All versions of this position will be deleted.  Do you wish to continue?");
			Thread.sleep(2000);
			SeleniumHelperClass.AcceptAlerts("Plan is assigned for this position.");

		}
	}

	public void deletePositionWithAssert(String name) throws Exception {
		SoftAssert Assert = new SoftAssert();
		searchPosition(name);
		if (Integer.parseInt(get_SearchResultCount()) > 0) {
			getPositionTable("Position Name", 1).click();
			Thread.sleep(3000);
			get_oposition_delete_position().click();
			SeleniumHelperClass
					.AcceptAlerts("All versions of this position will be deleted.  Do you wish to continue?");
			Thread.sleep(2000);
			SeleniumHelperClass.waitForElmentToBeReady(get_SearchResultTotal());
			Assert.assertEquals(get_SearchResultCount(), 0, "Delete position assertion failed");

		}
	}

	public void deleteCurrentPosition() throws Exception {
		SeleniumHelperClass.isClickable(get_oposition_delete_position(), 10);
		get_oposition_delete_position().click();
		SeleniumHelperClass.AcceptAlerts("All versions of this position will be deleted.  Do you wish to continue?");
	}

	public void deletePositionWithoutSearching(String name) throws Exception {
		get_All_Positions().click();
		SeleniumHelperClass.isVisible(get_oposition_New_Search(), 10);
		searchPosition(name);
		if (Integer.parseInt(get_SearchResultCount()) > 0) {
			getPositionTable("Position Name", 1).click();
			Thread.sleep(3000);
			get_oposition_delete_position().click();
			SeleniumHelperClass
					.AcceptAlerts("All versions of this position will be deleted.  Do you wish to continue?");
			Thread.sleep(2000);
		}
	}

	/*
	 * public void deletePositionNew(String name) throws Exception {
	 * get_oposition_new_Search().click();
	 * if(Integer.parseInt(get_SearchResultCount()) > 0){
	 * getPositionTable("Position Name",0).click(); Thread.sleep(3000);
	 * get_oposition_delete_position().click(); SeleniumHelperClass.
	 * AcceptAlerts("All versions of this position will be deleted.  Do you wish to continue?"
	 * ); Thread.sleep(2000); } }
	 */
	public void editPosition(String name, String titleName) throws Exception {
		searchPosition(name);
		getPositionTable("Position Name", 1).click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_oposition_edit_position().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SeleniumHelperClass.selectFromPopup("b_title_position_edit", "name_edit_title", titleName, "ceditframe");
		get_oposition_save().click();
		get_oposition_save_version().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	public WebElement getPositionTable(String columnName, int rowNum) throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		return (SeleniumHelperClass.getTableData(get_oposition_table(), columnName, rowNum));
	}

	public List<String> verifyAuditDetails() throws Exception {
		List<String> Auditdetails = new ArrayList<String>();

		// parentWindow=SetWebDrivers.getDriver().getWindowHandle();

		get_oposition_audit_version().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		String parentWindow = SeleniumHelperClass.switchToPopupWindow();
		try {
			// switchToNewWindow();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);

			String desc = get_oposition_Audit_Desc().getText();
			String name = get_oposition_Audit_PositionName().getText();
			String title = get_oposition_Audit_Title().getText();
			String businessGroup = get_oposition_Audit_defaultBusinessGroup().getText();

			Auditdetails.add(desc);
			Auditdetails.add(name);
			Auditdetails.add(title);
			Auditdetails.add(businessGroup);
			SetWebDrivers.getDriver().close();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
			// SetWebDrivers.getDriver().switchTo().window(parentWindow);
			SeleniumHelperClass.switchToWindow(parentWindow);
		} catch (Exception e) {
			// SetWebDrivers.getDriver().switchTo().window(parentWindow);
			SeleniumHelperClass.switchToWindow(parentWindow);
		}
		return Auditdetails;

	}

	public Map<String, String> verifyAuditVersionModified() throws Exception {
		Map<String, String> auditDetails = new HashMap<String, String>();
		get_oposition_audit_version().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		String parentWindow = SeleniumHelperClass.switchToPopupWindow();

		try {
			auditDetails.put("ModifiedDt", get_oposition_Audit_ModifiedDate().getText());
			auditDetails.put("ModifiedBy", get_oposition_Audit_ModifiedBy().getText());
			auditDetails.put("Description", get_oposition_Audit_Desc().getText());
			auditDetails.put("PositionName", get_oposition_Audit_PositionName().getText());
			auditDetails.put("Title", get_oposition_Audit_Title().getText());
			auditDetails.put("BusinessGroup", get_oposition_Audit_defaultBusinessGroup().getText());
			SetWebDrivers.getDriver().close();
			SeleniumHelperClass.switchToWindow(parentWindow);
		} catch (Exception e) {
			SetWebDrivers.getDriver().close();
			SeleniumHelperClass.switchToWindow(parentWindow);
		}
		return auditDetails;
	}

	public WebElement get_oposition_Save_Date() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//button[text()='Save']", "addVersionframe");
	}

	public WebElement getDate() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//a[@id='a_eff_start']", "addVersionframe");
	}

	public WebElement getToday() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//button[text()='Today']", "addVersionframe");
	}

	public List<String> InputElements(String desc, String name, String title, String businessGroup) throws Exception {

		List<String> InputDetails = new ArrayList<String>();
		InputDetails.add(desc);
		InputDetails.add(name);
		InputDetails.add(title);
		InputDetails.add(businessGroup);

		return InputDetails;

	}

	public WebElement downloadPosition() throws Exception {

		return SeleniumHelperClass.findWebElementbyLink("Download Positions", "mainFrame");

	}

	public List<WebElement> get_op_objectDropdown() throws Exception {
		return (SeleniumHelperClass.findWebElementsById("object_select", "contentFrame"));
	}

	public Map<String, String> CreateModifiedAuditVersionPosition(String positionName, String empId, String environment)
			throws Exception {
		new Positions(SetWebDrivers.getNavigationType());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);

		searchPosition(positionName);
		SeleniumHelperClass.doubleClick(getPositionTable("Position Name", 1));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_oposition_description().sendKeys("Modified by Admin");
		SeleniumHelperClass.isClickable(get_oposition_save(), 10);
		get_oposition_save().click();
		get_oposition_save_add_new_version().click();
		Positions.selectFromVersionPopup("eff_start", "ActiveDate");
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SeleniumHelperClass.selectFromPopup("b_participant_position_edit", "employeeId_edit_participant", empId,
				"ceditframe");
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		SeleniumHelperClass.isClickable(get_oposition_save(), 10);
		get_oposition_save().click();
		get_oposition_save_version().click();

		return verifyAuditVersionModified();
	}

	public Map<String, Object> getAuditTableRowData(List<Map<String, String>> auditDetails) throws Exception {
		List<WebElement> tableRow = get_oposition_version_table().findElements(By.tagName("tr"));
		SeleniumHelperClass.doubleClick(tableRow.get(2));
		get_oposition_audit_version().click();
		String parentWindow = SeleniumHelperClass.switchToPopupWindow();
		WebElement tableBody = SeleniumHelperClass.findWebElementbyid("listTable_edit_Hist");
		List<WebElement> rowData = SeleniumHelperClass.findWebElementsInWebElement(tableBody, "tag", "tr", "none");
		Map<String, Object> auditData = new HashMap<String, Object>();
		auditData.put("RowData", rowData);
		auditData.put("ParentWindow", parentWindow);

		return auditData;
	}

	public void editPositionWithPersonPopupAndClear(String name, String Personid) throws Exception {
		searchPosition(name);
		getPositionTable("Position Name", 1).click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_oposition_edit_position().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SeleniumHelperClass.selectFromPopupandClear("b_participant_position_edit", "employeeId_edit_participant",
				Personid, "ceditframe");
		get_oposition_save().click();
		get_oposition_save_version().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	public void editPositionWithPersonPopup(String name, String Personid) throws Exception {
		searchPosition(name);
		getPositionTable("Position Name", 1).click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_oposition_edit_position().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SeleniumHelperClass.selectFromPopup("b_participant_position_edit", "employeeId_edit_participant", Personid,
				"ceditframe");
		get_oposition_save().click();
		get_oposition_save_version().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	public WebElement get_advanceSearch_field_byrowNumer(int row) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				".//*[@id='advanced_search_tbody']/tr[" + row + "]/td[3]/button", "contentFrame");
	}

	public WebElement get_advanceSearch_fieldName(String name) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//table[@id='tableFixed']/tbody/tr/td/div[contains(text(),'" + name + "')]", "");
	}

	public WebElement get_ok_button() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(".//*[@id='okButton']", "");
	}

	public void select_AdvanceSearchuOperator(String operator, int row) throws Exception {
		WebElement optr = SeleniumHelperClass.findWebElementbyXpath(
				"//*[@id='ext-gen" + row + "']//select[@class='operator_select']//*[contains(.,'" + operator + "')]",
				"contentFrame");
		optr.click();
	}

	public WebElement get_advanceSearch_value_byrowNumber(int row) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//tbody[@id='advanced_search_tbody']/tr[" + row + "]/td[5]/input", "contentFrame");
	}

	public WebElement get_advanceSearch_Addrow() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//*[@id='advanced_search_tbody']//button[contains(.,'Add Row')]", "contentFrame");

	}

	public WebElement get_latestVersion() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@value='2']", "contentFrame");

	}

	public WebElement getAllVersionsToDownloadPositions() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@name='downloadOption' and @value='allVersions']",
				"downloadFrame");
	}

	public WebElement getLatestVersionsToDownloadPositions() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@name='downloadOption' and @value='latest']",
				"downloadFrame");
	}

	public WebElement getSelectDownloadFormat() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//select[@name='format']", "downloadFrame");
	}

	public WebElement getDownloadButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//button[contains(text(),'Download')]", "downloadFrame");
	}

	public String getUploadFileLocation(String directory, String file) {
		String path = this.getClass().getClassLoader().getResource(directory + file).getFile();
		if (SetWebDrivers.runningOS.equalsIgnoreCase("Windows")) {
			path = path.substring(1, path.length()).replace("/", "\\");
		}
		return path;
	}

	public WebElement getValueField(int rowNum) throws Exception {
		int newRow = rowNum + 1;
		return SeleniumHelperClass.findWebElementbyXpath("(//input[@id='value_input'])["+rowNum+"]","contentFrame");
	}
}
