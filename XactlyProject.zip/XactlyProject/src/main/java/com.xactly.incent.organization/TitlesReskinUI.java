package com.xactly.incent.organization;

import java.util.List;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.xactly.incent.navigation.LeftNavigationUtil;
import com.xactly.xcommons.selenium.SeleniumHelperClass;

public class TitlesReskinUI {
	public static Logger logger = Logger.getLogger(TitlesReskinUI.class.getName());

	public TitlesReskinUI() throws Exception {
		new Organization("gui-new");
		SeleniumHelperClass.isVisible(getTitlesLink_NewUI(), 60);
		LeftNavigationUtil.clickOnTitleTab();
		SeleniumHelperClass.isVisible(getTitleCreateButton(), 60);
	}

	public WebElement getTitlesLink_NewUI() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("ORGANIZATION_NAV-ORGANIZATION_TITLES", "topFrame"));
	}

	public WebElement getTitleCreateButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("newButton", "listFrame"));
	}

	public List<WebElement> getAddTitleFormFieldLabels() throws Exception {
		return (SeleniumHelperClass.findWebElementsInXpath("//*[@class='form-label']", "editframe"));
	}
}
