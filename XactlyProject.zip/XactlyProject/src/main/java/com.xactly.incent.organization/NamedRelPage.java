
package com.xactly.incent.organization;


import java.io.File;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.xactly.incent.navigation.LeftNavigationUtil;
import com.xactly.xcommons.selenium.Constants;

//import antlr.collections.List;





import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

public class NamedRelPage {
	public static Logger logger = Logger.getLogger(NamedRelPage.class.getName());
	WebDriver drv = SetWebDrivers.getDriver();
	private String parentWindow = "";
	private String recentWindow;
	private static final String date = "06/01/2017";
	private File latestFile;
	public File latestFilefromDir;	
	
	public String getParentWindowID()	{
		return parentWindow;
	}
	
	public void setParentWindowID(String windowHandleID)	{
		parentWindow = this.parentWindow;
	}
	
	//To get the Create Named Relationship Link
	public WebElement get_oNamedrelationship_Create_NamedRelationship() throws Exception {
		return (SeleniumHelperClass.findWebElementbyLink("Create Named Relationship","MainFrame"));		
	}
	
	//
	/*public WebElement get_oNamedRelationship_text() throws Exception{
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='objName']"));
	}*/
	
	//To get the Named Relationship name field while creating
	public WebElement get_oNR_name() throws Exception{
		return (SeleniumHelperClass.findWebElementbyid("name", "AddVersionFrame"));
	}
	
	//To get the Named Relationship Description field while creating
	public WebElement get_oNR_Desc() throws Exception{
		return (SeleniumHelperClass.findWebElementbyid("desc", "AddVersionFrame"));
	}
	
	//To get the Named Relationship Save button while creating
	public WebElement get_oNR_Save() throws Exception{
		return (SeleniumHelperClass.findWebElementbyXpath("//button[contains(text(),'Save')]","AddVersionFrame"));
	}
	
	//To get the NamedRelationship created name 
	public WebElement get_NamedRelationship_getname() throws Exception{
		return(SeleniumHelperClass.findWebElementbyXpath("//body/div[2]/table/tbody/tr[1]/td[1]/span", "clistframe"));
		
	}
	
		
	//To get the Create Relationship link
	public WebElement get_oNR_CreteRelationship() throws Exception{
		return (SeleniumHelperClass.findWebElementbyLink("Create Relationship", "MainFrame"));
	}
	
	//To get the Position Search in Create Relationship window
	public WebElement get_oNR_CreateRelationship_SearchPosition() throws Exception{
		return (SeleniumHelperClass.findWebElementbyid("name_search_list", "none"));
	}
	
	//To get the From Position button in the Create relationship window
	public WebElement get_oNR_SelectFromPosition() throws Exception{
		return (SeleniumHelperClass.findWebElementbyXpath("//body/div/form/table[5]/tbody/tr/td[1]/button[1]"));
	}
	
	//To get the To Position button in the Create relationship window
	public WebElement get_oNR_SelectToPosition() throws Exception{
		return (SeleniumHelperClass.findWebElementbyXpath("//body/div/form/table[5]/tbody/tr/td[1]/button[2]"));
	}
	
	public WebElement get_Relationships_FromPos() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//body/form/div/table/tbody/tr[1]/td[1]/div","ceditframe");
	}
	
	public WebElement get_Relationships_ToPos() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//body/form/div/table/tbody/tr[2]/td[3]/div","ceditframe");
	}
	
	
	//To get the Table Fixed
	public WebElement get_oNR_EditNR_table() throws Exception{
    	return (SeleniumHelperClass.findWebElementbyid("tableFixed", "none"));
    }
	
	public WebElement get_oNR_clear() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("clearButton", "contentframe"));
	}
	
	public WebElement get_oNR_textBox() throws Exception{
		return (SeleniumHelperClass.findWebElementbyName("From Position", "contentFrame"));
	}
	
	//To get the Table Fixed rows & columns
	public WebElement getEditNamedRelationshiptable(String columnName, int rowNum) throws Exception{	
		Thread.sleep(3000);
		return (SeleniumHelperClass.getTableData(get_oNR_EditNR_table(), columnName,rowNum));
	}
	
	//To get the Search button in Create Relationship window
	public WebElement get_oNR_CreateRelationship_Search() throws Exception{
		return (SeleniumHelperClass.findWebElementbyid("searchButton", "none"));
	}
	
	//To get the save button in Create Relationship window
	public WebElement get_oNR_CreateRelationship_Save() throws Exception{
		return (SeleniumHelperClass.findWebElementbyid("saveButton", "none"));
	}
	
	//To get the Edit Named Relationship link
	public WebElement get_oNamedrelationship_EdidNamedRelationship() throws Exception {
		return (SeleniumHelperClass.findWebElementbyLink("Edit Named Relationship","MainFrame"));		
	}
	
	//To get the NamedRelationship name in the Edit window
	public WebElement get_oNR_EditNR_Name() throws Exception{
		return (SeleniumHelperClass.findWebElementbyid("name_edit_list", "none"));
	}
	
	//To get the Search button in Edit Named Relationship window
	public WebElement get_oNR_EditNR_Search() throws Exception{
		return (SeleniumHelperClass.findWebElementbyid("searchButton", "none"));
	}
	
	//To get the ok button in Edit Named Relationship window
	public WebElement get_oNR_EditNR_Ok() throws Exception{
		return (SeleniumHelperClass.findWebElementbyid("okButton", "none"));
	}
	
	//To get the Cancel button in Edit Named Relationship window
	public WebElement get_EditNR_Cancel() throws Exception{
		return (SeleniumHelperClass.findWebElementbyid("cancelButton", "none"));
	}
	
	
	public WebElement get_CreateRelationship_SelectPos() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//table[2]/tbody/tr[1]/td/form/div/table/tbody/tr[1]/td[3]/div");
	}
	
	public WebElement get_Addversion() throws Exception{
		return SeleniumHelperClass.findWebElementbyLink("Add Version", "MainFrame");
	}
	
	public WebElement get_Addversion_EffStart() throws Exception{
		return SeleniumHelperClass.findWebElementbyid("eff_start", "addversionframe");
	}
	
	public WebElement get_Addversion_Save() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//body/div/form/center/table[2]/tbody/tr/td[2]/button");
	}
	
	public WebElement get_EditNR_versionEffStartDate() throws Exception{
	     return SeleniumHelperClass.findWebElementbyXpath("//body/form/div/table/tbody/tr[1]/td[1]/div","clistframe");
	}
	public WebElement get_EditNR_SecondVersionEffStartDate() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//body/form/div/table/tbody/tr[2]/td[1]/div","clistframe");
	}	
	public WebElement get_Editversion() throws Exception{
		return SeleniumHelperClass.findWebElementbyLink("Edit Version", "MainFrame");
	}
	
	public WebElement get_DeleteVersion() throws Exception{
		return SeleniumHelperClass.findWebElementbyLink("Delete Version", "MainFrame");
	}
	
	public WebElement get_Downloadrelationships() throws Exception{
		return SeleniumHelperClass.findWebElementbyLink("Download Relationships", "MainFrame");
	}
	
	public WebElement get_DeleteNamedrelationship() throws Exception{
		return SeleniumHelperClass.findWebElementbyLink("Delete Named Relationship", "MainFrame");
	}
	
	public WebElement get_AdvSearch_Fieldellipse1() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//body/div[2]/form/div[2]/div/table/tbody/tr[7]/td/table/tbody/tr[4]/td[3]/button");
	}
	
	public WebElement get_AdvSearch_Fieldellipse2() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//body/div[2]/form/div[2]/div/table/tbody/tr[7]/td/table/tbody/tr[5]/td[3]/button");
	}
	
	public WebElement get_AdvSearchpopup_okbutton() throws Exception{
		//return SeleniumHelperClass.findWebElementbyid("okButton", "none");
		return SeleniumHelperClass.findWebElementbyXpath("//*[@onclick='doOK()']");
	}
	
	public WebElement get_AdvSearch_Valueellipse1() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//body/div[2]/form/div[2]/div/table/tbody/tr[7]/td/table/tbody/tr[4]/td[5]/button");
	}
	
	public WebElement get_AdvSearch_ValuePositionname() throws Exception{
		return SeleniumHelperClass.findWebElementbyid("name_search_fromPositionName", "none");
	}
	
	public WebElement get_AdvSearch_ValuePosSearch() throws Exception{
		return SeleniumHelperClass.findWebElementbyid("searchButton", "none");
	}
	
	public WebElement get_AdvSearch_Addrow() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//body/div[2]/form/div[2]/div/table/tbody/tr[7]/td/table/tbody/tr[1]/td[2]/button[1]");
	}
	
	public WebElement get_AdvSearch_Search() throws Exception{
		return SeleniumHelperClass.findWebElementbyid("searchButton", "none");
	}
	
	/*public WebElement get_NamedRel_Searchlist() throws Exception{
		return SeleniumHelperClass.findWebElementbyTagName("tr", "none");
		
	}*/
	
	//To get the Named Relationships list in the window
	public List<WebElement> get_Delete_NRlist() throws Exception{
		return SeleniumHelperClass.findWebElements("//table[4]/tbody/tr[1]/td/form/div/table/tbody/tr", "none");
	}
	//To get the Named relationship list from the Delete window.
	public WebElement get_Delete_NRlist_Searchlist(int i) throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//table[4]/tbody/tr[1]/td/form/div/table/tbody/tr["+i+"]/td[1]/div","none");
		
	}
	
	public WebElement get_Delete_Comments() throws Exception{
		return SeleniumHelperClass.findWebElementbyid("comments", "none");
	}
	
	public WebElement get_NRDelete() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//body/center/table/tbody/tr[3]/td/button[1]", "none");
	}
	
	public WebElement get_NamedRel_AllRelationships() throws Exception{
		return SeleniumHelperClass.findWebElementbyLink("All Relationships", "MainFrame");
	}
	
	public WebElement get_NRSearch_FromPos() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//body/div[2]/form/div[2]/div/table/tbody/tr[5]/td/table/tbody/tr/td[1]/table/tbody/tr/td[2]/input", "contentframe");
	}
	
	public WebElement get_NRSearch_ToPos() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//body/div[2]/form/div[2]/div/table/tbody/tr[5]/td/table/tbody/tr/td[2]/table/tbody/tr/td[2]/input", "contentframe");
	}
	
	public WebElement getSearchToPos() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//input[@name='To Position']", "contentframe");
	}
	public WebElement get_NewSearch() throws Exception{
		return SeleniumHelperClass.findWebElementbyLink("New Search", "MainFrame");
	}
	
	public WebElement uploadButton() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'Upload Named Relationship')]", "MainFrame");
	}
	
	public WebElement getDownloadTemplateLink() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//b[contains(text(),'Click here')]", "addVersionframe");
	}
	
	public WebElement getCancelBtn() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath(".//*[@onclick='doCancel()']", "addVersionframe");
	}
	
	public String getUploadFileLocation(String file){		
		return this.getClass().getClassLoader().getResource(file).getFile();
	}
	
	public String getUploadFile(String filelocation){
		String URL= getUploadFileLocation(filelocation);
		if (!SetWebDrivers.runningOS.equals("Mac") && !SetWebDrivers.runningOS.equalsIgnoreCase("Linux")) {
			URL = URL.substring(1, URL.length()).replace("/", "\\");
		}
		logger.info("URL:" + URL);
		return URL;
		//csvSheetName = fileName;
	}
	
	
	public String getUploadFileUrl(String file) {
		String url;
		url = this.getClass().getClassLoader().getResource("com.xactly.incent.organization/UploadNamedRelationship/" + file).getFile();

		if (!SetWebDrivers.runningOS.equals("Mac") && !SetWebDrivers.runningOS.equalsIgnoreCase("Linux")) {

			url = url.substring(1, url.length()).replace("/", "\\");
		}
		return url;
	}
	
	public WebElement uploadNamedRelationshipText() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='namedRelationship']", "addVersionframe");
	}
	
	public WebElement uploadInParentWindow() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//*[@onclick='done()']", "addVersionframe");
	}
	
	public WebElement uploadField() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//input[@type='file']", "addVersionframe");
	}
	
	public WebElement okButton() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//button[@onclick='done()']", "addVersionframe");
	}
	
	public WebElement getErrorText() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='rTable']//td[3]", "addversionframe"));
	}
	
	public WebElement getUploadErrorText() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='rTable']//td[1]", "addversionframe"));
	}
	
	public WebElement getSuccessText() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//p", "addversionframe"));
	}
	
	public NamedRelPage(String testtype) throws Exception {
		
		if(testtype.equalsIgnoreCase("gui"))
        {
            new Organization("gui");
            SeleniumHelperClass.findWebElementbyid("A_Named Relationships", "topFrame").click();
			SeleniumHelperClass.acceptAlert();//this is added to handle the alert which comes when we click on the sublinks in organization,Can be removed once dev fix this issue.
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
			SeleniumHelperClass.isVisible(get_oNamedrelationship_Create_NamedRelationship(), 15);
        }
        else if(testtype.equalsIgnoreCase("gui-new"))
        {
            
            new Organization("gui-new");
			LeftNavigationUtil.clickOnNamedRelationTab();
			SeleniumHelperClass.acceptAlert();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
			SeleniumHelperClass.isVisible(get_oNamedrelationship_Create_NamedRelationship(), 15);
        }
	}
	
	
	public void CreateNamedRelationship(String name,String desc) throws Exception{
		drv = SetWebDrivers.getDriver();
		parentWindow = drv.getWindowHandle();
		get_oNamedrelationship_Create_NamedRelationship().click();
		Thread.sleep(3000);
		switchToPopup();
		get_oNR_name().sendKeys(name);
		get_oNR_Desc().sendKeys(desc);
		get_oNR_Save().click();
		Thread.sleep(2000);
		switchBackFromPopup(parentWindow);
	}
	
	
	public void CreateRelationship(String FromPos,String ToPos) throws Exception{
		get_oNR_CreteRelationship().click();
		switchToPopup();
		
		if (FromPos != ""){
		get_oNR_CreateRelationship_SearchPosition().sendKeys(FromPos);
		get_oNR_CreateRelationship_Search().click();
		Thread.sleep(3000);
		get_CreateRelationship_SelectPos().click();
        get_oNR_SelectFromPosition().click();
		Thread.sleep(3000);
		}
		
		get_oNR_CreateRelationship_SearchPosition().clear();
		get_oNR_CreateRelationship_SearchPosition().sendKeys(ToPos);
		get_oNR_CreateRelationship_Search().click();
		Thread.sleep(2000);
		get_CreateRelationship_SelectPos().click();
		Thread.sleep(2000);
		get_oNR_SelectToPosition().click();
		Thread.sleep(2000);
		get_oNR_CreateRelationship_Save().click();
		Thread.sleep(1000);
		switchBackFromPopup(parentWindow);
		
	}
	
	public void DeleteNamedRelationship(String name) throws Exception{
		get_DeleteNamedrelationship().click();
		switchToPopup();
		Thread.sleep(7000);
		int elementslist = get_Delete_NRlist().size();
		logger.info("Table rows size"+elementslist);
		for (int i=1;i<=elementslist;i++){
		if (get_Delete_NRlist_Searchlist(i).getText().contentEquals(name)){
		get_Delete_NRlist_Searchlist(i).click();
		break;
		}
	}
	}
	
	public void AddVersion(String EffectiveStartDate) throws Exception{
		get_Addversion().click();
	    switchToPopup();
	    Thread.sleep(5000);
	    get_Addversion_EffStart().sendKeys(EffectiveStartDate);
	    get_Addversion_Save().click();
	}
	
	public void SearchNamedRelationships(String name) throws Exception{
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		parentWindow = drv.getWindowHandle();
		setParentWindowID(parentWindow);
		get_oNamedrelationship_EdidNamedRelationship().click();
		switchToPopup();
		get_oNR_EditNR_Name().sendKeys(name);
		get_oNR_EditNR_Search().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	   	getEditNamedRelationshiptable("Name",1).click();
    	get_oNR_EditNR_Ok().click();
    	switchBackFromPopup(getParentWindowID());
	}
	
	public void SearchNamedRelationship(String name) throws Exception{
		get_oNamedrelationship_EdidNamedRelationship().click();
		switchToPopup();
		get_oNR_EditNR_Name().sendKeys(name);
		get_oNR_EditNR_Search().click();
	}
	
	public void SearchNR(String Frompos,String Topos) throws Exception{
		get_NRSearch_FromPos().sendKeys(Frompos);
		Thread.sleep(2000);
		get_NRSearch_ToPos().sendKeys(Topos);
		get_AdvSearch_Search().click();
		Thread.sleep(5000);
		getEditNamedRelationshiptable("Relationship Name", 1).click();
		
	}
	
	public void switchToPopup() throws Exception {
		drv = SetWebDrivers.getDriver();
		Set<String> windowHandlers = drv.getWindowHandles();
		for (String windowHandle : windowHandlers) {
			recentWindow = windowHandle;
			
		}
		drv.switchTo().window(recentWindow);

	}
	
	

	public void switchBackFromPopup(String parWindow) throws Exception {
		drv.switchTo().window(parWindow);
				
	}
	
	public WebElement downloadNamedRelationShip() throws Exception {

		return SeleniumHelperClass.findWebElementbyLink("Download Relationships", "mainFrame");
		
	}
	
	public WebElement getNamerelSearchPosition() throws Exception {

		return SeleniumHelperClass.findWebElementbyXpath("//*[@name='From Position']", "contentFrame");
		
	}
	
	public WebElement getDownloadButton() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//button[text()='Download']", "downloadFrame");
	}
	
	public WebElement valueOfToPersonfirstRow(String date) throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//div[text()='"+date+"']//..//..//td[@n='toParticipant']", "contentFrame");
	}
	
	public WebElement valueOfPersonSecondRow() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//div[text()='Start of Time']//..//..//td[@n='toParticipant']", "contentFrame");
	}
	
	public void searchNameRel(String name) throws Exception	{
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		getNamerelSearchPosition().sendKeys(name);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_oNR_CreateRelationship_Search().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		
	}
	
	public String searchNameRelToPos(String name) throws Exception	{
		
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		getSearchToPos().sendKeys(name);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_AdvSearch_Search().click();
		SeleniumHelperClass.isVisible(valueOfToPersonfirstRow(date), 40);
	    String valueofTopersonStartTime = valueOfPersonSecondRow().getText();	
	    return valueofTopersonStartTime;
		 
	}	
	
	public void downloadNamedRel() throws Exception{
		SeleniumHelperClass.isClickable(get_Downloadrelationships(), 30);
		get_Downloadrelationships().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		 String parentwin = SeleniumHelperClass.switchToPopupWindow();
		 SeleniumHelperClass.isClickable(getDownloadButton(), 30);
		 getDownloadButton().click();
		SeleniumHelperClass.switchToWindow(parentwin);
		
	}
	
	public File downloadTemplate() throws Exception{
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		SeleniumHelperClass.isVisible(uploadButton(), 10);
		uploadButton().click();		
		switchToPopup();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SeleniumHelperClass.isVisible(getDownloadTemplateLink(), 10);
		getDownloadTemplateLink().click();		
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX );
		logger.info("File Download is in progress");
		getCancelBtn().click();
		switchBackFromPopup(parentWindow);
		latestFile = findLatestFileInLocation(Constants.downloadLoc);	
		logger.info("latestFile:"+latestFile);		
		return latestFile;
	}
	
	public File findLatestFileInLocation(String downloadLoc) throws InterruptedException {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/2);
		latestFilefromDir = getLatestFilefromDir(downloadLoc);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/2);
		return latestFilefromDir;
	}

	public File getLatestFilefromDir(String dirPath) throws InterruptedException {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/2);
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			return null;
		}

		File lastModifiedFile = files[0];
		for (int i = 1; i < files.length; i++) {
			if (lastModifiedFile.lastModified() < files[i].lastModified()) {
				lastModifiedFile = files[i];
			}
		}
		return lastModifiedFile;
		}
	
	
	public boolean uploadNamedRelationship(String url,String namedrelationshipText,String errorMsg,String successMsg) throws Exception {
		boolean flag=true;		
		uploadButton().click();        
        String parentWIn = SeleniumHelperClass.switchToPopupWindow();
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);        
		uploadField().sendKeys(url);	
		uploadNamedRelationshipText().sendKeys(namedrelationshipText);
		uploadInParentWindow().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*2);
			
		try{
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN); 
			flag=true;
			getSuccessText().getText().contains(successMsg);
			okButton().click();			
			SeleniumHelperClass.switchToWindow(parentWIn);
		}
		catch(Exception ex){
			flag=false;
			getUploadErrorText().getText().contains(errorMsg);
			SeleniumHelperClass.switchToWindow(parentWIn);
		}		
		return flag;		
	}	
		
	public WebElement getNRTable() throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN); 
		WebElement obj = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='listDiv']//div", "ceditframe");		
		return obj;
	}
	
	public void uploadRestrictedRelationship(String url,String namedrelationshipText) throws Exception {
		parentWindow = drv.getWindowHandle();
		logger.info("Parent window handle: "+parentWindow);
		setParentWindowID(parentWindow);
		uploadButton().click();        
        SeleniumHelperClass.switchToPopupWindow();
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/2);        
		uploadField().sendKeys(url);	
		uploadNamedRelationshipText().sendKeys(namedrelationshipText);
		uploadInParentWindow().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX *2);
	}	
	
	public void OkClick() throws Exception {
		okButton().click();	
		logger.info("Switching to parent window:"+getParentWindowID());
		String parentWin = getParentWindowID();
		switchBackFromPopup(parentWin);
		new NamedRelPage(SetWebDrivers.getNavigationType());
		SeleniumHelperClass.isVisible(get_oNamedrelationship_Create_NamedRelationship(), SeleniumHelperClass.system_SpeedlimitMAX);
		logger.info("Closed the pop-up and switched back to parent window");

	}
	
	public void CancelClick() throws Exception {
		get_EditNR_Cancel().click();	
		logger.info("Clicked on Cancel");
		switchBackFromPopup(getParentWindowID());
		logger.info("Switched to parent window");
		new NamedRelPage(SetWebDrivers.getNavigationType());
		SeleniumHelperClass.isVisible(get_oNamedrelationship_Create_NamedRelationship(), SeleniumHelperClass.system_SpeedlimitMAX);
		logger.info("Closed the pop-up and switched back to parent window");
	}
	
	public List<WebElement> get_op_objectDropdown() throws Exception{
		return (SeleniumHelperClass.findWebElementsById("object_select", "contentFrame"));
	}
	
	//To get the Search button in Create Relationship window
		public WebElement get_oNR_CreateRelationship_Search1() throws Exception{
			return (SeleniumHelperClass.findWebElementbyid("searchButton", ""));
		}
		
		
		
		public WebElement get_Addversion_Description_popup() throws Exception{
			return SeleniumHelperClass.findWebElementbyid("desc", "addversionframe");
			
		}
		
		public WebElement get_Editversion_Save() throws Exception{
			return SeleniumHelperClass.findWebElementbyXpath("//button[text()='Save']", "addversionframe");
			
		}
		
	public void CreateRelationship1(String FromPos,String ToPos) throws Exception{
	get_oNR_CreteRelationship().click();
	switchToPopup();

	if (FromPos != ""){
	get_oNR_CreateRelationship_SearchPosition().sendKeys(FromPos);
	get_oNR_CreateRelationship_Search1().click();
	SeleniumHelperClass.isVisible(get_oNR_CreateRelationship_Search1(), SeleniumHelperClass.system_SpeedlimitMAX);

	get_CreateRelationship_SelectPos().click();
	get_oNR_SelectFromPosition().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	}

	get_oNR_CreateRelationship_SearchPosition().clear();
	get_oNR_CreateRelationship_SearchPosition().sendKeys(ToPos);
	get_oNR_CreateRelationship_Search1().click();
	SeleniumHelperClass.isVisible(get_oNR_CreateRelationship_Search1(), SeleniumHelperClass.system_SpeedlimitMAX);


	get_CreateRelationship_SelectPos().click();

	SeleniumHelperClass.isVisible(get_CreateRelationship_SelectPos(), SeleniumHelperClass.system_SpeedlimitMAX);

	get_oNR_SelectToPosition().click();
	SeleniumHelperClass.isVisible(get_oNR_SelectToPosition(), SeleniumHelperClass.system_SpeedlimitMAX);


	get_oNR_CreateRelationship_Save().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*3);

	switchBackFromPopup(parentWindow);
	}

	public void editnamedrelationship()throws Exception{

	getEditNamedRelationshiptable("Name",1).click();
	get_oNR_EditNR_Ok().click();
	switchBackFromPopup(getParentWindowID());

	}

	public void searchnamedrelationship(String position1,String position2 )throws Exception{

	     get_NewSearch().click();

	     SeleniumHelperClass.isVisible(get_NRSearch_FromPos(), SeleniumHelperClass.system_SpeedlimitMAX);

	     SearchNR(position1,position2);
	     
		SeleniumHelperClass.isVisible(getNRTable1(), SeleniumHelperClass.system_SpeedlimitMAX*2);

	     
	}

	   public void EditVersionwithoutassertion(String Description) throws Exception{
	        get_Editversion().click();
	         switchToPopup();
	         SeleniumHelperClass.isVisible(get_Addversion_EffStart(), SeleniumHelperClass.system_SpeedlimitMAX);

	            get_Addversion_Description_popup().clear();

	             get_Addversion_Description_popup().sendKeys(Description);

	            get_Editversion_Save().click();

	              switchBackFromPopup(getParentWindowID());

	         }

		public WebElement getNRTable1() throws Exception {
			
			WebElement obj = SeleniumHelperClass.findWebElementbyXpath("(//*[@id='listDiv']//div)[3]", "contentFrame");
			return obj;
		}


		public WebElement getNRTable2() throws Exception {
			WebElement obj = SeleniumHelperClass.findWebElementbyXpath("//td[@n='description']", "clistframe");
			return obj;
		}
	    
		public void auditVersion() throws Exception{
			get_oNR_AudiVersion().click();
			switchToPopup();
			get_AuditVersion_NrLastModifiedBy();
			get_AuditVersion_NrCreatedBy();
		}
		public WebElement get_oNR_AudiVersion() throws Exception{
			return (SeleniumHelperClass.findWebElementbyLink("Audit Version", "MainFrame"));
		}
		public String get_AuditVersion_NrLastModifiedBy() throws Exception{
			return (SeleniumHelperClass.findWebElementbyXpath("//*[@class='listTable']/tr[1]/td[@n='modifiedByName']").getText());
		}
		public String get_AuditVersion_NrCreatedBy() throws Exception{
			return (SeleniumHelperClass.findWebElementbyXpath("//*[@class='listTable']/tr[1]/td[@n='createdByName']").getText());
		}
		public WebElement get_NrRelation() throws Exception{
			return SeleniumHelperClass.findWebElement("xpath","//*[@id='listTable_relationships_edit_list']/tr[2]/td[3]","ceditframe");
		}
		public void deleteRelationship(String comment) throws Exception{
			get_oNR_DeleteRelationship().click();
			switchToPopup();
			get_Delete_Comments().sendKeys(comment);
			get_NRDelete().click();
		}
		public WebElement get_oNR_DeleteRelationship() throws Exception{
			return (SeleniumHelperClass.findWebElementbyLink("Delete Relationship", "MainFrame"));
		}
	
}


