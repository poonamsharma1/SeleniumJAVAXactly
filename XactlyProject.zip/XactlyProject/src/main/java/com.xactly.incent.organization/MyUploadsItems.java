package com.xactly.incent.organization;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.asserts.SoftAssert;

import com.xactly.icm.xtoolkit.wso.DeleteResponse;
import com.xactly.icm.xtoolkit.wso.ErrorCode;
import com.xactly.icm.xtoolkit.wso.PersonWSO;
import com.xactly.icm.xtoolkit.wso.PositionHierarchyTypeWSO;
import com.xactly.icm.xtoolkit.wso.PositionHierarchyWSO;
import com.xactly.icm.xtoolkit.wso.PositionWSO;
import com.xactly.icm.xtoolkit.wso.SearchResponse;
import com.xactly.icm.xtoolkit.wso.TitleWSO;
import com.xactly.icm.xtoolkit.wso.UploadResponse;
import com.xactly.xcommons.javahelper.CSVHelper;
import com.xactly.xcommons.javahelper.ExcelConnector;
import com.xactly.xcommons.javahelper.Time;

public class MyUploadsItems {
public static Logger logger = Logger.getLogger(MyUploadsItems.class.getName());
	private static XSSFSheet ExcelWSheet;
	private static XSSFWorkbook ExcelWBook;
	private DeleteResponse deleteResponse;
	private String hierarchyTypeName = "DEFAULT";
	Calendar c = null;

	public byte[] getBytesFromFile(File uploadFile1) throws Exception {
		FileInputStream is = new FileInputStream(uploadFile1);
		long length = uploadFile1.length();
		if (length > 2147483647L) {
			throw new Exception("File too large");
		} else {
			byte[] bytes = new byte[(int) length];
			int offset = 0;

			int numRead1;
			for (boolean numRead = false; offset < bytes.length
					&& (numRead1 = is.read(bytes, offset, bytes.length - offset)) >= 0; offset += numRead1) {
				;
			}

			if (offset < bytes.length) {
				throw new IOException("Could not completely read file "	+ uploadFile1.getName());
			} else {
				is.close();
				return bytes;
			}
		}
	}



	public List<TitleWSO> createTitleWSO(File file) throws IOException{

		List<TitleWSO> titleWSOList = new ArrayList<TitleWSO>();

		List<String[]> csvContent = CSVHelper.csvReaderWithoutHeader(file.getPath());		

		TitleWSO titleWSO ;

		for ( String[] row : csvContent) {
			titleWSO = new TitleWSO();
			titleWSO.setName(row[0]);				
			titleWSOList.add(titleWSO);			
		}		
		return titleWSOList;
	}
	
	
	/**
	 * creates a TitleWSO object with just name as property
	 * @param name
	 * @return TitleWSO
	 * @throws Exception
	 */
	public TitleWSO createTitleWSOWithName(String name) throws Exception{
		TitleWSO titleWSO = new TitleWSO();
		titleWSO.setName(name);
		return titleWSO ;
	}
	
	
	public List<PersonWSO> createPersonWSO(File file) throws Exception{

		List<PersonWSO> personWSOList = new ArrayList<PersonWSO>();		
		List<String> columnContent = readExcelColumn("FirstName", file);
		PersonWSO personWSO ;

		for ( String row : columnContent) {
			personWSO = new PersonWSO();
			personWSO.setFirstName(row);				
			personWSOList.add(personWSO);			
		}		
		return personWSOList;
	}
	
	/**
	 * Creates a Person object for each person in the excel file provided and returns a list of such objects
	 * @param file
	 * @return List of PersonWSO
	 * @throws Exception
	 */
	public List<PersonWSO> createPersonWSOWithAllData(File file) throws Exception{

		List<PersonWSO> personWSOList = new ArrayList<PersonWSO>();	
		List<Map<String,Object>> mapList = new ArrayList<Map<String,Object>>();
		ExcelConnector exCon = new ExcelConnector();
		mapList = exCon.convertExcelRowToMapEOF(file);
		
		for(Map<String,Object> map :mapList){
			PersonWSO personWSO = new PersonWSO();
			personWSO = createPersonWSOfromMap(map);
			personWSOList.add(personWSO);
		}
		
		
		return personWSOList;
	}
	
	
	
	/**
	 * Creates PersonWSO object from each map provided
	 * @param map
	 * @return PersonWSO
	 * @throws Exception
	 */
	public PersonWSO createPersonWSOfromMap(Map<String, Object> map) throws Exception{
		PersonWSO personWSO = new PersonWSO();
		Map<String,Object> personMap = new HashMap<String, Object>(map);
		for (Map.Entry<String, Object> m : personMap.entrySet()) {
			//logger.info(m.getKey()+"---:---"+m.getValue());
			   personWSO = setPersonWSOProperty(personWSO, m.getKey(), m.getValue());
		}
		return personWSO;
	}
	
	/**
	 * Sets the properties of PersonWSO object with the values provided
	 * Uses Switch on String - Needs Java7 and above
	 * @param personWSO
	 * @param headerKey
	 * @param value
	 * @return PersonWSO
	 * @throws Exception
	 */
	public PersonWSO setPersonWSOProperty(PersonWSO personWSO, String headerKey, Object value) throws Exception{
		if(headerKey.equals("Employee ID*"))
		{
			String eId = Double.toString((Double) value);
			eId = eId.substring(0, eId.length() - 2);// to remove ".0"
			//logger.info("###now empID is "+eId);
			personWSO.setEmployeeId(eId);
		}
		else if(headerKey.equals("Personal Target*"))
		{
			BigDecimal b = new BigDecimal((Double)value);
			//logger.info("###personal target is "+b);
			personWSO.setPersonalTarget(b);
		}
		else if(headerKey.equals("Effective Start Date"))
		{
			if (value!=null){
				Calendar calendar = Calendar.getInstance();
				if (value instanceof Date) {
					calendar.setTime((Date) value);
				}
				//logger.info("###date is" + calendar);
				personWSO.setEffectiveStartDate(calendar);
			}
		}
		else if(headerKey.equals("Description")||headerKey.equals("First Name*")||headerKey.equals("Middle Name*")||headerKey.equals("Last Name*")||headerKey.equals("Region"))
		{
			String methodName =  "set"+headerKey.replaceAll("[ *]", "");
			Method method = personWSO.getClass().getMethod(methodName,String.class);
			//logger.info("###method name is "+methodName+" "+(String)value);
			method.invoke(personWSO, (String)value);
		}
		
		/*//switch on string is support in Java 1.7+ , use this piece of code once entire framework is moved to 1.8
		switch (headerKey){
			case "Employee ID*": {
				String eId = Double.toString((double) value);
				eId = eId.substring(0, eId.length() - 2);// to remove ".0"
				//logger.info("###now empID is "+eId);
				personWSO.setEmployeeId(eId);
				break;
			}
			case "Description":
			case "First Name*":
			case "Middle Name*":
			case "Last Name*": 
			case "Region": {
				String methodName =  "set"+headerKey.replaceAll("[ *]", "");
				Method method = personWSO.getClass().getMethod(methodName,String.class);
				//logger.info("###method name is "+methodName+" "+(String)value);
				method.invoke(personWSO, (String)value);
				break;
			
			}
			case "Personal Target*": {
				BigDecimal b = new BigDecimal((double)value);
				//logger.info("###personal target is "+b);
				personWSO.setPersonalTarget(b);
				break;
			}
			case "Effective Start Date": {
				if (value!=null){
					Calendar calendar = Calendar.getInstance();
					if (value instanceof Date) {
						calendar.setTime((Date) value);
					}
					//logger.info("###date is" + calendar);
					personWSO.setEffectiveStartDate(calendar);
				}
				break;
			}
		}*/
		
		return personWSO;
	}
	
	/**
	 * Creates a Position object for each person in the excel file provided and returns a list of such objects
	 * @param file
	 * @return List of PositionWSO
	 * @throws Exception
	 */
	public List<PositionWSO> createPositionWSOWithAllData(String filePath) throws Exception{

		List<PositionWSO> positionWSOList = new ArrayList<PositionWSO>();	
		List<Map<String,Object>> mapList = new ArrayList<Map<String,Object>>();
		CSVHelper csv = new CSVHelper();
		mapList = csv.convertCSVRowToMap(filePath);
		
		for(Map<String,Object> map :mapList){
			PositionWSO positionWSO = new PositionWSO();
			positionWSO = createPositionWSOfromMap(map);
			positionWSOList.add(positionWSO);
		}
		
		
		return positionWSOList;
	}
	
	/**
	 * Creates PositionWSO object from each map provided
	 * @param map
	 * @return PositionWSO
	 * @throws Exception
	 */
	public PositionWSO createPositionWSOfromMap(Map<String, Object> map) throws Exception{
		PositionWSO positionWSO = new PositionWSO();
		Map<String,Object> positionMap = new HashMap<String, Object>(map);
		for (Map.Entry<String, Object> m : positionMap.entrySet()) {
			//logger.info(m.getKey()+"---:---"+m.getValue());
			positionWSO = setPositionWSOProperty(positionWSO, m.getKey(), m.getValue());
		}
		return positionWSO;
	}
	
	/**
	 * Sets the properties of PositionWSO object with the values provided
	 * Uses Switch on String - Needs Java7 and above
	 * @param PositionWSO
	 * @param headerKey
	 * @param value
	 * @return PositionWSO
	 * @throws Exception
	 */
	public PositionWSO setPositionWSOProperty(PositionWSO positionWSO, String headerKey, Object value) throws Exception{
		if(headerKey.equals("Position Name*"))
		{
			logger.info("Position name to be set "+value);
			positionWSO.setName((String)value);
		}
		else if(headerKey.equals("Effective Start Date"))
		{
			if (value!=null){
				Calendar cal = Calendar.getInstance();
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
				cal.setTime(sdf.parse((String) value));
				//logger.info(cal);
				positionWSO.setEffectiveStartDate(cal);
			}
		}
		else if(headerKey.equals("Description"))
		{
			logger.info("Description to be set "+value);
			positionWSO.setDescription((String)value);
		}
		
		/*//switch on string is support in Java 1.7+ , use this piece of code once entire framework is moved to 1.8
		switch (headerKey){
			
			}
		}*/
		
		return positionWSO;
	}

	/**
	 * Creates PersonWSO object with only FirstName set
	 * helpful while deleting a set of Persons with similar first name
	 * @param name
	 * @return PersonWSO
	 * @throws IOException
	 */
	public PersonWSO createPersonWSOWithFirstName(String name) throws IOException{

		PersonWSO personWSO = new PersonWSO();
		personWSO.setFirstName(name);
		return personWSO ;
		
	}
	
	/**
	 * Creates PersonWSO object with only EmployeeID set
	 * Helpful while searching different People Versions
	 * @param empId
	 * @return PersonWSO
	 * @throws IOException
	 */
	public PersonWSO createPersonWSOWithEmployeeId(String empId) throws IOException{

		PersonWSO personWSO = new PersonWSO();
		personWSO.setEmployeeId(empId);
		return personWSO ;
		
	}
	
	public List<PositionWSO> createPositionWSO(File file) throws Exception{

		List<PositionWSO> positionWSOList = new ArrayList<PositionWSO>();		
		List<String[]> csvContent = CSVHelper.csvReaderWithoutHeader(file.getPath());
		PositionWSO positionWSO ;

		for ( String[] row : csvContent) {
			positionWSO = new PositionWSO();
			logger.info("setting name "+row[0]);
			positionWSO.setName(row[0]);				
			positionWSOList.add(positionWSO);			
		}		
		return positionWSOList;
	}
	
	/**
	 * Creates PositionWSO object with only FirstName set
	 * helpful while deleting a set of Persons with similar first name
	 * @param name
	 * @return PersonWSO
	 * @throws IOException
	 */
	public PositionWSO createPositionWSOWithName(String name) throws IOException{

		PositionWSO positionWSO = new PositionWSO();
		positionWSO.setName(name);
		return positionWSO ;
		
	}

	/**
	 * creates PositionHierarchyTypeWSO using the start date provided and the default name
	 * used for search as it requires the default name
	 * @param effectiveStartDate
	 * @return
	 * @throws Exception
	 */
	public PositionHierarchyTypeWSO createPositionHierarchyTypeWSOForSearch(int effectiveStartDate) throws Exception{
		PositionHierarchyTypeWSO hierarchyObj = new PositionHierarchyTypeWSO();
		Time t = new Time();
		hierarchyObj.setName(hierarchyTypeName);
		//c = t.getCalendarInstanceIncremented(effectiveStartDate);
		hierarchyObj.setEffectiveStartDate(c);
		return hierarchyObj;
	}
	
	/**
	 * creates PositionHierarchyTypeWSO using the start date provided and the version name provided
	 * used for upload to distinguish each version with a unique name
	 * @param versionName
	 * @param effectiveStartDate
	 * @return
	 * @throws Exception
	 */
	public PositionHierarchyTypeWSO createPositionHierarchyTypeWSOForUpload(String versionName, int effectiveStartDate) throws Exception{
		PositionHierarchyTypeWSO hierarchyObj = new PositionHierarchyTypeWSO();
		Time t = new Time();
		hierarchyObj.setName(versionName);
		c = t.getCalendarInstanceIncremented(effectiveStartDate);
		hierarchyObj.setEffectiveStartDate(c);
		return hierarchyObj;
	}
	
	/**
	 * creates a List of PositionHierarchyWSO objects from the file provided
	 * each relationship maps to one PositionHierarchyWSO object
	 * @param file uploaded hierarchy file
	 * @return List of PositionHierarchyWSO objects from the file provided
	 * @throws IOException
	 */
	public List<PositionHierarchyWSO> createPositionHierarchyWSO(File file) throws IOException{

		List<PositionHierarchyWSO> hierarchyWSOList = new ArrayList<PositionHierarchyWSO>();
		List<String[]> csvContent = CSVHelper.csvReaderWithoutHeader(file.getPath());
		//logger.info("csv size is ----"+csvContent.size());
		PositionHierarchyWSO hierarchyWSO;
		for (int i = 0; i < csvContent.size(); i++) {
			hierarchyWSO = new PositionHierarchyWSO();
			//logger.info(csvContent.get(i)[0]+" --- "+csvContent.get(i)[1]);
			hierarchyWSO.setToPositionName(csvContent.get(i)[0]);
			if(!csvContent.get(i)[1].equals("")){
				hierarchyWSO.setFromPositionName(csvContent.get(i)[1]);
			}
			hierarchyWSOList.add(hierarchyWSO);
		}
		return hierarchyWSOList;
	}

	public String getUploadFileLocation(String file){
		String URL = this.getClass().getClassLoader().getResource("com.xactly.incent.organization//TitleUpload//"+file).getFile();		
		return URL.substring(1, URL.length()).replace("/", "\\");
	}
	
	
		
		public boolean isUploadSuceed(boolean isSucceed, UploadResponse uploadResponse) {
			ErrorCode[] errorCodes = uploadResponse.getErrorCodes();
			if (errorCodes == null || errorCodes.length == 0)
				return isSucceed;

			for (int i = 0; i < errorCodes.length; i++) {

				ErrorCode ec = errorCodes[i];
				logger.info("Error Code: " + ec.getCode() + "\n");
				logger.info("Error Text: " + ec.getReason() + "\n");
				logger.info("Stack: " + ec.getStackTrace() + "\n");
				isSucceed = false;
			}
			return isSucceed;
		}
		
		public List<String> readExcelColumn(String field, File file) throws Exception {
			logger.info("Field in readExcel " + field);
			String formatField = formatField(field);
			logger.info("Formatted String = " + formatField);

			FileInputStream ExcelFile = new FileInputStream(file);
			ExcelWBook = new XSSFWorkbook(ExcelFile);
			ExcelWSheet = ExcelWBook.getSheetAt(0);
			int rowNum = ExcelWSheet.getLastRowNum();
			int noOfColumns = ExcelWSheet.getRow(0).getLastCellNum();
			String[] header = new String[noOfColumns];

			List<String> dataList = new ArrayList<String>();
			// logger.info("Rows : " + rowNum + " Column : " + noOfColumns);
			for (int i = 0; i < noOfColumns; i++) {
				int cellType = ExcelWSheet.getRow(0).getCell(i).getCellType();
				if (cellType == org.apache.poi.ss.usermodel.Cell.CELL_TYPE_STRING) {
					header[i] = ExcelWSheet.getRow(0).getCell(i)
							.getStringCellValue();
				} else if (cellType == org.apache.poi.ss.usermodel.Cell.CELL_TYPE_NUMERIC) {
					header[i] = Double.toString(ExcelWSheet.getRow(0).getCell(i).getNumericCellValue());
				}
			}

			for (int i = 0; i < header.length; i++) {
				try {
					if (header[i].contains(formatField)) {
						for (int k = 1; k < rowNum; k++) {
							int cellType = ExcelWSheet.getRow(k).getCell(i).getCellType();
							if (cellType == org.apache.poi.ss.usermodel.Cell.CELL_TYPE_STRING) {
								dataList.add(ExcelWSheet.getRow(k).getCell(i).getStringCellValue());

							} else if (cellType == org.apache.poi.ss.usermodel.Cell.CELL_TYPE_NUMERIC) {
								double numericCellValue = ExcelWSheet.getRow(k).getCell(i).getNumericCellValue();
								String string = Double.toString(numericCellValue);
								dataList.add(string);
							}
						}
					}
				} catch (Exception e) {
					logger.info("Missing Header");
				}
			}
			dataList.remove("<EOF>");
			return dataList;
		}
		
		public String formatField(String field) {
			StringBuilder s = new StringBuilder(field);

			for (int i = 1; i < s.length(); i++) {
				if (Character.isUpperCase(s.charAt(i))) {
					s.insert(i++, ' ');
				}
			}
			return s.toString();

		}
		
		/**
		 * deletes all the position entries with the name provided while creating the PositionWSO object
		 * @param p PositionWSO created with a common string name
		 * @param service
		 * @throws Exception
		 */
	public void deletePositionsWithSingleVersion(PositionWSO p, com.xactly.icm.xtoolkit.service.XService service) throws Exception {
		Boolean isDeleted = true;
		String name = "";
		SoftAssert sa = new SoftAssert();
		logger.info("Deleting uploaded Positions with common name " + p.getName());

		while (isDeleted) {
			SearchResponse sr = service.search(p);
			if (sr.getSearchRecords() == null) {
				break;
			}
			// positions with single versions only
			PositionWSO pos = (PositionWSO) sr.getSearchRecords()[0];
			name = pos.getName();
			DeleteResponse deletePositionResponse = service.delete(pos);
			ErrorCode[] errorCodes = deletePositionResponse.getErrorCodes();
			isDeleted = deletePositionResponse.isResult();
			logger.info("Deletion:" + isDeleted);
			sa.assertTrue(((errorCodes.length == 1) && (errorCodes[0].getReason() == null)),
					"Deletion failed for " + name + "  reason: " + errorCodes[0].getReason());
			logger.info("Deleted: " + name);

		}
		sa.assertAll();
	}
	
	public PositionHierarchyTypeWSO createPositionHierarchyTypeWSOForSearchwithversionname(String versionName,int effectiveStartDate) throws Exception{
		PositionHierarchyTypeWSO hierarchyObj = new PositionHierarchyTypeWSO();
		Time t = new Time();
		hierarchyObj.setName(versionName);
		hierarchyObj.setEffectiveStartDate(c);
		return hierarchyObj;
	}
	
	public PositionHierarchyTypeWSO createPositionHierarchyTypeWSOForUploadwithUserinputDate(String versionName, String date,int effectiveStartDate) throws Exception{
		PositionHierarchyTypeWSO hierarchyObj = new PositionHierarchyTypeWSO();
		Time t = new Time();
		hierarchyObj.setName(versionName);
		c = t.getCalendarInstanceIncrementedwithUserInputdate(date,effectiveStartDate);
		hierarchyObj.setEffectiveStartDate(c);
		return hierarchyObj;
	}
}
			
		
		

