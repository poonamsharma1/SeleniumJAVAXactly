package com.xactly.incent.organization;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.Cookie;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Headers;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ResponseBody;
import com.jayway.restassured.specification.RequestSpecification;
import com.xactly.incent.navigation.oktaUsersBaseURIs;
import com.xactly.xcommons.restapi.LoginToRestAPI;
import com.xactly.xcommons.restapi.RestAPIHelperClass;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

import ch.qos.logback.core.recovery.ResilientSyslogOutputStream;
import edu.emory.mathcs.backport.java.util.concurrent.TimeUnit;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class OktaUsers {

	public static Logger logger = Logger.getLogger(OktaUsers.class.getName());
	private static RestAPIHelperClass rest = new RestAPIHelperClass();
	public JsonPath jsonPathEvaluator;
	ArrayList businessRoles = new ArrayList();

	/**
	 * @author ahanda
	 * @function To generate iam-state cookie
	 * @parameters Nan
	 */
	public String fetchIAMStateCookie(String environment) {
		SeleniumHelperClass.openNewTab();
		SeleniumHelperClass.switchTabs("child");
		switch(environment) {
		case "qaexp02":
			SetWebDrivers.getDriver().get(oktaUsersBaseURIs.contextAPIQAEXP02);
			SeleniumHelperClass.waitPageLoad();
			break;
		case "qaintx":
			SetWebDrivers.getDriver().get(oktaUsersBaseURIs.contextAPIQAINTX);
			SeleniumHelperClass.waitPageLoad();
			break;
		case "qainty":
			SetWebDrivers.getDriver().get(oktaUsersBaseURIs.contextAPIQAINTY);
			SeleniumHelperClass.waitPageLoad();
			break;
		case "ociqaintx":
			SetWebDrivers.getDriver().get(oktaUsersBaseURIs.contextAPIOCIQAINTX);
			SeleniumHelperClass.waitPageLoad();
			break;
		}
		
		Cookie iamState = SetWebDrivers.getDriver().manage().getCookieNamed("iam-state");
		logger.info("Cookie Value: "+iamState.getValue());
		SeleniumHelperClass.switchTabs("parent");
		return iamState.getValue();
	}
	
	public String testFName = "TestFName" + SeleniumHelperClass.uniqueCharSequence();
	public String testLName = "TestLName" + SeleniumHelperClass.uniqueCharSequence();
	public String testXEmail = "testEmail"+SeleniumHelperClass.uniqueCharSequence()+"@gmail.com";
	
	public String newUserIDCreated = "";

	/**
	 * @function To create Okta User via API
	 * @parameterscookie = iam-state cookie value
	 */
	public boolean userCreated = false;
	public boolean createOktaUser(String cookie) {
		RequestSpecification request = RestAssured.given();
		request.header("Cookie", "iam-state=" +cookie);
		request.header("Content-Type", "application/json");
		
		JSONObject requestParams = new JSONObject();
		Map createUser = new LinkedHashMap(7);
		createUser.put("lastName", testLName);
		createUser.put("firstName", testFName);
		createUser.put("XACTLY_USER_EMAIL", testXEmail);
		requestParams.put("profile", createUser);
		
		request.body(requestParams.toJSONString());
		Response response = request.post(oktaUsersBaseURIs.createUserURI);
		if(response.getStatusCode()==201) {
			Headers head = response.getHeaders();
			String userURI = head.getValue("Location");
			Response resp = RestAssured.given().relaxedHTTPSValidation().header("Cookie", "iam-state="+cookie)
					.when().expect().statusCode(200).get(userURI).prettyPeek();
			if(resp.getStatusCode() == 200) {
				jsonPathEvaluator = resp.jsonPath();
				newUserIDCreated = jsonPathEvaluator.get("user.id");
				System.out.println("NEW_USER_ID :"+newUserIDCreated);
				userCreated = true;
			}else {
				userCreated = false;
			}
		}
		return userCreated;
	}
	
	
	
	/**
	 * @function To update Okta User profile via API
	 * @parameters cookie = iam-state cookie value
	 */
	public boolean updateUserProfile(String cookie) {
		RequestSpecification request = RestAssured.given();
		request.header("Cookie", "iam-state=" + cookie);
		request.header("Content-Type", "application/json");
		
		JSONObject requestParams = new JSONObject();
		requestParams.put("id", newUserIDCreated);
		
		Map userProfile = new LinkedHashMap(7);
		userProfile.put("XACTLY_BUSINESS_UUID", oktaUsersBaseURIs.business_UUID);
		userProfile.put("lastName", testLName+"_Updated");
		userProfile.put("XACTLY_BUSINESS_ID", oktaUsersBaseURIs.business_ID);
		userProfile.put("login", testXEmail);
		userProfile.put("firstName", testFName+"_Updated");
		userProfile.put("XACTLY_USER_EMAIL", testXEmail);
		userProfile.put("email", testXEmail);
		requestParams.put("profile", userProfile);
	
		request.body(requestParams.toJSONString());
		
		Response response = request.put(oktaUsersBaseURIs.updateProfileURI + newUserIDCreated).prettyPeek();
		if(response.getStatusCode()==200) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * @function To delete Okta User via API
	 * @parameters cookie = iam-state cookie value
	 */
	public boolean deleteOktaUser(String cookie) {
		Response respo = RestAssured.given().contentType("application/json").header("Cookie", "iam-state="+cookie).delete(oktaUsersBaseURIs.deleteUserURI+newUserIDCreated);
		if(respo.getStatusCode() == 204) {
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * @function To validate User Pagination
	 * @parameters iaaStateCookieValue = iam-state cookie value
	 */
	public boolean userPagination(String iaaStateCookieValue) {
		Response respo = rest.getRequest("iam-state", iaaStateCookieValue, oktaUsersBaseURIs.userPaginationURI);
		jsonPathEvaluator = respo.jsonPath();
		String nextUserURL = jsonPathEvaluator.get("next");
		if (nextUserURL != null && nextUserURL.contains("bizId")) {
			logger.info("NEXT USER URL: " + nextUserURL);
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * @function To validate Privileges & IDs
	 * @parameters cookie = iam-state cookie value
	 */
	public boolean fetchPrivilegesIDs(String cookie) {
		Response resp = RestAssured.given().contentType("application/json").header("Cookie", "iam-state="+cookie).get(oktaUsersBaseURIs.fetchPrivileges);
		jsonPathEvaluator = resp.jsonPath();
		if (resp.getStatusCode() == 200) {
			Map privilegesToNames = new LinkedHashMap();
			privilegesToNames = jsonPathEvaluator.get("privilegesToNames");
			logger.info(privilegesToNames);
			Map namesToPrivileges = new LinkedHashMap();
			namesToPrivileges = jsonPathEvaluator.get("namesToPrivileges");
			logger.info(namesToPrivileges);
			return !(privilegesToNames.get("333834").equals(null)) || !(privilegesToNames.get("350").equals(null)) && 
					!(namesToPrivileges.get("PAY_CURVES_READ_ONLY").equals(null)) || !(namesToPrivileges.get("PLAN_DESIGN_TEMPLATES").equals(null));
		} else {
			return false;
		}
	}
	
	/**
	 * @function To fetch roles associated with business
	 * @parameters cookie = iam-state cookie value
	 */
	public boolean fetchBusinessRoles(String cookie) {
		Response resp = RestAssured.given().contentType("application/json").header("Cookie", "iam-state="+cookie).get(oktaUsersBaseURIs.fetchBusinessRoles);
		jsonPathEvaluator = resp.jsonPath();
		if (resp.getStatusCode() == 200) {
			ArrayList businessRoles = new ArrayList();
			businessRoles = jsonPathEvaluator.get("roles");
			logger.info(businessRoles);
			return businessRoles.get(businessRoles.indexOf("Xactly")).equals("Xactly");
		} else {
			return false;
		}
	}
	
	/**
	 * @function To create roles associated with business
	 * @parameters cookie = iam-state cookie value
	 */
	public String roleName = "Sales Representative_"+SeleniumHelperClass.uniqueCharSequence();
	public boolean createBusinessRoles(String cookie) {
		RequestSpecification request = RestAssured.given();
		request.header("Cookie", "iam-state=" +cookie);
		request.header("Content-Type", "application/json");
		
		ArrayList privilegeIDs = new ArrayList();
		privilegeIDs.add("10");
		
		JSONObject requestParams = new JSONObject();
		requestParams.put("roleName", roleName);
		requestParams.put("roleType", "INDIVIDUAL_PAYEE");
		requestParams.put("privileges", privilegeIDs);
		
		request.body(requestParams.toJSONString());
		Response response = request.post(oktaUsersBaseURIs.createBusinessRoles);
		if(response.getStatusCode()==201) {
			Response resp = RestAssured.given().contentType("application/json").header("Cookie", "iam-state="+cookie).get(oktaUsersBaseURIs.fetchBusinessRoles);
			jsonPathEvaluator = resp.jsonPath();
			ArrayList businessRoles = new ArrayList();
			businessRoles = jsonPathEvaluator.get("roles");
			logger.info("ALL BUSINESS ROLES: " +businessRoles);
			logger.info("ADDED ROLE: " +roleName);
			return !(businessRoles.get(businessRoles.indexOf(roleName)).equals(null));
		}else {
			return false;
		}
	}
	
	/**
	 * @function To update roles associated with business
	 * @parameters cookie = iam-state cookie value
	 */
	public String updateRoleName = "Sales Representative_"+SeleniumHelperClass.uniqueCharSequence();
	public boolean updateBusinessRoles(String cookie) {
		RequestSpecification request = RestAssured.given();
		request.header("Cookie", "iam-state=" +cookie);
		request.header("Content-Type", "application/json");
		
		ArrayList privilegeIDs = new ArrayList();
		privilegeIDs.add("10");
		
		JSONObject updateParams = new JSONObject();
		updateParams.put("roleName", updateRoleName);
		updateParams.put("roleType", "INDIVIDUAL_PAYEE");
		updateParams.put("privileges", privilegeIDs);
		
		request.body(updateParams.toJSONString());
		Response response = request.put(oktaUsersBaseURIs.updateBusinessRoles+roleName);
		if(response.getStatusCode()==200) {
			Response resp = RestAssured.given().contentType("application/json").header("Cookie", "iam-state="+cookie).get(oktaUsersBaseURIs.fetchBusinessRoles);
			jsonPathEvaluator = resp.jsonPath();
			ArrayList businessRoles = new ArrayList();
			businessRoles = jsonPathEvaluator.get("roles");
			logger.info("ALL BUSINESS ROLES: " +businessRoles);
			logger.info("UPDATED ROLE: " +updateRoleName);
			return !(businessRoles.get(businessRoles.indexOf(updateRoleName)).equals(null));
		}else {
			return false;
		}
	}
	
	/**
	 * @function To delete roles associated with business
	 * @parameters cookie = iam-state cookie value
	 */
	public boolean deleteBusinessRoles(String cookie) {
		Response resp = RestAssured.given().contentType("application/json").header("Cookie", "iam-state="+cookie).delete(oktaUsersBaseURIs.deleteBusinessRoles+updateRoleName);
		if (resp.getStatusCode() == 204) {
			logger.info("ROLE DELETED: "+updateRoleName);
			return true;
		} else {
			return false;
		}
	}
	
	public boolean fetchUserCurrentRoles(String cookie){
		Response resp = RestAssured.given().contentType("application/json").header("Cookie", "iam-state=" + cookie)
				.get(oktaUsersBaseURIs.fetchUserRoles.replace("userID", oktaUsersBaseURIs.userID_LinkedToIAMCookie));
		jsonPathEvaluator = resp.jsonPath();
		if (resp.getStatusCode() == 200) {
			businessRoles = jsonPathEvaluator.get("roles");
			logger.info("ROLES CURRENTLY ASSOCIATED WITH USER: "+businessRoles);
			return true;
		}else {
			return false;
		}
	}
	
	/**
	 * @function To fetch roles associated to a User
	 * @parameters cookie = iam-state cookie value
	 */
	public boolean fetchUserRoles(String cookie) {
		if(fetchUserCurrentRoles(cookie)) {
			return businessRoles.get(businessRoles.indexOf("Executive")).equals("Executive") || 
					businessRoles.get(businessRoles.indexOf("Sales Representative")).equals("Sales Representative");
		}else {
			return false;
		}			
	}
	
	/**
	 * @function To fetch details of a specific role associated to a User
	 * @parameters cookie = iam-state cookie value
	 */
	public boolean fetchDetailsOfSpecificUserRole(String cookie) {
		String detailsForSpecificRole = businessRoles.get(1).toString();
		Response response = RestAssured.given().contentType("application/json")
				.header("Cookie", "iam-state=" + cookie)
				.get(oktaUsersBaseURIs.fetchSpecificUserRoleDetail.replace("userID", oktaUsersBaseURIs.userID_LinkedToIAMCookie)
						+ detailsForSpecificRole).prettyPeek();
		if(response.getStatusCode() == 200) {
			jsonPathEvaluator = response.jsonPath();
			return !(jsonPathEvaluator.get("roleName").equals(null)) && !(jsonPathEvaluator.get("roleType").equals(null));
		}else {
			return false;
		}
	}
	
	/**
	 * @function To update user roles
	 * @parameters cookie = iam-state cookie value
	 */
	public String newRoleToBeAdded = "Sales Manager";
	public boolean updateUserRoles(String cookie) {
		RequestSpecification request = RestAssured.given();
		request.header("Cookie", "iam-state=" +cookie);
		request.header("Content-Type", "application/json");
		
		ArrayList rolesName = new ArrayList();
		rolesName.add(newRoleToBeAdded);
		
		JSONObject userRoles = new JSONObject();
		userRoles.put("roles", rolesName);
		
		request.body(userRoles.toJSONString());
		Response response = request.put(oktaUsersBaseURIs.updateUserRole.replace("userID", oktaUsersBaseURIs.userID_LinkedToIAMCookie));
		if(response.getStatusCode() == 200) {
			if(fetchUserCurrentRoles(cookie)) {
				logger.info("ROLE ADDED: "+newRoleToBeAdded);
			}			
			return businessRoles.contains(newRoleToBeAdded);
		}else {
			return false;
		}
	}
	
	/**
	 * @function To delete user role
	 * @parameters cookie = iam-state cookie value
	 */
	public String roleToBeDeleted = newRoleToBeAdded;
	public boolean deleteUserRole(String cookie) {
		Response response = RestAssured.given().contentType("application/json").header("Cookie", "iam-state=" + cookie)
				.delete(oktaUsersBaseURIs.deleteUserRole.replace("userID", oktaUsersBaseURIs.userID_LinkedToIAMCookie) + roleToBeDeleted);
		if (response.getStatusCode() == 204) {
			if(fetchUserCurrentRoles(cookie)) {
				logger.info("ROLE DELETED: " + roleToBeDeleted);
			}
			return !(businessRoles.contains(roleToBeDeleted));
		} else {
			return false;
		}
	}
	
	/**
	 * @function To fetch roles associated with a User tied to another business
	 * @parameters cookie = iam-state cookie value
	 */
	public boolean fetchUserRole_DifferentBusiness(String cookie) {
		Response resp = RestAssured.given().contentType("application/json").header("Cookie", "iam-state=" + cookie)
				.get(oktaUsersBaseURIs.fetchUserRoles.replace("userID", oktaUsersBaseURIs.userID_AnotherBusiness)).prettyPeek();
		if(resp.getStatusCode()==404) {
			jsonPathEvaluator = resp.jsonPath();
			logger.info("UNABLE TO FIND USER");
			return jsonPathEvaluator.get("message").equals("user not found for this business");
		}else {
			return false;
		}
	}
	
	/**
	 * @function To update roles associated with a User tied to another business
	 * @parameters cookie = iam-state cookie value
	 */
	public boolean updateUserRole_DifferentBusiness(String cookie) {
		RequestSpecification request = RestAssured.given();
		request.header("Cookie", "iam-state=" +cookie);
		request.header("Content-Type", "application/json");
		
		ArrayList rolesName = new ArrayList();
		rolesName.add(newRoleToBeAdded);
		
		JSONObject userRoles = new JSONObject();
		userRoles.put("roles", rolesName);
		
		request.body(userRoles.toJSONString());
		Response response = request.put(oktaUsersBaseURIs.updateUserRole.replace("userID", oktaUsersBaseURIs.userID_AnotherBusiness)).prettyPeek();
		
		if(response.getStatusCode()==404) {
			jsonPathEvaluator = response.jsonPath();
			logger.info("UNABLE TO FIND USER");
			return jsonPathEvaluator.get("message").equals("user not found for this business");
		}else {
			return false;
		}
	}
	
	/**
	 * @function To delete roles associated with a User tied to another business
	 * @parameters cookie = iam-state cookie value
	 */
	public boolean deleteUserRoles_DifferentBusiness(String cookie) {
		Response response = RestAssured.given().contentType("application/json").header("Cookie", "iam-state=" + cookie)
				.delete(oktaUsersBaseURIs.deleteUserRole.replace("userID", oktaUsersBaseURIs.userID_AnotherBusiness) + "Sales Representative").prettyPeek();
		if(response.getStatusCode()==404) {
			jsonPathEvaluator = response.jsonPath();
			logger.info("UNABLE TO FIND USER");
			return jsonPathEvaluator.get("message").equals("user not found for this business");
		}else {
			return false;
		}
	}
	
	/**
	 * @function To delete role when associated with a User
	 * @parameters cookie = iam-state cookie value
	 */
	String associatedRoleToBeDeleted = "";
	public boolean deleteRoleAssociatedToUser(String cookie) {
		fetchUserCurrentRoles(cookie);
		associatedRoleToBeDeleted = businessRoles.get(businessRoles.indexOf("Executive")).toString();
		Response resp = RestAssured.given().contentType("application/json").header("Cookie", "iam-state=" + cookie)
				.delete(oktaUsersBaseURIs.deleteBusinessRoles + associatedRoleToBeDeleted).prettyPeek();
		jsonPathEvaluator = resp.jsonPath();
		if (resp.getStatusCode() == 500) {
			logger.info("ROLE ASSOCIATED WITH A USER CANNOT BE DELETED");
			return jsonPathEvaluator.get("message").equals("Role is being used, cannot be deleted");
		} else {
			return false;
		}
	}
	
	/**
	 * @function To create role for a business using IAM state cookie of another business
	 * @parameters cookie = iam-state cookie value
	 */
	public boolean createRoleForAnotherBusiness(String cookie) {
		RequestSpecification request = RestAssured.given();
		request.header("Cookie", "iam-state=" +cookie);
		request.header("Content-Type", "application/json");
		
		ArrayList privilegeIDs = new ArrayList();
		privilegeIDs.add("10");
		
		JSONObject requestParams = new JSONObject();
		requestParams.put("roleName", roleName);
		requestParams.put("roleType", "INDIVIDUAL_PAYEE");
		requestParams.put("privileges", privilegeIDs);
		
		request.body(requestParams.toJSONString());
		Response response = request.post(oktaUsersBaseURIs.createRoleForAnotherBusiness.replace("businessID", oktaUsersBaseURIs.BizID_OtherBusiness)).prettyPeek();
		jsonPathEvaluator = response.jsonPath();
		
		if(response.getStatusCode() == 400) {
			logger.info(jsonPathEvaluator.get("message").toString().toUpperCase());
			return jsonPathEvaluator.get("message").equals("Invalid privilege: bizId from context cannot be overriden");
		}else {
			return false;
		}
	}
	
	
	/**
	 * @function To create role for a business using IAM State cookie of a User tied to the business
	 * @parameters cookie = iam-state cookie value
	 */
	public boolean createBusinessRolesViaUser(String cookie) {
		RequestSpecification request = RestAssured.given();
		request.header("Cookie", "iam-state=" +cookie);
		request.header("Content-Type", "application/json");
		
		ArrayList privilegeIDs = new ArrayList();
		privilegeIDs.add("10");
		
		JSONObject requestParams = new JSONObject();
		requestParams.put("roleName", roleName);
		requestParams.put("roleType", "INDIVIDUAL_PAYEE");
		requestParams.put("privileges", privilegeIDs);
		
		request.body(requestParams.toJSONString());
		Response response = request.post(oktaUsersBaseURIs.createBusinessRoles).prettyPeek();
		jsonPathEvaluator = response.jsonPath();
		if(response.getStatusCode()==403) {
			logger.info(jsonPathEvaluator.get("message").toString().toUpperCase());
			return jsonPathEvaluator.get("message").equals("User is not authorized");
		}else {
			logger.info("INVALID REQUEST");
			return false;
		}
	}
	
}