
package com.xactly.incent.organization;

import org.openqa.selenium.WebElement;

import com.xactly.incent.navigation.LeftNavigationUtil;
import com.xactly.xcommons.selenium.SeleniumHelperClass;

public class Organization {
public Organization(String testtype) throws Exception

{
	if(testtype.equalsIgnoreCase("gui"))
	{	
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		WebElement tab_organization = SeleniumHelperClass.findWebElementbyid("TAB_MIDDLE_ORGANIZATION_TAB","TopFrame");
		SeleniumHelperClass.isVisible(tab_organization, 10);
		tab_organization.click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	}
	else if(testtype.equalsIgnoreCase("gui-new"))
	{
		
		LeftNavigationUtil.openLeftNavigation();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*2);
		LeftNavigationUtil.openOrganizationTab();
	}
	else if(testtype.equalsIgnoreCase("Redesign"))
	{

		LeftNavigationUtil.openLeftNavigation();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*2);
		LeftNavigationUtil.openOrganizationTab();
	}
}
}
