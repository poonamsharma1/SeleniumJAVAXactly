package com.xactly.incent.organization;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.time.Duration;
import java.util.*;

import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
//import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.Response;
import com.xactly.incent.navigation.LeftNavigationUtil;
import com.xactly.xcommons.app.LoginToApplication;
import com.xactly.xcommons.javahelper.ExcelConnector;
import com.xactly.xcommons.restapi.LoginToRestAPI;
import com.xactly.xcommons.restapi.RestAPIHelperClass;
import com.xactly.xcommons.selenium.Constants;
import com.xactly.xcommons.selenium.DBConnections;
import com.xactly.xcommons.selenium.GetProperties;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;

public class Peoples {
	public static Logger logger = Logger.getLogger(Peoples.class.getName());
	private LoginToRestAPI login = new LoginToRestAPI();
	private RestAPIHelperClass rest = new RestAPIHelperClass();
	private String parentWindow;
	private File latestFile;
	private static String fileName = "XactlyPeopleUpload.xlsx";
	private static final String hierarchyName = "currencypos - test user (shd123)";
	private boolean enableProratedPersonalTarget = true;
	public Response logindo;
	private ExcelConnector excelUtil = new ExcelConnector();
	DBConnections db = new DBConnections();

	@FindBy(xpath = "//div[@ref='centerContainer']//div[@role='row' and @aria-label='Press SPACE to select this row.']")
	private List<WebElement> allPersons;

	public WebElement peopleSearchBoxRedesign() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[contains(@placeholder,'Search First Name')]","mainFrame");
	}

	public WebElement peopleSearchIconRedesign() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@data-testid='search-icon']//*[local-name()='svg']",
				"mainFrame");
	}

	public List<WebElement> getAllPersonsRedesign() {
		return allPersons;
	}

	public WebElement threeDotsBtnRedesign(String name) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//span[text()='" + name
						+ "']//parent::div//parent::div//parent::div//parent::div[@role='row']//div[@class='toggle-btn']//*[local-name()='svg']",
				"mainFrame");
	}


	public WebElement selectPersonRowRedesign(String name) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//span[text()='" + name + "']//parent::div//parent::div//parent::div//parent::div[@role='row']",
				"mainFrame"));
	}
	public WebElement selectRowRedesign(String name) throws Exception{
		return (SeleniumHelperClass.findWebElementbyXpath("//span[text()='"+name+"']//parent::div//parent::div//parent::div//parent::div[@role='row']","mainFrame"));
	}

	public WebElement selectToggleOptionRedesign(String name, String option) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[text()='" + name
				+ "']//parent::div//parent::div//parent::div//parent::div[@role='row']//button[text()='" + option
				+ "']", "mainFrame"));
	}

	public WebElement peopleSliderUIHeaderRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("modalTitleId", "mainFrame"));
	}

	public WebElement peopleSliderUICloseIconRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[@data-testid='slide-panel-close-button']",
				"mainFrame"));
	}

	public WebElement whereUsedUICloseBtnRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'XSlidePanelFooter')]//button[text()='Close' ]", "mainFrame"));

	}
	public WebElement sliderUICloseBtnRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(@class,'XSlidePanelFooter')]//button[text()='Close' ]", "mainFrame"));

	}

	public WebElement whereUsedUIAllResultsRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(@class,'align-center')]//span[text()='All Results']","mainFrame"));

	}

	public WebElement whereUsedUICountRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[contains(@class,'grid-count')]","mainFrame"));

	}

	public WebElement whereUsedUIDownloadBtnRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'modal-body')]//div[@id='fixed-header']//child::button[text()='Download']",
				"mainFrame"));
	}

	public WebElement whereUsedNameColRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@col-id='name']//div[@class='ag-header-cell-label']",
				"mainFrame"));
	}

	public WebElement whereUsedStartDateColRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@col-id='effectiveStartDate']//div[@class='ag-header-cell-label']", "mainFrame"));
	}

	public WebElement whereUsedUIDesColRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@col-id='description']//div[@class='ag-header-cell-label']", "mainFrame"));
	}

	public WebElement whereUsedNameColValueRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'row-position')]//child::div[@col-id='name']", "mainFrame"));
	}

	public WebElement whereUsedStartDateColValueRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'row-position')]//child::div[@col-id='effectiveStartDate']", "mainFrame"));
	}

	public WebElement whereUsedDesColValueRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'row-position')]//child::div[@col-id='description']", "mainFrame"));
	}

	public WebElement whereUsedNoDataRedesign() throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//div[@class='noDataContainer']//span[contains(text(),'No')]", "mainFrame"));
	}

	public WebElement whereUsedNoDataSubTextRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[contains(@style,'word-break')]//div", "mainFrame"));
	}

	public WebElement impersonateLabelRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='inline']", "mainFrame"));
	}

	public WebElement impersonateTextBoxRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("stacked", "mainFrame"));
	}

	public WebElement peopleSliderCancelBtnRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'XSlidePanelFooter')]//button[text()='Cancel']", "mainFrame"));
	}

	public WebElement peopleSliderImpersonateBtnRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'XSlidePanelFooter')]//button[text()='Impersonate']", "mainFrame"));
	}



	public WebElement impersonateErrorMessageRedesign() throws Exception{
		return (SeleniumHelperClass.findWebElementbyXpath("//*[text()='The maximum length is 256 characters']","mainFrame"));
	}

	public WebElement impersonateTitle1Redesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//h1//span[@title='Payments']", "mainFrame"));
	}

	public WebElement impersonateTitle2Redesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//h1//span[@title='Current Year Payments']", "mainFrame"));
	}

	public WebElement impersonateTitle3Redesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//h1//span[@title='Current Year Credits by Type']",
				"mainFrame"));
	}

	public WebElement impersonateTitle4Redesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//h1//span[@title='Current Year Credits by Period']",
				"mainFrame"));
	}

	public WebElement endImpersonateRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("endImpersonation", "headerFrame"));
	}

	public WebElement dashboardTitleRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@class='dropdown select']//button[@id='moreOptions']//span[@class='name']", "mainFrame"));
	}

	public WebElement impersonateErrorMsgRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//textarea[@id='stacked']//parent::div[contains(@class,'input-group')]//span[contains(@class,'XInputGroup')]",
				"mainFrame"));
	}

	public WebElement impersonateDeniedHeaderRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("modalTitleId", "mainFrame"));
	}

	public WebElement impersonateDeniedPopupMsgRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(text(),'This user cannot')]", "mainFrame"));
	}

	public WebElement impersonateDeniedOkBtnRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(@class,'SmodalFooter')]//button[text()='OK']",
				"mainFrame"));
	}

	public WebElement impersonateDeniedCloseIconRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[contains(@class,'CloseIcon')]//*[local-name()='svg']",
				"mainFrame"));
	}

	public WebElement get_op_firstNamesearch() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//*[@id=\"basic_search\"]/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td[2]/input", "contentFrame");
	}

	public Select get_op_versionReason() throws Exception {
		return SeleniumHelperClass.selectFromDropdown("versionReasonId_people_edit", "ceditFrame");
	}

	public Select get_op_versionSubReason() throws Exception {
		return SeleniumHelperClass.selectFromDropdown("versionSubReasonId_people_edit", "ceditFrame");
	}

	public WebElement get_op_firstName() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("firstName_people_edit", "ceditFrame");
	}

	public WebElement get_op_lastName() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("lastName_people_edit", "ceditFrame");
	}

	/*
	 * public WebElement get_op_employID() throws Exception { return
	 * SeleniumHelperClass.findWebElementbyid("employeeId_people_edit",
	 * "ceditFrame"); }
	 */

	public WebElement get_op_employID() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@id='employeeId_people_edit']", "ceditFrame");
	}

	public WebElement get_op_hireDate() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("hireDate_people_edit", "ceditFrame");
	}

	public WebElement get_op_personalTarget() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("personalTarget_people_edit", "ceditFrame");
	}

	public WebElement get_op_proratedPersonalTarget() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("proratedPersonalTarget_people_edit", "ceditFrame");
	}

	public WebElement get_op_salary() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("salary_people_edit", "ceditFrame");
	}

	public WebElement get_op_proratedSalary() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("proratedSalary_people_edit", "ceditFrame");
	}

	public Select get_op_employStatus() throws Exception {
		return (SeleniumHelperClass.selectFromDropdown("employeeStatusId_people_edit", "ceditFrame"));
	}

	public Select get_op_personalCur() throws Exception {
		return (SeleniumHelperClass.selectFromDropdown("personalTargetUnitTypeId_people_edit", "ceditFrame"));
	}

	public Select get_op_paymentCur() throws Exception {
		return (SeleniumHelperClass.selectFromDropdown("paymentCurrencyUnitTypeId_people_edit", "ceditFrame"));
	}

	public Select get_op_salaryCur() throws Exception {
		return (SeleniumHelperClass.selectFromDropdown("salaryUnitTypeId_people_edit", "ceditFrame"));
	}

	public Select get_op_businessGroup() throws Exception {
		return (SeleniumHelperClass.selectFromDropdown("businessGroupId_people_edit", "ceditFrame"));
	}

	public WebElement CalenderImage() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//img[@alt='Click here to select a date']"));
	}

	public WebElement activeDate() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//td[@class='x-date-active  x-date-selected']/a/em/span"));
	}

	public WebElement Custom_StringField(int index) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@name='string" + index + "_people_edit']",
				"ceditFrame"));
	}

	public WebElement submitButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyCssSelector("button[type='submit'"));
	}

	public String get_op_user() {
		return "b_user_people_edit";
	}

	// Bchauhan
	public String getElpseUserName() throws Exception {
		String ElpseUserName = SeleniumHelperClass.findWebElementbyid("show_user_people_edit", "ceditFrame")
				.getAttribute("value");
		logger.info("Found User : " + ElpseUserName);
		return ElpseUserName;
	}

	public WebElement ClickPeopleTab() throws Exception {
		WebElement PeoplTab = SeleniumHelperClass.findWebElementbyid("A_People");
		return PeoplTab;
	}

	public WebElement get_op_date1_cf() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='date1_people_edit']", "ceditFrame"));
	}

	public WebElement get_op_number1_cf() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='number1_people_edit']", "ceditFrame"));
	}

	public Select get_op_number1_unittype_cf() throws Exception {
		return (SeleniumHelperClass.selectFromDropdown("number1UnitTypeId_people_edit", "ceditFrame"));
	}

	public WebElement get_op_string1_cf() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='string1_people_edit']", "ceditFrame"));
	}

	public WebElement get_op_string2_boolean_cf() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='string2_people_edit']", "ceditFrame"));
	}

	public WebElement get_op_string3_ddlist_cf() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='string3_people_edit']", "ceditFrame"));
	}

	public WebElement get_person_new_search() throws Exception {
		return (SeleniumHelperClass.findWebElementbyLink("New Search", "MainFrame"));
	}

	public WebElement get_person_upload() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'Upload People')]", "mainFrame"));
	}

	public WebElement get_person_upload_Option1() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='bd']/center/form[2]/table/tbody/tr[3]/td[2]/input",
				""));
	}

	public WebElement get_person_upload_Option2() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='bd']/center/form[2]/table/tbody/tr[4]/td[2]/input",
				""));
	}

	public WebElement get_person_upload_Option3() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='bd']/center/form[2]/table/tbody/tr[5]/td[2]/input",
				""));
	}

	public WebElement get_op_searchButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("searchButton", "contentFrame");
	}

	public WebElement get_op_clearButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("clearButton", "contentFrame");
	}

	public String getUploadFileLocation(String file) {
		return this.getClass().getClassLoader().getResource("com.xactly.incent.organization/UploadPeople/" + file)
				.getFile();
	}

	public String getPeopleUploadFileLocation(String fileName) {
		String fileURL = System.getProperty("user.dir") + File.separator
				+ "src/main/resources/com.xactly.incent.organization/UploadPeople/" + fileName;
		System.out.println("FilePath=" + fileURL);
		return fileURL;
	}

	public WebElement get_op_audit_version() throws Exception {
//		return (SeleniumHelperClass.findWebElementbyLink("Audit Version","MainFrame"));
		return (SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'Audit Version')]", "MainFrame"));
	}

	public WebElement get_op_Audit_ModifiedBy() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//td[2]/div[1]"));
	}

	public WebElement get_op_Audit_FirstName() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//td[6]/div[1]"));
	}

	public WebElement get_op_Audit_Desc() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//td[4]/div[1]"));
	}

	public WebElement get_op_Audit_LastName() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//td[8]/div[1]"));
	}

	public WebElement get_op_Audit_EmpID() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//td[9]/div[1]"));
	}

	public WebElement get_op_Audit_PersonalTarget() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//td[14]/div[1]"));
	}

	public WebElement downloadAuditFirstdVersionPeople() throws Exception {

		return SeleniumHelperClass.findWebElementbyXpath("//tr[3]/td[@n='effectiveStartDate']", "clistframe");
	}

	public WebElement downloadAuditSecondVersionPeople() throws Exception {

		return SeleniumHelperClass.findWebElementbyXpath("//tr[2]/td[@n='effectiveStartDate']", "clistframe");
	}

	public WebElement downloadAuditThirdVersionPeople() throws Exception {

		return SeleniumHelperClass.findWebElementbyXpath("//tr[1]/td[@n='effectiveStartDate']", "clistframe");
	}

	public WebElement auditDownload() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//button[@id='downloadButton']"));
	}

	public WebElement getFirstName() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(text(),'First Name')]"));
	}

	public WebElement getLastName() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(text(),'Last Name')]"));
	}

	public WebElement getPersonalTarget() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(text(),'Personal Target')]"));
	}

	public WebElement getEmployeeId() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(text(),'Employee ID')]"));
	}

	public WebElement getSalary() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(text(),'Salary')]"));
	}

	public WebElement getRegion() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(text(),'Region')]"));
	}

	public WebElement getUserEmail() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(text(),'User Email')]"));
	}

	public WebElement getPaymentCurrency() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(text(),'Payment Currency')]"));
	}

	public WebElement getBusinessGroup() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(text(),'Business Group')]"));
	}

	public WebElement getPeople() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(text(),'People')]"));
	}

	public WebElement getPersonelTargetMaskData() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath(
				"//span[contains(text(),'Bgs1PEOPLE')]/ancestor::div[2]/following-sibling::div[2]"));
	}

	public WebElement getSalaryMaskData() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath(
				"//span[contains(text(),'Bgs1PEOPLE')]/ancestor::div[2]/following-sibling::div[4]"));
	}

	public WebElement getRegionMaskData() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath(
				"//span[contains(text(),'Bgs1PEOPLE')]/ancestor::div[2]/following-sibling::div[5]"));
	}

	public WebElement getPaymentCurrencyMaskData() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath(
				"//span[contains(text(),'Bgs1PEOPLE')]/ancestor::div[2]/following-sibling::div[7]"));
	}

	public WebElement gettitle_orderscredits() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//*[@title=\"Orders and Credits\"]", "mainFrame"));
	}

	public WebElement gettitle_payments() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//*[@title=\"Payments\"]", "mainFrame"));

	}

	public WebElement getlabel_commissionsearned() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//*[contains(text(),'Commissions Earned')]", "mainFrame"));

	}

	public WebElement getlabel_bonusearned() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath("//*[contains(text(),'Bonuses Earned')]", "mainFrame"));

	}

	public WebElement get_All_People_Link() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'All People')]", "mainFrame");
	}

	public WebElement get_Upload_People_Link() throws Exception {
		return SeleniumHelperClass.findWebElementbyLink("Upload People", "mainFrame");
	}

	public List<WebElement> get_Upload_People_LinkNewUI() throws Exception {
		return SeleniumHelperClass.findWebElements(
				"//button[@class='sc-ftTHYK styled-components__XButtonBase-sc-5ryo5-0 brTfmt dHjxb btn btn-secondary']",
				"mainFrame");
	}

	public WebElement clickDown() throws Exception {
		if (SetWebDrivers.getNavigationType().equalsIgnoreCase("gui")) {
			return SeleniumHelperClass.findWebElementbyXpath(".//*[@id='down']", "topFrame");
		} else {
			return SeleniumHelperClass.findWebElementbyXpath(".//*[@id='profile_pic_span']", "headerframe");
		}
	}

	public WebElement clickDownWithCurrentNavigation() throws Exception {
		String navType = "";
		try {
			LoginToApplication login = new LoginToApplication();
			navType = login.getCurrentNavigationType();
		} catch (Exception e) {
			logger.info("unable to get current navigation..setting global navigation type recevied");
			navType = SetWebDrivers.getNavigationType();
		}
		if (navType.equalsIgnoreCase("gui")) {
			return SeleniumHelperClass.findWebElementbyXpath(".//*[@id='down']", "topFrame");
		} else {
			return SeleniumHelperClass.findWebElementbyXpath(".//*[@id='profile_pic_span']", "headerframe");
		}
	}

	public WebElement get_endImpersonate_link() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(".//*[@id='endImpersonationlnk']", "profileFrame");
	}

	public WebElement get_firstName() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//td[@n='firstName']", "contentFrame");
	}

	public WebElement get_commEarnedAmt() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//td[@data-label='Commissions Earned']/span", "mainFrame");
	}

	public WebElement get_downloadDetails() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//span[@class='downloadText']", "mainFrame");
	}

	public Peoples(String testtype) throws Exception {
		if (testtype.equalsIgnoreCase("gui")) {
			new Organization("gui");
			SeleniumHelperClass.findWebElementbyid("A_People").click();
			// SeleniumHelperClass.acceptAlert();//this is added to handle the alert which
			// comes when we click on the sublinks in organization,Can be removed once dev
			// fix this issue.
			Thread.sleep(4000);
			SeleniumHelperClass.isVisible(get_Upload_People_Link(), 10);
			Thread.sleep(2000);
		} else if (testtype.equalsIgnoreCase("gui-new")) {

			new Organization("gui-new");
			LeftNavigationUtil.clickOnPeopleTab();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX * 2);
			SeleniumHelperClass.waitForElmentToBeReady(get_Upload_People_Link());
			SeleniumHelperClass.isVisible(get_Upload_People_Link(), 10);
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		} else if (testtype.equalsIgnoreCase("Redesign")) {

			new Organization("Redesign");
			LeftNavigationUtil.clickOnPeopleTab();
//			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
//			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*3);
//			SeleniumHelperClass.waitForElmentToBeReady(get_Upload_People_LinkNewUI().get(1));
//			SeleniumHelperClass.isVisible(get_Upload_People_LinkNewUI().get(1), 10);
//			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN*2);
		}

		GetProperties.setPeopletable(SetWebDrivers.tableDet.getProperty("incent.organization.people"));

	}

	/**
	 * verify Headers on peoples page.
	 *
	 * @throws Exception
	 */
	public void verifyHeadersOnNewUI() throws Exception {
		String peopleText = getPeople().getText();
		String firstName = getFirstName().getText();
		String lastName = getLastName().getText();
		String personelTarget = getPersonalTarget().getText();
		String employeeId = getEmployeeId().getText();
		String userEmail = getUserEmail().getText();
		String salary = getSalary().getText();
		String region = getRegion().getText();
		SeleniumHelperClass.scrollElementIntoViewUsingJS(getPaymentCurrency());
		String paymentCurrency = getPaymentCurrency().getText();
		logger.info("Payment Currency Values From UI is -- " + paymentCurrency);
		boolean isexist = peopleText.contains("People");
		Assert.assertEquals(isexist, true, "People is not matched");
		Assert.assertEquals("First Name", firstName, "First name is not matched");
		Assert.assertEquals("Last Name", lastName, "Last Name is not matched");
		Assert.assertEquals("Personal Target", personelTarget, "Personal Target is not matched");
		Assert.assertEquals("Employee ID", employeeId, "Employee Id is not matched");
		Assert.assertEquals("Salary", salary, "Salary is not matched");
		Assert.assertEquals("Region", region, "Region is not matched");
		Assert.assertEquals("User Email", userEmail, "User Email is not matched");
		Assert.assertEquals("Payment Currency", paymentCurrency, "Payment Currency is not matched");
	}

	public void clearAndSend(WebElement ele, String str) throws Exception {
		ele.clear();
		ele.sendKeys(str);
	}

	public void save(String opt) throws Exception {
		SeleniumHelperClass.waitForElmentToBeReady(SeleniumHelperClass.findWebElementbyid("saveButton", "ceditFrame"));
		SeleniumHelperClass.findWebElementbyid("saveButton", "ceditFrame").click();
		try {
			if (opt.equalsIgnoreCase("save")) {
				SeleniumHelperClass.waitForElmentToBeReady(SeleniumHelperClass.findWebElementbyid("menuSave_a_0"));

				SeleniumHelperClass.findWebElementbyid("menuSave_a_0").click();
			} else if (opt.equalsIgnoreCase("version")) {
				SeleniumHelperClass.waitForElement("id", "menuSave_a_1", "", SeleniumHelperClass.system_SpeedlimitMAX * 4);
				SeleniumHelperClass.mouseHover(SeleniumHelperClass.findWebElementbyid("menuSave_a_1"));
				SeleniumHelperClass.findWebElementbyid("menuSave_a_1").click();
				logger.info("Clicked on Save and add version");
			} else if (opt.equalsIgnoreCase("person")) {
				SeleniumHelperClass.findWebElementbyid("menuSave_a_2").click();
			}
		}catch(Exception e) {
			SeleniumHelperClass.findWebElementbyid("saveButton", "ceditFrame").click();

			if (opt.equalsIgnoreCase("save")) {

				SeleniumHelperClass.click(SeleniumHelperClass.findWebElementbyid("menuSave_a_0"));

			} else if (opt.equalsIgnoreCase("version")) {

				SeleniumHelperClass.click(SeleniumHelperClass.findWebElementbyid("menuSave_a_1"));
				logger.info("Clicked on Save and add version");

			} else if (opt.equalsIgnoreCase("person")) {

				SeleniumHelperClass.click(SeleniumHelperClass.findWebElementbyid("menuSave_a_2"));

			}

		}
	}

	public WebElement get_op_delete() throws Exception {
		return SeleniumHelperClass.findWebElementbyLink("Delete Person", "mainFrame");
	}

	public WebElement get_people_delete() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'Delete Person')]", "mainFrame");
	}

	public WebElement get_impersonate() throws Exception {
		return SeleniumHelperClass.findWebElementbyLink("Impersonate User", "mainFrame");
	}

	public void uploadPeople(String type, String file, String template_type) throws Exception {
		String filePath = null;
		if (template_type.contains("old")) {
			filePath = makeCSVWithOldTemplate(file);
		} else {
			filePath = makeCSV(file);
		}
		filePath = filePath.substring(1, filePath.length()).replace("/", "\\");
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		SeleniumHelperClass.findWebElementbyLink("Upload People", "mainFrame").click();
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				try {
					SetWebDrivers.getDriver().switchTo().window(windowHandle);
					Thread.sleep(500);
					SetWebDrivers.getDriver().switchTo().frame("uploadPeopleFrame");
					if (type.equalsIgnoreCase("new"))
						SeleniumHelperClass.findWebElementbyCssSelector("input[value='createData']").click();
					else if (type.equalsIgnoreCase("update"))
						SeleniumHelperClass.findWebElementbyCssSelector("input[value='updateData']").click();
					else if (type.equalsIgnoreCase("both"))
						SeleniumHelperClass.findWebElementbyCssSelector("input[value='both']").click();
					// SeleniumHelperClass.findWebElementbyName("file").sendKeys(filePath);

					WebElement uploadField = SeleniumHelperClass.findWebElementbyXpath("//input[@type='file']");
					uploadField.sendKeys(filePath);

					logger.info("Sleeping");
					Thread.sleep(1000);
					SeleniumHelperClass.findWebElementbyCssSelector("button[type='submit'").click();
					Thread.sleep(2000);
					// SetWebDrivers.getDriver().switchTo().frame("uploadPeopleFrame");
					// SeleniumHelperClass.findWebElementbyCssSelector("button:contains('OK')").click();
					SeleniumHelperClass.findWebElementbyXpath(".//*[@onclick='done()']").click();

				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the upload people window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}
		}
		/*
		 * if(!template_type.contains("error")) { SetWebDrivers.getDriver().close();
		 * logger.info("Closed the upload people window"); }
		 */
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
	}

	public void editPersonAndSaveTestProrationSetup(String EmpID) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		new Peoples(SetWebDrivers.getNavigationType());
		Thread.sleep(3000);
		SeleniumHelperClass.goToFrame("contentFrame");
		SeleniumHelperClass.findWebElementbyName("Employee Id").sendKeys(EmpID);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		get_op_editButton().click();
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
		save("save");
		Thread.sleep(2000);
	}

	public void editPersonAndEditProratedFieldsProrationSetup(String EmpID, String prorated_pt, String prorated_sal)
			throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		new Peoples(SetWebDrivers.getNavigationType());
		Thread.sleep(3000);
		SeleniumHelperClass.goToFrame("contentFrame");
		SeleniumHelperClass.findWebElementbyName("Employee Id").sendKeys(EmpID);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		get_op_editButton().click();
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
		clearAndSend(get_op_proratedPersonalTarget(), prorated_pt);
		clearAndSend(get_op_proratedSalary(), prorated_sal);
		save("save");

	}

	public String getProratedPersonalTarget(String EmpID) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		new Peoples(SetWebDrivers.getNavigationType());
		Thread.sleep(3000);
		SeleniumHelperClass.goToFrame("contentFrame");
		SeleniumHelperClass.findWebElementbyName("Employee Id").sendKeys(EmpID);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		get_op_editButton().click();
		Thread.sleep(3000);
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
		return get_op_proratedPersonalTarget().getAttribute("Value");
	}

	public String getProratedSalary(String EmpID) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		new Peoples(SetWebDrivers.getNavigationType());
		Thread.sleep(3000);
		SeleniumHelperClass.goToFrame("contentFrame");
		SeleniumHelperClass.findWebElementbyName("Employee Id").sendKeys(EmpID);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		get_op_editButton().click();
		Thread.sleep(3000);
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
		return get_op_proratedSalary().getAttribute("Value");
	}

	public String getProratedPersonalTargetForVersion(String EmpID, String date) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		new Organization(SetWebDrivers.getNavigationType());
		SeleniumHelperClass.findWebElementbyid("A_People").click();
		Thread.sleep(3000);
		SeleniumHelperClass.goToFrame("contentFrame");
		SeleniumHelperClass.findWebElementbyName("Employee Id").sendKeys(EmpID);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		get_op_editButton().click();
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
		SeleniumHelperClass.goToFrame("contentFrame");
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(120 * 2));
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id("listFrame")));
		WebElement tbody = SeleniumHelperClass.findWebElementbyid("tableFixed")
				.findElement(By.id("listTable_people_list"));
		List<WebElement> tr_elems = tbody.findElements(By.tagName("tr"));
		int tbody_size = tr_elems.size();
		for (int i = 0; i < tbody_size; i++) {
			if (tr_elems.get(i).getAttribute("xceffectivestartdate").equals(date)) {
				tr_elems.get(i).click();
				return get_op_proratedPersonalTarget().getAttribute("Value");
			}
		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
		return null;
	}

	public String getProratedSalaryForVersion(String EmpID, String date) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		new Organization(SetWebDrivers.getNavigationType());
		SeleniumHelperClass.findWebElementbyid("A_People").click();
		Thread.sleep(3000);
		SeleniumHelperClass.goToFrame("contentFrame");
		SeleniumHelperClass.findWebElementbyName("Employee Id").sendKeys(EmpID);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		get_op_editButton().click();
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
		SeleniumHelperClass.goToFrame("contentFrame");
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(120 * 2));
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id("listFrame")));
		WebElement tbody = SeleniumHelperClass.findWebElementbyid("tableFixed")
				.findElement(By.id("listTable_people_list"));
		List<WebElement> tr_elems = tbody.findElements(By.tagName("tr"));
		int tbody_size = tr_elems.size();
		for (int i = 0; i < tbody_size; i++) {
			if (tr_elems.get(i).getAttribute("xceffectivestartdate").equals(date)) {
				tr_elems.get(i).click();
				return get_op_proratedSalary().getAttribute("Value");
			}
		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
		return null;
	}

	public String getErrorMessageOnUpload(String error_message) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				try {
					SetWebDrivers.getDriver().switchTo().window(windowHandle);
					Thread.sleep(500);
					SetWebDrivers.getDriver().switchTo().frame("uploadPeopleFrame");
					logger.info("Reached the upload frame after error");
					List<WebElement> tr = SeleniumHelperClass.findWebElementbyid("rTable")
							.findElements(By.xpath("//tr/td[contains(text(), '" + error_message + "')]"));
					// WebElement tr =
					// SeleniumHelperClass.getTableRow(SeleniumHelperClass.findWebElementbyid("rTable"),1);

					SetWebDrivers.getDriver().close();
					logger.info("Closed the upload people window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					return error_message;
				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the upload people window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}
		}

		return null;
	}

	public String getErrorMessageAndFieldOnUpload(String error_message, String field) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				try {
					SetWebDrivers.getDriver().switchTo().window(windowHandle);
					Thread.sleep(500);
					SetWebDrivers.getDriver().switchTo().frame("uploadPeopleFrame");
					logger.info("Reached the upload frame after error");
					List<WebElement> tr = SeleniumHelperClass.findWebElementbyid("rTable")
							.findElements(By.xpath("//tr/td[contains(text(), '" + error_message + "')]"));
					logger.info("Found error message");
					List<WebElement> tr2 = SeleniumHelperClass.findWebElementbyid("rTable")
							.findElements(By.xpath("//tr/td[contains(text(), '" + field + "')]"));
					logger.info("Found field");
					// WebElement tr =
					// SeleniumHelperClass.getTableRow(SeleniumHelperClass.findWebElementbyid("rTable"),1);
					SetWebDrivers.getDriver().close();
					logger.info("Closed the upload people window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					logger.info("Printing return error message");
					logger.info(error_message + field);
					return (error_message + field);
				} catch (Exception e) {
					logger.info("Unable to find element");
					SetWebDrivers.getDriver().close();
					logger.info("Closed the upload people window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}
		}

		return null;
	}

	//Below method is for logging in using login string from properties file
	public void enableProratedTargetField(String bizLoginInfo) {
		SoftAssert sa = new SoftAssert();
		LoginToRestAPI logintorest = new LoginToRestAPI();
		try {
			logindo = logintorest.login(bizLoginInfo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("Checking if Prorated Personal target is set to manual or not");
		String getRequest1 = "/xicm/icmadvanced/setup/html/setup.html?view=proration";
		try {
			String response = rest.postHttpRequest(logindo, getRequest1);
			// logger.info("Response of getreq1: "+response.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}

		String getRequest = "/proration/v1/config/salary";
		String resp = rest.getRestAPI(getRequest);
		logger.info("JSON response received from GET: " + resp);
		String getPersonalTarget = JsonPath.read(resp, "$.personalTarget");
		logger.info("Person Target is: " + getPersonalTarget);
		if (getPersonalTarget.trim().contains("Same")) {
			logger.info(
					"Prorated Person Target is not enabled for taking any inputs in Create Person page, enabling it now");
			String postRequest = "/proration/v1/config/salary";
			String postReqBody = resp.replace("\"personalTarget\":\"Same\"", "\"personalTarget\":\"Manual\"");
			String postResp = rest.postRestAPI(postRequest, postReqBody);
			String getNewPersonalTarget = JsonPath.read(postResp, "$.personalTarget");
			logger.info("New personal target: " + getNewPersonalTarget);
			sa.assertEquals(getNewPersonalTarget, "Manual",
					"Assertion of Personal Target field failed for the POST request response");
		} else if (getPersonalTarget.trim().contains("Manual")) {
			logger.info("Prorated personal target is already set to take manual entries!");
		} else
			logger.info("Personal Target is neither set to Manual nor set to Same. Please check settings.");
	}

	//Below method is for logging in using username and password
	public void enableProratedTargetField(String bizUsername, String bizPassword) {
		SoftAssert sa = new SoftAssert();
		LoginToRestAPI logintorest = new LoginToRestAPI();
		try {
			logindo = logintorest.loginAdv(bizUsername, bizPassword);
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("Checking if Prorated Personal target is set to manual or not");
		String getRequest1 = "/xicm/icmadvanced/setup/html/setup.html?view=proration";
		try {
			String response = rest.postHttpRequest(logindo, getRequest1);
			// logger.info("Response of getreq1: "+response.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}

		String getRequest = "/proration/v1/config/salary";
		String resp = rest.getRestAPI(getRequest);
		logger.info("JSON response received from GET: " + resp);
		String getPersonalTarget = JsonPath.read(resp, "$.personalTarget");
		logger.info("Person Target is: " + getPersonalTarget);
		if (getPersonalTarget.trim().contains("Same")) {
			logger.info(
					"Prorated Person Target is not enabled for taking any inputs in Create Person page, enabling it now");
			String postRequest = "/proration/v1/config/salary";
			String postReqBody = resp.replace("\"personalTarget\":\"Same\"", "\"personalTarget\":\"Manual\"");
			String postResp = rest.postRestAPI(postRequest, postReqBody);
			String getNewPersonalTarget = JsonPath.read(postResp, "$.personalTarget");
			logger.info("New personal target: " + getNewPersonalTarget);
			sa.assertEquals(getNewPersonalTarget, "Manual",
					"Assertion of Personal Target field failed for the POST request response");
		} else if (getPersonalTarget.trim().contains("Manual")) {
			logger.info("Prorated personal target is already set to take manual entries!");
		} else
			logger.info("Personal Target is neither set to Manual nor set to Same. Please check settings.");
	}

	// public void createPeople(String user, String fname, String lname, String id,
	// String bGroup, String pTarget, String perCurr, String payCurr ) throws
	// Exception { }
	// public void createPeople(String user, String fname, String lname, String id,
	// String hireDate, String bGroup, String pTarget, String pPersonalTarget,
	// String perCurr, String payCurr, String salary, String salCurr ) throws
	// Exception {

	/****
	 * Please provide the business login string here from users.prop file, so that
	 * Prorated Personal Target customization can be done in the same business in
	 * which you are creating person NOTE: For the default automation business
	 * login, please provide as incent.username , as specified in users.properties
	 * file
	 ****/

	public void createPeople(String bizLoginInfo, String user, String fname, String lname, String id, String hireDate,
							 String bGroup, String pTarget, String pPersonalTarget, String perCurr, String payCurr, String salary,
							 String salCurr) throws Exception {

		// This is pre-check for the mandatory field Prorated Personal Target in Create
		// Person page
		if (enableProratedPersonalTarget)
			enableProratedTargetField(bizLoginInfo);
		logger.info("Creating a new Person");
		SeleniumHelperClass.findWebElementbyLink("Create Person", "mainFrame").click();
		Thread.sleep(1000);
		SeleniumHelperClass.selectFromPopup(get_op_user(), "name_edit_user", user, "ceditFrame");
		Thread.sleep(1000);
		clearAndSend(get_op_firstName(), fname);
		clearAndSend(get_op_lastName(), lname);
		clearAndSend(get_op_employID(), id);
		SeleniumHelperClass.waitForElmentToBeReady(get_op_hireDate());
		// clearAndSend(get_op_hireDate(), hireDate);
		get_op_hireDate().sendKeys(hireDate);
		get_op_businessGroup().selectByVisibleText(bGroup);
		clearAndSend(get_op_personalTarget(), pTarget);
		// Note: If enableProratedPersonalTarget is set to false please comment below
		// line as the field will be disabled.
		clearAndSend(get_op_proratedPersonalTarget(), pPersonalTarget);
		SeleniumHelperClass.waitForElement("id", "personalTargetUnitTypeId_people_edit", "ceditFrame",
				SeleniumHelperClass.system_SpeedlimitMAX);
		get_op_personalCur().selectByVisibleText(perCurr);
		SeleniumHelperClass.waitForElement("id", "paymentCurrencyUnitTypeId_people_edit", "ceditFrame",
				SeleniumHelperClass.system_SpeedlimitMAX);
		get_op_paymentCur().selectByVisibleText(payCurr);
		clearAndSend(get_op_salary(), salary);
		get_op_salaryCur().selectByVisibleText(salCurr);
		Thread.sleep(1000);
		save("save");
		Thread.sleep(2000);
	}

	/****
	 * Please provide the business login string users.prop file here so that
	 * Prorated Personal Target customization can be done in the same business in
	 * which you are creating person NOTE: For the default automation business
	 * login, please provide as incent.username , as specified in users.properties
	 * file
	 ****/

	public void createPeopleWithVRandVSR(String bizLoginInfo, String VersionReason, String VersionSubReason,
										 String user, String fname, String lname, String id, String hireDate, String bGroup, String pTarget,
										 String pPersonalTarget, String perCurr, String payCurr, String salary, String salCurr) throws Exception {
		// This is pre-check for the mandatory field Prorated Personal Target in Create
		// Person page
		if (enableProratedPersonalTarget)
			enableProratedTargetField(bizLoginInfo);
		SeleniumHelperClass.findWebElementbyLink("Create Person", "mainFrame").click();
		// SeleniumHelperClass.waitForElement("id", "versionReasonId_people_edit",
		// "ceditFrame", SeleniumHelperClass.system_SpeedlimitMAX*4);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX * 3);
		get_op_versionReason().selectByVisibleText(VersionReason);
		get_op_versionSubReason().selectByVisibleText(VersionSubReason);
		SeleniumHelperClass.selectFromPopup(get_op_user(), "name_edit_user", user, "ceditFrame");
		clearAndSend(get_op_firstName(), fname);
		clearAndSend(get_op_lastName(), lname);
		clearAndSend(get_op_employID(), id);
		// clearAndSend(get_op_hireDate(), hireDate);
		get_op_hireDate().sendKeys(hireDate);
		get_op_businessGroup().selectByVisibleText(bGroup);
		clearAndSend(get_op_personalTarget(), pTarget);
		clearAndSend(get_op_proratedPersonalTarget(), pPersonalTarget);
		get_op_personalCur().selectByVisibleText(perCurr);
		get_op_paymentCur().selectByVisibleText(payCurr);
		clearAndSend(get_op_salary(), salary);
		get_op_salaryCur().selectByVisibleText(salCurr);
		Thread.sleep(1000);
		save("save");
		Thread.sleep(2000);
	}

//Below methods are to pass biz usernames and passwords directly rather than login string from users.prop file
	/****
	 * Please provide the business login username & pwd so that Prorated Personal
	 * Target customization can be done in the same business in which you are
	 * creating person NOTE: For the default automation business login, use above
	 * methods which are taking login string as the argument and provide as
	 * incent.username, as specified in users.properties file
	 ****/

	public void createPeopleWithCustomStingField(String bizUsername, String bizPwd, String user, String fname,
												 String lname, String id, String hireDate, String bGroup, String pTarget, String pPersonalTarget,
												 String perCurr, String payCurr, String salary, String salCurr) throws Exception {

		// This is pre-check for the mandatory field Prorated Personal Target in Create
		// Person page
		// if(enableProratedPersonalTarget)
		// enableProratedTargetField(bizUsername, bizPwd);
		logger.info("Creating a new Person");
		SeleniumHelperClass.findWebElementbyLink("Create Person", "mainFrame").click();
		Thread.sleep(1000);
		SeleniumHelperClass.selectFromPopup(get_op_user(), "name_edit_user", user, "ceditFrame");
		Thread.sleep(1000);
		clearAndSend(get_op_firstName(), fname);
		clearAndSend(get_op_lastName(), lname);
		clearAndSend(get_op_employID(), id);
		SeleniumHelperClass.waitForElmentToBeReady(get_op_hireDate());
		// clearAndSend(get_op_hireDate(), hireDate);
		get_op_hireDate().sendKeys(hireDate);
		get_op_businessGroup().selectByVisibleText(bGroup);
		clearAndSend(get_op_personalTarget(), pTarget);
		// Note: If enableProratedPersonalTarget is set to false please comment below
		// line as the field will be disabled.
		clearAndSend(get_op_proratedPersonalTarget(), pPersonalTarget);
		SeleniumHelperClass.waitForElement("id", "personalTargetUnitTypeId_people_edit", "ceditFrame",
				SeleniumHelperClass.system_SpeedlimitMAX);
		get_op_personalCur().selectByVisibleText(perCurr);
		SeleniumHelperClass.waitForElement("id", "paymentCurrencyUnitTypeId_people_edit", "ceditFrame",
				SeleniumHelperClass.system_SpeedlimitMAX);
		get_op_paymentCur().selectByVisibleText(payCurr);
		clearAndSend(get_op_salary(), salary);
		get_op_salaryCur().selectByVisibleText(salCurr);
	}

	public void editPeopleCustomStingField(int index, String stringCustomFieldcharacter) throws Exception {
//		get_op_searchBox().sendKeys(first_name);
//		get_op_searchButton().click();
//		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
//		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
//		get_op_editButton().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		clearAndSend(Custom_StringField(index), stringCustomFieldcharacter);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);

	}

	/****
	 * Please provide the business login username & pwd so that Prorated Personal
	 * Target customization can be done in the same business in which you are
	 * creating person NOTE: For the default automation business login, use above
	 * methods which are taking login string as the argument and provide as
	 * incent.username, as specified in users.properties file
	 ****/

	public void editPeople(String first_name, String last_name, String salary, String salary_currency,
						   String personal_target, String paymant_currency, String persona_currency) throws Exception {
		get_op_searchBox().sendKeys(first_name);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_op_editButton().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		first_name = first_name + "edited";
		clearAndSend(get_op_firstName(), first_name);
		clearAndSend(get_op_lastName(), last_name);
		clearAndSend(get_op_salary(), salary);
		get_op_salaryCur().selectByVisibleText(salary_currency);
		clearAndSend(get_op_personalTarget(), personal_target);
		get_op_paymentCur().selectByVisibleText(paymant_currency);
		get_op_personalCur().selectByVisibleText(persona_currency);
		// SetWebDrivers.getDriver().manage().timeouts().implicitlyWait(20,
		// TimeUnit.SECONDS);
		Thread.sleep(1000);
		save("save");
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);

	}

	public void editPeoplewithgivenName(String New_first_name, String New_last_name, String existingfirstname)
			throws Exception {
		get_op_searchBox().sendKeys(existingfirstname);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		Thread.sleep(2000);
		get_op_editButton().click();
		Thread.sleep(5000);
		// String first_name1 = New_first_name;
		clearAndSend(get_op_firstName(), New_first_name);
		clearAndSend(get_op_lastName(), New_last_name);
		// SetWebDrivers.getDriver().manage().timeouts().implicitlyWait(20,
		// TimeUnit.SECONDS);
		Thread.sleep(1000);
		save("save");
		Thread.sleep(2000);

	}

	public void editPeopleSaveVersionWithEMPStatus(String EmpStatus, String New_first_name, String existingfirstname)
			throws Exception {
		get_op_searchBox().sendKeys(existingfirstname);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_op_editButton().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		// String first_name1 = New_first_name;
		get_op_employStatus().selectByVisibleText(EmpStatus);
		clearAndSend(get_op_firstName(), New_first_name);
		// SetWebDrivers.getDriver().manage().timeouts().implicitlyWait(20,
		// TimeUnit.SECONDS);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		save("save");
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);

	}

	public void editPeopleSaveVersionForSecondVersion(String EmpStatus, String New_last_name, String existingfirstname)
			throws Exception {
		get_op_searchBox().sendKeys(existingfirstname);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_op_editButton().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		// String first_name1 = New_first_name;
		downloadAuditSecondVersionPeople().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_op_employStatus().selectByVisibleText(EmpStatus);
		clearAndSend(get_op_lastName(), New_last_name);
		// SetWebDrivers.getDriver().manage().timeouts().implicitlyWait(20,
		// TimeUnit.SECONDS);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		save("save");
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);

	}

	// Edit person with Given name and click on "save and add New Version" in People
	// Page.
	public void editPeoplewithgivenNameandSaveNewversion(String New_first_name, String New_last_name,
														 String existingfirstname) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		get_op_searchBox().sendKeys(existingfirstname);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		// Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		logger.info("Clicked first row of table");
		SeleniumHelperClass.isVisible(get_op_editButton(), SeleniumHelperClass.system_SpeedlimitMAX * 2);
		get_op_editButton().click();
		logger.info("Clicked on edit");
		// Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		SeleniumHelperClass.isVisible(get_op_firstName(), SeleniumHelperClass.system_SpeedlimitMAX);
		// Clear and enter the new firstname
		clearAndSend(get_op_firstName(), New_first_name);
		clearAndSend(get_op_lastName(), New_last_name);
		logger.info("Provided first name and last name");
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		// Click on Save and Add New Version
		save("version");
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				logger.info("window handle isn't parentwindow");
				try {
					logger.info("Trying once");
					SetWebDrivers.getDriver().switchTo().window(windowHandle);
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
					SeleniumHelperClass.goToFrame("addVersionFrame");
					logger.info("Found the addVersion Frame");
					// Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
					// Click on Image Calender
					SeleniumHelperClass.waitForElement("xpath", "//img[@alt='Click here to select a date']",
							"addVersionframe", SeleniumHelperClass.system_SpeedlimitMIN * 2);
					SeleniumHelperClass.findWebElementbyXpath("//img[@alt='Click here to select a date']").click();
					// Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
					// Click on Date which is active and selected in calendar.
					SeleniumHelperClass.waitForElement("xpath",
							"//td[@class='x-date-active x-date-today  x-date-selected']/a/em/span", "addVersionframe",
							SeleniumHelperClass.system_SpeedlimitMIN * 2);
					SeleniumHelperClass.findWebElementbyXpath(
							"//td[@class='x-date-active x-date-today  x-date-selected']/a/em/span").click();
					// Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
					// Click on save button.
					SeleniumHelperClass.waitForElement("css", "button[type='submit'", "addVersionframe",
							SeleniumHelperClass.system_SpeedlimitMIN * 2);
					SeleniumHelperClass.findWebElementbyCssSelector("button[type='submit'").click();
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
					// Switch back to Parent window
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the add version window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}
		}
		logger.info("Edit people with new version is completed");
	}

	public void editPeoplewithgivenNameandSaveNewversionPPTarget(String ProratedPersonal_NewTarget,
																 String New_last_name, String existingfirstname) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		get_op_searchBox().sendKeys(existingfirstname);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_op_editButton().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		// Clear and enter the new firstname
		clearAndSend(get_op_proratedPersonalTarget(), ProratedPersonal_NewTarget);
		clearAndSend(get_op_lastName(), New_last_name);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		// Click on Save and Add New Version
		save("version");
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				logger.info("window handle isn't parentwindow");
				try {
					logger.info("Trying once");
					SetWebDrivers.getDriver().switchTo().window(windowHandle);
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
					SeleniumHelperClass.goToFrame("addVersionFrame");
					logger.info("Found the addVersion Frame");
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
					// Click on Image
					CalenderImage().click();
					// SeleniumHelperClass.findWebElementbyXpath("//img[@alt='Click here to select a
					// date']").click();
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
					// Click on Date which is active and selected in calendar.
					activeDate().click();
					// SeleniumHelperClass.findWebElementbyXpath("//td[@class='x-date-active
					// x-date-selected']/a/em/span").click();
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
					// Click on save button.
					submitButton().click();
					// SeleniumHelperClass.findWebElementbyCssSelector("button[type='submit'").click();
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
					// Switch back to Parent window
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the add version window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}
		}

	}

	public void editPeopleWithVRAndVSR(String first_name, String VersionReason, String VersionSubReason,
									   String last_name, String salary, String salary_currency, String personal_target, String paymant_currency,
									   String persona_currency) throws Exception {
		get_op_searchBox().sendKeys(first_name);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		get_op_editButton().click();
		// Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*3);
		get_op_versionReason().selectByVisibleText(VersionReason);
		get_op_versionSubReason().selectByVisibleText(VersionSubReason);
		first_name = first_name + "_Edited";
		clearAndSend(get_op_firstName(), first_name);
		clearAndSend(get_op_lastName(), last_name);
		clearAndSend(get_op_salary(), salary);
		get_op_salaryCur().selectByVisibleText(salary_currency);
		clearAndSend(get_op_personalTarget(), personal_target);
		get_op_paymentCur().selectByVisibleText(paymant_currency);
		get_op_personalCur().selectByVisibleText(persona_currency);
		// SetWebDrivers.getDriver().manage().timeouts().implicitlyWait(20,
		// TimeUnit.SECONDS);
		Thread.sleep(1000);
		save("save");
		Thread.sleep(2000);

	}

	public WebElement get_op_searchBox() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@name='First Name']", "contentFrame");
	}

	public WebElement get_lastName_searchBox() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@name='Last Name']", "contentFrame");
	}

	public WebElement get_employeeId_searchBox() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@name='Employee Id']", "contentFrame");
	}

	public WebElement get_advanceSearch_field() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(".//*[@id='advanced_search_tbody']/tr[4]/td[3]/button",
				"contentFrame");
	}

	public WebElement get_advanceSearch_fieldName(String name) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//table[@id='tableFixed']/tbody/tr/td/div[contains(text(),'" + name + "')]", "");
	}

	public WebElement get_ok_button() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(".//*[@id='okButton']", "");
	}

	public WebElement get_advanceSearch_value() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//tbody[@id='advanced_search_tbody']/tr[4]/td[5]/input",
				"contentFrame");
	}

	public WebElement get_tablefirstrowaftersearch() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id=\"tableFixed\"]/tbody/tr", "contentFrame");
	}

	public WebElement get_people_total() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id=\"total\"]", "contentFrame");
	}

	public WebElement get_advanceSearch_field_byrowNumer(int row) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				".//*[@id='advanced_search_tbody']/tr[" + row + "]/td[3]/button", "contentFrame");
	}

	public WebElement get_advanceSearch_value_byrowNumber(int row) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//tbody[@id='advanced_search_tbody']/tr[" + row + "]/td[5]/input", "contentFrame");
	}

	public void select_AdvanceSearchuOperator(String operator, int row) throws Exception {
		WebElement optr = SeleniumHelperClass.findWebElementbyXpath(
				"//*[@id='ext-gen" + row + "']//select[@class='operator_select']//*[contains(.,'" + operator + "')]",
				"contentFrame");
		optr.click();
	}

	public WebElement get_advanceSearch_Addrow() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//*[@id='advanced_search_tbody']//button[contains(.,'Add Row')]", "contentFrame");

	}

	public WebElement get_latestVersion() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@value='2']", "contentFrame");

	}

	public String get_SearchResultCount() throws Exception {
		String count = SeleniumHelperClass.findWebElementbyid("total", "contentFrame").getText();
		count = count.split(":")[1];
		return count.trim();
	}

	public void enableInputField(String date, WebElement ele) throws Exception {

		JavascriptExecutor js = (JavascriptExecutor) SetWebDrivers.driver;
		js.executeScript("arguments[0].removeAttribute('disabled')", ele);
		js.executeScript("arguments[0].value=arguments[1]", ele, date);
	}

	public void searchPeople(String name) throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_op_searchBox().sendKeys(name);
		get_op_searchButton().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	public void searchPeopleAndClickEdit(String name) throws Exception {
		get_op_searchBox().sendKeys(name);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		SeleniumHelperClass.isClickable(get_op_editButton(), 10);
		get_op_editButton().click();
	}

	public void deletePeople(String name) throws Exception {
		get_op_searchBox().sendKeys(name);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		Thread.sleep(2500);
		get_op_delete().click();
		SeleniumHelperClass.AcceptAlerts("All versions of this person will be deleted.  Do you wish to continue?");
		Thread.sleep(2500);
	}

	public void deletePeopleAndWaitForTotal(String name) throws Exception {
		get_op_searchBox().sendKeys(name);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		// Thread.sleep(2500);
		SeleniumHelperClass.isVisible(get_op_delete(), SeleniumHelperClass.system_SpeedlimitMIN);
		get_op_delete().click();
		SeleniumHelperClass.AcceptAlerts("All versions of this person will be deleted.  Do you wish to continue?");
		// Thread.sleep(2500);
		SeleniumHelperClass.isVisible(get_op_table(), SeleniumHelperClass.system_SpeedlimitMIN);
		SeleniumHelperClass.isVisible(get_people_total(), SeleniumHelperClass.system_SpeedlimitMIN);

	}

	public WebElement get_op_editButton() throws Exception {
		Thread.sleep(2500);
		return SeleniumHelperClass.findWebElementbyLink("Edit Person", "mainFrame");
	}

	// first result in the table
	public WebElement get_peopletable_firstresult() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(".//tbody[@id='listTable_search_list']/tr[1]", "contentframe");
	}

	public WebElement get_op_table() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("tableFixed", "contentframe");
	}

	public WebElement getPeopleTable(String columnName, int rowNum) throws Exception {
		Thread.sleep(1000);
		WebElement obj = SeleniumHelperClass.getTableData(get_op_table(), columnName, rowNum);
		// return (SeleniumHelperClass.getTableData(get_obg_table(),
		// columnName,rowNum));
		Thread.sleep(1000);
		return obj;
	}

	public void impersonate(String name) throws Exception {
		logger.info("Impersonating User : " + name);
		get_op_searchBox().sendKeys(name);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		Thread.sleep(2500);
		get_impersonate().click();
		SeleniumHelperClass.findWebElementbyName("reason", "mainFrame").sendKeys("123143");
		SeleniumHelperClass.findWebElementbyCssSelector("td.x-btn-center", "mainFrame").click();
	}

	public void impersonateByEmployeeID(String id) throws Exception {
		get_op_employID().sendKeys(id);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_op_searchButton().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		Thread.sleep(2500);
		get_impersonate().click();
		SeleniumHelperClass.findWebElementbyName("reason", "mainFrame").sendKeys("Initial Document Approvals");
		SeleniumHelperClass.findWebElementbyCssSelector("td.x-btn-center", "mainFrame").click();
	}

	public String getNumberOfPeople() throws Exception {
		String total = SeleniumHelperClass.findWebElementbyid("total", "contentFrame").getText();
		String totalarray[] = total.split(":");
		String num = totalarray[1].replace(" ", "");

		return num;
	}

	public void downloadTemplate(String uploadButtonId, String frame) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		SeleniumHelperClass.findWebElementbyXpath(uploadButtonId, frame).click();
		// SeleniumHelperClass.findWebElementbyid(uploadButtonId,frame).click();
		Thread.sleep(2000);
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				SetWebDrivers.getDriver().switchTo().window(windowHandle);
				try {
					SeleniumHelperClass.findWebElementbyLink("Click here", "uploadPeopleFrame").click();
					logger.info("File Download is in progress");
					Thread.sleep(5000);
					SeleniumHelperClass.findWebElementbyXpath(".//*[@onclick='doCancel()']", "uploadPeopleFrame")
							.click();
				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the child window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}
		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
	}

	public String makeCSV(String file) throws Exception {
		String filename = this.getClass().getClassLoader().getResource("prorationTestData/" + file + ".csv").getPath();
		CSVReader reader = new CSVReader(new FileReader(filename));
		List<String[]> csvBody = reader.readAll();

		for (int i = 1; i < csvBody.size(); i++) {
			csvBody.get(i)[18] = LoginToApplication.getUsername();
			// logger.info(csvBody.get(i)[0]);
		}
		reader.close();
		CSVWriter writer = new CSVWriter(new FileWriter(filename));
		writer.writeAll(csvBody);
		writer.flush();
		writer.close();
		CSVReader reader2 = new CSVReader(new FileReader(filename));
		List<String[]> csvBody2 = reader2.readAll();
		for (int i = 1; i < csvBody.size(); i++) {
			logger.info(Arrays.toString(csvBody2.get(i)));
		}
		return filename;
	}

	public String makeCSVWithOldTemplate(String file) throws Exception {
		// String filename =
		// this.getClass().getClassLoader().getResource("prorationTestData/"+file+".csv").getPath();
		String filename = this.getClass().getClassLoader().getResource("prorationTestData/" + file + ".csv").getFile();
		CSVReader reader = new CSVReader(new FileReader(filename));
		List<String[]> csvBody = reader.readAll();

		for (int i = 1; i < csvBody.size(); i++) {
			csvBody.get(i)[16] = LoginToApplication.getUsername();
			// logger.info(csvBody.get(i)[0]);
		}
		reader.close();
		CSVWriter writer = new CSVWriter(new FileWriter(filename));
		writer.writeAll(csvBody);
		writer.flush();
		writer.close();
		CSVReader reader2 = new CSVReader(new FileReader(filename));
		List<String[]> csvBody2 = reader2.readAll();
		for (int i = 1; i < csvBody.size(); i++) {
			logger.info(Arrays.toString(csvBody2.get(i)));
		}
		return filename;
	}

	public void changeProrationSetting(String personalTarget, String personalTargetDate, String personalTargetMethod,
									   String salary, String salaryDate, String salaryMethod) throws Exception {
		Response loginResp = rest.ApploginToIncent(LoginToApplication.getUsername(), LoginToApplication.getPassword());
		logger.info("The response cookies are:");
		logger.info(loginResp.getCookies());
		// String rbody =
		// "{\"salary\":\""+salary+"\",\"salaryMethod\":\""+salaryMethod+"\",\"salaryDate\":\""+salaryDate+"\",\"personalTarget\":\""+personalTarget+
		// "\",\"personalTargetMethod\":\""+personalTargetMethod+"\",\"personalTargetDate\":\""+personalTargetDate+"\",\"createdById\":null,\"modifiedById\":null,\"customDateFields\":[]}";
		String rbody = "{\"salary\":\"" + salary + "\",\"salaryMethod\":\"" + salaryMethod + "\",\"salaryDate\":\""
				+ salaryDate + "\",\"personalTarget\":\"" + personalTarget + "\",\"personalTargetMethod\":\""
				+ personalTargetMethod + "\",\"personalTargetDate\":\"" + personalTargetDate
				+ "\",\"createdById\":null,\"modifiedById\":null}";
		rest.postRest("/proration/v1/config/salary", rbody, loginResp);
		login.logoutAdv(loginResp);
	}

	public void deleteLatestVersion(String EmpID) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		new Organization(SetWebDrivers.getNavigationType());
		SeleniumHelperClass.findWebElementbyid("A_People").click();
		Thread.sleep(3000);
		SeleniumHelperClass.goToFrame("contentFrame");
		SeleniumHelperClass.findWebElementbyName("Employee Id").sendKeys(EmpID);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		get_op_editButton().click();
		Thread.sleep(2000);
		SeleniumHelperClass.findWebElementbyLink("Delete Version", "mainFrame").click();
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				logger.info("window handle isn't parentwindow");
				try {
					logger.info("Trying once");
					SetWebDrivers.getDriver().switchTo().window(windowHandle);
					Thread.sleep(500);
					SeleniumHelperClass.goToFrame("addVersionFrame");
					logger.info("Found the addVersion Frame");
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
					SeleniumHelperClass.findWebElementbyid("comments").sendKeys("deleting the version");
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
					SeleniumHelperClass.findWebElementbyCssSelector("button[type='submit'").click();
					Thread.sleep(500);
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					SeleniumHelperClass.goToFrame("contentFrame");
					WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(120 * 2));
					wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id("listFrame")));
					WebElement ver_table = SeleniumHelperClass.findWebElementbyid("tableFixed");
					SeleniumHelperClass.clickFirstRowOfTable(ver_table);
					SeleniumHelperClass.goToFrame("contentFrame");
					WebDriverWait wait2 = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(120 * 2));
					wait2.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id("editFrame")));
					SeleniumHelperClass.findWebElementbyid("saveButton").click();
					// logger.info(SeleniumHelperClass.findWebElementbyLink("Save
					// version").getAttribute("href"));
					SeleniumHelperClass.findWebElementbyLink("Save version").click();
					// SeleniumHelperClass.findWebElementbyid("menuSave_a_0").click();
					Thread.sleep(10000);
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					// save("version");
				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the delete version window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}
		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
	}

	public void deleteLatestVersionofuser(String EmpID) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		new Organization(SetWebDrivers.getNavigationType());
		if (SetWebDrivers.getNavigationType().equalsIgnoreCase("gui")) {
			SeleniumHelperClass.findWebElementbyid("A_People").click();
		} else if (SetWebDrivers.getNavigationType().equalsIgnoreCase("gui-new")) {
			LeftNavigationUtil.clickOnPeopleTab();
		}
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		SeleniumHelperClass.goToFrame("contentFrame");
		SeleniumHelperClass.findWebElementbyName("Employee Id").sendKeys(EmpID);
		get_op_searchButton().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		get_op_editButton().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		SeleniumHelperClass.findWebElementbyLink("Delete Version", "mainFrame").click();
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				logger.info("window handle isn't parentwindow");
				try {
					logger.info("Trying once");
					SetWebDrivers.getDriver().switchTo().window(windowHandle);
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
					SeleniumHelperClass.goToFrame("addVersionFrame");
					logger.info("Found the addVersion Frame");
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
					SeleniumHelperClass.findWebElementbyid("comments").sendKeys("deleting the version");
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
					SeleniumHelperClass.findWebElementbyCssSelector("button[type='submit'").click();
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					SeleniumHelperClass.goToFrame("contentFrame");
					WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(120 * 2));
					wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id("listFrame")));
					WebElement ver_table = SeleniumHelperClass.findWebElementbyid("tableFixed");
					SeleniumHelperClass.clickFirstRowOfTable(ver_table);
					SeleniumHelperClass.goToFrame("contentFrame");
					WebDriverWait wait2 = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(120 * 2));
					wait2.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id("editFrame")));
					SeleniumHelperClass.findWebElementbyid("saveButton").click();
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
					SeleniumHelperClass.findWebElementbyLink("Save version").click();
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);

				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the delete version window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}
		}
	}

	public void uploadFiles(WebElement uploadElement, String url, String uploadFrame, String uploadType)
			throws Exception {
		// logger.info(url.getPath());
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();

		uploadElement.click();
		Thread.sleep(2000);
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		logger.info(windowHandlers);
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {

				SetWebDrivers.getDriver().switchTo().window(windowHandle);
				try {

					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 2);
					SetWebDrivers.getDriver().switchTo().frame(uploadFrame);
					WebElement uploadField = SeleniumHelperClass.findWebElementbyXpath("//input[@type='file']");
					uploadField.sendKeys(url);

					if (uploadType.equalsIgnoreCase("createOnly")) {
						logger.info("createOnly");
						get_person_upload_Option1().click();
					} else if (uploadType.equalsIgnoreCase("updateOnly")) {
						logger.info("updateOnly");
						get_person_upload_Option2().click();
					} else if (uploadType.equalsIgnoreCase("createAndUpdate")) {
						logger.info("createAndUpdate");
						get_person_upload_Option3().click();
					}
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 2);
					SeleniumHelperClass.findWebElementbyXpath(".//*[@type='submit']").click();
					String bodyText;
					int count = 0;
					do {
						Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
						bodyText = SeleniumHelperClass.findWebElementbyTagName("body", "").getText();
						logger.info(bodyText);
						count++;
					} while (count <= 5 && !bodyText.contains("File was uploaded successfully"));

					if (bodyText.contains("File was uploaded successfully")) {
						logger.info("sync upload was successfull");
						WebElement ok = SeleniumHelperClass.findWebElementbyXpath(".//*[@onclick='done()']");
						ok.click();

					} else if (bodyText.contains(
							"Your upload request is being processed and when completed will appear in the myUploads page.")) {
						logger.info("async upload was successfull");
						SeleniumHelperClass.findWebElementbyXpath(".//*[@type='button']").click();
						/*
						 * WebElement
						 * OK=SeleniumHelperClass.findWebElementbyXpath(".//*[@onclick='doOk()']");
						 * OK.click();
						 */
						// SeleniumHelperClass.findWebElementbyXpath(".//*[@type='button']").click();
					}

				} catch (Exception e) {
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}

			}
		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);

	}

	public boolean isFileDownloaded(String downloc, String fileName) {

		boolean flag = false;

		File dir = new File(downloc);
		File[] dir_contents = dir.listFiles();

		for (int i = 0; i < dir_contents.length; i++) {
			if (dir_contents[i].getName().equals(fileName)) {
				flag = true;
				break;
			} else {
				flag = false;
			}
		}
		return flag;

	}

	public void deleteMiddleVersion(String EmpID) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		new Organization(SetWebDrivers.getNavigationType());
		SeleniumHelperClass.findWebElementbyid("A_People").click();
		Thread.sleep(3000);
		SeleniumHelperClass.goToFrame("contentFrame");
		SeleniumHelperClass.findWebElementbyName("Employee Id").sendKeys(EmpID);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		get_op_editButton().click();
		Thread.sleep(2000);
		// SetWebDrivers.getDriver().switchTo().window(parentWindow);
		SeleniumHelperClass.goToFrame("contentFrame");
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(120 * 2));
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id("listFrame")));
		WebElement ver_table = SeleniumHelperClass.findWebElementbyid("tableFixed");
		SeleniumHelperClass.clickSecondRowOfTable(ver_table);
		SeleniumHelperClass.findWebElementbyLink("Delete Version", "mainFrame").click();
		Thread.sleep(2000);
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				logger.info("window handle isn't parentwindow");
				try {
					logger.info("Trying once");
					SetWebDrivers.getDriver().switchTo().window(windowHandle);
					Thread.sleep(500);
					SeleniumHelperClass.goToFrame("addVersionFrame");
					logger.info("Found the addVersion Frame");
					SeleniumHelperClass.findWebElementbyid("comments").sendKeys("deleting the version");
					SeleniumHelperClass.findWebElementbyCssSelector("button[type='submit'").click();
					Thread.sleep(500);
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					SeleniumHelperClass.goToFrame("contentFrame");
					WebDriverWait wait2 = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(120 * 2));
					wait2.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id("listFrame")));
					WebElement ver_table2 = SeleniumHelperClass.findWebElementbyid("tableFixed");
					SeleniumHelperClass.clickFirstRowOfTable(ver_table2);
					SeleniumHelperClass.goToFrame("contentFrame");
					WebDriverWait wait3 = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(120 * 2));
					wait3.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id("editFrame")));
					SeleniumHelperClass.findWebElementbyid("saveButton").click();
					SeleniumHelperClass.findWebElementbyLink("Save version").click();
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					Thread.sleep(10000);
					// save("save");
				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the delete version window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}
		}

	}

	public void readFromFileAndDeleteLatestVersion(String file) throws Exception {
		String filename = this.getClass().getClassLoader().getResource(file).getPath();
		CSVReader reader = new CSVReader(new FileReader(filename));
		List<String[]> csvBody = reader.readAll();
		logger.info("Size of csvBody is" + csvBody.size());
		deleteLatestVersion(csvBody.get(1)[0]);
		reader.close();
	}

	public List<String> verifyAuditDetails() throws Exception {
		List<String> Auditdetails = new ArrayList<String>();

		// parentWindow=SetWebDrivers.getDriver().getWindowHandle();
		get_op_audit_version().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		String parentWindow = SeleniumHelperClass.switchToPopupWindow(); // switchToNewWindow();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		try {

			String desc = get_op_Audit_Desc().getText();
			String firstname = get_op_Audit_FirstName().getText();
			String lastname = get_op_Audit_LastName().getText();
			String empid = get_op_Audit_EmpID().getText();
			String personalTarget = get_op_Audit_PersonalTarget().getText();
			Auditdetails.add(desc);
			Auditdetails.add(firstname);
			Auditdetails.add(lastname);
			Auditdetails.add(empid);
			Auditdetails.add(personalTarget.replace(",", ""));
			SetWebDrivers.getDriver().close();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
			// SetWebDrivers.getDriver().switchTo().window(parentWindow);
			SeleniumHelperClass.switchToWindow(parentWindow);
		} catch (Exception e) {
			// SetWebDrivers.getDriver().switchTo().window(parentWindow);
			SeleniumHelperClass.switchToWindow(parentWindow);
		}
		return Auditdetails;

	}

	public List<String> verifyAuditDetailsWithModiedBy() throws Exception {
		List<String> Auditdetails = new ArrayList<String>();

		// parentWindow=SetWebDrivers.getDriver().getWindowHandle();
		get_op_audit_version().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		String parentWindow = SeleniumHelperClass.switchToPopupWindow(); // switchToNewWindow();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		try {
			String modifiedBy = get_op_Audit_ModifiedBy().getText();
			String desc = get_op_Audit_Desc().getText();
			String firstname = get_op_Audit_FirstName().getText();
			String lastname = get_op_Audit_LastName().getText();
			String empid = get_op_Audit_EmpID().getText();
			String personalTarget = get_op_Audit_PersonalTarget().getText();
			Auditdetails.add(modifiedBy);
			Auditdetails.add(desc);
			Auditdetails.add(firstname);
			Auditdetails.add(lastname);
			Auditdetails.add(empid);
			Auditdetails.add(personalTarget.replace(",", ""));
			SetWebDrivers.getDriver().close();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
			// SetWebDrivers.getDriver().switchTo().window(parentWindow);
			SeleniumHelperClass.switchToWindow(parentWindow);
		} catch (Exception e) {
			// SetWebDrivers.getDriver().switchTo().window(parentWindow);
			SeleniumHelperClass.switchToWindow(parentWindow);
		}
		return Auditdetails;

	}

	public List<String> InputElements(String desc, String firstname, String lastname, String empid,
									  String personalTarget) throws Exception {

		List<String> InputDetails = new ArrayList<String>();
		InputDetails.add(desc);
		InputDetails.add(firstname);
		InputDetails.add(lastname);
		InputDetails.add(empid);
		InputDetails.add(personalTarget);
		return InputDetails;

	}

	public List<String> InputElementsWithModifiedBy(String ModifiedBy, String desc, String firstname, String lastname,
													String empid, String personalTarget) throws Exception {

		List<String> InputDetails = new ArrayList<String>();
		InputDetails.add(ModifiedBy);
		InputDetails.add(desc);
		InputDetails.add(firstname);
		InputDetails.add(lastname);
		InputDetails.add(empid);
		InputDetails.add(personalTarget);
		return InputDetails;

	}

	public Peoples() {
	}

	public WebElement get_op_searchBox_secondName() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(".//input[@name='Last Name']", "contentFrame");
	}

	public WebElement get_op_searchBox_EmpId() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(".//input[@name='Employee Id']", "contentFrame");
	}

	public void impersonate(String FirstName, String LastName) throws Exception {

		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_op_searchBox().sendKeys(FirstName);
		get_op_searchBox_secondName().sendKeys(LastName);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_op_searchButton().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		Thread.sleep(2500);
		get_impersonate().click();
		Thread.sleep(1000);
		SeleniumHelperClass.findWebElementbyName("reason", "mainFrame").sendKeys("123143");
		SeleniumHelperClass.findWebElementbyCssSelector("td.x-btn-center", "mainFrame").click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);

		// SeleniumHelperClass.isVisible(get_Impuser(), 20);
		/* String titleName = get_firstName().getText(); */
		// Assert.assertEquals(get_Impuser().getText(), FirstName);
	}

	public WebElement get_reason() throws Exception {
		return SeleniumHelperClass.findWebElementbyName("reason", "mainFrame");
	}

	public WebElement get_Submit_button() throws Exception {
		return SeleniumHelperClass.findWebElementbyCssSelector("td.x-btn-center", "mainFrame");
	}

	public void impersonateEmpId(String employeeId) throws Exception {
		SoftAssert sa = new SoftAssert();
		SeleniumHelperClass.isVisible(get_op_searchBox_EmpId(), 10);
		get_op_searchBox_EmpId().sendKeys(employeeId);
		SeleniumHelperClass.isClickable(get_op_searchButton(), 10);
		get_op_searchButton().click();
		SeleniumHelperClass.isVisible(get_firstName(), 10);
		String titleName = get_firstName().getText();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		Thread.sleep(2500);
		get_impersonate().click();
		Thread.sleep(2500);
		get_reason().sendKeys("123143");
		SeleniumHelperClass.isVisible(get_Submit_button(), 10);
		get_Submit_button().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX * 2);
	}

	public void endImpersonate() throws Exception {
		if (SetWebDrivers.getNavigationType().equalsIgnoreCase("gui")) {
			SeleniumHelperClass.isVisible(clickDown(), 10);
			SeleniumHelperClass.isClickable(clickDown(), 10);
			clickDown().click();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 2);
			get_endImpersonate_link().click();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		} else {
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
			SeleniumHelperClass.isVisible(newEndImpersonation(), 20);
			newEndImpersonation().click();
		}

	}

	public void endImpersonateWithCurrentNavigation() throws Exception {
		String navType = "";
		try {
			LoginToApplication login = new LoginToApplication();
			navType = login.getCurrentNavigationType();
		} catch (Exception e) {
			logger.info("unable to get current navigation..setting global navigation type recevied");
			navType = SetWebDrivers.getNavigationType();
		}
		if (navType.equalsIgnoreCase("gui")) {
			SeleniumHelperClass.isVisible(clickDownWithCurrentNavigation(), 10);
			SeleniumHelperClass.isClickable(clickDownWithCurrentNavigation(), 10);
			clickDownWithCurrentNavigation().click();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 2);
			get_endImpersonate_link().click();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		} else {
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
			SeleniumHelperClass.isVisible(newEndImpersonation(), 10);
			newEndImpersonation().click();
		}

	}

	public WebElement newEndImpersonation() throws Exception {

		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='endImpersonation']", "headerframe");

	}

	public WebElement downloadPeople() throws Exception {

		return SeleniumHelperClass.findWebElementbyLink("Download People", "mainFrame");

	}

	public WebElement downloadDone() throws Exception {

		return SeleniumHelperClass.findWebElementbyXpath("//button[@onclick='done()']", "downloadframe");

	}

	public WebElement clickAllVersions() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@value='allVersions']", "downloadframe");

	}

	public WebElement getNotificationNumber() throws Exception {
		if (SetWebDrivers.getNavigationType().equalsIgnoreCase("gui")) {
			return SeleniumHelperClass.findWebElementbyXpath("//div[@id='notifications']//div[@class='badge'][1]",
					"topFrame");
		} else {
			return SeleniumHelperClass.findWebElementbyXpath("//div[@id='notifications']//div[@class='badge'][1]",
					"headerframe");
		}
	}

	public WebElement getNotification() throws Exception {
		if (SetWebDrivers.getNavigationType().equalsIgnoreCase("gui")) {
			return SeleniumHelperClass.findWebElementbyXpath("//div[@id='notifications']", "topFrame");
		} else {
			return SeleniumHelperClass.findWebElementbyXpath("//div[@id='notifications']", "headerFrame");
		}
	}

	public WebElement getAscendingOrderArrow() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//span[contains(text(),'Expiry Date')]//..//span[@class='sortIcon']//i[@class='fa fa-sort-asc']",
				"none");
	}

	public WebElement getDownloadButton() throws Exception {
		return SeleniumHelperClass
				.findWebElementbyXpath("(//span[@class='download-file']//i[@class='fa fa-download'])[1]", "none");
	}

	public WebElement getCloseButton() throws Exception {
		return SeleniumHelperClass
				.findWebElementbyXpath("//span[contains(text(),'Downloads')]//..//i[@class='fa fa-times']", "none");
	}

	public WebElement getProfilePicElement() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//img[@id='profile_pic_outer']", "headerFrame");
	}

	public WebElement getStickyElement(String userName) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[text()='" + userName + "']", "profileFrame");
	}

	public File download(String option) throws Exception {

		String parentWindow = SeleniumHelperClass.switchToPopupWindow();

		if (option.equals("All versions")) {
			logger.info("click");
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
			SeleniumHelperClass.click(clickAllVersions());
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);

		}

		else {

			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		}

		downloadDone().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		SeleniumHelperClass.acceptAlert();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX * 4);

		if (getNotificationNumber().isDisplayed()) {
			logger.info("Checking Incent downloads menu");
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX * 4);
			getNotification().click();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
			String parentWindow1 = SeleniumHelperClass.switchToPopupWindow();
			getAscendingOrderArrow().click();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
			getDownloadButton().click();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
			getCloseButton().click();
			SeleniumHelperClass.switchToWindow(parentWindow1);
		}
		latestFile = findLatestFileInLocation(Constants.downloadLoc);
		logger.info("latestFile:" + latestFile);
		return latestFile;
	}

	//Function used for selecting different file format for download by using option as all versions if required
	public File download(String option, String format) throws Exception {
		String parentWindow = SeleniumHelperClass.switchToPopupWindow();
		if (option.equals("All versions")) {
			SeleniumHelperClass.click(clickAllVersions());
		}
		Select sl = SeleniumHelperClass.selectFromDropdownwithelements("name", "format", "downloadframe");
		sl.selectByVisibleText(format);
		downloadDone().click();
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
		latestFile = findLatestFileInLocation(Constants.downloadLoc);
		logger.info("LatestFile path with Name:" + latestFile);
		return latestFile;
	}

	public void auditPeopleFirstVersionDownload() throws Exception {
		// First Version download
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		downloadAuditFirstdVersionPeople().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_op_audit_version().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		String parentWindow = SeleniumHelperClass.switchToPopupWindow();
		auditDownload().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SetWebDrivers.getDriver().close();
		SeleniumHelperClass.switchToWindow(parentWindow);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	public void auditPeopleSecondVersionDownload() throws Exception {
		// Second Audit Version download
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		downloadAuditSecondVersionPeople().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_op_audit_version().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		String parentWindow = SeleniumHelperClass.switchToPopupWindow();
		auditDownload().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SetWebDrivers.getDriver().close();
		SeleniumHelperClass.switchToWindow(parentWindow);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	public void auditPeopleThirdVersionDownload() throws Exception {
		// Third Audit Version download
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		downloadAuditThirdVersionPeople().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_op_audit_version().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		String parentWindow = SeleniumHelperClass.switchToPopupWindow();
		auditDownload().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SetWebDrivers.getDriver().close();
		SeleniumHelperClass.switchToWindow(parentWindow);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	private File latestFile1;

	public File downloadFile() throws Exception {

		latestFile1 = findLatestFileInLocation(Constants.downloadLoc);
		logger.info("latestFile:" + latestFile1);
		return latestFile1;
	}

	public File latestFilefromDir;

	public File findLatestFileInLocation(String downloadLoc) throws InterruptedException {
		logger.info("downloadloc: " + downloadLoc);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX * 3);
		logger.info("Finding latest file");
		latestFilefromDir = getLatestFilefromDir(downloadLoc);
		Thread.sleep(2000);
		return latestFilefromDir;
	}

	public File getLatestFilefromDir(String dirPath) throws InterruptedException {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX * 2);
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			return null;
		}

		File lastModifiedFile = files[0];
		for (int i = 1; i < files.length; i++) {
			if (lastModifiedFile.lastModified() < files[i].lastModified()) {
				lastModifiedFile = files[i];
			}
		}
		logger.info("lastModifiedFile: " + lastModifiedFile);
		return lastModifiedFile;
	}

	public WebElement get_Custom_Field() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//td[text()='Auto']", "ceditFrame");
	}

	public String verifyCustomField() throws Exception {
		get_op_searchButton().click();
		SeleniumHelperClass.isVisible(get_op_table(), 10);
		SeleniumHelperClass.doubleClick(get_op_table());
		// SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		SeleniumHelperClass.executeJavaScriptScroll(get_Custom_Field());
		String CusField = get_Custom_Field().getText();
		return CusField;

	}

	public boolean verifyDownloadTemplate() throws Exception {

		downloadTemplate("(//span[contains(text(),'Upload People')])[3]", "mainframe");
		String sheetName = "Xactly Incent - People Upload";
		String downloadPath = Constants.downloadLoc;
		// logger.info("downloadPath"+downloadPath);
		// logger.info("Latest File"+getLatestFilefromDir(download).getName());
		String FilePath = downloadPath + File.separator + getLatestFilefromDir(downloadPath).getName();
		// logger.info("FilePath"+FilePath);
		boolean isDownloaded = isFileDownloaded(downloadPath, fileName);
		// return isDownloaded;
		SoftAssert sa = new SoftAssert();
		sa.assertTrue(isDownloaded);
		sa.assertAll();
		boolean customFieldPresent = ExcelConnector.findRow(FilePath, sheetName, "Auto");
		return customFieldPresent;
	}

	public String editPersonStatus(String repName, String status) throws Exception {
		get_op_firstNamesearch().sendKeys(repName);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		get_op_editButton().click();
		get_op_employStatus().selectByVisibleText(status);
		save("save");
		SeleniumHelperClass.goToFrame("contentFrame");
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(10 * 2));
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id("listFrame")));
		WebElement ver_table = SeleniumHelperClass.findWebElementbyid("tableFixed");
		SeleniumHelperClass.clickSecondRowOfTable(ver_table);
		String strCurrentValue = get_op_employStatus().getFirstSelectedOption().getText();
		logger.info("The text in next version is.." + strCurrentValue);
		return strCurrentValue;
	}

	public String revertStatusChange() throws Exception {
		get_op_employStatus().selectByVisibleText("Active");
		save("save");
		String strCurrentValue = get_op_employStatus().getFirstSelectedOption().getText();
		logger.info("The text in next version is.." + strCurrentValue);
		return strCurrentValue;
	}

	/**
	 * @return
	 * @throws Exception
	 */
	public void waitLoadHomePage() throws Exception {
		SeleniumHelperClass.waitforPageToLoad("id", "HOME_TAB_HOME_BUSINESS_DASHBOARD", "topFrame");
	}

	/**
	 * @return
	 * @throws Exception
	 */
	public List<WebElement> userInfoList() throws Exception {
		return SeleniumHelperClass.findWebElementsInXpath(".//*[@class='user']//a", "profileframe");

	}

	/**
	 * @return
	 * @throws Exception
	 */
	public void waitLoadHomeTab() throws Exception {
		SeleniumHelperClass.waitforPageToLoad("id", "HOME_TAB_HOME_TAB", "topFrame");
	}

	public WebElement getplaninformation() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("A_Plan Information", "topFrame");
	}

	public WebElement getplaninformation_newnav() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("HOME_NAV-HOME_PLAN_INFOMRATION", "topFrame");
	}

	public WebElement getOrganizationalHierarchy(String name) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'" + name + "')]",
				"xbaseHierarchyFrame");
	}

	public WebElement getCurrencyPeople() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//td[text()='USD']", "reportcontentframe");
	}

	public WebElement getPaymentCurrencyPeople() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//td[text()='EUR']", "reportcontentframe");
	}

	public WebElement getManagersNameCurrentPlanInformation() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//*[@id=\"CurrentYearPlanInformation\"]/div[2]/div[1]/table/tbody/tr[2]/td[2]", "mainFrame");
	}

	public void searchWithEmployeeId(String name) throws Exception {
		SoftAssert sa = new SoftAssert();
		SeleniumHelperClass.isVisible(get_op_searchBox_EmpId(), 30);
		get_op_searchBox_EmpId().sendKeys(name);
		get_op_searchButton().click();
		boolean empId = SeleniumHelperClass.isVisible(get_op_table(), 30);
		sa.assertTrue(empId);
		sa.assertAll();

	}

	public String readPersonalCurrencyDetails() throws Exception {
		String personalCurrency = get_op_personalCur().getFirstSelectedOption().getText();
		return personalCurrency;
	}

	public String readPaymentCurrencyDetails() throws Exception {
		String paymentCurrency = get_op_paymentCur().getFirstSelectedOption().getText();
		return paymentCurrency;
	}

	public void click_plan_information() throws Exception {
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(30));
		wait.until(ExpectedConditions.elementToBeClickable(getplaninformation()));
		// Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		// SeleniumHelperClass.isClickable(getplaninformation(), 30);
		getplaninformation().click();
	}

	public void click_plan_information_newnav() throws Exception {
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(30));
		wait.until(ExpectedConditions.elementToBeClickable(getplaninformation_newnav()));
		getplaninformation_newnav().click();
	}

	public void click_currency_pos() throws Exception {

		// Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(30));
		wait.until(ExpectedConditions.elementToBeClickable(getplaninformation()));
		SeleniumHelperClass.isVisible(getOrganizationalHierarchy(hierarchyName), 30);
		getOrganizationalHierarchy(hierarchyName).click();
	}

	public void click_currency_pos_newnav() throws Exception {

		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(30));
		SeleniumHelperClass.isVisible(getOrganizationalHierarchy(hierarchyName), 30);
		getOrganizationalHierarchy(hierarchyName).click();
	}

	public String readImpersonatePersonalCurrency() throws Exception {

		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		SeleniumHelperClass.isVisible(getCurrencyPeople(), 30);
		String personalcurrency = getCurrencyPeople().getText();
		return personalcurrency;

	}

	public String readImpersonatePaymentCurrency() throws Exception {

		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);

		String payCurrency = getPaymentCurrencyPeople().getText();
		// arr1.add(currency);
		// arr1.add(payCurrency);
		return payCurrency;

	}

	//Get the Managers name from the Current Plan information from the Impersonate screen .
	public String readImpersonateManagersNamefromCurrentPlanInformation() throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		String managerName = getManagersNameCurrentPlanInformation().getText();
		return managerName;

	}

	public WebElement get_op_firstNametextBox() throws Exception {
		return (SeleniumHelperClass.findWebElementbyName("First Name", "contentFrame"));
	}

	public List<WebElement> get_op_personDropdown() throws Exception {
		return (SeleniumHelperClass.findWebElementsById("object_select", "contentFrame"));
	}

	public void SearchedElpse(String empID) throws Exception {

		if (SetWebDrivers.getNavigationType().equalsIgnoreCase("gui")) {
			SeleniumHelperClass.isVisible(ClickPeopleTab(), SeleniumHelperClass.system_SpeedlimitMIN);
			ClickPeopleTab().click();
			SeleniumHelperClass.isVisible(get_employeeId_searchBox(), SeleniumHelperClass.system_SpeedlimitMAX);
			get_employeeId_searchBox().sendKeys(empID);
			SeleniumHelperClass.isVisible(get_op_searchButton(), SeleniumHelperClass.system_SpeedlimitMIN);
			get_op_searchButton().click();
			SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
			SeleniumHelperClass.isVisible(get_op_editButton(), SeleniumHelperClass.system_SpeedlimitMIN);
			get_op_editButton().click();
		} else {
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
			LeftNavigationUtil.clickOnPeopleTab();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX * 2);
			get_employeeId_searchBox().sendKeys(empID);
			SeleniumHelperClass.isVisible(get_op_searchButton(), SeleniumHelperClass.system_SpeedlimitMIN);
			get_op_searchButton().click();
			SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
			SeleniumHelperClass.isVisible(get_op_editButton(), SeleniumHelperClass.system_SpeedlimitMIN);
			get_op_editButton().click();
		}
	}

	public static String getParticipantId(String businessId, String empId)
			throws ClassNotFoundException, SQLException, InterruptedException {
		DBConnections db = new DBConnections();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		return db.connect_Db_string(
				"SELECT * FROM XC_PARTICIPANT WHERE BUSINESS_ID=" + businessId + " AND EMPLOYEE_ID= '" + empId + "'",
				"PARTICIPANT_ID");
	}

	public static void deleteParticipant(String participantId)
			throws ClassNotFoundException, SQLException, InterruptedException {
		DBConnections db = new DBConnections();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		db.connect_Db_string("DELETE FROM XC_PART_USER_ASSIGNMENT WHERE PARTICIPANT_ID=" + participantId);
	}

	public void createPeopleWithoutBizAdminLogin(String user, String fname, String lname, String id, String bGroup,
												 String pTarget, String perCurr, String payCurr) throws Exception {

		SeleniumHelperClass.findWebElementbyLink("Create Person", "mainFrame").click();
		Thread.sleep(1000);
//	SeleniumHelperClass.waitForElmentToBeReady(SeleniumHelperClass.findWebElementbyXpath("//*[@id=\"iconHeader\"]/table/tbody/tr/td[2]/span[1]/b"));
		SeleniumHelperClass.selectFromPopup(get_op_user(), "name_edit_user", user, "ceditFrame");
		Thread.sleep(1000);
//	SeleniumHelperClass.waitForElmentToBeReady(SeleniumHelperClass.findWebElementbyXpath("//*[@id=\"iconHeader\"]/table/tbody/tr/td[2]/span[1]/b"));
		clearAndSend(get_op_firstName(), fname);
		clearAndSend(get_op_lastName(), lname);
		clearAndSend(get_op_employID(), id);
		get_op_businessGroup().selectByVisibleText(bGroup);
		clearAndSend(get_op_personalTarget(), pTarget);
		get_op_personalCur().selectByVisibleText(perCurr);
		SeleniumHelperClass.waitForElement("id", "paymentCurrencyUnitTypeId_people_edit", "ceditFrame",
				SeleniumHelperClass.system_SpeedlimitMAX);
		get_op_paymentCur().selectByVisibleText(payCurr);
		SeleniumHelperClass.findWebElementbyid("saveButton").click();
		SeleniumHelperClass.waitForElmentToBeReady(SeleniumHelperClass.findWebElementbyid("menuSave_a_0"));
		SeleniumHelperClass.findWebElementbyid("menuSave_a_0").click();
	}

	public void impersonateWithoutReason(String FirstName, String LastName) throws Exception {

		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_op_searchBox().sendKeys(FirstName);
		get_op_searchBox_secondName().sendKeys(LastName);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_op_searchButton().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		Thread.sleep(2500);
		get_impersonate().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);

	}

	public WebElement get_endImpersonate_NewUI() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(".//*[@id='endImpersonation']", "headerFrame");
	}

	public void endImpersonateNewUI() throws Exception {
		SeleniumHelperClass.isVisible(get_endImpersonate_NewUI(), 10);
		get_endImpersonate_NewUI().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	}

	public WebElement selectTodaysDate() throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//td[@class='x-date-active x-date-today  x-date-selected']/a/em/span"));
	}

	public WebElement clickOnSubmitButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[@type='submit']"));
	}

	public WebElement getUser() throws Exception {
		return (SeleniumHelperClass.findWebElementbyCssSelector("input[id='show_user_people_edit']", "ceditframe"));
	}

	public WebElement get_Version_table() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//div[text()='Start of Time']", "clistframe");
	}

	public WebElement get_Impuser() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(".//*[@id='impersonation']/div/span[2]", "headerFrame");
	}

	public String editPersonAndAssertLatestUser(String EID) throws Exception {
		get_employeeId_searchBox().sendKeys(EID);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		get_op_editButton().click();
		get_Version_table().click();
		String name = getUser().getAttribute("value");
		return name;
	}

	public void editPeopleAndChangeUser(String user, String existingfirstname) throws Exception {
		get_op_searchBox().sendKeys(existingfirstname);
		get_op_searchButton().click();
		SeleniumHelperClass.clickFirstRowOfTable(get_op_table());
		SeleniumHelperClass.isVisible(get_op_editButton(), SeleniumHelperClass.system_SpeedlimitMIN);
		get_op_editButton().click();
		SeleniumHelperClass.selectFromPopup(get_op_user(), "name_edit_user", user, "ceditFrame");
		save("version");
		SeleniumHelperClass
				.AcceptAlerts("Your new user assignment will be changed for all versions. Do you wish to continue?");
		SeleniumHelperClass.waitForFrame("addVersionFrame", 10);
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				logger.info("window handle isn't parentwindow");
				try {
					logger.info("Trying once");
					SetWebDrivers.getDriver().switchTo().window(windowHandle);
					SeleniumHelperClass.waitForFrame("addVersionFrame", 20);
					SeleniumHelperClass.goToFrame("addVersionFrame");
					logger.info("Found the addVersion Frame");
					SeleniumHelperClass.isVisible(CalenderImage(), SeleniumHelperClass.system_SpeedlimitMAX);
					CalenderImage().click();
					SeleniumHelperClass.isVisible(selectTodaysDate(), SeleniumHelperClass.system_SpeedlimitMAX);
					selectTodaysDate().click();
					SeleniumHelperClass.isVisible(clickOnSubmitButton(), SeleniumHelperClass.system_SpeedlimitMAX);
					clickOnSubmitButton().click();
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the add version window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}

		}

	}

	/**
	 * To Search People using either First name, Last name or Employee id
	 *
	 * @param firstName(Send  first name need to be searched)
	 * @param lastName(Send   last name need to be searched)
	 * @param employeeId(Send employee id needs to be searched)
	 */
	public void searchPeople(String firstName, String lastName, String employeeId) throws Exception {

		SeleniumHelperClass.click(get_person_new_search());
		if (firstName != null) {
			get_op_searchBox().sendKeys(firstName);
		}
		if (lastName != null) {
			get_lastName_searchBox().sendKeys(lastName);
		}
		if (employeeId != null) {
			get_employeeId_searchBox().sendKeys(employeeId);
		}
		SeleniumHelperClass.click(get_op_searchButton());
		SeleniumHelperClass.goToFrame("mainFrame");
		SeleniumHelperClass.waitUntilInvisibilityOfLocatedElement(
				"//*[contains(@class,'x-unselectable x-layout-panel-hd x-dock-panel-title x-window-header-text x-dock-panel-title-collapsed')]");

	}

	public WebElement tabCollapse() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[contains(@class,'x-unselectable x-layout-panel-hd x-dock-panel-title x-window-header-text x-dock-panel-title-collapsed')]"));
	}

	public WebElement getSearchedData(String searchData) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//td[@n='employeeId']/div[text()='" + searchData + "']"));
	}

	public WebElement getAddVersion() throws Exception {
		return SeleniumHelperClass.findWebElementbyLink("Add Version");
	}

	public WebElement getEffStartDateDropdown() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("a_eff_start");
	}

	public WebElement getTodayButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//button[contains(text(),'Today')]");
	}

	public WebElement getSaveButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//button[contains(text(),'Save')]");
	}

	public void getCurrentFrame(String expectedFrame, String frameKey) throws Exception {
		SeleniumHelperClass.waitPageLoad();
		checkCurrentFrame(expectedFrame, frameKey);
	}

	public static WebElement isVisible(WebElement e, int sec) {
		WebDriverWait wait = new WebDriverWait(SetWebDrivers.getDriver(), Duration.ofSeconds(sec));
		try {
			wait.until(ExpectedConditions.visibilityOf(e));
			return e;
		} catch (Exception ex) {
			return e;
		}
	}

	public static void checkCurrentFrame(String expectedFrame, String frameKey) throws Exception {
		if (!fetchCurrentFrame().equalsIgnoreCase(expectedFrame)) {
			SeleniumHelperClass.goToFrame(frameKey);
		}
	}

	public static String fetchCurrentFrame() {
		JavascriptExecutor jsExecutor = (JavascriptExecutor) SetWebDrivers.getDriver();
		String currentFrame = (String) jsExecutor.executeScript("return self.name");
		return currentFrame;
	}

	/**
	 * To validate the EOF in XLSX
	 */
	public String validateEOF(File file) throws IOException, InvalidFormatException {
		ExcelConnector excelUtil = new ExcelConnector();
		int rowNum = excelUtil.getLastRowNum(file);
		String eofValue = excelUtil.readFromExcel(file, rowNum, 0);
		return eofValue;
	}

	/**
	 * To Upload People based on version, format
	 *
	 * @param url
	 * @param uploadType
	 */
	public String uploadPeople_New(String url, String uploadType) throws Exception {
		logger.info("Executing the uploadPeople function");
		String message = "";
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		SeleniumHelperClass.findWebElementbyLink("Upload People", "mainFrame").click();
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				try {
					SetWebDrivers.getDriver().switchTo().window(windowHandle);
					Thread.sleep(500);
					SetWebDrivers.getDriver().switchTo().frame("uploadPeopleFrame");
					Thread.sleep(2000);
					logger.info("Try create/update/create&update");

					if (uploadType.equalsIgnoreCase("CreateOnly")) {
						logger.info("Select CreateOnly");
						SeleniumHelperClass.findWebElementbyCssSelector("input[value='createData']").click();
					} else if (uploadType.equalsIgnoreCase("UpdateOnly")) {
						logger.info("Select UpdateOnly ");
						SeleniumHelperClass.findWebElementbyCssSelector("input[value='updateData']").click();
					} else if (uploadType.equalsIgnoreCase("CreateAndUpdate")) {
						logger.info("Select CreateAndUpdate");
						SeleniumHelperClass.findWebElementbyCssSelector("input[value='both']").click();
					}
					logger.info("Selected radio button");
					WebElement uploadField = SeleniumHelperClass.findWebElementbyXpath("//input[@type='file']");
					logger.info("Clicked on Upload Button");
					uploadField.sendKeys(url);
					logger.info("Sleeping");
					Thread.sleep(1000);
					SeleniumHelperClass.findWebElementbyCssSelector("button[type='submit'").click();
					Thread.sleep(2000);
					SeleniumHelperClass.findWebElementbyXpath(".//*[@onclick='done()']").click();
					logger.info("Clicked on Upload done");
					if (message.contains("Invalid or Duplicate header name, TierR1-1")) {
						logger.info("File not uploaded");
					} else if (message.contains("File was uploaded successfully.")) {
						logger.info("File uploaded successfully");
					}
				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the upload people window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}
		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
		return message;
	}

	/**
	 * To Search People using either First name, Last name or Employee id
	 *
	 * @param firstName(Send  first name need to be searched)
	 * @param lastName(Send   last name need to be searched)
	 * @param employeeId(Send employee id needs to be searched)
	 */
	public void searchPeopleAndEdit(String firstName, String lastName, String employeeId) throws Exception {

		SeleniumHelperClass.click(get_person_new_search());
		if (firstName != null) {
			get_op_searchBox().sendKeys(firstName);
		}
		if (lastName != null) {
			get_lastName_searchBox().sendKeys(lastName);
		}
		if (employeeId != null) {
			get_employeeId_searchBox().sendKeys(employeeId);
		}
		SeleniumHelperClass.click(get_op_searchButton());
		SeleniumHelperClass.goToFrame("contentFrame");
		SeleniumHelperClass.click(getSearchedData(employeeId));
		SeleniumHelperClass.click(get_op_editButton());
	}

	public WebElement getBusinessGroupDropdown(String frame) throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("businessGroupId_people_edit", frame));
	}

	/**
	 * To validate the BGS field
	 */
	public boolean validateBGS(String BGSValue, String frame) throws Exception {
		String BGSActualValue = "";
		try {
			BGSActualValue = SeleniumHelperClass.getSelectedDropDownValue(getBusinessGroupDropdown(frame));
		} catch (NoSuchElementException e) {
			BGSActualValue = "";
		}
		if (BGSValue.equalsIgnoreCase(BGSActualValue))
			return true;
		else
			return false;
	}

	/**
	 * This method is to delete the person created
	 *
	 * @param personName
	 * @param alertMessage
	 */
	public void deletePeople(String personName, String alertMessage) throws Exception {

		searchPeople(null, null, personName);
		SeleniumHelperClass.goToFrame("contentFrame");
		SeleniumHelperClass.click(getSearchedData(personName));
		SeleniumHelperClass.click(get_people_delete());
		SeleniumHelperClass.AcceptAlerts(alertMessage);
	}

	/**
	 * To Upload invalid file based on version, format
	 *
	 * @param url
	 * @param uploadType
	 */
	public String uploadPeopleFail(String url, String uploadType) throws Exception {
		logger.info("Executing the uploadPeople function");
		String message = "";
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		SeleniumHelperClass.findWebElementbyLink("Upload People", "mainFrame").click();
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {
				try {
					SetWebDrivers.getDriver().switchTo().window(windowHandle);
					Thread.sleep(500);
					SetWebDrivers.getDriver().switchTo().frame("uploadPeopleFrame");
					Thread.sleep(2000);
					logger.info("Try create/update/create&update");

					if (uploadType.equalsIgnoreCase("CreateOnly")) {
						logger.info("Select CreateOnly");
						SeleniumHelperClass.findWebElementbyCssSelector("input[value='createData']").click();
					} else if (uploadType.equalsIgnoreCase("UpdateOnly")) {
						logger.info("Select UpdateOnly ");
						SeleniumHelperClass.findWebElementbyCssSelector("input[value='updateData']").click();
					} else if (uploadType.equalsIgnoreCase("CreateAndUpdate")) {
						logger.info("Select CreateAndUpdate");
						SeleniumHelperClass.findWebElementbyCssSelector("input[value='both']").click();
					}
					logger.info("Selected radio button");
					WebElement uploadField = SeleniumHelperClass.findWebElementbyXpath("//input[@type='file']");
					logger.info("Clicked on Upload Button");
					uploadField.sendKeys(url);
					logger.info("Sleeping");
					Thread.sleep(1000);
					SeleniumHelperClass.findWebElementbyCssSelector("button[type='submit'").click();
					Thread.sleep(5000);
					if (SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'Error uploading file!')]")
							.isDisplayed()) {
						message = SeleniumHelperClass.findWebElementbyXpath("(//table[@id='rTable']/tbody/tr/td)[3]")
								.getText().trim();
						logger.info(message);
					}
					SeleniumHelperClass.findWebElementbyXpath(".//*[@onclick='done()']").click();
					if (!message.contains("File was uploaded successfully.")) {
						logger.info("File upload failed");
					}
				} catch (Exception e) {
					SetWebDrivers.getDriver().close();
					logger.info("Closed the upload people window");
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}
			}
		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
		return message;
	}

	/**
	 * To add version for person
	 */
	public void addVersion() throws Exception {
		getAddVersion().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		String parentWindow = SeleniumHelperClass.switchToPopupWindow(); // switchToNewWindow();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		SeleniumHelperClass.goToFrame("addVersionframe");
		getEffStartDateDropdown().click();
		getTodayButton().click();
		getSaveButton().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		SeleniumHelperClass.switchToWindow(parentWindow);
	}

	/**
	 * To validate * mandatory fields
	 */
	public boolean validateBasicMandatoryFields(File file, ArrayList<String> mandatoryFields)
			throws IOException, InvalidFormatException {
		String[] str;
		String columnText;
		boolean isMandatory = false;
		for (String s : mandatoryFields) {
			str = s.split(",");
			columnText = excelUtil.readCSV(file.toString(), Integer.parseInt(str[0]), Integer.parseInt(str[1]));
			if (columnText.contains("*"))
				isMandatory = true;
			else
				isMandatory = false;
		}
		return isMandatory;
	}

	/** Below code is written for People create new UI Redesign page **/

	// To click on create button in people redesign list page

	public WebElement get_redesign_create_People_Button() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"(//*[@id='moduleRootContainer']//button[contains(@class,'btn-primary')  and text()='Create'])[1]",
				"mainFrame");
	}

	// To get PlaceHolder/DefaultSelectedValue of Start date and End date in the
	// create page
	public WebElement getPlaceHolderOfstartDateAndEndDate(String elementId) throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//*[contains(@for,'" + elementId + "')]/following-sibling::span", "mainFrame"));
	}

	// To get PlaceHolder/DefaultSelectedValue of all the fields in the create page
	public WebElement getPlaceHolderOfAllFields(String elementId) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[contains(@for,'" + elementId + "')]/following-sibling::span//span/span", "mainFrame"));
	}

	// To get the text box for the input fields in the create page
	public WebElement getInputTextBoxPeopleResedesignCreatePageFields(String elementId) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[contains(@for,'" + elementId + "')]/following-sibling::span/input", "mainFrame"));
	}

	// To get the text box for the input fields in the create page with common names
	// like Salary and Prorated Salary
	public WebElement getInputTextBoxCommonNamePeopleResedesignCreatePageFields(String elementId) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//*[contains(@for,'" + elementId + "')]/following-sibling::span/input)[1]", "mainFrame"));
	}

	// To get the place holder can get it by getAttribute(placeholder)
	public String getPlaceHolderPeopleRedesignCreatePageFields(String elementId) throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//*[contains(@for,'" + elementId + "')]/following-sibling::span/input",
						"mainFrame")
				.getAttribute("placeholder"));
	}

	// To get the place holder can get it by getAttribute(placeholder) for
	// description field
	public String getPlaceHolderPeopleRedesignDescritptionField(String elementId) throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//*[contains(@for,'" + elementId + "')]/following-sibling::span/textarea",
						"mainFrame")
				.getAttribute("placeholder"));
	}

	// to click on Save or Save and add new version and Save and add add new person
	// common method
	public WebElement getPeopleRedesignUploadOrCancelButton(String cancelorupload) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//button[text()='" + cancelorupload + "' and contains(@class,'btn-secondary')])[1]", "mainFrame"));
	}

	// To get click on save on Edit page
	public WebElement getPeopleRedesignSaveButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@id='fixed-header']//*[contains(@class,'dropdown')]/button[contains(@role,'presentation') and contains(@class,'btn-primary')]",
				"mainFrame"));
	}

	public WebElement getPeopleRedesignSaveOptionsFromDropdownButton(String saveOptions) throws Exception {
		SeleniumHelperClass.click(getPeopleRedesignSaveButton());
		waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
		return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(@class,'dropdown show')]//button[text()='"
				+ saveOptions + "' and contains(@class,'btn-secondary')]", "mainFrame"));
	}

	// to click on Save or Save and add new version and Save and add add new person
	// common method
	public WebElement getPeopleRedesignSaveOptionsFromDropdownOrUploadCancelbuttonPath(String saveOptions)
			throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(@class,'dropdown show')]//button[text()='"
				+ saveOptions + "' and contains(@class,'btn-secondary')]", "mainFrame"));
	}

	public void getPeopleRedesignSaveOptionsFromDropdownWithWait(String saveOptions) throws Exception {
		try
		{
			Actions act = new Actions(SetWebDrivers.getDriver());
			SeleniumHelperClass.isClickable(getPeopleRedesignSaveButton(), 3);
			WebElement getsavebutton = SeleniumHelperClass.findWebElementbyXpath(
					"//div[@id='fixed-header']//*[contains(@class,'dropdown')]/button[contains(@role,'presentation') and contains(@class,'btn-primary')]",
					"mainFrame");

			//SeleniumHelperClass.secondaryClick(getsavebutton);
			//SeleniumHelperClass.click(getPeopleRedesignSaveButton());
			act.click(getsavebutton).build().perform();
			waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
			WebElement getsavedropdown = SeleniumHelperClass.findWebElementbyXpath("//div[contains(@class,'dropdown show')]//button[text()='"
					+ saveOptions + "' and contains(@class,'btn-secondary')]", "mainFrame");

			SeleniumHelperClass.waitUntilElementDisplayed(
					getsavedropdown, 30);
			act.click(getsavedropdown).build().perform();
			//SeleniumHelperClass.secondaryClick(getsavedropdown);

			//SeleniumHelperClass.secondaryClick(getPeopleRedesignSaveOptionsFromDropdownOrUploadCancelbuttonPath(saveOptions));
		}
		catch (ElementNotInteractableException e) {
			logger.info("trying with java script as a Retry..Ignore themessage..." + e.getMessage());
			SeleniumHelperClass.isClickable(getPeopleRedesignSaveButton(), 3);
			WebElement getsavebutton = SeleniumHelperClass.findWebElementbyXpath(
					"//div[@id='fixed-header']//*[contains(@class,'dropdown')]/button[contains(@role,'presentation') and contains(@class,'btn-primary')]",
					"mainFrame");
			((JavascriptExecutor) SetWebDrivers.getDriver()).executeScript("arguments[0].scrollIntoView(true);",
					getsavebutton	);
			waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);

			WebElement getsavedropdown = SeleniumHelperClass.findWebElementbyXpath("//div[contains(@class,'dropdown show')]//button[text()='"
					+ saveOptions + "' and contains(@class,'btn-secondary')]", "mainFrame");

			SeleniumHelperClass.waitUntilElementDisplayed(
					getsavedropdown, 30);
			((JavascriptExecutor) SetWebDrivers.getDriver()).executeScript("arguments[0].scrollIntoView(true);",
					getsavedropdown	);

		}
		catch (Exception e) {
			logger.info("Failed to click webelement due to " + e.getMessage() + ", trying with JSClick...");
			WebElement getsavebutton = SeleniumHelperClass.findWebElementbyXpath(
					"//div[@id='fixed-header']//*[contains(@class,'dropdown')]/button[contains(@role,'presentation') and contains(@class,'btn-primary')]",
					"mainFrame");
			JavascriptExecutor executor = (JavascriptExecutor) SetWebDrivers.getDriver();
			executor.executeScript("arguments[0].click();", getsavebutton);
			waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);

			WebElement getsavedropdown = SeleniumHelperClass.findWebElementbyXpath("//div[contains(@class,'dropdown show')]//button[text()='"
					+ saveOptions + "' and contains(@class,'btn-secondary')]", "mainFrame");

			SeleniumHelperClass.waitUntilElementDisplayed(
					getsavedropdown, 30);

			executor.executeScript("arguments[0].click();", getsavedropdown);

		}




	}

	// to click on description text box
	public WebElement getPeopleRedesignDescriptionTextBox() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='peopleDescription']", "mainFrame"));
	}

	// Web Element for Slider page search icon
	public WebElement getSliderPageSearchIcon() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[contains(@class,'GroupAddonSearch')]", "mainFrame"));
	}

	// Web Element for Table in slider page
	public WebElement getSliderPageTable() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@ref='eContainer' and @role='rowgroup']"));
	}

	// Web Element for Table in slider page
	public WebElement getSliderPageOKButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'SlidePanelFooter')]//button[text()='OK' and contains(@class,'btn btn-primary')]"));
	}

	// Web Element for input field in slider page
	public WebElement getSliderPageInputTextField() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//input[@placeholder='Search Here']"));
	}

	// Web Element for input field in slider page
	public String returnSliderPageInputFieldXpath() throws Exception {
		return "//span[@data-testid='search-icon']/parent::div/following-sibling::input";
	}

	// span[@data-testid='search-icon']/parent::div/following-sibling::input

	// To select from any slider like User
	public void selectFromSlider(String sliderXpath, String searchFieldXpath, String searchString, String frame)
			throws Exception {
		try {
			waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
			SeleniumHelperClass.findWebElementbyXpath(sliderXpath, frame).click();
			waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
			logger.info("Switched to slider page");
			waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
			WebElement nameTextField = SeleniumHelperClass.findWebElementbyXpath(returnSliderPageInputFieldXpath());
			SeleniumHelperClass.clearElement(nameTextField);
			nameTextField.sendKeys(searchString);
			WebElement searchButton = getSliderPageSearchIcon();
			SeleniumHelperClass.isClickable(searchButton, 10);
			searchButton.click();
			waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
			WebElement table = getSliderPageTable();
			clickFirstRowOfTable_Redesign(table);
			SeleniumHelperClass.click(getSliderPageOKButton());
		} catch (Exception e) {
			throw new Exception(e);
		}
	}

	public static void clickFirstRowOfTable_Redesign(WebElement tableElement) throws Exception {
		WebElement firstRow = null;
		ArrayList<WebElement> rowElements = (ArrayList<WebElement>) tableElement.findElements(By.xpath(".//div"));
		if (rowElements.size() > 1)
			firstRow = rowElements.get(1);
		else
			throw new Exception("Required row is not found");
		SeleniumHelperClass.click(firstRow);
	}

	public static void waitInMS(long timeInMS) {
		try {
			Thread.sleep(timeInMS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// To click on calendar in people redesign create page
	public WebElement clickDatePickerFromSlideOutPeopleRedesign(String datePickerElementLabel) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[contains(@for,'" + datePickerElementLabel
						+ "')]/following-sibling::span/div//div[contains(@class,'StyledSingleDatePicker')]/button",
				"mainframe"));
	}

	// To click on calendar in people redesign create page for custom fields
	public WebElement clickDatePickerFromSlideOutPeopleRedesignCustomFields(String datePickerElementLabel)
			throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[contains(@for,'" + datePickerElementLabel
						+ "')]/following-sibling::span/div//div[contains(@class,'StyledSingleDatePicker')]/button",
				"mainframe"));
	}

	// To click on year menu dropdown in active calendar in people redesign create
	// page
	public WebElement yearDropDownFromCalendar() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//div[@data-visible='true' and contains(@class,'CalendarMonth')]//div[contains(@role,'listbox')])[2]",
				"mainframe"));

	}

	// To click on month menu dropdown in active calendar in people redesign create
	// page
	public WebElement monthDropDownFromCalendar() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//div[@data-visible='true' and contains(@class,'CalendarMonth')]//div[contains(@role,'listbox')])[1]",
				"mainframe"));

	}

	// To select year value from dropdown in active calendar in people redesign
	// create page
	public WebElement selectYear(String year) throws Exception {

		SeleniumHelperClass.click(yearDropDownFromCalendar());
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@data-visible='true' and contains(@class,'CalendarMonth')]//button[@value='" + year + "']",
				"mainframe"));
	}

	// To select month value from dropdown in active calendar in people redesign
	// create page
	public WebElement selectMonth(String month) throws Exception {

		SeleniumHelperClass.click(monthDropDownFromCalendar());
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@data-visible='true' and contains(@class,'CalendarMonth')]//button[@value='" + month + "']",
				"mainframe"));
	}

	// To select date from date picker in active calendar in people redesign create
	// page
	public WebElement selectDay(String date) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[2][contains(@class,'CalendarMonthGrid')]//table/tbody/tr/td[contains(@aria-label,'" + date
						+ "')]"));
	}

	// To get text below the input text box of all the fields in the create page for
	// Personal Info as well as for Personal target field
	public String getTextBelowTheInputBoxes(String elementId) throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//label[@for='" + elementId + "']/following-sibling::span/span", "mainFrame"))
				.getText();
	}

	// To get text below the input text box of all the fields in the create page for
	// PersonalCurrency, Payment Currency,Salry Currency ,Business Group ,Prorated
	// Personal Target
	public String getTextBelowTheInputBoxesForCompensationInformation(String elementId) throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//label[@for='" + elementId + "']/following-sibling::span/span", "mainFrame"))
				.getText();
	}
	//div[contains(@class,'SlidePanelFooter')]//button[text()='Selecte' and contains(@class,'btn btn-primary')]
	// Web Element for Table in slider page
	public WebElement getSliderPageSelectButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'SlidePanelFooter')]//button[text()='Select' and contains(@class,'btn btn-primary')]"));
	}

	/**
	 * To select Calendar date from date picker
	 *
	 * @param datePickerElementLabel
	 * @param year
	 * @param month
	 * @throws Exception
	 */
	public void selectFromDatePicker(String datePickerElementLabel, String month, String year, String calendarDate)
			throws Exception {

		SeleniumHelperClass.click(clickDatePickerFromSlideOutPeopleRedesign(datePickerElementLabel));
		SeleniumHelperClass.click(selectMonth(month));
		SeleniumHelperClass.click(selectYear(year));
		SeleniumHelperClass.click(selectDay(calendarDate));
	}

	/**
	 * To select Calendar date from date picker for custom fields
	 *
	 * @param datePickerElementLabel
	 * @param year
	 * @param month
	 * @throws Exception
	 */
	public void selectFromDatePickerCustomField(String datePickerElementLabel, String month, String year,
												String calendarDate) throws Exception {

		SeleniumHelperClass.click(clickDatePickerFromSlideOutPeopleRedesignCustomFields(datePickerElementLabel));
		SeleniumHelperClass.click(selectMonth(month));
		SeleniumHelperClass.click(selectYear(year));
		SeleniumHelperClass.click(selectDay(calendarDate));
	}

	// To click on any get any drop down in people redesign page
	public WebElement getRespectiveDropDown(String elementId) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("(//*[contains(@class,'container-fluid')]//*[contains(@for,'"
				+ elementId + "')]/following-sibling::span/div//div[contains(@class,'dropdown')])[1]", "mainFrame"));
	}

	// To get Drop down menu items in people redesign page
	public List<WebElement> getRespectiveDropDownDropDownMenuItems(String elementId) throws Exception {
		SeleniumHelperClass.click(getRespectiveDropDown(elementId));
		return (SeleniumHelperClass.findWebElementsInXpath(
				"//*[contains(@class,'container-fluid')]//*[contains(@for,'" + elementId
						+ "')]/following-sibling::span/div//div[contains(@class,'dropdown-menu')]/button",
				"mainframe"));
	}

	// To click on any get any drop down in people redesign page for custom fields
	public WebElement getRespectiveDropDownCustomFields(String elementId) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//*[contains(@for,'" + elementId
						+ "')]/following-sibling::span//div/button[contains(@data-toggle,'dropdown')])[1]",
				"mainFrame"));
	}

	// To get Drop down menu items in people redesign page for custom fields
	public List<WebElement> getRespectiveDropDownDropDownMenuItemsCustomFields(String elementId) throws Exception {
		SeleniumHelperClass.click(getRespectiveDropDownCustomFields(elementId));
		return (SeleniumHelperClass.findWebElementsInXpath(
				"//*[contains(@for,'" + elementId
						+ "')]/following-sibling::span//div//div[contains(@class,'dropdown-menu')]/button",
				"mainframe"));
	}

	// To get the text box for the input fields in the custom fields text create
	// page
	public WebElement getTextBoxPeopleRedesignCreatePageCustomFields(String elementId) throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("(//div[@id='" + elementId + "']/following-sibling::input)[1]", "mainFrame"));
	}

	// click on create button
	public void clickOnCreateButtonPeopleRedesignPage() throws Exception {
		SeleniumHelperClass.click(get_redesign_create_People_Button());

	}

	// To get the place holder can get it by getAttribute(placeholder)
	public String getPlaceHolderPeopleRedesignCreateCustomFields(String elementId) throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("(//*[contains(@id,'person')]/following-sibling::input)[1]", "mainFrame")
				.getAttribute(elementId));
	}

	// *[contains(@for,'Description')]/following-sibling::textarea
	public String returnUserInputFieldDotsXpath() throws Exception {
		return "//button[span[text()='Select User']]";
	}

	public String returnUserInputFieldDotsXpathForEditPage(String selecteduser) throws Exception {
		return "//button//span[text()='" + selecteduser + "']";
	}
	public String returnBusinessGroupFieldDotsXpath() throws Exception {
		return "//button[span[text()='Select Business Group']]";
	}

	public void enterAllMandatoryFields(String datePickerElementLabel, String month, String year, String calendarDate)
			throws Exception {
	}

	// create people with mandatory fields only
	public void createPeopleRedesignMandatoryFields(String user, String firstname, String lname, String empid,
													String personalTarget, String perCurr, int perCurrIndex, String payCurr, int payCurrIndex,
													String saveOption) throws Exception {

		logger.info("Creating a new Person with mandatory parameters");
		clickOnCreateButtonPeopleRedesignPage();
		selectFromSlider(returnUserInputFieldDotsXpath(), returnSliderPageInputFieldXpath(), user, "mainframe");
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("First Name"), firstname);
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Last Name"), lname);
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Employee ID"), empid);
		getInputTextBoxPeopleResedesignCreatePageFields("Personal Target").sendKeys(personalTarget);
		List<WebElement> getRespectiveDropDownDropDownMenuItems1 = getRespectiveDropDownDropDownMenuItems(perCurr);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems1.get(perCurrIndex));
		List<WebElement> getRespectiveDropDownDropDownMenuItems2 = getRespectiveDropDownDropDownMenuItems(payCurr);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems2.get(payCurrIndex));
		// SeleniumHelperClass.click(getPeopleRedesignSaveOptionsFromDropdownButton(saveOption));
		getPeopleRedesignSaveOptionsFromDropdownWithWait(saveOption);

	}

	// create people with mandatory fields only and passing business group
	public void createPeopleRedesignMandatoryFieldsWithBusinessGroup(String user, String firstname, String lname,
																	 String empid, String personalTarget, String perCurr, int perCurrIndex, String payCurr, int payCurrIndex,
																	 String businessGroupIndex, String saveOption) throws Exception {

		logger.info("Creating a new Person with mandatory parameters");
		clickOnCreateButtonPeopleRedesignPage();
		selectFromSlider(returnUserInputFieldDotsXpath(), returnSliderPageInputFieldXpath(), user, "mainframe");
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("First Name"), firstname);
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Last Name"), lname);
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Employee ID"), empid);
		getInputTextBoxPeopleResedesignCreatePageFields("Personal Target").sendKeys(personalTarget);
		List<WebElement> getRespectiveDropDownDropDownMenuItems1 = getRespectiveDropDownDropDownMenuItems(perCurr);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems1.get(perCurrIndex));
		List<WebElement> getRespectiveDropDownDropDownMenuItems2 = getRespectiveDropDownDropDownMenuItems(payCurr);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems2.get(payCurrIndex));
		selectFromBusinessGroupSlider(returnBusinessGroupFieldDotsXpath(), returnSliderPageInputFieldXpath(), businessGroupIndex, "mainframe");
		// SeleniumHelperClass.click(getPeopleRedesignSaveOptionsFromDropdownButton(saveOption));
		getPeopleRedesignSaveOptionsFromDropdownWithWait(saveOption);

	}

	// create people with mandatory fields and customFields of String Type
	public void createPeopleRedesignwithCustomFields_StringType(String user, String firstname, String lname,
																String empid, String personalTarget, String perCurr, String payCurr, String optionalFieldName,
																String optionalFieldValue, String reqFieldName, String reqFieldValue, String saveOption) throws Exception {
		logger.info("Creating a new Person with mandatory parameters");
		clickOnCreateButtonPeopleRedesignPage();
		selectFromSlider(returnUserInputFieldDotsXpath(), returnSliderPageInputFieldXpath(), user, "mainframe");
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("First Name"), firstname);
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Last Name"), lname);
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Employee ID"), empid);
		getInputTextBoxPeopleResedesignCreatePageFields("Personal Target").sendKeys(personalTarget);
		List<WebElement> getRespectiveDropDownDropDownMenuItems1 = getRespectiveDropDownDropDownMenuItems(perCurr);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems1.get(1));
		List<WebElement> getRespectiveDropDownDropDownMenuItems2 = getRespectiveDropDownDropDownMenuItems(payCurr);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems2.get(1));
		// Custom field with labels optional and required created in Setup>>Custom
		// Fields Page
		clearAndSend(getTextBoxPeopleRedesignCreatePageCustomFields(optionalFieldName), optionalFieldValue);
		clearAndSend(getTextBoxPeopleRedesignCreatePageCustomFields(reqFieldName), reqFieldValue);
		// SeleniumHelperClass.click(getPeopleRedesignSaveOptionsFromDropdownButton(saveOption));
		getPeopleRedesignSaveOptionsFromDropdownWithWait(saveOption);

		// waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);

	}

	// create people with mandatory fields and customFields of String Type with
	// business group
	public void createPeopleRedesignwithCustomFieldsWithBusinessGroup_StringType(String user, String firstname,
																				 String lname, String empid, String personalTarget, String perCurr, String payCurr, String optionalFieldName,
																				 String optionalFieldValue, String reqFieldName, String reqFieldValue, String businessGroupIndex,
																				 String saveOption) throws Exception {
		logger.info("Creating a new Person with mandatory parameters");
		clickOnCreateButtonPeopleRedesignPage();
		selectFromSlider(returnUserInputFieldDotsXpath(), returnSliderPageInputFieldXpath(), user, "mainframe");
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("First Name"), firstname);
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Last Name"), lname);
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Employee ID"), empid);
		getInputTextBoxPeopleResedesignCreatePageFields("Personal Target").sendKeys(personalTarget);
		List<WebElement> getRespectiveDropDownDropDownMenuItems1 = getRespectiveDropDownDropDownMenuItems(perCurr);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems1.get(1));
		List<WebElement> getRespectiveDropDownDropDownMenuItems2 = getRespectiveDropDownDropDownMenuItems(payCurr);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems2.get(1));
		selectFromBusinessGroupSlider(returnBusinessGroupFieldDotsXpath(), returnSliderPageInputFieldXpath(),
				businessGroupIndex, "mainframe");
		// Custom field with labels optional and required created in Setup>>Custom
		// Fields Page
		clearAndSend(getTextBoxPeopleRedesignCreatePageCustomFields(optionalFieldName), optionalFieldValue);
		clearAndSend(getTextBoxPeopleRedesignCreatePageCustomFields(reqFieldName), reqFieldValue);
		// SeleniumHelperClass.click(getPeopleRedesignSaveOptionsFromDropdownButton(saveOption));
		getPeopleRedesignSaveOptionsFromDropdownWithWait(saveOption);

	}

	// To get labels in people redesign create page
	public List<WebElement> getRespectiveLabelsInCreatePage(String elementId) throws Exception {
		SeleniumHelperClass.click(getRespectiveDropDown(elementId));
		return (SeleniumHelperClass.findWebElementsInXpath("//*[contains(@class,'container-fluid')]//label",
				"mainframe"));
	}

	// create people with mandatory fields and optional fields only
	public void createPeopleRedesignMandatoryFieldsAndOptionalFields(String user, String description, String firstname,
																	 String middlename, String lname, int prefixIndex, String empid, int empstatusIndex, String region,
																	 String hiredate, String terminationdate, String personalTarget, String perCurr, int personalcurrencyIndex,
																	 String payCurr, int paymentcurrencyIndex, String salary, int salaryCurrencyIndex, String businessGroupIndex,
																	 String saveOption) throws Exception {

		logger.info("Creating a new Person with mandatory parameters");
		clickOnCreateButtonPeopleRedesignPage();
		selectFromSlider(returnUserInputFieldDotsXpath(), returnSliderPageInputFieldXpath(), user, "mainframe");
		clearAndSend(getPeopleRedesignDescriptionTextBox(), description);
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("First Name"), firstname);
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Middle Name"), middlename);
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Last Name"), lname);
		List<WebElement> getRespectiveDropDownDropDownMenuItems1 = getRespectiveDropDownDropDownMenuItems("Prefix");
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems1.get(prefixIndex));
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Employee ID"), empid);
		List<WebElement> getRespectiveDropDownDropDownMenuItems2 = getRespectiveDropDownDropDownMenuItems(
				"Employee Status");
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems2.get(empstatusIndex));
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Region"), region);
		selectFromDatePicker("Hire Date", hiredate.split(" ")[0], hiredate.split(" ")[2], hiredate.split(" ")[1]);
		selectFromDatePicker("Termination Date", terminationdate.split(" ")[0], terminationdate.split(" ")[2],
				terminationdate.split(" ")[1]);
		getInputTextBoxCommonNamePeopleResedesignCreatePageFields("Personal Target").sendKeys(personalTarget);
		List<WebElement> getRespectiveDropDownDropDownMenuItems3 = getRespectiveDropDownDropDownMenuItems(perCurr);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems3.get(personalcurrencyIndex));
		List<WebElement> getRespectiveDropDownDropDownMenuItems4 = getRespectiveDropDownDropDownMenuItems(payCurr);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems4.get(paymentcurrencyIndex));
		clearAndSend(getInputTextBoxCommonNamePeopleResedesignCreatePageFields("Salary"), salary);
		List<WebElement> getRespectiveDropDownDropDownMenuItems5 = getRespectiveDropDownDropDownMenuItems(
				"Salary Currency");
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems5.get(salaryCurrencyIndex));
		selectFromBusinessGroupSlider(returnBusinessGroupFieldDotsXpath(), returnSliderPageInputFieldXpath(), businessGroupIndex, "mainframe");
		// SeleniumHelperClass.click(getPeopleRedesignSaveOptionsFromDropdownButton(saveOption));
		getPeopleRedesignSaveOptionsFromDropdownWithWait(saveOption);

	}

	// create people with mandatory fields and optional fields along with manual
	// proration on
	public void createPeopleRedesignMandatoryFieldsAndOptionalFieldsWithManualProrationAndOptionalBusinessGroup(
			String bizLoginInfo, String user, String description, String firstname, String middlename, String lname,
			int prefixIndex, String empid, int empstatusIndex, String region, String hiredate, String terminationdate,
			String personalTarget, String proratedPersonalTarget, String perCurr, int personalcurrencyIndex,
			String payCurr, int paymentcurrencyIndex, String salary, int salaryCurrencyIndex, String businessGroupIndex,
			String saveOption) throws Exception {
		if (enableProratedPersonalTarget)
			enableProratedTargetField(bizLoginInfo);
		logger.info("Creating a new Person with mandatory parameters");
		clickOnCreateButtonPeopleRedesignPage();
		selectFromSlider(returnUserInputFieldDotsXpath(), returnSliderPageInputFieldXpath(), user, "mainframe");
		clearAndSend(getPeopleRedesignDescriptionTextBox(), description);
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("First Name"), firstname);
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Middle Name"), middlename);
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Last Name"), lname);
		List<WebElement> getRespectiveDropDownDropDownMenuItems1 = getRespectiveDropDownDropDownMenuItems("Prefix");
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems1.get(prefixIndex));
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Employee ID"), empid);
		List<WebElement> getRespectiveDropDownDropDownMenuItems2 = getRespectiveDropDownDropDownMenuItems(
				"Employee Status");
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems2.get(empstatusIndex));
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Region"), region);
		selectFromDatePicker("Hire Date", hiredate.split(" ")[0], hiredate.split(" ")[2], hiredate.split(" ")[1]);
		selectFromDatePicker("Termination Date", terminationdate.split(" ")[0], terminationdate.split(" ")[2],
				terminationdate.split(" ")[1]);
		getInputTextBoxCommonNamePeopleResedesignCreatePageFields("Personal Target").sendKeys(personalTarget);
		getInputTextBoxCommonNamePeopleResedesignCreatePageFields("Prorated Personal Target")
				.sendKeys(proratedPersonalTarget);
		List<WebElement> getRespectiveDropDownDropDownMenuItems3 = getRespectiveDropDownDropDownMenuItems(perCurr);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems3.get(personalcurrencyIndex));
		List<WebElement> getRespectiveDropDownDropDownMenuItems4 = getRespectiveDropDownDropDownMenuItems(payCurr);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems4.get(paymentcurrencyIndex));
		clearAndSend(getInputTextBoxCommonNamePeopleResedesignCreatePageFields("Salary"), salary);
		List<WebElement> getRespectiveDropDownDropDownMenuItems5 = getRespectiveDropDownDropDownMenuItems(
				"Salary Currency");
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems5.get(salaryCurrencyIndex));
	/*	/List<WebElement> getRespectiveDropDownDropDownMenuItems6 = getRespectiveDropDownDropDownMenuItems(
				"Business Group");
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems6.get(businessGroupIndex));*/
		selectFromBusinessGroupSlider(returnBusinessGroupFieldDotsXpath(), returnSliderPageInputFieldXpath(), businessGroupIndex, "mainframe");
		// SeleniumHelperClass.click(getPeopleRedesignSaveOptionsFromDropdownButton(saveOption));
		getPeopleRedesignSaveOptionsFromDropdownWithWait(saveOption);

	}

	// create people with mandatory fields and optional fields along with manual
	// proration on and custom fields
	public void createPeopleRedesignMandatoryFieldsAndOptionalFieldsWithProrationAndBusinessGroupAndStringCustomFieldMandatoryAndRequired(
			String bizLoginInfo, String user, String description, String firstname, String middlename, String lname,
			int prefixIndex, String empid, int empstatusIndex, String region, String hiredate, String terminationdate,
			String personalTarget, String proratedPersonalTarget, String perCurr, int personalcurrencyIndex,
			String payCurr, int paymentcurrencyIndex, String salary, int salaryCurrencyIndex, String businessGroupIndex,
			String optionalFieldName, String optionalFieldValue, String reqFieldName, String reqFieldValue,
			String reqFieldDropdownName, int reqFieldDropdownIndex, String optionalFieldDropdownName,
			int optionalFieldDropdownIndex, String reqFieldBooleanName, int reqFieldBooleanIndex,
			String optionalFieldBooleanName, int optionalFieldBooleanIndex, String reqFieldBooleanOnOffName,
			int reqFieldBooleanOnOffIndex, String reqFieldNumbercurrencyName, int reqFieldNumbercurrencyIndex,
			String optionalNumbercurrency, int optionalNumbercurrencyindex, String requiredNumfieldName,
			String requiredNumfieldvalue, String optionalNumfieldName, String optionalNumfieldvalue,
			String reqFieldCustomdateName, String reqFieldCustomdate, String optionalFieldCustomdateName,
			String optionalFieldCustomdate, String saveOption) throws Exception {
		if (enableProratedPersonalTarget)
			enableProratedTargetField(bizLoginInfo);
		logger.info("Creating a new Person with mandatory parameters");
		clickOnCreateButtonPeopleRedesignPage();
		selectFromSlider(returnUserInputFieldDotsXpath(), returnSliderPageInputFieldXpath(), user, "mainframe");
		clearAndSend(getPeopleRedesignDescriptionTextBox(), description);
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("First Name"), firstname);
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Middle Name"), middlename);
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Last Name"), lname);
		List<WebElement> getRespectiveDropDownDropDownMenuItems1 = getRespectiveDropDownDropDownMenuItems("Prefix");
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems1.get(prefixIndex));
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Employee ID"), empid);
		List<WebElement> getRespectiveDropDownDropDownMenuItems2 = getRespectiveDropDownDropDownMenuItems(
				"Employee Status");
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems2.get(empstatusIndex));
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Region"), region);
		selectFromDatePicker("Hire Date", hiredate.split(" ")[0], hiredate.split(" ")[2], hiredate.split(" ")[1]);
		selectFromDatePicker("Termination Date", terminationdate.split(" ")[0], terminationdate.split(" ")[2],
				terminationdate.split(" ")[1]);
		getInputTextBoxCommonNamePeopleResedesignCreatePageFields("Personal Target").sendKeys(personalTarget);
		getInputTextBoxCommonNamePeopleResedesignCreatePageFields("Prorated Personal Target")
				.sendKeys(proratedPersonalTarget);
		List<WebElement> getRespectiveDropDownDropDownMenuItems3 = getRespectiveDropDownDropDownMenuItems(perCurr);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems3.get(personalcurrencyIndex));
		List<WebElement> getRespectiveDropDownDropDownMenuItems4 = getRespectiveDropDownDropDownMenuItems(payCurr);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems4.get(paymentcurrencyIndex));
		clearAndSend(getInputTextBoxCommonNamePeopleResedesignCreatePageFields("Salary"), salary);
		List<WebElement> getRespectiveDropDownDropDownMenuItems5 = getRespectiveDropDownDropDownMenuItems(
				"Salary Currency");
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems5.get(salaryCurrencyIndex));
		selectFromBusinessGroupSlider(returnBusinessGroupFieldDotsXpath(), returnSliderPageInputFieldXpath(), businessGroupIndex, "mainframe");
		// Custom field with labels optional and required created in Setup>>Custom
		// Fields Page
		clearAndSend(getTextBoxPeopleRedesignCreatePageCustomFields(optionalFieldName), optionalFieldValue);
		clearAndSend(getTextBoxPeopleRedesignCreatePageCustomFields(reqFieldName), reqFieldValue);
		clearAndSend(getTextBoxPeopleRedesignCreatePageCustomFields(optionalNumfieldName), optionalNumfieldvalue);
		clearAndSend(getTextBoxPeopleRedesignCreatePageCustomFields(requiredNumfieldName), requiredNumfieldvalue);

		List<WebElement> getRespectiveDropDownDropDownMenuItems7 = getRespectiveDropDownDropDownMenuItemsCustomFields(
				reqFieldDropdownName);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems7.get(reqFieldDropdownIndex));
		List<WebElement> getRespectiveDropDownDropDownMenuItems8 = getRespectiveDropDownDropDownMenuItemsCustomFields(
				optionalFieldDropdownName);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems8.get(optionalFieldDropdownIndex));
		List<WebElement> getRespectiveDropDownDropDownMenuItems9 = getRespectiveDropDownDropDownMenuItemsCustomFields(
				reqFieldBooleanName);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems9.get(reqFieldBooleanIndex));
		List<WebElement> getRespectiveDropDownDropDownMenuItems10 = getRespectiveDropDownDropDownMenuItemsCustomFields(
				optionalFieldBooleanName);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems10.get(optionalFieldBooleanIndex));
		List<WebElement> getRespectiveDropDownDropDownMenuItems11 = getRespectiveDropDownDropDownMenuItemsCustomFields(
				reqFieldBooleanOnOffName);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems11.get(reqFieldBooleanOnOffIndex));
		List<WebElement> getRespectiveDropDownDropDownMenuItems12 = getRespectiveDropDownDropDownMenuItemsCustomFields(
				reqFieldNumbercurrencyName);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems12.get(reqFieldNumbercurrencyIndex));
		List<WebElement> getRespectiveDropDownDropDownMenuItems13 = getRespectiveDropDownDropDownMenuItemsCustomFields(
				optionalNumbercurrency);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems13.get(optionalNumbercurrencyindex));

		selectFromDatePickerCustomField(reqFieldCustomdateName, reqFieldCustomdate.split(" ")[0],
				reqFieldCustomdate.split(" ")[2], reqFieldCustomdate.split(" ")[1]);
		selectFromDatePickerCustomField(optionalFieldCustomdateName, optionalFieldCustomdate.split(" ")[0],
				optionalFieldCustomdate.split(" ")[2], optionalFieldCustomdate.split(" ")[1]);
		// SeleniumHelperClass.click(getPeopleRedesignSaveOptionsFromDropdownButton(saveOption));
		getPeopleRedesignSaveOptionsFromDropdownWithWait(saveOption);

	}

	//To delete person from database by passing empid
	public void deletePersonFromDB(String busid, String empid, DBConnections db) throws Exception {
		try {
			logger.info("Delete from xc_participant:  " + busid);
			int result = db.executeDeleteQuery(
					"delete from xc_participant where business_id =" + busid + " and employee_id = '" + empid + "'");
			logger.info("Delete result" + result);
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	// To select a column name for a person like FIRST_NAME
	public String getColumnNameForPerson(String busid, String empid, String column_name, DBConnections db)
			throws Exception, SQLException {
		String column_name_value = null;
		try {
			logger.info(" Running select query for the business id  : " + busid);

			String query = "select " + column_name + " from xc_participant where business_id =" + busid
					+ " and employee_id = '" + empid + "'";
			column_name_value = db.connect_Db_string(query, column_name);

		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		logger.info("The value of the respective column is : " + column_name_value);

		return column_name_value;

	}

	public String getBusinessGroupSecurityEnabled(String busid, DBConnections db) throws Exception, SQLException {
		String column_name_value = null;
		try {
			logger.info(" Running select query for the business id  : " + busid);

			String query = "select VALUE from xc_business_pref where business_id =" + busid
					+ " and Name like 'BUSINESS_GROUP_SECURITY' ";
			column_name_value = db.connect_Db_withoutColumnName(query);

		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		logger.info("The value of the respective column is : " + column_name_value);

		return column_name_value;

	}

	// Below method is for checking whether bgs is enabled or not
	public boolean checkBusinessGroupSecurityEnabled(String busid, DBConnections db) throws Exception {
		boolean flag = true;

		try {

			String Value = getBusinessGroupSecurityEnabled(busid, db);

			if (Value.contains("1")) {
				logger.info("It is a bgs enabled business");
				return flag;
			} else {
				logger.info("It is not a bgs enabled business ");
				return false;
			}
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}

		return flag;

	}

	// To get Toaster message from slide out for success message like Person is
	// created
	public WebElement getToasterMessage() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@type='success' and @data-testid='xtoast-wrapper']");
	}

	// To get Toaster message from slide out for error messges like Required field
	// is missing
	public WebElement getErrorToasterMessage() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@type='urgent']");
	}

	// To get first name
	public String getRandomFirstName() throws Exception {
		String firstname = "FirstName" + SeleniumHelperClass.generateRandomNumber(1000000, 10);
		return firstname;
	}

	// To get last name
	public String getRandomLasttName() throws Exception {
		String lastname = "LastName" + SeleniumHelperClass.generateRandomNumber(1000000, 10);
		return lastname;

	}

	// To get middle name
	public String getRandomMiddleName() throws Exception {
		String middlename = "MiddleName" + SeleniumHelperClass.generateRandomNumber(1000000000, 10);
		return middlename;

	}

	// To get employee id
	public String getRandomEmpid() throws Exception {
		String empid = "empid" + SeleniumHelperClass.generateRandomNumber(1000000, 10);
		return empid;

	}

	// To get a random number
	public String getRandomNumber() throws Exception {
		String empid = "123" + SeleniumHelperClass.generateRandomNumber(1000000, 10);
		return empid;

	}

	// Below method is for checking whether maunal proration is enabled
	public boolean checkManualProrationEnabled(String bizLoginInfo) throws Exception {
		boolean flag = true;
		SoftAssert sa = new SoftAssert();
		LoginToRestAPI logintorest = new LoginToRestAPI();
		try {
			logindo = logintorest.login(bizLoginInfo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("Checking if Prorated Personal target is set to manual or not");

		String getRequest = "/proration/v1/config/salary";
		String resp = rest.getRestAPI(getRequest);
		logger.info("JSON response received from GET: " + resp);
		String getPersonalTarget = JsonPath.read(resp, "$.personalTarget");
		logger.info("Person Target is: " + getPersonalTarget);
		if (getPersonalTarget.trim().contains("Manual")) {
			logger.info("Prorated personal target is set to take manual entries!");
			return flag;
		} else
			logger.info("Personal Target is set to Same");
		return false;
	}

	/** Below code is written for People new UI Redesign pages */

	public WebElement getUploadButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id=\"fixed-header\"]//span[2]/button", "mainFrame");
	}

	public WebElement getAddFileButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//div/input[@type='file']");
	}

	public WebElement getUploadButtonOnUploadPanel() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//button[contains(text(),'Upload')]");
	}

	public WebElement getUploadParamRadioButton(String uploadType) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"(//input[@id='uploadParams' and @value='" + uploadType + "']/../*[local-name()='svg'])[1]");
	}

	public String getUploadFileLocationRedesign(String file) {
		String path = this.getClass().getClassLoader()
				.getResource("com.xactly.incent.organization/PeopleUploadRedesign/" + file).getFile();
		logger.info("Actual path is  : " + path);
		if (SetWebDrivers.runningOS.equalsIgnoreCase("Windows")) {
			logger.info("OS in Windows, Fie Path : " + path);
			path = path.substring(1, path.length()).replace("/", "\\");
		}
		logger.info("Upload File location Path returned : " + path);
		return path;
	}

	public String getToastMessage() throws Exception {

		return SeleniumHelperClass.findWebElementbyid("xtoast-container__content").getText();
	}

	public WebElement getUploadPeopleTemplate() throws Exception {

		return SeleniumHelperClass.findWebElementbyXpath("//span[text()='upload template file.']");
	}

	public void searchPeopleRedesign(String name) throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		peopleSearchBoxRedesign().sendKeys(name);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 3);
		peopleSearchIconRedesign().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 2);
	}

	public void click3DotsRedesign(String name) throws Exception {
		// searchPeopleRedesign(name);
		// SeleniumHelperClass.moveToElement(getAllPersonsRedesign().get(0));
		SeleniumHelperClass.executeJavaScriptScroll(threeDotsBtnRedesign(name));
		SeleniumHelperClass.moveToElement(selectPersonRowRedesign(name));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 2);
		SeleniumHelperClass.moveToElement(selectRowRedesign(name));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/2);
		SeleniumHelperClass.waitUntilElementDisplayed(threeDotsBtnRedesign(name), 30);
		SeleniumHelperClass.click(threeDotsBtnRedesign(name));
		/*
		 * Actions actions = new Actions(webDriver);
		 * actions.click(threeDotsBtnForPersonRedesign(name)).build().perform();
		 */
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	public void selectOptionsRedesign(String name, String option) throws Exception {
		SeleniumHelperClass.waitUntilElementDisplayed(selectToggleOptionRedesign(name, option), 30);
		SeleniumHelperClass.click(selectToggleOptionRedesign(name, option));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	public void validatePeopleWhereUsedRedesignLabels(String expFirstName, String expLastName, String expEmplID,
													  String expAllResults, String expCount, String expDownloadBtnText) throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 2);
		String expHeader = "Where Used: " + expFirstName + " " + expLastName + " (" + expEmplID + ")";
		Assert.assertEquals(peopleSliderUIHeaderRedesign().getText(), expHeader, "Header displayed Incorrectly");
		logger.info(peopleSliderUIHeaderRedesign().getText() + " is displayed instead " + expHeader);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 3);
		Assert.assertEquals(whereUsedUIAllResultsRedesign().getText().substring(0, 11), expAllResults,
				"All results Text displayed incorrectly");
		logger.info(whereUsedUIAllResultsRedesign().getText() + " is displayed instead " + expAllResults);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 3);
		Assert.assertEquals(whereUsedUICountRedesign().getText(), expCount, "Incorrect Count displayed");
		logger.info(whereUsedUICountRedesign().getText() + " is displayed instead " + expCount);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 3);
		Assert.assertEquals(whereUsedUIDownloadBtnRedesign().getText(), expDownloadBtnText,
				"Incorrect Download Button Text");
		logger.info(whereUsedUIDownloadBtnRedesign().getText() + " is displayed instead " + expDownloadBtnText);
	}

	public void validateRedesignWhereUsedColLabels(String expNameLabel, String expEffDateLabel, String expDesLabel) throws  Exception{
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/3);
		Assert.assertEquals(whereUsedNameColRedesign().getText(), expNameLabel, "Incorrect Column Name displayed");
		logger.info(whereUsedNameColRedesign().getText()+" displayed");
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/3);
		Assert.assertEquals(whereUsedStartDateColRedesign().getText(), expEffDateLabel, "Incorrect Column Name displayed");
		logger.info(whereUsedStartDateColRedesign().getText()+" displayed");
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN/3);
		Assert.assertEquals(whereUsedUIDesColRedesign().getText(), expDesLabel, "Incorrect Column Name displayed");
		logger.info(whereUsedUIDesColRedesign().getText()+" displayed");
	}

	public void validateRedesignPersonWhereUsedData(String expPositionName, String expStartDate, String expDescription)
			throws Exception {
		SeleniumHelperClass.waitForElmentToBeReady(whereUsedNameColValueRedesign());
		Assert.assertEquals(whereUsedNameColValueRedesign().getText(), expPositionName, "Incorrect Position Name displayed");
		logger.info(whereUsedNameColValueRedesign().getText()+" displayed");
		SeleniumHelperClass.waitForElmentToBeReady(whereUsedStartDateColValueRedesign());
		Assert.assertEquals(whereUsedStartDateColValueRedesign().getText(), expStartDate, "Incorrect Start date Name displayed");
		logger.info(whereUsedStartDateColValueRedesign().getText()+" displayed");
		SeleniumHelperClass.waitForElmentToBeReady(whereUsedDesColValueRedesign());
		Assert.assertEquals(whereUsedDesColValueRedesign().getText(), expDescription, "Incorrect description displayed");
		logger.info(whereUsedDesColValueRedesign().getText()+" displayed");
	}

	public void validateRedesignNoRecordsSlider(String expRecordsText, String expSubText) throws Exception{
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		SeleniumHelperClass.waitForElmentToBeReady(whereUsedNoDataRedesign());
		String actualRecordsText = whereUsedNoDataRedesign().getText();
		Assert.assertEquals(actualRecordsText, expRecordsText, "No Records Found is not displayed");
		logger.info(actualRecordsText+" displayed");
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		String actualSubText = whereUsedNoDataSubTextRedesign().getText();
		Assert.assertEquals(actualSubText, expSubText, "No results were found is not displayed");
		logger.info(actualSubText+" displayed");
	}

	public void clickOnSliderRedesignCloseIcon() throws Exception {
		if (peopleSliderUICloseIconRedesign().isDisplayed()) {
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 2);
			SeleniumHelperClass.click(peopleSliderUICloseIconRedesign());
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 2);
		}
	}


	public void clickOnSliderRedesignCloseBtn() throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 2);
		SeleniumHelperClass.click(whereUsedUICloseBtnRedesign());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 2);
	}

	public void validateImpersonateRedesignLabels(String expHeader, String expLabel) throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		Assert.assertEquals(peopleSliderUIHeaderRedesign().getText(), expHeader, "Header displayed Incorrectly");
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 3);
		Assert.assertEquals(impersonateLabelRedesign().getText(), expLabel, "Labels validation failed");
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 3);
		Assert.assertEquals(peopleSliderCancelBtnRedesign().getText(), "Cancel",
				"Cancel button text validation failed");
		Assert.assertEquals(peopleSliderImpersonateBtnRedesign().getText(), "Impersonate",
				"Impersonate button text validation failed");
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 3);
	}

	public void enterImpersonateReasonRedesign(String reason) throws Exception {
		impersonateTextBoxRedesign().sendKeys(reason);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 3);
	}

	public void clickOnImpersonateRedesign() throws Exception {
		SeleniumHelperClass.click(peopleSliderImpersonateBtnRedesign());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		SeleniumHelperClass.waitPageLoad();
	}

	public void valImpersonateDashboardTitleRedesign(String valImpHeader) throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 3);
		Assert.assertEquals(impersonateTitle1Redesign().getText(), valImpHeader,
				"Page not navigated to Impersonate Dashboard");
		logger.info("Page navigated to Impersonate user Profile");
	}

	public void closeImpersonateProfileRedesign(String dashboard) throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 3);
		SeleniumHelperClass.click(endImpersonateRedesign());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		SeleniumHelperClass.waitPageLoad();
	}

	public void valImpErrorRedesign(String expError) throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 3);
		Assert.assertEquals(impersonateErrorMsgRedesign().getText(), expError, "Error message not validated");
		logger.info(impersonateErrorMsgRedesign().getText() + " error message validated");
	}

	public void valDeniedPopupRedesign(String expHeader, String expPopupText) throws Exception {
		boolean status = false;
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 3);
		Assert.assertEquals(impersonateDeniedHeaderRedesign().getText(), expHeader, "Header validation failed");
		logger.info("'" + impersonateDeniedHeaderRedesign().getText() + "' validated");
		Assert.assertEquals(impersonateDeniedPopupMsgRedesign().getText(), expPopupText,
				"Denied Popup text validation failed");
		logger.info("'" + impersonateDeniedPopupMsgRedesign().getText() + "' validated");
	}

	public void okDeniedImpersonateRedesign() throws Exception {
		boolean status = false;
		if (impersonateDeniedOkBtnRedesign().isDisplayed()) {
			status = true;
		}
		Assert.assertTrue(status, "OK button not displayed");
		logger.info("OK button displayed");
		impersonateDeniedOkBtnRedesign().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 3);
	}

	public void closeDeniedImpersonateRedesign() throws Exception {
		boolean status = false;
		if (impersonateDeniedCloseIconRedesign().isDisplayed()) {
			status = true;
		}
		Assert.assertTrue(status, "'X' icon not displayed");
		logger.info("'X' icon displayed");
		impersonateDeniedCloseIconRedesign().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 3);
	}

	public void cancelImpersonateRedesign() throws Exception {
		peopleSliderCancelBtnRedesign().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 2);
	}

	public WebElement getErrorModal() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//h4[span[text()='Error']]", "mainFrame");
	}

	public WebElement getErrorModalFieldValue(String fieldValue) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//div[text()='" + fieldValue + "' and @aria-colindex='2']",
				"mainFrame");
	}

	public WebElement getErrorModalErrorText(String errorText) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//div[text()='" + errorText + "' and @aria-colindex='3']",
				"mainFrame");
	}

	/**
	 * To validate Error field and it's value in Error Modal
	 */
	public boolean isExpectedErrorModalDisplayed(String sExpectedField, String errorExpectedtext) throws Exception {
		boolean isDisplayed = false;
		if (getErrorModal().isDisplayed()) {
			if (getErrorModalFieldValue(sExpectedField).isDisplayed()
					&& getErrorModalErrorText(errorExpectedtext).isDisplayed())
				isDisplayed = true;
		} else
			isDisplayed = false;
		return isDisplayed;
	}

	public WebElement getErrorModalDownloadButton() throws Exception {

		return SeleniumHelperClass.findWebElementbyXpath("//div[contains(@class,'modal')]//button[text()='Download']",
				"mainFrame");

	}

	public ArrayList<String> getErrorCsvFileContent(String csvFile) throws IOException {
		String value = null;
		logger.info("FIle path " + csvFile);
		BufferedReader br = new BufferedReader(new FileReader(csvFile));
		String line;
		ArrayList<String> arrList = new ArrayList<String>();
		;
		while ((line = br.readLine()) != null) {
			arrList.add(line);

		}
		return arrList;
	}

	public WebElement errorModalOkBtnRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[text()='Ok']", "mainFrame"));
	}

	/** Below code is written for People create new UI Add version page **/

	// To get the edit people page version button
	// page
	public WebElement getEditPeoplePageVersionButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//button[text()='Versions' and contains(@class,'btn-secondary')])[1]", "mainFrame"));
	}

	// To get the edit people page version button
	// page
	public WebElement getEditPeoplePageAddVersionButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//span[text()='Versions']/following-sibling::span//*[name()='svg']", "mainFrame"));
	}

	// To get the version year dropdown button in the add version page
	// page
	public WebElement clickDatePickerFromAddVersionPeopleSlideout() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[contains(text(),'The latest version’s effective end will be updated to the period before the effective start listed below.')]/following-sibling::div//div[contains(@class,'StyledSingleDatePicker')]/button",
				"mainFrame"));
	}

	public String getDatePickerFromAddVersionPeopleSlideoutPlaceholder() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//*[contains(text(),'The latest version’s effective end will be updated to the period before the effective start listed below.')]/following-sibling::div//following-sibling::span/span)[1]",
				"mainFrame").getText());
	}

	/**
	 * To select Calendar date from date picker for add version page
	 *
	 * @param calendarDate
	 * @param year
	 * @param month
	 * @throws Exception
	 */
	public void selectFromDatePickerAddVersionRedesignPage(String month, String year, String calendarDate)
			throws Exception {

		SeleniumHelperClass.click(clickDatePickerFromAddVersionPeopleSlideout());
		SeleniumHelperClass.click(selectMonth(month));
		SeleniumHelperClass.click(selectYear(year));
		SeleniumHelperClass.click(selectDay(calendarDate));
	}

	// To click on any get any drop down in people redesign page like version reason
	// and version sub reason
	public WebElement getRespectiveDropDownAddVersionPageVersionReasonAndVersionSubReasion(String elementId)
			throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("(//*[contains(@class,'modal-content')]//*[contains(@for,'"
				+ elementId + "')]/following-sibling::span/div//div[contains(@class,'dropdown')])[1]", "mainFrame"));
	}

	// To get Drop down menu items in people add version redesign page for version
	// reason and version sub reason
	public List<WebElement> getRespectiveDropDownAddVersionDropDownMenuItems(String elementId) throws Exception {
		SeleniumHelperClass.click(getRespectiveDropDownAddVersionPageVersionReasonAndVersionSubReasion(elementId));
		return (SeleniumHelperClass.findWebElementsInXpath(
				"//*[contains(@class,'modal-content')]//*[contains(@for,'" + elementId
						+ "')]/following-sibling::span/div//div[contains(@class,'dropdown-menu')]/button",
				"mainframe"));
	}

	// To get the save or cancel button in add version page
	// page
	public WebElement getEditPeoplePageAddVersionPageSaveOrCancelButton(String option) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				".//*[@class='modal fade show']//descendant::button[text()='" + option + "']", "mainFrame"));
	}

	// To get the sub heading
	public String getTheRepectiveVersionSubHeading(String index) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='" + index + "_subHeading']", "mainFrame")
				.getText());
	}

	// To get the sub heading
	public WebElement getRepectiveVersionSubHeading(String index) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='" + index + "_subHeading']", "mainFrame"));
	}

	// To get the description
	// page
	public String getTheRepectiveVersionSubDescription(String index) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='" + index + "_description']", "mainFrame")
				.getText());
	}

	// To get the business group in case exists
	// page
	public String getTheRepectiveVersionBusinesGroup(String index) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@id='" + index
						+ "_additionalField']/span[contains(text(),'Business Group:')]/following-sibling::span",
				"mainFrame").getText());
	}

	// To get the delete or the cancel button
	public String getVersionCrossMarkAddVersionPage() throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//span[text()='Add Version']/following-sibling::div//button", "mainFrame")
				.getText());
	}

	// create version with optional subreason and sub reason version
	public void CreateVersionWithOptionalFields(String versiondate, String versionreson, int versionreasonIndex,
												String versionsubreson, int versionsubreasonIndex, String saveOption) throws Exception {
		logger.info("Creating a new version");
		SeleniumHelperClass.click(getEditPeoplePageAddVersionButton());

		selectFromDatePickerAddVersionRedesignPage(versiondate.split(" ")[0], versiondate.split(" ")[2],
				versiondate.split(" ")[1]);

		List<WebElement> getRespectiveDropDownDropDownMenuItems1 = getRespectiveDropDownAddVersionDropDownMenuItems(
				versionreson);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems1.get(versionreasonIndex));

		List<WebElement> getRespectiveDropDownDropDownMenuItems2 = getRespectiveDropDownAddVersionDropDownMenuItems(
				versionsubreson);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems2.get(versionsubreasonIndex));

		SeleniumHelperClass.click(getEditPeoplePageAddVersionPageSaveOrCancelButton(saveOption));

	}

	// create version without optional subreason and sub reason version
	public void CreateVersion(String versiondate, String saveOption) throws Exception {
		logger.info("Creating a new version");
		SeleniumHelperClass.click(getEditPeoplePageAddVersionButton());

		selectFromDatePickerAddVersionRedesignPage(versiondate.split(" ")[0], versiondate.split(" ")[2],
				versiondate.split(" ")[1]);

		SeleniumHelperClass.click(getEditPeoplePageAddVersionPageSaveOrCancelButton(saveOption));

	}

	// create version without optional subreason and sub reason version
	public void EnterValuesInAddVersionWithoutOptionalFields(String versiondate, String saveOption) throws Exception {
		logger.info("Creating a new version");

		selectFromDatePickerAddVersionRedesignPage(versiondate.split(" ")[0], versiondate.split(" ")[2],
				versiondate.split(" ")[1]);

		SeleniumHelperClass.click(getEditPeoplePageAddVersionPageSaveOrCancelButton(saveOption));

	}

	// To get the edit people page version button
	// page
	public void clickgetEditPeoplePageVersionButton() throws Exception {

		SeleniumHelperClass.click(getEditPeoplePageVersionButton());

	}

	// To get the edit icon on people redesign list page
	// page
	public WebElement getEditIconBasedOnEmpId(String employeeId) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[text()='" + employeeId
						+ "']/parent::div/parent::div/following-sibling::div//div[@class='grid-action-buttons-container']/button//*[local-name()='svg']",
				"mainFrame"));
	}

	// To get the select person on list page based on empid

	public WebElement selectPersonRowRedesignBasedonEmpId(String employeeid) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//span[text()='" + employeeid + "']//parent::div//parent::div//parent::div[@role='row']",
				"mainFrame"));
	}


	//
	public void getEditIconBasedOnEmpFirstName(String employeeName) throws Exception {
		(SeleniumHelperClass.findWebElementbyXpath("//span[text()='"+employeeName+"']/parent::div/parent::div/following-sibling::div[last()]//div[@class='grid-action-buttons-container']/button",
				"mainFrame")).click();;
	}
	// To search with empid and click on edit button in list page

	public void searchWithEmployeeIdRedesignAndClickOnEditButton(String employeeId) throws Exception {

		SeleniumHelperClass.executeJavaScriptScroll(getEditIconBasedOnEmpId(employeeId));
		SeleniumHelperClass.moveToElement(selectPersonRowRedesignBasedonEmpId(employeeId));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 2);
		SeleniumHelperClass.waitUntilElementDisplayed(getEditIconBasedOnEmpId(employeeId), 30);
		SeleniumHelperClass.click(getEditIconBasedOnEmpId(employeeId));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);

	}

	// To double clikc on any row based on employee id

	public void doubleClickEditPerson(String employeeId) throws Exception {
		SeleniumHelperClass.doubleClick(selectPersonRowRedesignBasedonEmpId(employeeId));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 2);

	}

	// To get employee id
	public String getempid() throws Exception {
		String empid = "eid" + +SeleniumHelperClass.generateRandomNumber(1000000, 10);
		return empid;

	}

	// To get the 3 dots for respective version
	// page
	public WebElement getTheRepectiveVersionThreeDotsBasedonindex(String index) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@id='" + index
						+ "_subHeading']/parent::div/following-sibling::div/div/button//*[local-name()='svg']",
				"mainFrame"));
	}

	// To get the 3 dots for respective version
	// page
	public WebElement getTheRepectiveVersionThreeDotsBasedonindexbutton(String index) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@id='" + index + "_subHeading']/parent::div/following-sibling::div/div/button", "mainFrame"));
	}

	// To get the 3 dots for respective version and deleting
	// page
	public WebElement getVersionPageAuditOrDeleteButton(String option) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'dropdown show')]//div//descendant::button/span[text()='" + option + "']",
				"mainFrame"));
	}

	// to click on the Audit or delete button for each version
	public void addversionClickOnThreeDotsWithSelectingAuditOrDelete(String index, String option) throws Exception {
		SeleniumHelperClass.moveToElement(getTheRepectiveVersionThreeDotsBasedonindex(index));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 2);
		SeleniumHelperClass.waitUntilElementDisplayed(getTheRepectiveVersionThreeDotsBasedonindex(index), 30);
		SeleniumHelperClass.click(getTheRepectiveVersionThreeDotsBasedonindexbutton(index));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SeleniumHelperClass.click(getVersionPageAuditOrDeleteButton(option));

	}

	public String getauditVersionSliderHeader() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("modalTitleId", "mainFrame").getText();

	}

/*	public List<String> auditVersionSliderTableHeaders() throws Exception {
		 List<WebElement> sliderHeader = SeleniumHelperClass.findWebElementsInXpath("(//div[text()='All Results']//ancestor::div//div[@id='myGrid']//div[@role='columnheader']//div[@role='presentation' and @class='ag-header-cell-label'])", "mainFrame");
		 List<String> headerElements = new ArrayList<String>();
		 int size = sliderHeader.size();
		 for(int i=0;i<=sliderHeader.size();i++)
		 {
			 //0-Modified date-
			 //1-Modified By-
			 //2-People Name-
			 //3-Effective Start-
			 //4-Eff End-
			 //5-Action-
			 //6-Element changed-
			 //7-Old value-
			 //8-New Value-
			 headerElements.add(sliderHeader.get(i).getText());
		 }
		 return headerElements;
	}*/

	public HashMap<String,String> auditVersionSliderTabledata(int i) throws Exception
	{
		HashMap<String,String> tableData = new HashMap<String,String>();
		int rows = SeleniumHelperClass.findWebElementsInXpath("(//div[@id='myGrid']//div[@name='center']//div[@role='row'])","mainFrame").size();
		logger.info("Verifying Audit data - rows = "+rows);
		String commonXpath = "(//div[@id='myGrid']//div[@name='center']//div[@role='row']/div[@col-id='";
		String peopleName = "",effectiveStart= "",effectiveEnd= "",action= "",modifiedField= "",oldValue= "",newValue= "";
		try
		{
			if(i<rows)
			{
				logger.info("i value -"+i+" rows value -"+rows);
				peopleName = SeleniumHelperClass.findWebElementsInXpath(commonXpath+"peopleName'])", "mainFrame").get(i).getText();
				effectiveStart = SeleniumHelperClass.findWebElementsInXpath(commonXpath+"effectiveStart'])", "mainFrame").get(i).getText();
				effectiveEnd = SeleniumHelperClass.findWebElementsInXpath(commonXpath+"effectiveEnd'])", "mainFrame").get(i).getText();
				action = SeleniumHelperClass.findWebElementsInXpath(commonXpath+"action'])", "mainFrame").get(i).getText();
				modifiedField = SeleniumHelperClass.findWebElementsInXpath(commonXpath+"modifiedField'])", "mainFrame").get(i).getText();
				oldValue = SeleniumHelperClass.findWebElementsInXpath(commonXpath+"previousValue'])", "mainFrame").get(i).getText();
				newValue = SeleniumHelperClass.findWebElementsInXpath(commonXpath+"newValue'])", "mainFrame").get(i).getText();

				tableData.put("peopleName",peopleName);
				tableData.put("effectiveStart",effectiveStart);
				tableData.put("effectiveEnd",effectiveEnd);
				tableData.put("action",action);
				tableData.put("modifiedField",modifiedField);
				tableData.put("oldValue",oldValue);
				tableData.put("newValue",newValue);
			}
		}
		catch(IndexOutOfBoundsException e)
		{
			logger.info("Exception - "+e);
			peopleName = SeleniumHelperClass.findWebElementsInXpath(commonXpath+"peopleName'])", "mainFrame").get(i).getText();
			effectiveStart = SeleniumHelperClass.findWebElementsInXpath(commonXpath+"effectiveStart'])", "mainFrame").get(i).getText();
			effectiveEnd = SeleniumHelperClass.findWebElementsInXpath(commonXpath+"effectiveEnd'])", "mainFrame").get(i).getText();
			action = SeleniumHelperClass.findWebElementsInXpath(commonXpath+"action'])", "mainFrame").get(i).getText();
			modifiedField = SeleniumHelperClass.findWebElementsInXpath(commonXpath+"modifiedField'])", "mainFrame").get(i).getText();
			oldValue = SeleniumHelperClass.findWebElementsInXpath(commonXpath+"previousValue'])", "mainFrame").get(i).getText();
			newValue = SeleniumHelperClass.findWebElementsInXpath(commonXpath+"newValue'])", "mainFrame").get(i).getText();

			tableData.put("peopleName",peopleName);
			tableData.put("effectiveStart",effectiveStart);
			tableData.put("effectiveEnd",effectiveEnd);
			tableData.put("action",action);
			tableData.put("modifiedField",modifiedField);
			tableData.put("oldValue",oldValue);
			tableData.put("newValue",newValue);
		}
		logger.info("peopleName -"+peopleName);
		logger.info("effectiveStart -"+effectiveStart);
		logger.info("effectiveEnd -"+effectiveEnd);
		logger.info("action -"+action);
		logger.info("modifiedField -"+modifiedField);
		logger.info("oldValue -"+oldValue);
		logger.info("newValue -"+newValue);

		logger.info("tableData size: "+tableData.size());
		return tableData;
	}

	// to click on each version in the verson pannel
	public void addversionClickOnThreeDots(String index) throws Exception {
		SeleniumHelperClass.moveToElement(getTheRepectiveVersionThreeDotsBasedonindex(index));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 2);
		SeleniumHelperClass.waitUntilElementDisplayed(getTheRepectiveVersionThreeDotsBasedonindex(index), 30);
		SeleniumHelperClass.doubleClick(getTheRepectiveVersionThreeDotsBasedonindexbutton(index));

	}

	// To get the comments field in the delete version page
	public WebElement getPeopleVersionRedesignCommentsField(String elementId) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[contains(@for,'" + elementId + "')]/following-sibling::span/textarea", "mainFrame"));
	}

	public String getPlaceHoldePeopleVersionRedesignCommentsField(String elementId) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[contains(@for,'" + elementId + "')]/following-sibling::span/span", "mainFrame").getText());
	}

	// To get the delete or the cancel button in delete version
	public WebElement getVersionDeleteOrCancelButton(String elementId) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'modal-footer')]//button[text()='" + elementId + "']", "mainFrame"));
	}

	// To enter the comments in the delete version text box
	public void entercommentsInDeleteFieldInDeleteVersion(String comments, String option) throws Exception {
		getPeopleVersionRedesignCommentsField("Comments").sendKeys(comments);
		SeleniumHelperClass.click(getVersionDeleteOrCancelButton(option));

	}

	// To get the edit people page version button
	// page
	public WebElement getEditIconInPeopleSlider() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//span[@id,'modalTitleId']/following-sibling::div//*[name()='svg'])[1]", "mainFrame"));
	}

	// to search with emp id and clikc on edit button in slider
	public void searchWithEmployeeIdRedesignAndClickOnEditButtonInSlider(String employeeId) throws Exception {

		SeleniumHelperClass.moveToElement(selectPersonRowRedesignBasedonEmpId(employeeId));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 2);
		SeleniumHelperClass.click(selectPersonRowRedesignBasedonEmpId(employeeId));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SeleniumHelperClass.click(getEditIconInPeopleSlider());

	}

	// edit people with mandatory fields only
	public void editPeopleRedesignMandatoryFieldsWithoutBusinessGroup(String user, String firstname, String lname,
																	  String personalTarget, String perCurr, int perCurrIndex, String payCurr, int payCurrIndex,
																	  String saveOption) throws Exception {
		logger.info("editing a new Person with mandatory parameters");
		getCrossMarkUserPeopleEditButton().click();
		selectFromSlider(returnUserInputFieldDotsXpath(), returnSliderPageInputFieldXpath(), user, "mainframe");
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("First Name"), firstname);
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Last Name"), lname);
		clearAndSend(getInputTextBoxPeopleResedesignCreatePageFields("Personal Target"), personalTarget);
		List<WebElement> getRespectiveDropDownDropDownMenuItems1 = getRespectiveDropDownDropDownMenuItems(perCurr);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems1.get(perCurrIndex));
		List<WebElement> getRespectiveDropDownDropDownMenuItems2 = getRespectiveDropDownDropDownMenuItems(payCurr);
		SeleniumHelperClass.click(getRespectiveDropDownDropDownMenuItems2.get(payCurrIndex));
		getPeopleRedesignSaveOptionsFromDropdownWithWait(saveOption);

	}

	// To get the frozen input text in the edit form page like for effective start
	// date and so on
	public String getEditPageFrozenInputText(String datePickerElementLabel) throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath(
						"//*[contains(@for,'" + datePickerElementLabel + "')]/following-sibling::span/div", "mainframe")
				.getText());
	}

	// To get the calendar effective start date input text in the edit form page
	// like
	// for effective start date and so on
	public String getEditPageEnabledEffectiveInputText(String datePickerElementLabel) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
						"//*[contains(@for,'" + datePickerElementLabel + "')]/following-sibling::span//span", "mainframe")
				.getText());
	}

	// to click on the cross button in the user field in the edit people page
	public WebElement getCrossMarkUserPeopleEditButton() throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//span[@data-testid='xbadge-container']//*[local-name()='svg']", "mainframe"));
	}

	public WebElement getCrossMarkBusinessGroupPeopleEditButton() throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//label[@id='businessGroup_Business Group']/parent::div/child::span//span[@data-testid='xbadge-container']//*[local-name()='svg']", "mainframe"));
	}

	// to select a person record and click on the version button
	public void selectRowAndClickVersion(String employee_id) throws Exception {
		new Peoples(SetWebDrivers.getNavigationType());
		waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
		doubleClickEditPerson(employee_id);
		waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
		clickgetEditPeoplePageVersionButton();
	}

	// to select a person record
	public void selectRowAndClick(String employee_id) throws Exception {
		new Peoples(SetWebDrivers.getNavigationType());
		waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
		doubleClickEditPerson(employee_id);
		waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	// creating a version without optional fields and validating the toaster message
	public void validatePersonVersionCreated(String versondate1, String saveOption1, String expectedSuccessmsg,
											 String msg) throws Exception {

		CreateVersion(versondate1, saveOption1);
		String actualSuccessversionMessage = getToasterMessage().getText();
		Assert.assertEquals(actualSuccessversionMessage, expectedSuccessmsg, " Version is not created successfully ");

	}

	// creating a version with optional fields and validating the toaster message

	public void validatePersonVersionCreatedWithOptionalFields(String versondate, String saveOption1,
															   String expectedSuccessmsg, String msg) throws Exception {

		CreateVersionWithOptionalFields(versondate, "Version Reason", 0, "Version Subreason", 0, saveOption1);

		String actualSuccessMessage1 = getToasterMessage().getText();

		Assert.assertEquals(actualSuccessMessage1, expectedSuccessmsg, msg);

	}

	// clicking on delete for a version and validating whether it got deleted
	public void validatePersonVersionDeleted(String versionindex, String saveOption1, String expectedSuccessmsg)
			throws Exception {

		addversionClickOnThreeDotsWithSelectingAuditOrDelete(versionindex, "Delete");
		entercommentsInDeleteFieldInDeleteVersion("Testing delete comments", "Delete");
		String actualSuccessMessagedeletedversion = getToasterMessage().getText();
		String expectedSuccessMessagedeletedversion = "Version deleted successfully.";
		Assert.assertEquals(actualSuccessMessagedeletedversion, expectedSuccessMessagedeletedversion,
				" version is not deleted ");
	}

	//validating the version sub heading
	public void validatePersonVersionSubHeading(String versionindex, String exp_date_fr_latestversion1, String message)
			throws Exception {

		String actual_date_fr_latestversion = getTheRepectiveVersionSubHeading(versionindex);
		Assert.assertEquals(actual_date_fr_latestversion, exp_date_fr_latestversion1, message);
	}

	// validating the toaster for person created
	public void validatePersonCreated(String saveOption1, String expectedSuccessmsg, String message) throws Exception {

		String actualSuccessMessage1 = getToasterMessage().getText();
		Assert.assertEquals(actualSuccessMessage1, expectedSuccessmsg, message);

	}

	// validating toaster for version creation

	public void validateVersionToasterMessage(String expectedSuccessmsg, String message) throws Exception {

		String actualSuccessMessage = getToasterMessage().getText();

		Assert.assertEquals(actualSuccessMessage, expectedSuccessmsg, message);

	}

	// validating the edit form page text
	public void validateEditFormPageText(String expectedvalueeffectivedate, String inputname, String message)
			throws Exception {

		String actual_end_date = getEditPageFrozenInputText(inputname);

		Assert.assertEquals(actual_end_date, expectedvalueeffectivedate, message);
	}

	// validating whether add version page loaded
	public void validateAddVersionPageLoading(String saveOption1) throws Exception {

		boolean flag = SeleniumHelperClass.isClickable(getEditPeoplePageAddVersionPageSaveOrCancelButton(saveOption1),
				10);
		Assert.assertTrue(flag, "Add version page is not loading");

	}

	// validating whether new create page is loading

	public void validateNewCreatePageLoading(String input, String expectedmessage) throws Exception {

		String actualmessage_first_name = getTextBelowTheInputBoxes(input);
		Assert.assertEquals(actualmessage_first_name, expectedmessage,
				" not required since assertion is not matching ");
	}

	// validating the personal target

	public void validatePersonalTarget(String expetedpersonaltarget, String message) throws Exception {

		String actual_personal_target = getInputTextBoxCommonNamePeopleResedesignCreatePageFields("Personal Target")
				.getAttribute("value");
		Assert.assertEquals(actual_personal_target, expetedpersonaltarget, message);

	}

	public WebElement peopleSearchClearIcon() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[@data-testid='cancel-icon']/*[@title]","mainFrame"));
	}

	public List<WebElement> getColumnData_PeopleListPage(String columnId) throws Exception{
		return (SeleniumHelperClass.findWebElementsInXpath("//div[@col-id='"+columnId+"']//span[contains(@class,'cell-text')]", "mainFrame"));
	}

	public WebElement getColumnHeaderSortIcon_PeopleListPage(String coloumnId) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@col-id='"+coloumnId+"' and @role='columnheader']","mainFrame"));
	}

	public void searchPeople_NewUI(String empIDorFirstORLastName) throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		if(!peopleSearchBoxRedesign().getAttribute("value").isEmpty())
			peopleSearchClearIcon().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		peopleSearchBoxRedesign().sendKeys(empIDorFirstORLastName);
		peopleSearchIconRedesign().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	public boolean validateColumnDataPeopleListPage(String column,String empIDorFirstORLastName) throws Exception {
		boolean isRowsContains=false;
		int index=0;
		List<WebElement> elements = null;
		logger.info("Search Element " + empIDorFirstORLastName);
		switch (column) {
			case "First Name":
				elements = getColumnData_PeopleListPage("firstName");
				break;
			case "Last Name":
				elements = getColumnData_PeopleListPage("lastName");
				break;
			case "Employee ID":
				elements = getColumnData_PeopleListPage("employeeId");
				break;
			default:
				logger.info("Invalid column Name = " + column);
		}
		int Size=elements.size();
		while(index<Size)
		{
			if(elements.get(index).getText().toUpperCase().contains(empIDorFirstORLastName.toUpperCase())) {
				isRowsContains = true;
			}
			else {
				isRowsContains = false;
				break;
			}
			index++;
		}

		return isRowsContains;
	}

	public void sortColumnHeaderInPeopleList_NewUI(String columnId,String sortOrder) throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		if(getColumnHeaderSortIcon_PeopleListPage(columnId).getAttribute("aria-sort").contains("none")) {
			getColumnHeaderSortIcon_PeopleListPage(columnId).click();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
			logger.info("clicked on column-id = " + columnId + " for sorting in " + getColumnHeaderSortIcon_PeopleListPage(columnId).getAttribute("aria-sort"));
		}
		if (!getColumnHeaderSortIcon_PeopleListPage(columnId).getAttribute("aria-sort").contains(sortOrder)) {
			getColumnHeaderSortIcon_PeopleListPage(columnId).click();
			logger.info("clicked on column-id = " + columnId + " for sorting in " + sortOrder);
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		}
		else {
			logger.info("column-id = " + columnId + "is already available in sorting " + sortOrder);
		}
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	}

	/**
	 * To get column Data in People List Page
	 * @param columnName
	 * @return
	 * @throws Exception
	 */
	public ArrayList<String> getColumnDataPeopleListPage(String columnName) throws Exception {
		int index=0;
		List<WebElement> elements = null;
		logger.info("Column Name : " + columnName);
		switch (columnName) {
			case "First Name":
				elements = getColumnData_PeopleListPage("firstName");
				break;
			case "Last Name":
				elements = getColumnData_PeopleListPage("lastName");
				break;
			case "Employee ID":
				elements = getColumnData_PeopleListPage("employeeId");
				break;
			case "Salary":
				elements = getColumnData_PeopleListPage("salary");
				break;
			case "Region":
				elements = getColumnData_PeopleListPage("region");
				break;
			case "Payment Currency":
				elements = getColumnData_PeopleListPage("paymentCurrency");
				break;
			case "Personal Target":
				elements = getColumnData_PeopleListPage("personalTarget");
				break;
			default:
				logger.info("Invalid column Name = " + columnName);
		}
		ArrayList<String> arrList=new ArrayList<>();//To Maintain insertion order
		int Size=elements.size();
		while(index<Size)
		{
			arrList.add(elements.get(index).getText());
			index++;
		}
		return arrList;
	}


	// To get the options in unsaved changes
	public WebElement getEditPageUnsavedOptions(String unsavedOptions) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//span[text()='Unsaved Changes']//parent::h4//parent::div/following-sibling::div//button[text()='" + unsavedOptions + "']", "mainframe"));

	}

	// to click on the cross button in the unsaved changes popup
	public WebElement getCrossMarkUseUnsavedPopup() throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//span[text()='Unsaved Changes']//parent::h4//span[contains(@class,'CloseIcon')]", "mainframe"));

	}

	// entering the personal target

	public void enterPersonalTarget(String personaltargetnew) throws Exception {

		clearAndSend(getInputTextBoxCommonNamePeopleResedesignCreatePageFields("Personal Target"),personaltargetnew);

	}

	// clicking on either "yes aave chnages" or no discard changes in the person page

	public void clickOnSaveChangesForUnsavedChanges(String unsavedOptions) throws Exception {
		clickgetEditPeoplePageVersionButton();
		getEditPeoplePageAddVersionButton().click();
		getEditPageUnsavedOptions("Cancel").click();
		getEditPeoplePageAddVersionButton().click();
		getEditPageUnsavedOptions(unsavedOptions).click();

	}

	public WebElement getPeopleListPageDownloadButton_NewUI() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//button[text()='Download']",
				"mainFrame");
	}

	public WebElement getAllVersionsNewUI() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@id='versions' and @value='ALL']", "mainFrame");
	}

	public WebElement getSliderDownloadButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//div[contains(@class,'XSlidePanelFooter')]/button[text()='Download']",
				"mainFrame");
	}

	public WebElement getDownloadFormatDropdown() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//div[text()='Download Format']/following-sibling::div//button[contains(@class,'DropdownToggle')]",
				"mainFrame");
	}

	public WebElement getDownloadFormatDropdownMenuItem(String formatValue) throws Exception {
		String xpath="//div[text()='Download Format']/following-sibling::div//div[contains(@class,'dropdown-menu')]/button[@Value='VALUE']";
		return SeleniumHelperClass.findWebElementbyXpath(xpath.replace("VALUE",formatValue),
				"mainFrame");
	}

	public void clickDownloadButtonRedesignUI() throws Exception {
		waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
		getPeopleListPageDownloadButton_NewUI().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	}

	public WebElement getLatestVersionsNewUI() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@id='versions' and @value='LATEST']", "mainFrame");
	}

	public String downloadPeopleSliderNewUI(String version, String format) throws Exception {
		String parentWindow = SeleniumHelperClass.switchToPopupWindow();
		if (version.equalsIgnoreCase("All versions"))
			SeleniumHelperClass.click(getAllVersionsNewUI());
		else
			SeleniumHelperClass.click(getLatestVersionsNewUI());
		SeleniumHelperClass.click(getDownloadFormatDropdown());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SeleniumHelperClass.click(getDownloadFormatDropdownMenuItem(format));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		getSliderDownloadButton().click();
		String toasterMessage=getToasterMessage().getText();
		logger.info("Download Message :" + toasterMessage);
		latestFile = findLatestFileInLocation(Constants.downloadLoc);
		logger.info("LatestFile path with Name:" + latestFile);
		return toasterMessage;
	}

	public String getPeopleDownloadExpectedFileLocation(String fileName) {
		String path = this.getClass().getClassLoader()
				.getResource("com.xactly.incent.organization/PeopleDownloadRedesign/" + fileName).getFile();
		System.out.println("FilePath=" + path);
		logger.info("Actual path is  : " + path);
		if (SetWebDrivers.runningOS.equalsIgnoreCase("Windows")) {
			logger.info("OS in Windows, Fie Path : " + path);
			path = path.substring(1, path.length()).replace("/", "\\");
		}
		logger.info("Upload File location Path returned : " + path);
		return path;
	}

	public String getTextFileContent(String csvFile) throws IOException {
		String value = null;
		logger.info("FIle path " + csvFile);
		BufferedReader br = new BufferedReader(new FileReader(csvFile));
		String line;
		String arrList ="";

		while ((line = br.readLine()) != null) {
			arrList= arrList+line;

		}
		return arrList;
	}

	public WebElement get_AdvanceSearchFilter_Link() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//button[contains(@class,'search-filter-btn btn btn-bareIcon')]", "mainFrame");
	}

	public WebElement get_AdvanceSearch_SelectField_DropDown() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//button[contains(@class,'XDropdownToggle') and not (contains(@class,'disabled')) and span]", "mainFrame");


	}
	public WebElement get_AdvanceSearch_SelectFieldValue_FromDropDown(String Value) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//div[contains(@id,'dropdown-menu-wrapper')]//button[label[@id='"+Value+"']]", "mainFrame");


	}

	public WebElement get_AdvanceSearch_FieldValue_Input() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@type='InputSelectBox']", "mainFrame");
	}

	public WebElement get_AdvanceSearch_FieldValue_InputText() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@type='text' and @placeholder='Select Value']", "mainFrame");


	}
	public WebElement get_AdvanceSearch_SelectSliderElipseButton(int Value) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("(//input[@type='InputSelectBox']//parent::div//*[local-name()='svg'])["+Value+"]", "mainFrame");


	}
	public WebElement get_AdvanceSearch_Apply_Button() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//button[contains(text(),'Apply')]", "mainFrame");

	}
	public WebElement get_AdvanceSearch_DatePicker() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//span[contains(@class,'styled-components__StyledPlaceHolder')]", "mainFrame");


	}

	/**
	 * To select Calendar date from date picker
	 *
	 * @param year
	 * @param month
	 * @throws Exception
	 */
	public void selectFromDatePickerForAdvanceSearch( String year, String month, String calendarDate)
			throws Exception {

		SeleniumHelperClass.click(get_AdvanceSearch_DatePicker());
		SeleniumHelperClass.click(selectMonth(month));
		SeleniumHelperClass.click(selectYear(year));
		SeleniumHelperClass.click(selectDay(calendarDate));
	}


	public void selectAdvanceSearchConditionsFromFilter(String fieldName,String InputType,String operatorName,String inputValue,int index) throws Exception {
		String values[] = new String[10];
		//fieldname:firstname,lastnam---
		// input type: TEXT,In,Date,List
		//Operator name;Equals,noteuals
		// input value
		int selectValues;
		switch(InputType) {
			case "InputText" :
				// code block
				SeleniumHelperClass.waitUntilElementDisplayed(getAdvanceSearch_SelectField_DropDown(index), 30);
				SeleniumHelperClass.click(getAdvanceSearch_SelectField_DropDown(index));
				SeleniumHelperClass.click(getAdvanceSearch_SelectFieldValue_DropDown(index,fieldName));
				SeleniumHelperClass.click(getAdvanceSearch_SelectOperator_DropDown(index));
				SeleniumHelperClass.click(getAdvanceSearch_SelectOperatorValue_DropDown(index,operatorName));
				waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
				get_AdvanceSearch_FieldValue_InputText(fieldName).sendKeys(inputValue);
				break;
			case "Slider":
				SeleniumHelperClass.waitUntilElementDisplayed(getAdvanceSearch_SelectField_DropDown(index), 30);
				SeleniumHelperClass.click(getAdvanceSearch_SelectField_DropDown(index));
				SeleniumHelperClass.click(getAdvanceSearch_SelectFieldValue_DropDown(index,fieldName));
				SeleniumHelperClass.click(getAdvanceSearch_SelectOperator_DropDown(index));
				SeleniumHelperClass.click(getAdvanceSearch_SelectOperatorValue_DropDown(index,operatorName));
				values=inputValue.split(":");
				// write a method select single value i.e: values array index 0 value
				WebElement ele;
				if(operatorName.equalsIgnoreCase("In")) {
					ele = get3DotsSelectItemButton_MultiSelect(fieldName);
					SeleniumHelperClass.click(ele);
					selectValueFromSlider(values, false, true);
				}
				else {
					ele = get3DotsSelectItemButton_SingleSelect(fieldName);
					SeleniumHelperClass.click(ele);
					selectValueFromSlider(values, false, false);
				}
				break;
			case "Date":
				// code block
				values=inputValue.split(":");
				// value should pass like year,Month,date
				// need to write method to select data by passing year,month,date
				SeleniumHelperClass.waitUntilElementDisplayed(getAdvanceSearch_SelectField_DropDown(index), 30);
				SeleniumHelperClass.click(getAdvanceSearch_SelectField_DropDown(index));
				SeleniumHelperClass.click(getAdvanceSearch_SelectFieldValue_DropDown(index,fieldName));
				SeleniumHelperClass.click(getAdvanceSearch_SelectOperator_DropDown(index));
				SeleniumHelperClass.click(getAdvanceSearch_SelectOperatorValue_DropDown(index,operatorName));
				selectFromDatePickerForAdvanceSearch(values[0],values[1],values[2]);
				break;

			case "DropDown":
				SeleniumHelperClass.waitUntilElementDisplayed(getAdvanceSearch_SelectField_DropDown(index), 30);
				SeleniumHelperClass.click(getAdvanceSearch_SelectField_DropDown(index));
				SeleniumHelperClass.click(getAdvanceSearch_SelectFieldValue_DropDown(index,fieldName));
				SeleniumHelperClass.click(getAdvanceSearch_SelectOperator_DropDown(index));
				SeleniumHelperClass.click(getAdvanceSearch_SelectOperatorValue_DropDown(index,operatorName));
				SeleniumHelperClass.click(get_Custom_Field());
				SeleniumHelperClass.click(getAdvanceSearch_SelectOperatorValue_DropDown(index,operatorName));

				// value should pass like year,Month,date
				// need to write method to select data by passing year,month,date


				break;

			default:
				// code block
		}




	}

	public WebElement get3DotsSelectItemButton_SingleSelect(String peopleDropDownfieldId) throws Exception {
		String xpath = "((//label[@id='" + peopleDropDownfieldId + "'])/parent::span)/../../../../../../following-sibling::div//input[@type='InputSelectBox']/following-sibling::*";
		return SeleniumHelperClass.findWebElementbyXpath(xpath,
				"mainFrame");
	}

	public WebElement get3DotsSelectItemButton_MultiSelect(String peopleDropDownfieldId) throws Exception {
		String xpath = "(//label[@id='"+peopleDropDownfieldId+"']/ancestor::div[contains(@class,'table-row-cell')]/following-sibling::div//button[contains(@class,'btn-primary') and span[contains(text(),'Select Value')]]//button)[2]";
		return SeleniumHelperClass.findWebElementbyXpath(xpath,
				"mainFrame");
	}

	public WebElement getSliderRow(String sliderselectValue) throws Exception {
		String xpath = "//div[@role='gridcell' and text()='" + sliderselectValue + "']";
		return SeleniumHelperClass.findWebElementbyXpath(xpath, "mainFrame");
	}

	public WebElement getSliderCheckbox(String slidercheckboxValue) throws Exception {
		String xpath = "//div[@role='row']//div[text()='" + slidercheckboxValue + "']/preceding-sibling::div//input[@type='checkbox']";
		return SeleniumHelperClass.findWebElementbyXpath(xpath, "mainFrame");
	}

	public void selectValueFromSlider(String [] selectValue, boolean isSearchfield, boolean isMultiSelect)
			throws Exception {
		try {
			waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
			logger.info("Switched to slider page");
			waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
			if (isSearchfield) {
				WebElement nameTextField = SeleniumHelperClass.findWebElementbyXpath(returnAdvanceSearchSliderPageInputFieldXpath());
				SeleniumHelperClass.clearElement(nameTextField);
				nameTextField.sendKeys(selectValue[0]);
				WebElement searchButton = getSliderPageSearchIcon();
				SeleniumHelperClass.isClickable(searchButton, 10);
				searchButton.click();
				waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
				SeleniumHelperClass.click(getSliderRow(selectValue[0]));
				waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
			} else if (isMultiSelect) {
				for (int k = 0; k < selectValue.length; k++) {
					if (!getSliderCheckbox(selectValue[k]).isSelected()) {
						SeleniumHelperClass.click(getSliderCheckbox(selectValue[k]));
						waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
					}
				}
			} else {
				SeleniumHelperClass.click(getSliderRow(selectValue[0]));
				waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
			}
			SeleniumHelperClass.click(get_AdvanceSearch_SliderSelectButton());
		} catch (Exception e) {
			throw new Exception(e);
		}
	}

	public void clickAdvanceSearchLink_NewUI() throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SeleniumHelperClass.click(get_AdvanceSearchFilter_Link());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	public WebElement get_AdvanceSearch_AddRow_Button() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//button[@type='button' and normalize-space()='Add Row']", "mainFrame");
	}

	public void clickAddRowLink_RedesignUI() throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SeleniumHelperClass.click(get_AdvanceSearch_AddRow_Button());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	public void clickApplyButton_RedesignUI() throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SeleniumHelperClass.click(get_AdvanceSearch_Apply_Button());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	public WebElement get_AdvanceSearch_SliderSelectButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//button[@type='button' and text()='Select']", "mainFrame");
	}

	public String returnAdvanceSearchSliderPageInputFieldXpath() throws Exception {
		return "//div[@class='ag-theme-custom ag-grid-select-type-single']//input[@type='text' and contains(@class,'components__StyledInput')]";
	}

	public WebElement getAdvanceSearch_SelectField_DropDown(int index) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("((//*[input[@value='Person']]/ancestor::div[contains(@class,'llGpeB') or contains(@class,'gxhjRj') or contains(@class,'kHPczg')])["+index+"]/div[contains(@class,'form-table-row-cell')])[3]//button[contains(@class,'XDropdownToggle') and not (contains(@class,'disabled')) and span]", "mainFrame");
	}

	public WebElement getAdvanceSearch_SelectFieldValue_DropDown(int index,String labelID) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("((//*[input[@value='Person']]/ancestor::div[contains(@class,'llGpeB') or contains(@class,'gxhjRj') or contains(@class,'kHPczg')])["+index+"]/div[contains(@class,'form-table-row-cell')])[3]//button[contains(@class,'XDropdownToggle') and not (contains(@class,'disabled')) and span]/following-sibling::div[contains(@id,'dropdown-menu-wrapper')]//button[label[@id='"+labelID+"']]", "mainFrame");
	}


	public WebElement getAdvanceSearch_SelectOperator_DropDown(int index) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("((//*[input[@value='Person']]/ancestor::div[contains(@class,'llGpeB') or contains(@class,'gxhjRj') or contains(@class,'kHPczg')])["+index+"]/div[contains(@class,'form-table-row-cell')])[4]//button[contains(@class,'XDropdownToggle') and not (contains(@class,'disabled')) and span]", "mainFrame");
	}

	public WebElement getAdvanceSearch_SelectOperatorValue_DropDown(int index,String labelID) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("((//*[input[@value='Person']]/ancestor::div[contains(@class,'llGpeB') or contains(@class,'gxhjRj') or contains(@class,'kHPczg')])["+index+"]/div[contains(@class,'form-table-row-cell')])[4]//button[contains(@class,'XDropdownToggle') and not (contains(@class,'disabled')) and span]/following-sibling::div[contains(@id,'dropdown-menu-wrapper')]//button[label[@id='"+labelID+"']]", "mainFrame");
	}

	public WebElement get_AdvanceSearch_FieldValue_InputText(String labelID) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//label[@id='"+labelID+"']/parent::span/ancestor::div[contains(@class,'llGpeB') or contains(@class,'gxhjRj') or contains(@class,'kHPczg')]//input[@type='text' and not(@disabled)]", "mainFrame");
	}


	public String getAdvanceSearchPeopleDownloadExpectedFileLocation(String fileName) {
		String path = this.getClass().getClassLoader()
				.getResource("com.xactly.incent.organization/PeopleAdvanceSearchDownloadRedesign/" + fileName).getFile();
		System.out.println("FilePath=" + path);
		logger.info("Actual path is  : " + path);
		if (SetWebDrivers.runningOS.equalsIgnoreCase("Windows")) {
			logger.info("OS in Windows, Fie Path : " + path);
			path = path.substring(1, path.length()).replace("/", "\\");
		}
		logger.info("Upload File location Path returned : " + path);
		return path;
	}

	public WebElement get_AdvanceSearch_Reset_Button() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//button[contains(text(),'Reset')]", "mainFrame");

	}

	public void clickResetButton_RedesignUI() throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SeleniumHelperClass.click(get_AdvanceSearch_Reset_Button());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	public WebElement peopleSearchResultsCount() throws Exception {

		return SeleniumHelperClass.findWebElementbyXpath("//div[contains(@class,'styled-components__BreadCrumbCurrentItem')]", "mainFrame");

	}
	public WebElement getUserEmailText(String userEmail) throws Exception {

		return SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'"+userEmail+"')]", "mainFrame");

	}
	public WebElement getFirstOrLastNameOrEmpIdOrRegionText(String name) throws Exception {

		return SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'"+name+"')]", "mainFrame");

	}

	public void verifySearchResults(HashMap<String ,String> values) throws Exception {
		SoftAssert softAssert = new SoftAssert();

		// Verify the results count displayed in ui.
		String count = values.get("Count");
		String ActualCount=peopleSearchResultsCount().getText();
		if(ActualCount.contains(count)){
			logger.info("Search results matched with expected");
			softAssert.assertTrue(true);
		}else {
			logger.info("Search results not matched with expected");
			softAssert.assertTrue(false);
		}

		// Verify FirstName values from Ui displayed value.
		String ExpectedFirstName=values.get("FirstName");
		String actualFirstName=getFirstOrLastNameOrEmpIdOrRegionText(ExpectedFirstName).getText();
		softAssert.assertEquals(actualFirstName,ExpectedFirstName,"firstName value is not matched");


		// Verify LastName values from Ui displayed value.
		String ExpectedLastName=values.get("LastName");
		String actualExpectedLastName=getFirstOrLastNameOrEmpIdOrRegionText(ExpectedLastName).getText();
		softAssert.assertEquals(actualExpectedLastName,ExpectedLastName,"LastName value is not matched");


		// Verify empID values from Ui displayed value.
		String expectedEmpID=values.get("EmployeeID");
		String actualEmpID=getFirstOrLastNameOrEmpIdOrRegionText(expectedEmpID).getText();
		softAssert.assertEquals(actualEmpID,expectedEmpID,"EmpID value is not matched");


		// Verify Region values from Ui displayed value.
		String expectedRegion=values.get("Region");
		String actualRegion=getFirstOrLastNameOrEmpIdOrRegionText(expectedRegion).getText();
		softAssert.assertEquals(actualRegion,expectedRegion,"Region value is not matched");

		// Verify UserEmail values from Ui displayed value.
		String expectedUserEmail=values.get("UserEmail");
		String actualUserEmail=getUserEmailText(expectedUserEmail).getText();
		softAssert.assertEquals(actualUserEmail,expectedUserEmail,"UserEmail value is not matched");

		softAssert.assertAll();



	}


	// To select from any slider like User
	public void selectFromBusinessGroupSlider(String sliderXpath, String searchFieldXpath, String searchString, String frame)
			throws Exception {
		try {
			waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
			SeleniumHelperClass.findWebElementbyXpath(sliderXpath, frame).click();
			waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
			logger.info("Switched to slider page");
			waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
			WebElement nameTextField = SeleniumHelperClass.findWebElementbyXpath(returnSliderPageInputFieldXpath());
			SeleniumHelperClass.clearElement(nameTextField);
			nameTextField.sendKeys(searchString);
			WebElement searchButton = getSliderPageSearchIcon();
			SeleniumHelperClass.isClickable(searchButton, 10);
			searchButton.click();
			waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
			WebElement table = getSliderPageTable();
			clickFirstRowOfTable_Redesign(table);
			SeleniumHelperClass.click(getSliderPageSelectButton());
		} catch (Exception e) {
			throw new Exception(e);
		}
	}



}