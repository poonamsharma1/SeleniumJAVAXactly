package com.xactly.incent.organization;

import java.math.BigDecimal;
import java.net.URL;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import org.apache.axis.client.Stub;
import org.apache.log4j.Logger;
import org.testng.asserts.SoftAssert;

import com.xactly.icm.xtoolkit.service.DiscoveryServiceSoapBindingStub;
import com.xactly.icm.xtoolkit.service.XService;
import com.xactly.icm.xtoolkit.service.XServiceServiceLocator;
import com.xactly.icm.xtoolkit.wso.BusinessGroupWSO;
import com.xactly.icm.xtoolkit.wso.DeleteResponse;
import com.xactly.icm.xtoolkit.wso.ErrorCode;
import com.xactly.icm.xtoolkit.wso.LoginResponse;
import com.xactly.icm.xtoolkit.wso.XObject;
import com.xactly.xcommons.app.LoginToApplication;
import com.xactly.icm.xtoolkit.wso.SearchResponse;
import com.xactly.icm.xtoolkit.wso.TitleWSO;
import com.xactly.icm.xtoolkit.wso.UnitTypeWSO;
import com.xactly.icm.xtoolkit.wso.UserWSO;
import com.xactly.icm.xtoolkit.wso.VersionReasonTypeWSO;
import com.xactly.icm.xtoolkit.wso.VersionReasonTypeWSOArea;
import com.xactly.icm.xtoolkit.wso.PersonWSO;
import com.xactly.icm.xtoolkit.wso.PositionWSO;
import com.xactly.icm.xtoolkit.wso.ReasonCodeWSO;
import com.xactly.icm.xtoolkit.wso.SaveResponse;

public class PositionsAPI {
	public static Logger logger = Logger.getLogger(PositionsAPI.class.getName());
	SoftAssert sassert = new SoftAssert();

	public boolean createPosition(String username, String password, String DISCOVERY_SERVICE_URL,String positionName, String title, String bizGroup) throws Exception{
		
		logger.info("Logging in using wsdl URL: "+DISCOVERY_SERVICE_URL);
		XService service = new XServiceServiceLocator().getDiscoveryService(new URL(DISCOVERY_SERVICE_URL));
		((DiscoveryServiceSoapBindingStub) service).setMaintainSession(true);
		LoginResponse response = service.login(username,password, "Incent");
		logger.info("isAuthenticated :" + response.isAuthenticated());
		logger.info("getSessionId :" + response.getSessionId());
		boolean loginStatus=false;
		boolean saveResp = true;
		
		if (!response.isAuthenticated()) {
			logger.info("Login failed");
			sassert.assertEquals(loginStatus, true, "Toolkit login has failed");
		} else {
			loginStatus = true;
			sassert.assertTrue(loginStatus, "Toolkit login assertion failed");
			logger.info("Login successful by user "+username);
			((DiscoveryServiceSoapBindingStub) service).clearHeaders();
			String sessionId = response.getSessionId();
			String serverUrl = response.getServerUrl();
			logger.info("serverUrl :" + response.getServerUrl());
			((DiscoveryServiceSoapBindingStub) service)._setProperty(Stub.ENDPOINT_ADDRESS_PROPERTY, serverUrl);
			((DiscoveryServiceSoapBindingStub) service)
					.setHeader(new XServiceServiceLocator().getServiceName().getNamespaceURI(), "SessionId", sessionId);
			((DiscoveryServiceSoapBindingStub) service).setHeader(
					new XServiceServiceLocator().getServiceName().getNamespaceURI(), "UserName", username);
		}
		
		PositionWSO positionWSO = new  PositionWSO();
        TitleWSO titleWSO = new TitleWSO();
        titleWSO.setName(title);
		SearchResponse searchResponse = service.search(titleWSO);
	    XObject[] srXObjs = searchResponse.getSearchRecords();
        if ( srXObjs != null && srXObjs.length >= 0){
        	titleWSO = (TitleWSO)srXObjs[0];
        	logger.info("TitleID:"+titleWSO.getId() + "\n");
        	positionWSO.setTitle(titleWSO.getId());
        } else
        {
			logger.info("Could not find Title: "+titleWSO.getName() + "\n");
		}
        BusinessGroupWSO businessGroupWSO = new  BusinessGroupWSO();
		businessGroupWSO.setName(bizGroup);
		SearchResponse searchResponse4 = service.search(businessGroupWSO);
		XObject[] srXObjs4 = searchResponse4.getSearchRecords();
	    if ( srXObjs4 != null && srXObjs4.length >= 1){
	    	businessGroupWSO = (BusinessGroupWSO)srXObjs4[0];
	    }
		
	    positionWSO.setName(positionName);
	    positionWSO.setBusinessGroupId(businessGroupWSO.getId());
        positionWSO.setTitle(titleWSO.getId());

	    SaveResponse saveResponse = service.save(positionWSO);
	    logger.info("Service Result: "+saveResponse.isResult());

	    logger.info("Expected response : true\n");
	    if(!saveResponse.isResult()){
	    	saveResp = false;
			ErrorCode[] errorCodes = saveResponse.getErrorCodes();
		    if (errorCodes != null)
		    {
		    	for (int i = 0; i < errorCodes.length; i++) {
		    		logger.info("errorCodes: " + errorCodes[i].getCode() + "\n");
		    		logger.info("errorMsg: " + errorCodes[i].getReason() + "\n");
		    		logger.info("Stack Trace: " + errorCodes[i].getStackTrace() + "\n");
		    	}
		    }
	    }
	 sassert.assertAll();
	 return saveResp;

	}
	public List<Object> searchPosition(String username, String password, String DISCOVERY_SERVICE_URL,String positionName) throws Exception {
		logger.info("Logging in using wsdl URL: "+DISCOVERY_SERVICE_URL);
		XService service = new XServiceServiceLocator().getDiscoveryService(new URL(DISCOVERY_SERVICE_URL));
		((DiscoveryServiceSoapBindingStub) service).setMaintainSession(true);
		LoginResponse response = service.login(username,password, "Incent");
		logger.info("isAuthenticated :" + response.isAuthenticated());
		logger.info("getSessionId :" + response.getSessionId());
		boolean loginStatus=false;
		List<Object> assertions = new ArrayList<Object>();
		boolean searchResp = true;
		String actualPositionName = null;
		if (!response.isAuthenticated()) {
			logger.info("Login failed");
			sassert.assertTrue(loginStatus, "Toolkit login has failed");
		} else {
			loginStatus = true;
			sassert.assertTrue(loginStatus, "Toolkit login assertion failed");
			logger.info("Login successful by user "+username);
			((DiscoveryServiceSoapBindingStub) service).clearHeaders();
			String sessionId = response.getSessionId();
			String serverUrl = response.getServerUrl();
			logger.info("serverUrl :" + response.getServerUrl());
			((DiscoveryServiceSoapBindingStub) service)._setProperty(Stub.ENDPOINT_ADDRESS_PROPERTY, serverUrl);
			((DiscoveryServiceSoapBindingStub) service)
					.setHeader(new XServiceServiceLocator().getServiceName().getNamespaceURI(), "SessionId", sessionId);
			((DiscoveryServiceSoapBindingStub) service).setHeader(
					new XServiceServiceLocator().getServiceName().getNamespaceURI(), "UserName", username);
		}
		
		PositionWSO positionWSO = new  PositionWSO();
		positionWSO.setName(positionName);
		SearchResponse psr = service.search(positionWSO);
		logger.info("Search Response " + psr.isResult());
		assertions.add(searchResp);
		if (psr.getSearchRecords() != null){
			logger.info("Below are the Number of Position objects found =  " + psr.getSearchRecords().length + "\n");
			PositionWSO position = (PositionWSO) psr.getSearchRecords()[0];
			actualPositionName= position.getName();
			logger.info("Actual position name: "+actualPositionName);
		}
		assertions.add(psr.getSearchRecords().length);
		assertions.add(actualPositionName);
		return assertions;
	}

	public List<Object> addVersionPosition(String username, String password, String DISCOVERY_SERVICE_URL,String positionName, String effStartDate, String versionDesc) throws Exception{
		
		logger.info("Logging in using wsdl URL: "+DISCOVERY_SERVICE_URL);
		XService service = new XServiceServiceLocator().getDiscoveryService(new URL(DISCOVERY_SERVICE_URL));
		((DiscoveryServiceSoapBindingStub) service).setMaintainSession(true);
		LoginResponse response = service.login(username,password, "Incent");
		logger.info("isAuthenticated :" + response.isAuthenticated());
		logger.info("getSessionId :" + response.getSessionId());
		boolean loginStatus=false;
		boolean saveResp = true;
		List<Object> versionAssertions = new ArrayList<Object>(10);

		if (!response.isAuthenticated()) {
			logger.info("Login failed");
			sassert.assertEquals(loginStatus, true, "Toolkit login has failed");
		} else {
			loginStatus = true;
			sassert.assertTrue(loginStatus, "Toolkit login assertion failed");
			logger.info("Login successful by user "+username);
			((DiscoveryServiceSoapBindingStub) service).clearHeaders();
			String sessionId = response.getSessionId();
			String serverUrl = response.getServerUrl();
			logger.info("serverUrl :" + response.getServerUrl());
			((DiscoveryServiceSoapBindingStub) service)._setProperty(Stub.ENDPOINT_ADDRESS_PROPERTY, serverUrl);
			((DiscoveryServiceSoapBindingStub) service)
					.setHeader(new XServiceServiceLocator().getServiceName().getNamespaceURI(), "SessionId", sessionId);
			((DiscoveryServiceSoapBindingStub) service).setHeader(
					new XServiceServiceLocator().getServiceName().getNamespaceURI(), "UserName", username);
		}
		SaveResponse saveResponse = null;
		SearchResponse sr = null;
		XObject[] srecords = null;
		
		java.util.Date effectiveStartDate = new java.util.Date();
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MM/dd/yyyy");
		try {
			effectiveStartDate = sdf.parse(effStartDate);
		}catch(java.text.ParseException p) {
			logger.info("Exception received while parsing the date: "+p.toString()+ "\n");
		}
		Calendar effectiveStartcalender = new GregorianCalendar();
		effectiveStartcalender.setTime(effectiveStartDate);
		// Add a Position version
		PositionWSO positionV1 = new PositionWSO();
		positionV1.setName(positionName);
		positionV1.setDescription(versionDesc);
		saveResponse = service.addVersion(positionV1, effectiveStartcalender);
		logger.info("Expected response : true\n");
		if(!saveResponse.isResult())
		{
			saveResp=false;
			ErrorCode[] errorCodes = saveResponse.getErrorCodes();
			if (errorCodes != null)
			{
				for (int i = 0; i < errorCodes.length; i++) {
				logger.info("errorCodes: " + errorCodes[i].getCode() + "\n");
				logger.info("errorMsg: " + errorCodes[i].getReason()+ "\n");
				logger.info("Stack Trace: " + errorCodes[i].getStackTrace()+ "\n");
				}
			}

		}
		PositionWSO positionWSO = new  PositionWSO();
		positionWSO.setName(positionName);
		SearchResponse psr = service.search(positionWSO);
		logger.info("Search Response " + psr.isResult());
		logger.info("Below are the Number of Position version objects found =  " + psr.getSearchRecords().length + "\n");
		//Get version details newly created
		PositionWSO posVersion = (PositionWSO) psr.getSearchRecords()[1];
		String posName = posVersion.getName();
		Calendar date = posVersion.getEffectiveStartDate();
		Calendar calender = new GregorianCalendar();
		java.text.SimpleDateFormat fmt = new java.text.SimpleDateFormat("MM/dd/yyyy");
	    fmt.setCalendar(calender);
	    String dateFormatted = fmt.format(calender.getTime());
		logger.info("Start date: "+dateFormatted);
		versionAssertions.add(saveResp);
		versionAssertions.add(psr.getSearchRecords().length);
		versionAssertions.add(posName);
		versionAssertions.add(dateFormatted);
		return versionAssertions;
		
	}
	
}
