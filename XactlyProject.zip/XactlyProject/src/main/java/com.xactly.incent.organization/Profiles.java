package com.xactly.incent.organization;

import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.xactly.xcommons.selenium.DBConnections;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

/*
 * @Author: Ami Rajdev 
 */

public class Profiles {
	public static Logger logger = Logger.getLogger(Profiles.class.getName());

	public Profiles(boolean profilesNavigation) throws Exception {
		new Organization("gui-new");
		SeleniumHelperClass.isVisible(getProfilesTablink(), 120);
		SeleniumHelperClass.click(getProfilesTablink());
		SeleniumHelperClass.isVisible(getProfilesSearchInputbox(), 120);
	}
	
	public Profiles() {
	}

	// To get Profiles Tab link under Organization Tab
	public WebElement getProfilesTablink() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("ORGANIZATION_NAV-ORGANIZATION_PROFILES", "topFrame"));
	}

	// To get search input box of profiles list page
	public WebElement getProfilesSearchInputbox() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='tableWrapper']/div[1]/div[1]/input", "mainframe"));
	}

	// To get search button of profiles list page
	public WebElement getSearchButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@class='externalFilter']//*[name()='svg' and @title='search']", "mainframe"));
	}

	// To get searched row from Ag grid list table
	public WebElement getSearchedRowFromAgGridList(String searchedRowText) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[contains(@class,'ag-center-cols-container')]//div[contains(text(),\"" + searchedRowText + "\")]",
				"mainframe"));
	}

	// To get Period picker within profiles page
	public WebElement getMonthPicker() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='top-section']/div[2]/div[2]/div[1]/span/div/button",
				"mainframe"));
	}

	// To select current&Prior or Future section under period picker
	public WebElement getCurrentOrFutureSection(String currentOrFuture) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[text()='" + currentOrFuture + "']", "mainframe"));
	}

	// To select period from period picker of profiles page
	public WebElement selectPeriod(String period) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[@value='" + period + "']", "mainframe"));
	}

	// To get the date picker of profiles page
	public WebElement getDatePicker() throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//*[@id='top-section']//div[contains(@class,'DatePickerWrapper')]//button"));
	}

	// To select date from date picker
	public WebElement selectDay(String date) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[2][contains(@class,'CalendarMonthGrid')]//table/tbody/tr/td[contains(@aria-label,'" + date
						+ "')]"));
	}

	// To get Edit Position Drop down
	public WebElement getPositionEditDropDown() throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//*[@id='position-container']//div[contains(@class,'dropdown')]"));
	}

	// To get Edit Position Drop down menu items
	public List<WebElement> getPositionEditDropDownMenuItems() throws Exception {
		SeleniumHelperClass.click(getPositionEditDropDown());
		return (SeleniumHelperClass.findWebElementsInXpath(
				"//*[@id='position-container']//div[contains(@class,'dropdown-menu')]/button", "mainframe"));
	}

	// To get Edit Position or Change Position Item from drop down
	public WebElement getEditOrChangePosition(String editOrChangePosition) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//button[text()='" + editOrChangePosition + "' and contains(@class,'dropdown-item')]"));
	}

	// To get Slide Out header
	public WebElement getSlideOutPanelHeader() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'XSlidePanelContainer')]//h4[contains(@class,'modal-title')]"));
	}

	// To get SeeAllFields link of any card
	public WebElement getSeeAllFields(String sectionName) throws Exception {
		return SeleniumHelperClass
				.findWebElementbyXpath("//*[@id='" + sectionName + "']//button[text()='See All Fields']");
	}

	// To get the Change Position Form Header in change position slide out
	public WebElement getChangePositionFormHeader() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='change-position-form']/div[2]/label"));
	}

	// To get the Change Position Form Sub Header in change position slide out
	public WebElement getChangePositionFormSubHeader() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='change-position-form']/div[3]/div[1]"));
	}

	// To get labels of Create New and Choose Existing Position Radio buttons in
	// change position slide out
	public List<WebElement> getNewPositionRadioButtonLabels() throws Exception {
		return (SeleniumHelperClass
				.findWebElementsInXpath("//input[@id='newPositionRadioButton']/following-sibling::label", "mainframe"));
	}

	// To get Create New Position Radio Button in change position slide out
	public WebElement getCreateNewPositionRadioButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//input[@value='createNewPosition']"));
	}

	// To get Choose Existing Position Radio Button in change position slide out
	public WebElement getChooseExistingPositionRadioButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//input[@value='chooseExistingPosition']"));
	}

	// To get Version Info label in change position slide out
	public WebElement getVersionInfoLabel() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='change-position-form']/div[4]/div/div[1]/span"));
	}

	// To get Position Info label in change position slide out
	public WebElement getPositionInfoLabel() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='change-position-form']/div[6]/div[1]/div/span"));
	}

	// To get all the form element labels in change position slide out
	public WebElement getLabelsOfChangePositionFormElements(String elementId) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='" + elementId + "']/span"));
	}

	// To get Optional labels of Non mandatory Fields in change position slide out
	public WebElement getOptionalLabelOfNonMandaoryFields(String elementId) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='" + elementId + "']/span[2]"));
	}

	// To get PlaceHolder/DefaultSelectedValue of Date Picker Fields in change
	// position slide out
	public WebElement getPlaceHolderOfDatePickerFields(String elementId) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='" + elementId + "']/following-sibling::div//span"));
	}

	// To get PlaceHolder of Drop Down Fields in change position slide out
	public WebElement getPlaceHolderOfDropDownFields(String elementId) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='" + elementId + "']/following-sibling::div//div"));
	}

	// To get End Of Time label under Effective End Date Field in change position
	// slide out
	public WebElement getEndOfTimeLabel() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='End of Time_label']"));
	}

	// To get Close button of Slide Out Modal
	public WebElement getCloseButtonOfSlideOut() throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//div[contains(@class,'modal-content')]//button[contains(@data-testid,'close-button')]"));
	}

	// To get Cancel(Secondary button of slide-out) button of Slide Out Modal
	public WebElement getCancelButtonOfSlideOut() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'XSlidePanelFooter')]//button[contains(@class,'btn-secondary')]"));
	}
	
	// To get Save(Primary button of slide-out) button of Slide Out Modal
	public WebElement getSaveButtonOfSlideOut() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'XSlidePanelFooter')]//button[contains(@class,'btn-primary')]"));
	}

	// To get cancel/continue button of Unsaved Changes Modal
	public WebElement getButtonsOfUnsavedModal(String option) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'styled-components')]//button[contains(text(),'" + option + "')]"));
	}

	// To get Effective End Date Toggle (Set A Date/Set to End of Time) in change
	// position slide out
	public WebElement getEffectiveEndDateToggle() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='Effective End Date']/following-sibling::button"));
	}

	// To get Date Picker from slide out
	public WebElement getDatePickerFromSlideOut(String datePickerElementLabel) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='" + datePickerElementLabel
				+ "']/following-sibling::div//div[contains(@class,'DatePicker')]/button"));
	}

	// To get list of Date Picker from slide out
	public List<WebElement> getListOfDatePickerFromSlideOut(String datePickerElementLabel) throws Exception {
		return (SeleniumHelperClass.findWebElementsInXpath("//*[@id='" + datePickerElementLabel
				+ "']/following-sibling::div//div[contains(@class,'DatePicker')]/button", "mainframe"));
	}

	// To get Card Header from Profiles page
	public WebElement getCardHeader(String cardContainer) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[@id='" + cardContainer + "']//div[contains(@class,'profile-card-header')]"));
	}

	// To get modal dialog header
	public WebElement getModalDialogHeader() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'modal-dialog modal-lg')]//h4[contains(@class,'modal-title')]"));
	}

	// To get modal dialog headertext
	public WebElement getModalDialogHeaderText() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'modal-dialog modal-lg')]//following-sibling::div[contains(@class,'modal-body')]"));
	}

	// To get TextArea under slide-out
	public WebElement getTextArea(String fieldName) throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//div[contains(@id,'" + fieldName + "')]/following-sibling::div//textarea"));
	}
	
	// To get InputBox under slide-out
	public WebElement getInputBox(String fieldName) throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//div[contains(@id,'" + fieldName + "')]/following-sibling::div//input"));
	}
	
	// To get list of Reset Date Button of Date Picker Fields
	public List<WebElement> getListOfResetDateButton(String datePickerFieldName) throws Exception {
		return (SeleniumHelperClass.findWebElementsInXpath(
				"//*[@id='" + datePickerFieldName
						+ "']/following-sibling::div//*[name()='svg' and contains(@class,'reset-date-btn')]",
				"mainframe"));
	}

	// To get Choose Existing Position radio button under change position slide-out
	public WebElement getChooseExistingPosition() throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//input[@value='chooseExistingPosition']/following-sibling::label"));
	}
	// To get Create New Position radio button under change position slide-out
		public WebElement getCreateNewPosition() throws Exception {
			return (SeleniumHelperClass
					.findWebElementbyXpath("//input[@value='createNewPosition']/following-sibling::label"));
		}

	// To get parent column element of given field in slide out
	public WebElement getParentColumnElement(String fieldName) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='" + fieldName + "']/parent::div/parent::div"));
	}

	// To get parent row element of given field in slide out
	public WebElement getParentRowElement(String fieldName) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[@id='" + fieldName + "']/parent::div/parent::div/parent::div[contains(@class,'row')]"));
	}

	// To get Drop Down button
	public WebElement getDropDown(String dropDownField) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@id,'" + dropDownField + "')]/following-sibling::div//*[name()='svg']");
	}

	// To get Position Modal Header
	public WebElement getPositionModalHeader() throws Exception {
		return SeleniumHelperClass
				.findWebElementbyXpath("//div[contains(@id,'posModal')]//h4[contains(@class,'modal-title')]");
	}

	// To get AG-grid Table Header
	public WebElement getAgGridTableHeader() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='myGrid']//div[contains(@class,'title')]");
	}

	// To get AG-grid Table Column Headers
	public List<WebElement> getAgGridTableColumnHeaders() throws Exception {
		return SeleniumHelperClass.findWebElementsInXpath("//div[contains(@class,'ag-header-cell-label')]",
				"mainframe");
	}
	
	// To get AG-grid Table Rows
	public List<WebElement> getAgGridTableRows() throws Exception {
		return SeleniumHelperClass.findWebElementsInXpath(
				"//*[contains(@class,'ag-center-cols-container')]/div[contains(@class,'ag-row')]", "mainframe");
	}
	
	// To get AG-grid Table Cell Values based on Row index
	public List<WebElement> getAgGridTableCells(int rowIndex) throws Exception {
		return SeleniumHelperClass.findWebElementsInXpath(
				"//*[contains(@class,'ag-center-cols-container')]/div[@row-index=" + rowIndex + "]/div", "mainframe");
	}
	
	// To get AG-grid Table inline Edit button based on Row index
	public WebElement getAgGridTableInlineEditButton(int rowIndex) throws Exception {
		return SeleniumHelperClass
				.findWebElementbyXpath("//*[contains(@class,'ag-pinned-right-cols-container')]/div[@row-index="
						+ rowIndex + "]//*[name()='svg']");
	}
	
	// To get AG-grid Table inline Save button based on Row index
	public WebElement getAgGridTableInlineSaveButton(int rowIndex) throws Exception {
		return SeleniumHelperClass
				.findWebElementbyXpath("//*[contains(@class,'ag-pinned-right-cols-container')]/div[@row-index="
						+ rowIndex + "]//*[name()='svg'][2]");
	}
		
	// To get Modal Dialog Cancel button
	public WebElement getCancelButtonOfModalDialog() throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//div[contains(@class,'modal-footer')]//button[contains(@class,'btn-link')]"));
	}

	// To get Position Modal Dialog Select button
	public WebElement getSelectButtonOfPositionModal() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@id='posModal']//div[contains(@class,'modal-footer')]//button[contains(@class,'btn-primary')]"));
	}

	// To get Position Modal Dialog Close button
	public WebElement getCloseButtonOfPositionModal() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='posModal']//span[contains(@class,'CloseIcon')]"));
	}

	// To get Add Position Button of Position Card
		public WebElement getAddPositionButton() throws Exception {
			SeleniumHelperClass.moveToElement(SeleniumHelperClass.findWebElementbyXpath(
					"//*[@id='position-container']//div[contains(@class,'profile-card-header-title')]"));
			return SeleniumHelperClass.findWebElementbyXpath("//button[contains(@title,'Add Position')]");
		}

	// To get Inline validation Message of given field
	public WebElement getInlineValidation(String fieldName) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@id,'" + fieldName + "')]/following-sibling::div//span[contains(@class,'inMDaS')]"));
	}
	
	// To get Warning message from Modal dialog
	public WebElement getWarningMessage() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@type='warning']//span"));
	}
	
	// To get BGS Error Message From Change Position slide out
	public WebElement getBGSErrorOfChangePosition() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[@id='change-position-form']//div[@type='error']//div[text()='Unable to Save Changes']/following-sibling::div"));
	}
	
	public WebElement getPositionNameFromProfileSummary() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[@id='Position']", "mainframe"));
	}

	public WebElement getTitleFromProfileSummary() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[@id='Title']", "mainframe"));
	}

	public WebElement getPositionBGFromProfileSummary() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[@id='Position Business Group']", "mainframe"));
	}

	public WebElement getPlanNameFromProfileSummary() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[@id='Plan Name']", "mainframe"));
	}

	public WebElement getManagerNameFromProfileSummary() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[@id='Manager']", "mainframe"));
	}

	// To click on calendar
	public WebElement clickDatePickerFromSlideOut(String datePickerElementLabel) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[@id='" + datePickerElementLabel
						+ "']/following-sibling::div//div[contains(@class,'StyledSingleDatePicker')]/button",
				"mainframe"));
	}

	// To click on year menu dropdown in active calendar
	public WebElement yearDropDownFromCalendar() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//div[@data-visible='true' and contains(@class,'CalendarMonth')]//div[contains(@role,'listbox')])[2]",
				"mainframe"));

	}

	// To click on month menu dropdown in active calendar
	public WebElement monthDropDownFromCalendar() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//div[@data-visible='true' and contains(@class,'CalendarMonth')]//div[contains(@role,'listbox')])[1]",
				"mainframe"));

	}

	// To select year value from dropdown
	public WebElement selectYear(String year) throws Exception {
		
		SeleniumHelperClass.click(yearDropDownFromCalendar());
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@data-visible='true' and contains(@class,'CalendarMonth')]//button[@value='" + year + "']",
				"mainframe"));
	}

	// To select month value from dropdown
	public WebElement selectMonth(String month) throws Exception {
		
		SeleniumHelperClass.click(monthDropDownFromCalendar());
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@data-visible='true' and contains(@class,'CalendarMonth')]//button[@value='" + month + "']",
				"mainframe"));
	}

	// To select year value from Effective start date dropdown
	public WebElement selectYearInEffectiveStartDate(String year) throws Exception {

		SeleniumHelperClass.secondaryClick(yearDropDownFromCalendar());
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//div[contains(@id,'dropdown-menu-wrapper')]//button[@value='" + year + "'])[2]", "mainframe"));
	}

	// To select month value from Effective start date dropdown
	public WebElement selectMonthInEffectiveStartDate(String month) throws Exception {

		SeleniumHelperClass.secondaryClick(monthDropDownFromCalendar());
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//div[contains(@id,'dropdown-menu-wrapper')]//button[@value='" + month + "'])[2]", "mainframe"));
	}
	
   // To get copyPreviousPostion button from slideout
   public WebElement getCopyPreviousPositionLink() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='change-position-form']//*[contains(text(),'Copy Previous Position')]","mainframe"));
	}
   
   // To get Tooltip dynamic message
   public WebElement getTooltipMessageHeader() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(@data-testid,'styled-tooltip')]","mainframe"));
	}
  
   // To get Description field on Position Card from Profiles page
   public WebElement getDescriptionInPositionCard() throws Exception {
	   return (SeleniumHelperClass.
			   findWebElementbyXpath("//*[@id='position-container']//following-sibling::div//div//span[contains(text(),'Description')]"));
   }
   
   // To get inline notification on change position slideout
   public WebElement getInlineMessage() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@id='change-position-form']//following-sibling::div//div[contains(@type,'info')]","mainframe"));
	}

	// To get error message when position is not unique
	public WebElement getErrorMessageOnProfileName() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[@id='change-position-form']/div[7]/div[1]/div/div[2]/span"));
	}
	
	// To select Item from Infinite scroll dropdown
	public void selectItemFromInfiniteScrollDropdown(String item) throws Exception {
		SeleniumHelperClass.findWebElementbyXpath("//div[@id='infinite-scroll-dropdown']/button[@value='" + item + "']")
				.click();
	}

	public WebElement getMessageTextWhenNotInHierarchy(String messageText) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//div[text()='"+ messageText +"']","mainframe"));
	}

	public WebElement getNamedRelationshipCardHeader() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//div[text()='Named Relationships']","mainframe"));
	}

	public WebElement getAddNamedRelationShipButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//button[@title='Add Named Relationships']","mainframe"));
	}

	public WebElement getCloseButtonInSlideOut() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//button[@type='button' and contains(text(), 'Close')]", "mainframe"));
	}

	public WebElement getPendoIconImage() throws Exception {
		SetWebDrivers.getDriver().switchTo().defaultContent();
		return (SeleniumHelperClass.findWebElementbyXpath(".//img[contains(@id,'pendo-image-badge')]"));
	}

	public WebElement getEditIconInSeeAllFieldsSlideOut() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//span[text()='See All Fields']//following-sibling::button","mainframe"));
	}

	public WebElement getSaveButtonInEditAllFieldsSlideOut() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='edit-slide-panel']//descendant::button[text()='Save']","mainframe"));
	}

	public WebElement getCancelButtonInEditAllFieldsSlideOut() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='edit-slide-panel']//descendant::button[text()='Cancel']","mainframe"));
	}
	
	public WebElement getAddColumnInProfilesList() throws Exception{
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='Add Columns_label']","mainframe"));
	}
	
	public WebElement getPersonCustomFieldCheckboxInList() throws Exception{
		return (SeleniumHelperClass.findWebElementbyXpath("//ol[@data-testid='person']/li/div/button/button[@type='button']","mainframe"));
	}
	
	

	public List<WebElement> getPersonCustomFileds() throws Exception{
		return (SeleniumHelperClass.findWebElementsInXpath(
				"//ol[@data-testid='customFields']/li", "mainframe"));
	}
	
	// To get ClockIcon button(Version History) of any card
	public WebElement getVersionHistoryButton(String sectionName) throws Exception {
		return SeleniumHelperClass
				.findWebElementbyXpath("//*[@id='" + sectionName + "']//button[contains(@id,'disableCardEdit')]");
	}
	
	// To get Toaster message from slide out
	public WebElement getToasterMessage() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//div[contains(@class,'ToastMessage')]");
	}

	/**
	 * To search and select profile using EmployeeId
	 * 
	 * @param employeeId
	 * @throws Exception
	 */
	public void selectProfile(String employeeId) throws Exception {
		SeleniumHelperClass.waitforPageToLoad("class", "ag-header-container", "mainframe");
		WebElement searchBox = getProfilesSearchInputbox();
		SeleniumHelperClass.click(searchBox);
		SeleniumHelperClass.clearElement(searchBox);
		searchBox.sendKeys(employeeId);
		SeleniumHelperClass.click(getSearchButton());
		SeleniumHelperClass.waitForElmentToBeReady(getSearchedRowFromAgGridList(employeeId));
		SeleniumHelperClass.click(getSearchedRowFromAgGridList(employeeId));
		SeleniumHelperClass.waitforPageToLoad("xpath",
				"//span[@id='Employee ID' and contains(text(),'" + employeeId + "')]", "mainframe");
	}

	/**
	 * To select month and date in profiles page
	 * 
	 * @param currentOrFuture
	 * @param period
	 * @param date
	 * @throws Exception
	 */
	public void selectDate(String currentOrFuture, String period, String date) throws Exception {

		SeleniumHelperClass.click(getMonthPicker());
		SeleniumHelperClass.click(getCurrentOrFutureSection(currentOrFuture));
		SeleniumHelperClass.click(selectPeriod(period));
		SeleniumHelperClass.click(getDatePicker());
		SeleniumHelperClass.click(selectDay(date));
	}

	/**
	 * To select Edit Position or Change Position option from Drop down Menu
	 * 
	 * @param editOrChangePosition
	 * @throws Exception
	 */
	public void selectEditOrChangePosition(String editOrChangePosition) throws Exception {
		SeleniumHelperClass.click(getPositionEditDropDown());
		SeleniumHelperClass.click(getEditOrChangePosition(editOrChangePosition));
	}

	/**
	 * To search and select Position/Title from Select Position/Title Modal
	 * 
	 * @param positionNameOrTitle
	 * @throws Exception
	 */
	public void selectPositionOrTitle(String positionNameOrTitle) throws Exception {
		SeleniumHelperClass.waitforPageToLoad("class", "ag-header-container", "mainframe");
		WebElement searchBox = getProfilesSearchInputbox();
		SeleniumHelperClass.click(searchBox);
		SeleniumHelperClass.clearElement(searchBox);
		searchBox.sendKeys(positionNameOrTitle);
		SeleniumHelperClass.click(getSearchButton());
		SeleniumHelperClass.waitForElmentToBeReady(getSearchedRowFromAgGridList(positionNameOrTitle));
		SeleniumHelperClass.click(getSearchedRowFromAgGridList(positionNameOrTitle));
		getSelectButtonOfPositionModal().click();
		SeleniumHelperClass.waitforPageToLoad("xpath", "//*[@id='change-position-form']/div[2]/label", "mainframe");
	}

	/**
	 * To get the Business ID from the database
	 * 
	 * @param email
	 * @param db
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws InterruptedException
	 */
	public String getbusinessIDfromDB(String email, DBConnections db)
			throws ClassNotFoundException, SQLException, InterruptedException {
		String result = db.connect_Db_string("select Business_ID from XC_USER where EMAIL like '" + email + "'",
				"BUSINESS_ID");
		logger.info(result);
		return result;
	}

	/**
	 * To get the total Position count of business from the database
	 * 
	 * @param email
	 * @param db
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 * @throws InterruptedException
	 */
	public String getTotalPositionCount(DBConnections db, String businessId)
			throws ClassNotFoundException, SQLException, InterruptedException {
		String result = db.connect_Db_withoutColumnName(
				"select count(DISTINCT MASTER_POSITION_ID) from XC_POSITION where BUSINESS_ID=" + businessId);
		result = result.replaceAll("\\[", "").replaceAll("\\]", "");
		logger.info("Total Position Count: " + result);
		return result;
	}

	/**
	 * To select Calendar date from date picker
	 * 
	 * @param datePickerElementLabel
	 * @param year
	 * @param month
	 * @param date
	 * @throws Exception
	 */
	public void selectFromDatePicker(String datePickerElementLabel, String month, String year, String calendarDate)
			throws Exception {

		SeleniumHelperClass.click(clickDatePickerFromSlideOut(datePickerElementLabel));
		SeleniumHelperClass.click(selectMonth(month));
		SeleniumHelperClass.click(selectYear(year));
		SeleniumHelperClass.click(selectDay(calendarDate));
	}
   
	/**
	 * Select date from Effective Start Date Dropdown
	 * 
	 * @param datePickerElementLabel
	 * @param month
	 * @param year
	 * @param calendarDate
	 * @throws Exception
	 */
	public void selectEffectiveStartDate(String datePickerElementLabel, String month, String year, String calendarDate)
			throws Exception {
		//SeleniumHelperClass.secondaryClick(getAddPositionButton());
		SeleniumHelperClass.secondaryClick(clickDatePickerFromSlideOut(datePickerElementLabel));
		SeleniumHelperClass.secondaryClick(selectMonthInEffectiveStartDate(month));
		SeleniumHelperClass.secondaryClick(selectYearInEffectiveStartDate(year));
		SeleniumHelperClass.secondaryClick(selectDay(calendarDate));

	}

	/**
	 * To fetch dynamic Tooltip message from copy Previous Position button
	 */
   
   public String getToolTipMessage() throws Exception {
	   
	  Actions actions = new Actions(SetWebDrivers.getDriver());
	  actions.moveToElement(getCopyPreviousPositionLink()).perform();
      String toolTipText = getTooltipMessageHeader().getText();
      return toolTipText;
		
		}
   /**
	 * To fetch dynamic Tooltip message from Datepickers
	 */
  
  public String getToolTipMessageFromDatePicker(String datePickerElementLabel,String month, String year,String calendarDate) throws Exception {
	  
	    SeleniumHelperClass.click(clickDatePickerFromSlideOut(datePickerElementLabel));
	    SeleniumHelperClass.click(selectMonth(month));
		SeleniumHelperClass.click(selectYear(year));
	    Actions actions = new Actions(SetWebDrivers.getDriver());
	    actions.moveToElement(selectDay(calendarDate)).perform();
        String toolTipText = getTooltipMessageHeader().getText();
        return toolTipText;
		
		}

	/**
	 * To navigate to back window browser
	 */
	public void clickOnBackHistoryPage() throws Exception {

		SeleniumHelperClass.clickOnBackButton();
		Thread.sleep(5000);
		SeleniumHelperClass.fetchCurrentFrame();
		SeleniumHelperClass.goToFrame("mainFrame");

	}

	/**
	 * checking copy previous button disabled
	 * 
	 * @return
	 * @throws Exception
	 */
	public boolean isCopyPreviousVersionButtonDisabled() throws Exception {
		boolean disabled = false;
		String buttonValue = getCopyPreviousPositionLink().getAttribute("class");
		if (buttonValue.contains("disabled")) {
			disabled = true;
		}
		return disabled;
	}

   public Boolean checkVersionInfoHeaderLabel() throws Exception {
	   
	  return(SeleniumHelperClass.isElementPresent("xpath", "//*[@id='change-position-form']/div[4]/div/div[2]"));
   
   }
}
