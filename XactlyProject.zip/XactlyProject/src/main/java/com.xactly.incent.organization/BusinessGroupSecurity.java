package com.xactly.incent.organization;

import org.apache.log4j.Logger;
import org.testng.Reporter;
import com.jayway.restassured.response.Response;
import com.xactly.xcommons.restapi.RestAPIHelperClass;

public class BusinessGroupSecurity {
	public static Logger logger = Logger.getLogger(BusinessGroupSecurity.class.getName());
	RestAPIHelperClass rest = new RestAPIHelperClass();
	
	public String checkBusinessGroupSecurity(Response response, String requestid,String positionId) throws Exception{
		logger.info("Checking Business Group Security... ");
		String resp = rest.getHttpRequest(response,"/xicm/ajax.async.do?action=isPositionBGAccessible&positionId="+positionId+"&sessionId="+requestid+"&d=1505208896115"); 
		return resp;	
	}
}
