package com.xactly.incent.organization;

import com.xactly.xcommons.selenium.Constants;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class PositionsRedesign {

	Peoples peoples = new Peoples();
	public static Logger logger = Logger.getLogger(PositionsRedesign.class.getName());

	String row = "//*[@ref='eViewport']//div[@role='rowgroup']//div[@role='row']";

	public WebElement previewPositionTitle() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("modalTitleId", "mainFrame"));
	}

	public WebElement positionDeleteText() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@class='modal-content']//div[contains(@class,'SmodalBody')]", "mainFrame"));
	}

	public WebElement positionDeletePopupCancelBtn() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@class='modal-content']//button[text()='Delete']//parent::div//button[text()='Cancel']",
				"mainFrame"));
	}

	public WebElement positionDeletePopupDeleteBtn() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@class='modal-content']//button[text()='Delete']",
				"mainFrame"));
	}

	public WebElement positionDeletePopupOkBtn() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[text()='ok']", "mainFrame"));
	}

	public WebElement positionDeleteToaster() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='xtoast-container__content']//div", "mainFrame"));
	}

	public WebElement getToasterMessage() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@type='success' and @data-testid='xtoast-wrapper']");
	}

	public WebElement previewPanelWhereUsedTitle() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'Where Used')]", "mainFrame"));
	}

	public WebElement previewPanelDeleteTitle() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[text()='Delete Position']", "mainFrame"));
	}

	public WebElement previewPanelDeleteCloseIcon() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//span[text()='Delete Position']//parent::h4//span[contains(@class,'CloseIcon')]", "mainFrame"));
	}

	public WebElement previewPanelWhereUsedCloseBtn() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//span[contains(text(),'Where Used')]//parent::h4//parent::div//parent::div//div[contains(@class,'modal-footer')]//button",
				"mainFrame"));
	}

	public WebElement previewPositionHeader1() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[text()='Version Info']", "mainFrame"));
	}

	public WebElement previewPositionHeader2() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[text()='Position Info']", "mainFrame"));
	}

	public WebElement listPageVersionFilterOption(String option) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[@value='" + option + "']", "mainFrame"));
	}

	public WebElement listPageVersionFilterDataText() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@class='d-flex align-center']//span[2]", "mainFrame"));
	}

	public WebElement previewEditIcon() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//*[@id='modalTitleId']//parent::h4//div[contains(@class,'IconWrapper')])[1]//*[local-name()='svg']",
				"mainFrame"));
	}

	public WebElement editPageTitle(String name) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='fixed-header']//*[text()='" + name + "']",
				"mainFrame"));
	}

	public WebElement previewThreeDots() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[@id='modalTitleId']//parent::h4//div[@dropdownitemscolor='bareIcon']//child::button[@role='presentation']",
				"mainFrame"));
	}

	public WebElement selectPreviewthreeDotsOption(String option) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@dropdownitemscolor='bareIcon']//button[text()='" + option + "']", "mainFrame"));
	}

	public WebElement sliderCloseBtn() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'XSlidePanelFooter')]//button[text()='Close' ]", "mainFrame"));
	}

	public WebElement previewEffStartDateLabel() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='Effective Start Date']", "mainFrame"));
	}

	public WebElement previewEffStartDateValue() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='Effective Start Date']//parent::div//span",
				"mainFrame"));
	}

	public WebElement previewEffEndDateLabel() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='Effective End Date']", "mainFrame"));
	}

	public WebElement previewEffEndDateValue() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='Effective End Date']//parent::div//span",
				"mainFrame"));
	}

	public WebElement previewDescriptionLabel() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='Description']", "mainFrame"));
	}

	public WebElement previewDescriptionValue() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='Description']//parent::div//span",
				"mainFrame"));
	}

	public WebElement previewPositionNameLabel() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='Position Name']", "mainFrame"));
	}

	public WebElement previewPositionNameValue() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='Position Name']//parent::div//span",
				"mainFrame"));
	}

	public WebElement previewIncentiveStartDateLabel() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='Incentive Start Date']", "mainFrame"));
	}

	public WebElement previewIncentiveStartValue() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='Incentive Start Date']//parent::div//span",
				"mainFrame"));
	}

	public WebElement previewIncentiveEndDateLabel() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='Incentive End Date']", "mainFrame"));
	}

	public WebElement previewIncentiveEndValue() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='Incentive End Date']//parent::div//span",
				"mainFrame"));
	}

	public WebElement previewTitleLabel() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='Title']", "mainFrame"));
	}

	public WebElement previewTitleValue() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='Title']//parent::div//span", "mainFrame"));
	}

	public WebElement previewBGLabel() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='Business Group']", "mainFrame"));
	}

	public WebElement previewBGeValue() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='Business Group']//parent::div//span",
				"mainFrame"));
	}

	public WebElement previewPersonNameLabel() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='Person Name (Latest)']", "mainFrame"));
	}

	public WebElement previewPersonNameValue() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='Person Name (Latest)']//parent::div//span",
				"mainFrame"));
	}

	public WebElement whereUsedTitle() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//label[@for='Business Group']", "mainFrame"));
	}

	public List<WebElement> positionWhereUsedTabs() throws Exception {
		return (SeleniumHelperClass.findWebElementsInXpath(
				"(//*[@id='tabList']//button//span[contains(@class,'SflexContainer')])", "mainFrame"));
	}

	public WebElement whereUsedUIEmpIDCol() throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//div[@col-id='employeeId']//div[@class='ag-header-cell-label']", "mainFrame"));
	}

	public WebElement whereUsedEmpIdColValue() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'row-position')]//child::div[@col-id='employeeId']", "mainFrame"));
	}

	public WebElement whereUsedNameColValueRedesign(int row) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//div[contains(@class,'row-position')]//child::div[@col-id='name'])[" + row + "]", "mainFrame"));
	}

	public WebElement whereUsedStartDateColValueRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'row-position')]//child::div[@col-id='effectiveStartDate']", "mainFrame"));
	}

	public WebElement whereUsedDesColValueRedesign(int row) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//div[contains(@class,'row-position')]//child::div[@col-id='description'])[" + row + "]",
				"mainFrame"));
	}

	public WebElement whereUsedUIQuotaValueCol() throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath("//div[@col-id='quotaValue']//div[@class='ag-header-cell-label']", "mainFrame"));
	}

	public WebElement whereUsedQuotaValueColValue(int row) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//div[contains(@class,'row-position')]//child::div[@col-id='quotaValue'])[" + row + "]",
				"mainFrame"));
	}

	public WebElement whereUsedUIUnitTypeCol() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@col-id='quotaValueUnitTypeName']//div[@class='ag-header-cell-label']", "mainFrame"));
	}

	public WebElement whereUsedUnitTypeColValue(int row) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//div[contains(@class,'row-position')]//child::div[@col-id='quotaValueUnitTypeName'])[" + row + "]",
				"mainFrame"));
	}

	public WebElement whereUsedUIQuotaPeriodCol() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@col-id='quotaPeriod']//div[@class='ag-header-cell-label']", "mainFrame"));
	}

	public WebElement whereUsedQuotaPeriodColValue(int row) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//div[contains(@class,'row-position')]//child::div[@col-id='quotaPeriod'])[" + row + "]",
				"mainFrame"));
	}

	public WebElement whereUsedTab(String tab) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='tabList']//button//span[text()='" + tab + "']",
				"mainFrame"));
	}

	public List<WebElement> listPageRows() throws Exception {
		return (SeleniumHelperClass
				.findWebElementsInXpath("//*[@ref='eViewport']//div[@role='rowgroup']//div[@role='row']", "mainFrame"));
	}

	public WebElement listPageTitle() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@id='moduleRootContainer']//div[@class='d-flex align-center']", "mainFrame"));
	}

	public WebElement listPageTitleCount() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@id='moduleRootContainer']//div[@class='d-flex align-center']//span", "mainFrame"));
	}

	public WebElement listPageUploadBtn() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("(//div[@id='fixed-header']//button)[1]", "mainFrame"));
	}

	public WebElement listPageDownloadBtn() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("(//div[@id='fixed-header']//button)[2]", "mainFrame"));
	}

	public WebElement listPageCreateBtn() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("(//div[@id='fixed-header']//button)[3]", "mainFrame"));
	}

	public WebElement listPageSearchIcon() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[@data-testid='search-icon']//*[local-name()='svg']",
				"mainFrame"));
	}

	public WebElement listPageSearchTextBox() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='positionsGrid_search_tooltip']//input",
				"mainFrame"));
	}

	public WebElement listPageVersionFilter() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[text()='Version:']", "mainFrame"));
	}

	public WebElement listPageVersionDropDown() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[@data-toggle='dropdown']", "mainFrame"));
	}

	public WebElement listPagePositionNameSortIcon() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[text()='Position Name']//parent::div//span[@class='header-sort-icon']", "mainFrame"));
	}

	public WebElement listPagePositionCol() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@col-id='positionName']//div[@class='ag-header-cell-label']", "mainFrame"));
	}

	public WebElement listPageTitleCol() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@col-id='title']//div[@class='ag-header-cell-label']",
				"mainFrame"));
	}

	public WebElement listPagePersonNameCol() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@col-id='effectivePersonName']//div[@class='ag-header-cell-label']", "mainFrame"));
	}

	public WebElement listPageBGCol() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@col-id='businessGroup']//div[@class='ag-header-cell-label']", "mainFrame"));
	}

	public WebElement listPagePositionColValue() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[@ref='eViewport']//div[@role='rowgroup']//div[@role='row']//div[@col-id='positionName']//span",
				"mainFrame"));
	}

	public WebElement listPageTitleColValue() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[@ref='eViewport']//div[@role='rowgroup']//div[@role='row']//div[@col-id='title']//span",
				"mainFrame"));
	}

	public WebElement listPagePersonNameColValue() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[@ref='eViewport']//div[@role='rowgroup']//div[@role='row']//div[@col-id='effectivePersonName']//span",
				"mainFrame"));
	}

	public WebElement listPageBGColValue() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[@ref='eViewport']//div[@role='rowgroup']//div[@role='row']//div[@col-id='businessGroup']//span",
				"mainFrame"));
	}

	public List<WebElement> getColumnData_PositionListPage(String columnId) throws Exception {
		return (SeleniumHelperClass.findWebElementsInXpath(
				"//div[@col-id='" + columnId + "']//span[contains(@class,'cell-text')]", "mainFrame"));
	}

	public WebElement getColumnHeaderSortIcon_PositionListPage(String coloumnId) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@col-id='" + coloumnId + "' and @role='columnheader']",
				"mainFrame"));
	}

	public WebElement listPageNoDataSubText() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[contains(@style,'word-break')]", "mainFrame"));
	}

	public WebElement listPageCancelSearch() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@data-testid='cancel-icon']//*[local-name()='svg']",
				"mainFrame"));
	}

	public WebElement cancelPositionEditPage() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='editPage']//button[text()='Cancel']", "mainFrame"));
	}

	public WebElement createPositionButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[contains(.,'Create')]", "mainFrame"));
	}

	public WebElement positionNameInputField() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//input[@ id='positionName']", "mainFrame"));
	}

	public WebElement positionDescriptionInputField() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//textarea[@ id='positionDescription']", "mainFrame"));
	}

	public WebElement selectTitleButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[contains(.,'Select Title')]", "mainFrame"));
	}

	public WebElement searchTitleInputField() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//span[@data-testid='search-icon']/parent::div/following-sibling::input", "mainFrame"));
	}

	public WebElement getSliderPageSearchIcon() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[contains(@class,'GroupAddonSearch')]", "mainFrame"));
	}

	public WebElement getSliderPageTable() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@ref='eContainer' and @role='rowgroup']"));
	}

	public WebElement getPositionListPageDownloadButton_NewUI() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//button[text()='Download']", "mainFrame");
	}

	public WebElement getAllVersionsNewUI() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@id='versions' and @value='ALL']", "mainFrame");
	}

	public WebElement getLatestVersionsToDownloadPositionsRedesign() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//label[text()='Latest Versions']", "mainFrame");
	}

	public WebElement getLatestVersionsNewUI() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//input[@id='versions' and @value='LATEST']", "mainFrame");
	}

	public WebElement getDownloadFormatDropdownMenuItem(String formatValue) throws Exception {
		String xpath = "//div[text()='Download Format']/following-sibling::div//div[contains(@class,'dropdown-menu')]/button[@Value='VALUE']";
		return SeleniumHelperClass.findWebElementbyXpath(xpath.replace("VALUE", formatValue), "mainFrame");
	}

	public WebElement getDownloadButtonRedesign() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//button[contains(text(),'Download')]", "mainFrame");
	}

	public WebElement positionDatePicker(String datePickerElementLabel) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[contains(@for,'" + datePickerElementLabel
						+ "')]/following-sibling::span/div//div[contains(@class,'StyledSingleDatePicker')]/button",
				"mainframe"));
	}

	public String returnTitleInput() throws Exception {
		return "//button[contains(.,'Select Title')]";
	}

	public String returnPositionInput() throws Exception {
		return "//button [contains(.,'Select Person Name')]";
	}

	public WebElement clickDatePickerFromSlideOutPeopleRedesign(String datePickerElementLabel) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[contains(@for,'" + datePickerElementLabel
						+ "')]/following-sibling::span/div//div[contains(@class,'StyledSingleDatePicker')]/button",
				"mainframe"));
	}

	public WebElement monthDropDownFromCalendar() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//div[@data-visible='true' and contains(@class,'CalendarMonth')]//div[contains(@role,'listbox')])[1]",
				"mainframe"));

	}

	public WebElement selectMonth(String month) throws Exception {

		SeleniumHelperClass.click(monthDropDownFromCalendar());
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@data-visible='true' and contains(@class,'CalendarMonth')]//button[@value='" + month + "']",
				"mainframe"));
	}

	public WebElement sliderSearchIcon() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("(//*[contains(@class,'GroupAddonSearch')])[2]",
				"mainFrame"));
	}

	public WebElement listPageCount() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[text()='Position']//span", "mainFrame"));
	}

	public WebElement clickVersionDropdown() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[text()='Latest']//*[local-name()='svg']",
				"mainFrame"));
	}

	public WebElement selectVersionListPage(String version) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[@value='" + version + "']", "mainFrame"));
	}

	public WebElement clickConditionDropdown() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//label[@id='And']//parent::span//parent::button//*[local-name()='svg']", "mainFrame"));
	}

	public WebElement selectCondition(String condition) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[@id='" + condition + "']//label", "mainFrame"));
	}

	public WebElement getSliderRow(String sliderselectValue) throws Exception {
		String xpath = "//div[@role='gridcell' and text()='" + sliderselectValue + "']";
		return SeleniumHelperClass.findWebElementbyXpath(xpath, "mainFrame");
	}

	public WebElement get_AdvanceSearch_SliderSelectButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//button[@type='button' and text()='Select']", "mainFrame");
	}

	public WebElement sliderSearchCancelIcon() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//span[@data-testid='cancel-icon']//*[local-name()='svg']",
				"mainFrame");
	}

	public WebElement getSliderCheckbox(String slidercheckboxValue) throws Exception {
		String xpath = "//div[@role='row']//div[text()='" + slidercheckboxValue
				+ "']/preceding-sibling::div//input[@type='checkbox']";
		return SeleniumHelperClass.findWebElementbyXpath(xpath, "mainFrame");
	}

	public WebElement getSliderDownloadButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'XSlidePanelFooter')]/button[text()='Download']", "mainFrame");
	}

	public WebElement getDownloadFormatDropdown() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//div[text()='Download Format']/following-sibling::div//button[contains(@class,'DropdownToggle')]",
				"mainFrame");
	}

	public WebElement selectFieldDropdown() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//span[text()='Select Field']//parent::span//parent::button[@data-toggle='dropdown']", "mainframe"));
	}

	public WebElement selectOpratorDropdown() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//span[text()='Select Operator']//parent::span//parent::button[@data-toggle='dropdown']",
				"mainFrame"));
	}

	public WebElement enterValueText(int index) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//div[contains(@class,'InputGroup')]//span//div//input[@placeholder='Select Item'])[" + index + "]",
				"mainFrame"));
	}

	public List<WebElement> enterValueText() throws Exception {
		return (SeleniumHelperClass.findWebElementsInXpath(
				"//div[contains(@class,'InputGroup')]//span//div//input[@placeholder='Select Item']", "mainFrame"));
	}

	public WebElement enterValueTextForContains(int index) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//div[contains(@class,'InputGroup')]//span//input[@placeholder='Select Value'])[" + index + "]",
				"mainFrame"));
	}

	public List<WebElement> enterValueTextForContains() throws Exception {
		return (SeleniumHelperClass.findWebElementsInXpath(
				"//div[contains(@class,'InputGroup')]//span//input[@placeholder='Select Value']", "mainFrame"));
	}

	public WebElement selectDropdownAdvanceSearch(String id, int index) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("(//button[@id='" + id + "'])[" + index + "]", "mainFrame"));
	}

	public WebElement clickSlider3dots(int index) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//div[contains(@class,'InputGroup')]//span//div//input[@placeholder='Select Item']//parent::div//*[local-name()='svg'])["
						+ index + "]",
				"mainFrame"));
	}

	public List<WebElement> clickSlider3dots() throws Exception {
		return (SeleniumHelperClass.findWebElementsInXpath(
				"//div[contains(@class,'InputGroup')]//span//div//input[@placeholder='Select Item']//parent::div//*[local-name()='svg']",
				"mainFrame"));
	}

	public WebElement clickSlider3dotsForIn(int index) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("(//div[@class='floating-icons-wrapper'])[" + index + "]",
				"mainFrame"));
	}

	public List<WebElement> clickSlider3dotsForIn1() throws Exception {
		return (SeleniumHelperClass.findWebElementsInXpath("//div[@class='floating-icons-wrapper']", "mainFrame"));
	}

	public WebElement applyButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[text()='Apply']", "mainFrame"));
	}

	public WebElement sliderSearch() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//div[@class='externalFilter'])[2]//div[contains(@class,'input-group')]//input", "mainFrame"));
	}

	public WebElement addRow() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[text()='Add Row']//*[local-name()='svg']",
				"mainFrame"));
	}

	public WebElement resetAdvanceFilter() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[text()='Reset']", "mainFrame"));
	}

	public WebElement selectValueSlider(String selectValue, int index) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("(//div[text()='" + selectValue + "'])[" + index + "]",
				"mainFrame"));
	}

	public WebElement downloadButton_NewUI() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//button[text()='Download']", "mainFrame");
	}

	public WebElement get_AdvanceSearchFilter_Link() throws Exception {
		return SeleniumHelperClass
				.findWebElementbyXpath("//button[contains(@class,'search-filter-btn btn btn-bareIcon')]", "mainFrame");
	}

	public WebElement getEditPositionPageVersionsButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//button[text()='Versions' and contains(@class,'btn-secondary')])[1]", "mainFrame"));
	}


	private File latestFile;
	public File latestFilefromDir;

	public static void waitInMS(long timeInMS) {
		try {
			Thread.sleep(timeInMS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public String returnSliderPageInputFieldXpath() throws Exception {
		return "//span[@data-testid='search-icon']/parent::div/following-sibling::input";
	}

	public static void clickFirstRowOfTable_Redesign(WebElement tableElement) throws Exception {
		WebElement firstRow = null;
		ArrayList<WebElement> rowElements = (ArrayList<WebElement>) tableElement.findElements(By.xpath(".//div"));
		if (rowElements.size() > 1)
			firstRow = rowElements.get(1);
		else
			throw new Exception("Required row is not found");
		SeleniumHelperClass.click(firstRow);
	}

	public WebElement getTitleSelectButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[text()='Select']"));
	}

	public void selectFromSlider(String sliderXpath, String searchFieldXpath, String searchString, String frame)
			throws Exception {
		try {
			waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
			SeleniumHelperClass.findWebElementbyXpath(sliderXpath, frame).click();
			waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
			logger.info("Switched to slider page");
			waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
			WebElement nameTextField = SeleniumHelperClass.findWebElementbyXpath(returnSliderPageInputFieldXpath());
			SeleniumHelperClass.clearElement(nameTextField);
			nameTextField.sendKeys(searchString);
			WebElement searchButton = getSliderPageSearchIcon();
			SeleniumHelperClass.isClickable(searchButton, 10);
			searchButton.click();
			waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
			WebElement table = getSliderPageTable();
			clickFirstRowOfTable_Redesign(table);
			SeleniumHelperClass.click(getTitleSelectButton());
		} catch (Exception e) {
			throw new Exception(e);
		}
	}

//    public WebElement clickDatePickerFromSlideOutPeopleRedesignCustomFields(String datePickerElementLabel)
//            throws Exception {
//        return (SeleniumHelperClass.findWebElementbyXpath(
//                "//*[contains(@for,'" + datePickerElementLabel
//                        + "')]/following-sibling::span/div//div[contains(@class,'StyledSingleDatePicker')]/button",
//                "mainframe"));
//    }

	public WebElement yearDropDownFromCalendar() throws Exception {

		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//div[@data-visible='true' and contains(@class,'CalendarMonth')]//div[contains(@role,'listbox')])[2]",
				"mainframe"));

	}

	public WebElement selectYear(String year) throws Exception {

		SeleniumHelperClass.click(yearDropDownFromCalendar());
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@data-visible='true' and contains(@class,'CalendarMonth')]//button[@value='" + year + "']",
				"mainframe"));
	}

	public WebElement selectDay(String date) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[2][contains(@class,'CalendarMonthGrid')]//table/tbody/tr/td[contains(@aria-label,'" + date
						+ "')]"));
	}

	public WebElement getRespectiveDropDown(String elementId) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("(//*[contains(@class,'container-fluid')]//*[contains(@for,'"
				+ elementId + "')]/following-sibling::span/div//div[contains(@class,'dropdown')])[1]", "mainFrame"));
	}

	public List<WebElement> getRespectiveDropDownDropDownMenuItems(String elementId) throws Exception {
		SeleniumHelperClass.click(getRespectiveDropDown(elementId));
		return (SeleniumHelperClass.findWebElementsInXpath(
				"//*[contains(@class,'container-fluid')]//*[contains(@for,'" + elementId
						+ "')]/following-sibling::span/div//div[contains(@class,'dropdown-menu')]/button",
				"mainframe"));
	}

	public WebElement selectBusinessGroupDropdown() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button/span[contains(.,'Select Business Group')]",
				"mainFrame"));
	}

	public WebElement getPeopleRedesignSaveButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@id='fixed-header']//*[contains(@class,'dropdown')]/button[contains(@role,'presentation') and contains(@class,'btn-primary')]",
				"mainFrame"));
	}
	public WebElement businessGroupSliderSearch() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@class='externalFilter']//div[contains(@class,'input-group')]//input", "mainFrame"));
	}
	public WebElement getBusinessGroupElipseButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("(//div[@class='floating-icons-wrapper']/child::button[2])[2]",
				"mainFrame");
	}

	public WebElement businessGroupSliderSearchIcon() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[@data-testid='search-icon']//*[local-name()='svg']",
				"mainFrame"));
	}

	public void selectFromDatePicker(String datePickerElementLabel, String month, String year, String calendarDate)
			throws Exception {

		SeleniumHelperClass.click(clickDatePickerFromSlideOutPeopleRedesign(datePickerElementLabel));
		SeleniumHelperClass.click(selectMonth(month));
		SeleniumHelperClass.click(selectYear(year));
		SeleniumHelperClass.click(selectDay(calendarDate));
	}

	public WebElement getSaveOptions(String saveOptions) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(@class,'dropdown show')]//button[text()='"
				+ saveOptions + "' and contains(@class,'btn-secondary')]", "mainFrame"));
	}
	public WebElement getListColumnText(String name) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[text()='"+name+"']",
				"mainFrame"));
	}

	public void getPeopleRedesignSaveOptionsFromDropdownWithWait1(String saveOptions) throws Exception {
		SeleniumHelperClass.isClickable(getPeopleRedesignSaveButton(), 3);
		SeleniumHelperClass.secondaryClick(getPeopleRedesignSaveButton());
		waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
		SeleniumHelperClass.waitUntilElementDisplayed(getSaveOptions(saveOptions), 30);
		SeleniumHelperClass.secondaryClick(getSaveOptions(saveOptions));
	}

	public void getPeopleRedesignSaveOptionsFromDropdownWithWait(String saveOptions) throws Exception {
		try {
			Actions act = new Actions(SetWebDrivers.getDriver());
			SeleniumHelperClass.isClickable(getPeopleRedesignSaveButton(), 3);
			WebElement getsavebutton = SeleniumHelperClass.findWebElementbyXpath(
					"//div[@id='fixed-header']//*[contains(@class,'dropdown')]/button[contains(@role,'presentation') and contains(@class,'btn-primary')]",
					"mainFrame");
			act.click(getsavebutton).build().perform();
			waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
			WebElement getsavedropdown = SeleniumHelperClass
					.findWebElementbyXpath("//div[contains(@class,'dropdown show')]//button[text()='" + saveOptions
							+ "' and contains(@class,'btn-secondary')]", "mainFrame");

			SeleniumHelperClass.waitUntilElementDisplayed(getsavedropdown, 30);
			act.click(getsavedropdown).build().perform();

		} catch (ElementNotInteractableException e) {
			logger.info("trying with java script as a Retry..Ignore themessage..." + e.getMessage());
			SeleniumHelperClass.isClickable(getPeopleRedesignSaveButton(), 3);
			WebElement getsavebutton = SeleniumHelperClass.findWebElementbyXpath(
					"//div[@id='fixed-header']//*[contains(@class,'dropdown')]/button[contains(@role,'presentation') and contains(@class,'btn-primary')]",
					"mainFrame");
			((JavascriptExecutor) SetWebDrivers.getDriver()).executeScript("arguments[0].scrollIntoView(true);",
					getsavebutton);
			waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);

			WebElement getsavedropdown = SeleniumHelperClass
					.findWebElementbyXpath("//div[contains(@class,'dropdown show')]//button[text()='" + saveOptions
							+ "' and contains(@class,'btn-secondary')]", "mainFrame");

			SeleniumHelperClass.waitUntilElementDisplayed(getsavedropdown, 30);
			((JavascriptExecutor) SetWebDrivers.getDriver()).executeScript("arguments[0].scrollIntoView(true);",
					getsavedropdown);

		} catch (Exception e) {
			logger.info("Failed to click webelement due to " + e.getMessage() + ", trying with JSClick...");
			WebElement getsavebutton = SeleniumHelperClass.findWebElementbyXpath(
					"//div[@id='fixed-header']//*[contains(@class,'dropdown')]/button[contains(@role,'presentation') and contains(@class,'btn-primary')]",
					"mainFrame");
			JavascriptExecutor executor = (JavascriptExecutor) SetWebDrivers.getDriver();
			executor.executeScript("arguments[0].click();", getsavebutton);
			waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);

			WebElement getsavedropdown = SeleniumHelperClass
					.findWebElementbyXpath("//div[contains(@class,'dropdown show')]//button[text()='" + saveOptions
							+ "' and contains(@class,'btn-secondary')]", "mainFrame");

			SeleniumHelperClass.waitUntilElementDisplayed(getsavedropdown, 30);

			executor.executeScript("arguments[0].click();", getsavedropdown);

		}

	}

	public void valHeaderAndCount(String expHeader) throws Exception {
		SeleniumHelperClass.waitForElmentToBeReady(listPageTitle());
		Assert.assertEquals(listPageTitle().getText().substring(0, 8), expHeader, "Incorrect Title displayed");
		logger.info("'" + listPageTitle().getText() + "' displayed as Title");
		valPositionListViewCount();
	}

	public int valPositionListViewCount() throws Exception {
		SeleniumHelperClass.waitForElement("xpath", row, 10);
		Assert.assertEquals(listPageTitleCount().getText(), "(" + listPageRows().size() + ")",
				"Count mismatch with the no. of rows");
		logger.info("Count: '" + listPageTitleCount().getText() + "'");
		return listPageRows().size();
	}

	public void validatePositonListPageHeaderBtns(String expUploadText, String expDwnldText, String expCreateText)
			throws Exception {

		Assert.assertEquals(listPageUploadBtn().getText(), expUploadText, "Incorrect button text displayed");
		logger.info("'" + listPageUploadBtn().getText() + "' Button displayed");
		Assert.assertEquals(listPageDownloadBtn().getText(), expDwnldText, "Incorrect button text displayed");
		logger.info("'" + listPageDownloadBtn().getText() + "' Button displayed");
		Assert.assertEquals(listPageCreateBtn().getText(), expCreateText, "Incorrect button text displayed");
		logger.info("'" + listPageCreateBtn().getText() + "' Button displayed");
	}

	public void searchTextListPage(String text) throws Exception {
		SeleniumHelperClass.waitForElmentToBeReady(listPageTitle());
		SeleniumHelperClass.waitForElmentToBeReady(listPageSearchTextBox());
		listPageSearchTextBox().clear();
		listPageSearchTextBox().sendKeys(text);
		SeleniumHelperClass.click(listPageSearchIcon());
		SeleniumHelperClass.waitPageLoad();
	}

	public boolean valColumnData_PositionListView(String columnId, String positionName) throws Exception {
		boolean isRowsContains = false;
		int index = 0;
		List<WebElement> elements = getColumnData_PositionListPage(columnId);
		int Size = elements.size();
		while (index < Size) {
			if (elements.get(index).getText().toUpperCase().contains(positionName.toUpperCase())) {
				isRowsContains = true;
			} else {
				isRowsContains = false;
				break;
			}
			index++;
		}

		return isRowsContains;

	}

	public void valSearchPlaceholder(String expPlaceholderText) throws Exception {
		String actualPHValue = listPageSearchTextBox().getAttribute("placeholder");
		Assert.assertEquals(actualPHValue, expPlaceholderText,
				"'" + actualPHValue + "' displayed instead '" + expPlaceholderText + "'");
		logger.info("Placeholder text validated");
	}

	public void valCancelSearch() throws Exception {
		if (listPageCancelSearch().isDisplayed()) {
			listPageCancelSearch().click();
			logger.info("Search box cleared");
		}
	}

	public String getRandomPositionName() {
		String firstname = "Automation" + SeleniumHelperClass.generateRandomNumber(1000000, 10);
		return firstname;
	}

	public void valVersionFilter(String expVersionTitle, String expDropdownText) throws Exception {
		Assert.assertEquals(listPageVersionFilter().getText(), expVersionTitle,
				"'" + listPageVersionFilter().getText() + "' displayed instead '" + expVersionTitle + "'");
		Assert.assertEquals(listPageVersionDropDown().getText(), expDropdownText,
				"'" + listPageVersionDropDown().getText() + "' displayed instead '" + expDropdownText + "'");
		logger.info("Dropdown text validated");
	}

	public void selectVersionFilter(String selectDropdown) throws Exception {
		SeleniumHelperClass.waitForElmentToBeReady(listPageVersionDropDown());
		SeleniumHelperClass.click(listPageVersionDropDown());
		SeleniumHelperClass.waitForElmentToBeReady(listPageVersionFilterOption(selectDropdown));
		SeleniumHelperClass.click(listPageVersionFilterOption(selectDropdown));
	}

	public void valVersionFilterDataText(String expVersionDataText) throws Exception {
		Assert.assertEquals(listPageVersionFilterDataText().getText(), expVersionDataText,
				"'" + listPageVersionFilterDataText().getText() + "' displayed instead '" + expVersionDataText + "'");
		logger.info("'" + listPageVersionFilterDataText().getText() + "' validated");
	}

	public void clickOnSort() throws Exception {
		SeleniumHelperClass.waitForElmentToBeReady(listPageTitle());
		listPagePositionNameSortIcon().click();
		SeleniumHelperClass.waitPageLoad();
	}

	public void validatePositonListPageColLabels(String expNameLabel, String expTitle, String expPerson, String expBG)
			throws Exception {
		Assert.assertEquals(listPagePositionCol().getText(), expNameLabel, "Incorrect Column Name displayed");
		logger.info("'" + listPagePositionCol().getText() + "' Column displayed");
		Assert.assertEquals(listPageTitleCol().getText(), expTitle, "Incorrect Column Name displayed");
		logger.info("'" + listPageTitleCol().getText() + "' Column displayed");
		Assert.assertEquals(listPagePersonNameCol().getText(), expPerson, "Incorrect Column Name displayed");
		logger.info("'" + listPagePersonNameCol().getText() + "' Column displayed");
		Assert.assertEquals(listPageBGCol().getText(), expBG, "Incorrect Column Name displayed");
		logger.info("'" + listPageBGCol().getText() + "' Column displayed");
		logger.info("Columns validated in Positions List Page");
	}

	public void validateRedesignNoRecords(String expRecordsText, String expSubText, String searchNoRecordsSubText2)
			throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		String actualRecordsText = peoples.whereUsedNoDataRedesign().getText();
		String actualSubText = listPageNoDataSubText().getText().substring(0, 55);
		String actualNoRcordsSubText2 = listPageNoDataSubText().getText().substring(56);
		Assert.assertEquals(actualRecordsText, expRecordsText, "No Records Found is not displayed");
		logger.info(actualRecordsText + " displayed");
		Assert.assertEquals(actualSubText, expSubText, "No results were found is not displayed");
		Assert.assertEquals(actualNoRcordsSubText2, searchNoRecordsSubText2, "No results were found is not displayed");
		logger.info(listPageNoDataSubText().getText() + " displayed");
	}

	public void validateRedesignNoRecordsForSpclChars(String expRecordsText, String expSubText,
													  String searchNoRecordsSubText2) throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		String actualRecordsText = peoples.whereUsedNoDataRedesign().getText();
		String actualSubText = listPageNoDataSubText().getText().substring(0, 76);
		String actualNoRcordsSubText2 = listPageNoDataSubText().getText().substring(77);
		Assert.assertEquals(actualRecordsText, expRecordsText, "No Records Found is not displayed");
		logger.info(actualRecordsText + " displayed");
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 3);
		Assert.assertEquals(actualSubText, expSubText, "No results were found is not displayed");
		Assert.assertEquals(actualNoRcordsSubText2, searchNoRecordsSubText2, "No results were found is not displayed");
		logger.info(listPageNoDataSubText().getText() + " displayed");
	}

	public void validatePositonListPageColValues(String expPositionName, String expTitleValue, String expPersonName,
												 String expBGValue) throws Exception {
		Assert.assertEquals(listPagePositionColValue().getText(), expPositionName,
				"Incorrect data displayed for Position Name");
		logger.info("'" + listPagePositionColValue().getText() + "' displayed");
		Assert.assertEquals(listPageTitleColValue().getText(), expTitleValue, "Incorrect data displayed for Title");
		logger.info("'" + listPageTitleColValue().getText() + "' displayed");
		Assert.assertEquals(listPagePersonNameColValue().getText(), expPersonName,
				"Incorrect data displayed for Person Name");
		logger.info("'" + listPagePersonNameColValue().getText() + "' displayed");
		Assert.assertEquals(listPageBGColValue().getText(), expBGValue, "Incorrect data displayed for Business Group");
		logger.info("'" + listPageBGColValue().getText() + "' displayed");
	}

	public void sortColumnHeaderInPositionList_NewUI(String columnId, String sortOrder) throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		if (getColumnHeaderSortIcon_PositionListPage(columnId).getAttribute("aria-sort").contains("none")) {
			getColumnHeaderSortIcon_PositionListPage(columnId).click();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
			logger.info("clicked on column-id = " + columnId + " for sorting in "
					+ getColumnHeaderSortIcon_PositionListPage(columnId).getAttribute("aria-sort"));
		}
		if (!getColumnHeaderSortIcon_PositionListPage(columnId).getAttribute("aria-sort").contains(sortOrder)) {
			getColumnHeaderSortIcon_PositionListPage(columnId).click();
			logger.info("clicked on column-id = " + columnId + " for sorting in " + sortOrder);
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		} else {
			logger.info("column-id = " + columnId + "is already available in sorting " + sortOrder);
		}
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		SeleniumHelperClass.waitPageLoad();
	}

	public ArrayList<String> getColumnDataPositionListPage(String columnName) throws Exception {
		int index = 0;
		List<WebElement> elements = null;
		logger.info("Column Name : " + columnName);
		switch (columnName) {
			case "Position Name":
				elements = getColumnData_PositionListPage("positionName");
				break;
			case "Title":
				elements = getColumnData_PositionListPage("title");
				break;
			case "Person Name (Latest)":
				elements = getColumnData_PositionListPage("effectivePersonName");
				break;
			default:
				logger.info("Invalid column Name = " + columnName);
		}
		ArrayList<String> arrList = new ArrayList<>();// To Maintain insertion order
		int Size = elements.size();
		while (index < Size) {
			if (!elements.get(index).getText().equalsIgnoreCase("")) {
				arrList.add(elements.get(index).getText());
			}
			index++;
		}
		return arrList;
	}

	public void click3DotsRedesign(String name) throws Exception {
		SeleniumHelperClass.waitForElmentToBeReady(peoples.selectRowRedesign(name));
		SeleniumHelperClass.mouseHover(peoples.selectRowRedesign(name));
		logger.info("Moved to the Row");
		SeleniumHelperClass.waitForElmentToBeReady(peoples.threeDotsBtnRedesign(name));
		SeleniumHelperClass.click(peoples.threeDotsBtnRedesign(name));
	}

	public void valDeletePositionPopup(String title, String text) throws Exception {
		Assert.assertEquals(previewPositionTitle().getText(), title, "Header displayed Incorrectly");
		logger.info(previewPositionTitle().getText() + " is displayed");
		Assert.assertEquals(positionDeleteText().getText(), text, "Delete Popup text displayed Incorrectly");
		logger.info(positionDeleteText().getText() + " is displayed");

	}

	public void valDeletePopupButtons(String cancelBtnText, String deleteBtnText) throws Exception {
		Assert.assertEquals(positionDeletePopupCancelBtn().getText(), cancelBtnText,
				"Cancel Button text displayed Incorrectly");
		logger.info(positionDeletePopupCancelBtn().getText() + " is displayed");
		Assert.assertEquals(positionDeletePopupDeleteBtn().getText(), deleteBtnText,
				"Delete Button text displayed Incorrectly");
		logger.info(positionDeletePopupDeleteBtn().getText() + " is displayed");
	}

	public void valDeletePopupOkButton(String okText) throws Exception {
		Assert.assertEquals(positionDeletePopupOkBtn().getText(), okText, "Cancel Button text displayed Incorrectly");
		logger.info(positionDeletePopupOkBtn().getText() + " is displayed");
	}

	public void clickDeletePopupOkButton() throws Exception {
		SeleniumHelperClass.click(positionDeletePopupOkBtn());
		logger.info("OK button clicked");
	}

	public void clickDeletePopupDeleteBtn() throws Exception {
		SeleniumHelperClass.waitForElmentToBeReady(positionDeletePopupDeleteBtn());
		SeleniumHelperClass.click(positionDeletePopupDeleteBtn());
	}

	public void clickDeletePopupCancelBtn() throws Exception {
		SeleniumHelperClass.waitForElmentToBeReady(positionDeletePopupCancelBtn());
		SeleniumHelperClass.click(positionDeletePopupCancelBtn());
	}

	public void valDeleteToaster(String expMessage) throws Exception {
		String actualToster = positionDeleteToaster().getText();
		Assert.assertEquals(actualToster, expMessage, "Delete toaster message displayed Incorrectly");
		logger.info(actualToster + " is displayed");
	}

	public void validatePositionWhereUsedRedesignLabels(String positionName, String expDownloadBtnText)
			throws Exception {
		String expHeader = "Where Used: Position " + positionName;
		Assert.assertEquals(peoples.peopleSliderUIHeaderRedesign().getText(), expHeader,
				"Header displayed Incorrectly");
		logger.info(peoples.peopleSliderUIHeaderRedesign().getText() + " is displayed");
		Assert.assertEquals(peoples.whereUsedUIDownloadBtnRedesign().getText(), expDownloadBtnText,
				"Incorrect Download Button Text");
		logger.info(peoples.whereUsedUIDownloadBtnRedesign().getText() + " is displayed ");
	}

	public void selectWhereUsedTab(String tabName) throws Exception {
		SeleniumHelperClass.waitForElmentToBeReady(whereUsedTab(tabName));
		SeleniumHelperClass.click(whereUsedTab(tabName));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	public void validateAllResultsCount(String expAllResults, String expCount) throws Exception {
		Assert.assertEquals(peoples.whereUsedUIAllResultsRedesign().getText().substring(0, 11), expAllResults,
				"All results Text displayed incorrectly");
		logger.info(peoples.whereUsedUIAllResultsRedesign().getText() + " is displayed ");
		Assert.assertEquals(peoples.whereUsedUICountRedesign().getText(), expCount, "Incorrect Count displayed");
		logger.info(peoples.whereUsedUICountRedesign().getText() + " is displayed");
	}

	public void validateRedesignWhereUsedPeopleColLabels(String expNameLabel, String expEffDateLabel,
														 String expDesLabel, String empIDLabel) throws Exception {
		Assert.assertEquals(peoples.whereUsedNameColRedesign().getText(), expNameLabel,
				"Incorrect Column Name displayed");
		logger.info("'" + peoples.whereUsedNameColRedesign().getText() + "' Column displayed");
		Assert.assertEquals(peoples.whereUsedStartDateColRedesign().getText(), expEffDateLabel,
				"Incorrect Column Name displayed");
		logger.info("'" + peoples.whereUsedStartDateColRedesign().getText() + "' Column displayed");
		Assert.assertEquals(peoples.whereUsedUIDesColRedesign().getText(), expDesLabel,
				"Incorrect Column Name displayed");
		logger.info("'" + peoples.whereUsedUIDesColRedesign().getText() + "' Column displayed");
		Assert.assertEquals(whereUsedUIEmpIDCol().getText(), empIDLabel, "Incorrect Column Name displayed");
		logger.info("'" + whereUsedUIEmpIDCol().getText() + "' Column displayed");
	}

	public void validatePositionWhereUsedPeopleData(String expPersonName, String expStartDate, String expDescription,
													String empId) throws Exception {
		Assert.assertEquals(peoples.whereUsedNameColValueRedesign().getText(), expPersonName,
				"Incorrect Position Name displayed");
		logger.info("'" + peoples.whereUsedNameColValueRedesign().getText() + "' displayed");
		Assert.assertEquals(peoples.whereUsedStartDateColValueRedesign().getText(), expStartDate,
				"Incorrect Start date Name displayed");
		logger.info("'" + peoples.whereUsedStartDateColValueRedesign().getText() + "' displayed");
		Assert.assertEquals(peoples.whereUsedDesColValueRedesign().getText(), expDescription,
				"Incorrect description displayed");
		logger.info("'" + peoples.whereUsedDesColValueRedesign().getText() + "' displayed");
		Assert.assertEquals(whereUsedEmpIdColValue().getText(), empId, "Incorrect Employee ID displayed");
		logger.info("'" + whereUsedEmpIdColValue().getText() + "' displayed");
	}

	public void valNameAndDesLabels(String expNameLabel, String expDesLabel) throws Exception {
		Assert.assertEquals(peoples.whereUsedNameColRedesign().getText(), expNameLabel,
				"Incorrect Column Name displayed");
		logger.info("'" + peoples.whereUsedNameColRedesign().getText() + "' Column displayed");
		Assert.assertEquals(peoples.whereUsedUIDesColRedesign().getText(), expDesLabel,
				"Incorrect Column Name displayed");
		logger.info("'" + peoples.whereUsedUIDesColRedesign().getText() + "' Column displayed");
	}

	public void valNameAndDesColValues(int row, String expPersonNameValue, String expDescriptionValue)
			throws Exception {
		Assert.assertEquals(whereUsedNameColValueRedesign(row).getText(), expPersonNameValue,
				"Incorrect Position Name displayed");
		logger.info("'" + whereUsedNameColValueRedesign(row).getText() + "' displayed");
		Assert.assertEquals(whereUsedDesColValueRedesign(row).getText(), expDescriptionValue,
				"Incorrect description displayed");
		logger.info("'" + whereUsedDesColValueRedesign(row).getText() + "' displayed");
	}

	public void valQuotaTabColumnValues(int row, String expQuotaVal, String expUnitTypeVal, String expQuotaPeriodVal)
			throws Exception {
		Assert.assertEquals(whereUsedQuotaValueColValue(row).getText(), expQuotaVal, "Incorrect Column Name displayed");
		logger.info("'" + whereUsedQuotaValueColValue(row).getText() + "' displayed");
		Assert.assertEquals(whereUsedUnitTypeColValue(row).getText(), expUnitTypeVal,
				"Incorrect Column Name displayed");
		logger.info("'" + whereUsedUnitTypeColValue(row).getText() + "' displayed");
		Assert.assertEquals(whereUsedQuotaPeriodColValue(row).getText(), expQuotaPeriodVal,
				"Incorrect Column Name displayed");
		logger.info("'" + whereUsedQuotaPeriodColValue(row).getText() + "' displayed");
	}

	public void valQuotaTabColumns(String expQuotaValuLabel, String expUnitTypeLabel, String expQuotaPeriodLabel)
			throws Exception {
		Assert.assertEquals(whereUsedUIQuotaValueCol().getText(), expQuotaValuLabel, "Incorrect Column Name displayed");
		logger.info("'" + whereUsedUIQuotaValueCol().getText() + "' Column displayed");
		Assert.assertEquals(whereUsedUIUnitTypeCol().getText(), expUnitTypeLabel, "Incorrect Column Name displayed");
		logger.info("'" + whereUsedUIUnitTypeCol().getText() + "' Column displayed");
		Assert.assertEquals(whereUsedUIQuotaPeriodCol().getText(), expQuotaPeriodLabel,
				"Incorrect Column Name displayed");
		logger.info("'" + whereUsedUIQuotaPeriodCol().getText() + "' Column displayed");
	}

	public void valPositionWhereUsedTabs(String tab1, String tab2, String tab3, String tab4, String tab5)
			throws Exception {
		SeleniumHelperClass.waitForElmentToBeReady(positionWhereUsedTabs().get(0));
		Assert.assertEquals(positionWhereUsedTabs().get(0).getText(), tab1, "Tab Name mismatch");
		logger.info("'" + positionWhereUsedTabs().get(0).getText() + "' tab  displayed");
		Assert.assertEquals(positionWhereUsedTabs().get(1).getText(), tab2, "Tab Name mismatch");
		logger.info("'" + positionWhereUsedTabs().get(1).getText() + "' tab  displayed");
		Assert.assertEquals(positionWhereUsedTabs().get(2).getText(), tab3, "Tab Name mismatch");
		logger.info("'" + positionWhereUsedTabs().get(2).getText() + "' tab  displayed");
		Assert.assertEquals(positionWhereUsedTabs().get(3).getText(), tab4, "Tab Name mismatch");
		logger.info("'" + positionWhereUsedTabs().get(3).getText() + "' tab  displayed");
		Assert.assertEquals(positionWhereUsedTabs().get(4).getText(), tab5, "Tab Name mismatch");
		logger.info("'" + positionWhereUsedTabs().get(4).getText() + "' tab  displayed");

	}

	public void clickOnPosition(String name) throws Exception {
		SeleniumHelperClass.waitForElmentToBeReady(peoples.selectRowRedesign(name));
		peoples.selectRowRedesign(name).click();
		SeleniumHelperClass.waitForElmentToBeReady(previewPositionTitle());
	}

	public void valPreviewPanelSlider(String header, String closeBtn) throws Exception {
		Assert.assertEquals(previewPositionTitle().getText(), header);
		Assert.assertEquals(peoples.sliderUICloseBtnRedesign().getText(), closeBtn);
	}

	public void valVersonSecLablesPrevPanel(String versionSubHead, String startDateLabel, String endDateLabel,
											String desLabel) throws Exception {
		Assert.assertEquals(previewPositionHeader1().getText(), versionSubHead,
				"Incorrect Version sub header displayed");
		Assert.assertEquals(previewEffStartDateLabel().getText(), startDateLabel,
				startDateLabel + " not displayed correctly");
		Assert.assertEquals(previewEffEndDateLabel().getText(), endDateLabel,
				endDateLabel + " not displayed correctly");
		Assert.assertEquals(previewDescriptionLabel().getText(), desLabel, desLabel + " not displayed correctly");
	}

	public void valVersionSecValuesPrevPanel(String startDateValue, String endDateValue, String desValue)
			throws Exception {
		Assert.assertEquals(previewEffStartDateValue().getText(), startDateValue,
				startDateValue + " not displayed correctly");
		Assert.assertEquals(previewEffEndDateValue().getText(), endDateValue,
				endDateValue + " not displayed correctly");
		Assert.assertEquals(previewDescriptionValue().getText(), desValue, desValue + " not displayed correctly");
	}

	public void valPositionSecLablesPrevPanel(String positionDetailsSec, String positionNameLabel,
											  String incentStartDateLabel, String incentEndDateLabel, String titleLabel, String BGLabel,
											  String personNameLabel) throws Exception {
		Assert.assertEquals(previewPositionHeader2().getText(), positionDetailsSec,
				positionDetailsSec + " not displayed correctly");
		Assert.assertEquals(previewPositionNameLabel().getText(), positionNameLabel,
				positionNameLabel + " not displayed correctly");
		Assert.assertEquals(previewIncentiveStartDateLabel().getText(), incentStartDateLabel,
				incentStartDateLabel + " not displayed correctly");
		Assert.assertEquals(previewIncentiveEndDateLabel().getText(), incentEndDateLabel,
				incentEndDateLabel + " not displayed correctly");
		Assert.assertEquals(previewTitleLabel().getText(), titleLabel, titleLabel + " not displayed correctly");
		Assert.assertEquals(previewBGLabel().getText(), BGLabel, BGLabel + " not displayed correctly");
		Assert.assertEquals(previewPersonNameLabel().getText(), personNameLabel,
				personNameLabel + " not displayed correctly");
	}

	public void valPositionDetailsValuesPrevPanel(String positionNameValue, String startDateValue, String endDateValue,
												  String titleValue, String BGValue, String personNameValue) throws Exception {
		Assert.assertEquals(previewPositionNameValue().getText(), positionNameValue,
				positionNameValue + " not displayed correctly");
		Assert.assertEquals(previewIncentiveStartValue().getText(), startDateValue,
				startDateValue + " not displayed correctly");
		Assert.assertEquals(previewIncentiveEndValue().getText(), endDateValue,
				endDateValue + " not displayed correctly");
		Assert.assertEquals(previewTitleValue().getText(), titleValue, titleValue + " not displayed correctly");
		Assert.assertEquals(previewBGeValue().getText(), BGValue, BGValue + " not displayed correctly");
		Assert.assertEquals(previewPersonNameValue().getText(), personNameValue,
				personNameValue + " not displayed correctly");
	}

	public void clickonPositionCreateButton() throws Exception {
		SeleniumHelperClass.click(createPositionButton());
	}

	public WebElement getPositionInputFields(String elementId) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[contains(@for,'" + elementId + "')]/following-sibling::span/input", "mainFrame"));
	}

	public void clearAndSend(WebElement ele, String str) throws Exception {
		ele.clear();
		ele.sendKeys(str);
	}

	public void createPositionWithAllFields(String posName, String posDesc, String startDate, String endDate,
											String title, String businessGroupIndex, String personName, String saveOption, Boolean isPersonAssigned)
			throws Exception {
		// clickonPositionCreateButton();
		selectFromSlider(returnTitleInput(), returnSliderPageInputFieldXpath(), title, "mainframe");
		clearAndSend(getPositionInputFields("Position Name"), posName);
		clearAndSend(positionDescriptionInputField(), posDesc);
		selectValueFromSliderWithSearch(businessGroupIndex, true);
		selectFromDatePicker("Incentive Start Date", startDate.split(" ")[0], startDate.split(" ")[2],
				startDate.split(" ")[1]);
		selectFromDatePicker("Incentive End Date", endDate.split(" ")[0], endDate.split(" ")[2], endDate.split(" ")[1]);
		if (isPersonAssigned) {
			selectFromSlider(returnPositionInput(), returnSliderPageInputFieldXpath(), personName, "mainframe");
		}
		getPeopleRedesignSaveOptionsFromDropdownWithWait(saveOption);

	}

	public String downloadPositionSliderNewUI(String version, String format) throws Exception {
		SeleniumHelperClass.switchToPopupWindow();

		if (version.equalsIgnoreCase("All versions"))
			SeleniumHelperClass.click(getAllVersionsNewUI());
		else {
			SeleniumHelperClass.click(getLatestVersionsToDownloadPositionsRedesign());
		}
		// SeleniumHelperClass.click(getSelectDownloadFormatRedesign());
		SeleniumHelperClass.click(getDownloadFormatDropdownMenuItem(format));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		getDownloadButtonRedesign().click();
		String toasterMessage = getToasterMessage().getText();
		logger.info("Download Message :" + toasterMessage);
		// latestFile = findLatestFileInLocation(Constants.downloadLoc);
		// logger.info("LatestFile path with Name:" + latestFile);
		return toasterMessage;
	}

	/**
	 * Method to get expected position download file
	 *
	 * @param fileName
	 * @return
	 */
	public String getPositionDownloadExpectedFileLocation(String fileName) {
		String path = this.getClass().getClassLoader()
				.getResource("com.xactly.incent.organization/PositionsDownloadRedesign/" + fileName).getFile();
		System.out.println("FilePath=" + path);
		logger.info("Actual path is  : " + path);
		if (SetWebDrivers.runningOS.equalsIgnoreCase("Windows")) {
			logger.info("OS in Windows, Fie Path : " + path);
			path = path.substring(1, path.length()).replace("/", "\\");
		}
		logger.info("Upload File location Path returned : " + path);
		return path;
	}

	// To get the edit position page where used button
	// page
	public WebElement getEditPosiitonPageWhereUsedButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//button[text()='Where Used' and contains(@class,'btn-secondary')])[1]", "mainFrame"));
	}

	public WebElement getSliderPageSaveButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'SlidePanelFooter')]/button[contains(@type,'button') and contains(@class,'btn-primary')]"));
	}

	public void addVersionSlider(String effectiveStartDate) throws Exception {
		logger.info("In Add Version slider page selecting effective start date and save");
		selectDatePickerInSlider("Effective Start", effectiveStartDate.split(" ")[0], effectiveStartDate.split(" ")[2],
				effectiveStartDate.split(" ")[1]);
		SeleniumHelperClass.click(getSliderPageSaveButton());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 3);
	}

	public void createPositionMandatoryFields(String posName, String title, String businessGroupIndex,
											  String saveOption) throws Exception {
		if (!title.isEmpty()) {
			selectFromSlider(returnTitleInput(), returnSliderPageInputFieldXpath(), title, "mainframe");
		}
		if (!posName.isEmpty()) {
			clearAndSend(getPositionInputFields("Position Name"), posName);
		}
		if (!businessGroupIndex.isEmpty()) {
			selectValueFromSliderWithSearch(businessGroupIndex, false);
		}
		getPeopleRedesignSaveOptionsFromDropdownWithWait(saveOption);
	}

	public WebElement getRequiredInLineMessage(String fieldLabel) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//label[@for='" + fieldLabel + "']/following-sibling::span//*[text()='Required']", "mainFrame"));
	}

	public boolean validateMandatoryFieldsInPosition(String type) {
		boolean isdisplayed = false;
		try {
			if (type.equalsIgnoreCase("Create")) {
				if (getRequiredInLineMessage("Position Name").isDisplayed()
						&& getRequiredInLineMessage("Title").isDisplayed()
						&& getRequiredInLineMessage("Business Group").isDisplayed())
					isdisplayed = true;
			} else if (type.equalsIgnoreCase("Edit")) {
				if (getRequiredInLineMessage("Title").isDisplayed())
					isdisplayed = true;
			} else {
				logger.info("Please provide valid type Input ex: Create or Edit");
			}
		} catch (Exception e) {
			logger.info("Exception is thrown :" + e.getStackTrace());
		}
		return isdisplayed;
	}

	public WebElement getModalNoDiscardChangesButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[text()='No, Discard Changes']", "mainFrame"));
	}

	public WebElement getTitleFieldCloseIcon() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//label[@for='Title']/following-sibling::span//span[@data-testid='xbadge-container']//*[@fill='currentColor']",
				"mainFrame"));
	}

	public void clearTitleFieldValue() throws Exception {
		SeleniumHelperClass.clickElementUsingActions(getTitleFieldCloseIcon());
	}

	public void editPositionWithAllFields(String posDesc, String startDate, String endDate, String title,
										  String businessGroupIndex, String personName, String saveOption, Boolean isPersonAssigned)
			throws Exception {

		clearTitleFieldValue();
		selectFromSlider(returnTitleInput(), returnSliderPageInputFieldXpath(), title, "mainframe");
		clearAndSend(positionDescriptionInputField(), posDesc);
		//List<WebElement> getBusinessGroupValues = getRespectiveDropDownDropDownMenuItems("Business Group");
		//SeleniumHelperClass.click(getBusinessGroupValues.get(businessGroupIndex));
		selectValueFromSliderWithSearch(businessGroupIndex, false);
		selectFromDatePicker("Incentive Start Date", startDate.split(" ")[0], startDate.split(" ")[2],
				startDate.split(" ")[1]);
		selectFromDatePicker("Incentive End Date", endDate.split(" ")[0], endDate.split(" ")[2], endDate.split(" ")[1]);
		if (isPersonAssigned) {
			clearPersonNameFieldValue();
			selectFromSlider(returnPositionInput(), returnSliderPageInputFieldXpath(), personName, "mainframe");
		}
		getPeopleRedesignSaveOptionsFromDropdownWithWait(saveOption);
	}

	// To click the edit position page where used button

	public void clickonPositionWhereUsedButton() throws Exception {
		getEditPosiitonPageWhereUsedButton().click();
	}

	// To get the edit position page Delete button
	// page
	public WebElement getEditPositionPageDeleteButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//button[text()='Delete' and contains(@class,'btn-secondary')])[1]", "mainFrame"));
	}

	// To get the edit position page Cancel button
	// page
	public WebElement getEditPositionPageCancelButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"(//button[text()='Cancel' and contains(@class,'btn-secondary')])[1]", "mainFrame"));
	}

	// To click the edit position page cancel button

	public void clickonPositionCancelButton() throws Exception {
		getEditPositionPageCancelButton().click();
	}

	// To click the edit position page Delete button

	public void clickonPositionDeleteButton() throws Exception {
		getEditPositionPageDeleteButton().click();
	}

	// To double click on any row based on employee id

	public void doubleClickEditPosition(String employeeId) throws Exception {
		SeleniumHelperClass.doubleClick(selectPositionRowRedesignBasedonPositionName(employeeId));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 2);

	}

	// to select a position record
	public void selectRowAndClick(String positionName) throws Exception {
		new Positions(SetWebDrivers.getNavigationType());
		waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
		doubleClickEditPosition(positionName);
		waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	// To get the select position on list page based on position name

	public WebElement selectPositionRowRedesignBasedonPositionName(String employeeid) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//span[text()='" + employeeid + "']//parent::div//parent::div//parent::div[@role='row']",
				"mainFrame"));
	}

	public WebElement getPersonNameFieldCloseIcon() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//label[contains(@for,'Person Name (Latest)')]/following-sibling::span//span[@data-testid='xbadge-container']//*[@fill='currentColor']",
				"mainFrame"));
	}

	public void clearPersonNameFieldValue() throws Exception {
		SeleniumHelperClass.clickElementUsingActions(getPersonNameFieldCloseIcon());
	}

	public void selectDatePickerInSlider(String datePickerElementLabel, String month, String year, String calendarDate)
			throws Exception {

		SeleniumHelperClass.click(clickDatePickerFromSliderPeopleRedesign(datePickerElementLabel));
		SeleniumHelperClass.click(selectMonth(month));
		SeleniumHelperClass.click(selectYear(year));
		SeleniumHelperClass.click(selectDay(calendarDate));
	}

	public WebElement clickDatePickerFromSliderPeopleRedesign(String datePickerElementLabel) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//*[@for='" + datePickerElementLabel
						+ "']/following-sibling::span/div//div[contains(@class,'StyledSingleDatePicker')]/button",
				"mainframe"));
	}

	public void clickAdvanceSearchLink_NewUI() throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SeleniumHelperClass.click(get_AdvanceSearchFilter_Link());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	}

	public void selectAdvanceSearchConditionsFromFilter(String fieldId, String InputType, String operatorId,
														String inputValue, int index) throws Exception {
		String values[] = new String[10];
		int count;
		switch (InputType) {
			case "InputText":
				// code block
				SeleniumHelperClass.waitUntilElementDisplayed(selectFieldDropdown(), 30);
				SeleniumHelperClass.click(selectFieldDropdown());
				SeleniumHelperClass.click(selectDropdownAdvanceSearch(fieldId, index));
				SeleniumHelperClass.click(selectOpratorDropdown());
				SeleniumHelperClass.click(selectDropdownAdvanceSearch(operatorId, index));
				waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
				if (operatorId.equalsIgnoreCase("Contains")) {
					List<WebElement> noOfpaths = enterValueTextForContains();
					count = noOfpaths.size();
					enterValueTextForContains(count).sendKeys(inputValue);

				} else {
					List<WebElement> noOfpaths = enterValueText();
					count = noOfpaths.size();
					enterValueText(count).sendKeys(inputValue);
				}
				break;
			case "Slider":
				SeleniumHelperClass.waitUntilElementDisplayed(selectFieldDropdown(), 30);
				SeleniumHelperClass.click(selectFieldDropdown());
				SeleniumHelperClass.click(selectDropdownAdvanceSearch(fieldId, index));
				SeleniumHelperClass.click(selectOpratorDropdown());
				SeleniumHelperClass.click(selectDropdownAdvanceSearch(operatorId, index));
				values = inputValue.split(":");
				// write a method select single value i.e: values array index 0 value
				WebElement ele;
				if (operatorId.equalsIgnoreCase("In")) {
					List<WebElement> noOf3Dots = clickSlider3dotsForIn1();
					count = noOf3Dots.size();
					ele = clickSlider3dotsForIn(count);
					SeleniumHelperClass.click(ele);
					selectValueFromSlider(values, true, true);
				} else {
					List<WebElement> noOf3Dots = clickSlider3dots();
					count = noOf3Dots.size();
					ele = clickSlider3dots(count);
					SeleniumHelperClass.click(ele);
					selectValueFromSlider(values, false, false);
				}
				break;

			default:
				// code block
		}
	}

	public void selectValueFromSlider(String[] selectValue, boolean isSearchfield, boolean isMultiSelect)
			throws Exception {
		waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
		logger.info("Switched to slider page");
		waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
		if (isSearchfield && isMultiSelect) {

			for (int k = 0; k < selectValue.length; k++) {
				waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
				boolean status = SeleniumHelperClass.isElementPresent("xpath",
						"//span[@data-testid='cancel-icon']//*[local-name()='svg']");
				if (status) {
					SeleniumHelperClass.click(sliderSearchCancelIcon());
				}
				sliderSearch().sendKeys(selectValue[k]);
				WebElement searchButton = sliderSearchIcon();
				SeleniumHelperClass.waitForElmentToBeReady(searchButton);
				searchButton.click();
				waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
				SeleniumHelperClass.click(getSliderCheckbox(selectValue[k]));
				waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
			}
		} else {
			SeleniumHelperClass.scrollElementIntoViewUsingJS(getSliderRow(selectValue[0]));
			SeleniumHelperClass.waitForElmentToBeReady(getSliderRow(selectValue[0]));
			SeleniumHelperClass.click(getSliderRow(selectValue[0]));
			waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
		}
		SeleniumHelperClass.click(get_AdvanceSearch_SliderSelectButton());
	}

	public void selectConditionForAdvanceSearch(String condition) throws Exception {
		SeleniumHelperClass.waitForElmentToBeReady(clickConditionDropdown());
		SeleniumHelperClass.click(clickConditionDropdown());
		SeleniumHelperClass.waitForElmentToBeReady(selectCondition(condition));
		SeleniumHelperClass.click(selectCondition(condition));

	}

	public void selectFilterCombo(LinkedHashMap<String, String> hInfo, int count, String condition) throws Exception {
		int size = hInfo.size();

		for (Map.Entry<String, String> entry : hInfo.entrySet()) {
			String sFieldName = (String) entry.getKey();
			String fieldInputType = entry.getValue().split(",")[0];
			String fieldOperator = entry.getValue().split(",")[1];
			String fieldValue = entry.getValue().split(",")[2];
			selectAdvanceSearchConditionsFromFilter(sFieldName, fieldInputType, fieldOperator, fieldValue, count + 1);
			if ((count + 1) != size) {
				SeleniumHelperClass.click(addRow());
				if (count == 2) {
					selectConditionForAdvanceSearch(condition);
				}
				count++;
			} else {
				break;
			}
		}
	}

	public String downloadPositionSlider(String version, String format) throws Exception {
		SeleniumHelperClass.switchToPopupWindow();
		if (version.equalsIgnoreCase("All versions"))
			SeleniumHelperClass.click(getAllVersionsNewUI());
		else
			SeleniumHelperClass.click(getLatestVersionsNewUI());
		SeleniumHelperClass.click(getDownloadFormatDropdown());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SeleniumHelperClass.click(getDownloadFormatDropdownMenuItem(format));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		getSliderDownloadButton().click();
		String toasterMessage = getToasterMessage().getText();
		logger.info("Download Message :" + toasterMessage);
		latestFile = findLatestFileInLocation(Constants.downloadLoc);
		logger.info("LatestFile path with Name:" + latestFile);
		return toasterMessage;
	}

	public String positionDownloadExpFile(String fileName) {
		String path = this.getClass().getClassLoader()
				.getResource("com.xactly.incent.organization/PositionsDownloadRedesign/" + fileName).getFile();
		System.out.println("FilePath=" + path);
		logger.info("Actual path is  : " + path);
		if (SetWebDrivers.runningOS.equalsIgnoreCase("Windows")) {
			logger.info("OS in Windows, Fie Path : " + path);
			path = path.substring(1, path.length()).replace("/", "\\");
		}
		logger.info("Upload File location Path returned : " + path);
		return path;
	}

	public File findLatestFileInLocation(String downloadLoc) throws InterruptedException {
		logger.info("downloadloc: " + downloadLoc);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX * 3);
		logger.info("Finding latest file");
		latestFilefromDir = getLatestFilefromDir(downloadLoc);
		Thread.sleep(2000);
		return latestFilefromDir;
	}

	public File getLatestFilefromDir(String dirPath) throws InterruptedException {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX * 2);
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			return null;
		}

		File lastModifiedFile = files[0];
		for (int i = 1; i < files.length; i++) {
			if (lastModifiedFile.lastModified() < files[i].lastModified()) {
				lastModifiedFile = files[i];
			}
		}
		logger.info("lastModifiedFile: " + lastModifiedFile);
		return lastModifiedFile;
	}

	public void clickDownloadButtonRedesignUI() throws Exception {
		waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
		downloadButton_NewUI().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	}

	public WebElement downloadPositionRedesign() throws Exception {

		return SeleniumHelperClass
				.findWebElementbyXpath("//div[contains(@class, 'sc-5xp2gj-3 sc-5xp2gj-5 emQRP')]/span[2]", "mainFrame");

	}

	public WebElement getAllVersionsToDownloadPositionsRedesign() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//label[text()='All Versions']", "mainFrame");
	}

	public void getSelectDownloadFormatRedesign(String type) throws Exception {

		Select sel = new Select(SeleniumHelperClass
				.findWebElementbyXpath("//div[text()='Download Format']/following-sibling::div/select", "mainFrame"));
		sel.selectByVisibleText(type);

	}

	public WebElement getPositionEditButton(String positionName) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//span[text()='" + positionName + "']/../..//following-sibling::div/div/div/button", "mainFrame");
	}

	public void clickPositionEditButton(String positionName) throws Exception {
		logger.info("Start Clicking on the Edit Button of position : " + positionName);
		try {
			SeleniumHelperClass.moveToElement(getPositionEditButton(positionName));
			SeleniumHelperClass.isClickable(getPositionEditButton(positionName), 10);
			SeleniumHelperClass.click(getPositionEditButton(positionName));
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		} catch (Exception e) {
			SeleniumHelperClass.moveToElement(getPositionEditButton(positionName));
			SeleniumHelperClass.isClickable(getPositionEditButton(positionName), 10);
			SeleniumHelperClass.click(getPositionEditButton(positionName));
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		}
		logger.info("Clicked successfully on the Edit Button of position : " + positionName);
	}

	public WebElement getPositionEditDescriptionTextArea() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//textarea[@id='positionDescription']", "mainFrame");
	}

	public void enterTextInPositionDescriptionBox(String description) throws Exception {
		SeleniumHelperClass.isClickable(getPositionEditDescriptionTextArea(), 10);
		getPositionEditDescriptionTextArea().clear();
		getPositionEditDescriptionTextArea().sendKeys(description);
		getPositionNameOnEditPage().click();
	}

	public WebElement getPositionSaveButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='fixed-header']//button[@role='presentation']",
				"mainFrame");
	}

	public void clickPositionSaveButton() throws Exception {
		SeleniumHelperClass.isClickable(getPositionSaveButton(), 10);
		SeleniumHelperClass.click(getPositionSaveButton());
	}

	public WebElement getPositionSaveVersionButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='fixed-header']//div[@role='menu']/button[1]",
				"mainFrame");
	}

	public WebElement getPositionSaveAndAddVersionButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='fixed-header']//div[@role='menu']/button[2]",
				"mainFrame");
	}

	public WebElement getPositionSaveAndAddPositionButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='fixed-header']//div[@role='menu']/button[3]",
				"mainFrame");
	}

	public void clickPositionSaveVersionButton() throws Exception {
		clickPositionSaveButton();
		SeleniumHelperClass.isClickable(getPositionSaveVersionButton(), 10);
		SeleniumHelperClass.click(getPositionSaveVersionButton());
	}

	public void clickPositionSaveAndAddVersionButton() throws Exception {
		SeleniumHelperClass.isClickable(getPositionSaveAndAddVersionButton(), 10);
		SeleniumHelperClass.click(getPositionSaveAndAddVersionButton());
	}

	public void clickPositionSaveAndAddPositionButton() throws Exception {
		SeleniumHelperClass.isClickable(getPositionSaveAndAddPositionButton(), 10);
		SeleniumHelperClass.click(getPositionSaveAndAddPositionButton());
	}

	public WebElement getPositionNameOnEditPage() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='positionName']", "mainFrame");
	}

	public WebElement getBusinessGroupDropdown() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='editPage']//div[@role='listbox']/button",
				"mainFrame");
	}

	public void clickBusinessGroupDropdown() throws Exception {
		SeleniumHelperClass.isClickable(getBusinessGroupDropdown(), 10);
		SeleniumHelperClass.click(getBusinessGroupDropdown());
	}

	public void selectBusinessGroupFromDropdown(String businessGroup) throws Exception {
		clickBusinessGroupDropdown();
		WebElement businessGroupElement = SeleniumHelperClass.findWebElementbyXpath(
				"//div[@role='listbox']/div[@id='businessGroup']/button[text()='" + businessGroup + "']", "mainFrame");
		SeleniumHelperClass.isClickable(businessGroupElement, 10);
		SeleniumHelperClass.click(businessGroupElement);
	}

	public WebElement getTitleDropdown() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//*[@id='title_Title']//following-sibling::span//button[@data-toggle='dropdown']", "mainFrame");
	}

	public void clickTitleToOpenSidePanel() throws Exception {
		SeleniumHelperClass.isClickable(getTitleDropdown(), 10);
		SeleniumHelperClass.click(getTitleDropdown());
	}

	public WebElement getTitleCancelButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//div[@class='modal-dialog modal-md']//div[@class='modal-content']/div[contains(@class,'footer')]//button[1]",
				"mainFrame");
	}

	public WebElement getTitleCloseButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//div[@class='modal-dialog modal-md']//div[@class='modal-content']/div[contains(@class,'header')]//button[1]",
				"mainFrame");
	}

	public void selectTitleFromSidePanel(String title) throws Exception {
		clickTitleToOpenSidePanel();
		WebElement titleElement = SeleniumHelperClass.findWebElementbyXpath(
				"//*[@id='tableWrapper']//div[@role='presentation' and @name='center']//div[@ref='eContainer']/div/div[text()='"
						+ title + "']",
				"mainFrame");
		SeleniumHelperClass.isClickable(titleElement, 10);
		SeleniumHelperClass.click(titleElement);
		SeleniumHelperClass.isClickable(getTitleSelectButton(), 10);
		SeleniumHelperClass.click(getTitleSelectButton());
	}

	public WebElement getPersonDropdown() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//*[contains(@id,'personName')]//following-sibling::span//button[@data-toggle='dropdown']",
				"mainFrame");
	}

	public void clickPersonToOpenSidePanel() throws Exception {
		SeleniumHelperClass.isClickable(getPersonDropdown(), 10);
		SeleniumHelperClass.click(getPersonDropdown());
	}

	public WebElement getPersonSelectButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//div[@class='modal-dialog modal-lg']//div[@class='modal-content']/div[contains(@class,'footer')]//button[2]",
				"mainFrame");
	}

	public WebElement getPersonCancelButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//div[@class='modal-dialog modal-lg']//div[@class='modal-content']/div[contains(@class,'modal-footer')]//button[contains(@class,'btn-secondary')]",
				"mainFrame");
	}

	public WebElement getPersonCloseButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//div[@class='modal-dialog modal-lg']//div[@class='modal-content']//button[@data-testid='slide-panel-close-button']",
				"mainFrame");
	}

	public void selectPersonFromSidePanel(String employeeId) throws Exception {
		clickPersonToOpenSidePanel();
		WebElement personElement = SeleniumHelperClass.findWebElementbyXpath(
				"//*[@id='tableWrapper']//div[@role='presentation' and @name='center']//div[@ref='eContainer']/div/div[3][text()='"
						+ employeeId + "']",
				"mainFrame");
		SeleniumHelperClass.isClickable(personElement, 10);
		SeleniumHelperClass.click(personElement);
		SeleniumHelperClass.isClickable(getPersonSelectButton(), 10);
		SeleniumHelperClass.click(getPersonSelectButton());
	}

	public WebElement getEffectiveStartDate() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//div[@id='positionEffectiveStart']", "mainFrame");
	}

	public String getEffectiveStartDateText() throws Exception {
		return getEffectiveStartDate().getText();
	}

	public WebElement getEffectiveEndDate() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//div[@id='positionEffectiveEnd']", "mainFrame");
	}

	public String getEffectiveEndDateText() throws Exception {
		return getEffectiveEndDate().getText();
	}

	public WebElement getSearchPositionNameInput() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//span[@id='positionsGrid_search_tooltip']//input",
				"mainFrame");
	}

	public void searchPositionNameRedesign(String positionName) throws Exception {
		SeleniumHelperClass.isClickable(getSearchPositionNameInput(), 10);
		getSearchPositionNameInput().sendKeys(positionName);
		getSearchPositionNameInput().sendKeys(Keys.ENTER);
	}

	public ArrayList<HashMap<String, String>> getPositionTable() throws Exception {
		List<WebElement> positionTableRows = SeleniumHelperClass.findWebElementsInXpath(
				"//*[@id='tableWrapper']//div[@ref='centerContainer']//div[@role='rowgroup']/div", "mainFrame");
		ArrayList<HashMap<String, String>> positionTable = new ArrayList<HashMap<String, String>>();
		for (WebElement webElement : positionTableRows) {
			List<WebElement> colName = webElement.findElements(By.xpath(".//div"));
			List<WebElement> cell = webElement.findElements(By.xpath(".//div/div/span"));
			HashMap<String, String> tableData = new HashMap<String, String>();
			for (int i = 0; i <= 3; i++) {
				tableData.put(colName.get(i).getAttribute("col-id").toString(), cell.get(i).getText());
			}
			positionTable.add(tableData);
		}
		return positionTable;
	}

	public void clickFirstRowOfPositionTable() throws Exception {
		WebElement firstRow = SeleniumHelperClass.findWebElementbyXpath(
				"//*[@id='tableWrapper']//div[@ref='centerContainer']//div[@role='rowgroup']/div[1]", "mainFrame");
		SeleniumHelperClass.isClickable(firstRow, 10);
		SeleniumHelperClass.click(firstRow);
	}

	public WebElement getDescriptionPreviewPanel() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//div[@class='modal-dialog modal-sm']//label[@for='Description']/../span", "mainFrame");
	}

	public WebElement getPositionNamePreviewPanel() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//div[@class='modal-dialog modal-sm']//label[@for='Position Name']/../span", "mainFrame");
	}

	public WebElement getTitlePreviewPanel() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//div[@class='modal-dialog modal-sm']//label[@for='Title']/../span", "mainFrame");
	}

	public WebElement getBusinessGroupPreviewPanel() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//div[@class='modal-dialog modal-sm']//label[@for='Business Group']/../span", "mainFrame");
	}

	public WebElement getPersonNamePreviewPanel() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//div[@class='modal-dialog modal-sm']//label[@for='Person Name (Latest)']/../span", "mainFrame");
	}

	public WebElement getSelectedTitlePositionEdit() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//*[@id='title_Title']//following-sibling::span//button[@data-toggle='dropdown']/span[2]/span/div",
				"mainFrame");
	}

	public WebElement getSelectedBusinessGroupPositionEdit() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//*[@for='Business Group']//following-sibling::span//button[@data-toggle='dropdown']/span[2]/span/div",
				"mainFrame");
	}

	public void removeSelectedTitlePositionEdit() throws Exception {
		WebElement selectedTitle = SeleniumHelperClass.findWebElementbyXpath(
				"//*[@id='title_Title']//following-sibling::span//button[@data-toggle='dropdown']/span[2]/span/*[name()='svg']",
				"mainFrame");
		SeleniumHelperClass.isClickable(selectedTitle, 10);
		SeleniumHelperClass.click(selectedTitle);
	}

	public String getMandatoryFieldText() throws Exception {
		return SeleniumHelperClass
				.findWebElementbyXpath("//*[@id='title_Title']//following-sibling::span/span", "mainFrame").getText();
	}

	public WebElement getUploadButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='fixed-header']//span[1]/button", "mainFrame");
	}

	public void clickUploadButton() throws Exception {
		WebElement uploadButton = getUploadButton();
		SeleniumHelperClass.isClickable(uploadButton, 10);
		SeleniumHelperClass.click(uploadButton);
	}

	public WebElement getCsvTemplateFile() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@class='downloadTemplateClass']/span", "mainFrame");
	}

	public void clickCsvTemplateFile() throws Exception {
		WebElement csvTemplateButton = getCsvTemplateFile();
		SeleniumHelperClass.isClickable(csvTemplateButton, 10);
		SeleniumHelperClass.click(csvTemplateButton);
	}

	public WebElement getAddFileButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='position_upload_singleFile']", "mainFrame");
	}

	public void selectFileToUpload(String filePath) throws Exception {
		SeleniumHelperClass.isVisible(getAddFileButton(), 10);
		getAddFileButton().sendKeys(filePath);
	}

	public WebElement getUploadButtonOnUploadPanel() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'modal-dialog modal-sm')]//div[contains(@class,'modal-footer')]/button[contains(@class,'btn-primary')]",
				"mainFrame");
	}

	public void clickUploadButtonOnUploadPanel() throws Exception {
		WebElement uploadButton = getUploadButtonOnUploadPanel();
		SeleniumHelperClass.isClickable(uploadButton, 10);
		SeleniumHelperClass.click(uploadButton);
	}

	public String getToastMessage() throws Exception {
		WebElement toastMsgElement = SeleniumHelperClass.findWebElementbyid("xtoast-container__content", "mainFrame");
		SeleniumHelperClass.isVisible(toastMsgElement, 10);
		return toastMsgElement.getText();
	}

	public WebElement getErrorModal() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'modal-dialog modal-lg')]//span[@id='modalTitleId']", "mainFrame");
	}

	public WebElement getErrorModalFieldValue(String fieldValue) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//div[text()='" + fieldValue + "' and @aria-colindex='2']",
				"mainFrame");
	}

	public WebElement getErrorModalErrorText(String errorText) throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//div[text()='" + errorText + "' and @aria-colindex='3']",
				"mainFrame");
	}

	/**
	 * To validate Error field and it's value in Error Modal
	 */
	public boolean isExpectedErrorModalDisplayed(String sExpectedField, String errorExpectedtext) throws Exception {
		boolean isDisplayed = false;
		if (getErrorModal().isDisplayed()) {
			if (getErrorModalFieldValue(sExpectedField).isDisplayed()
					&& getErrorModalErrorText(errorExpectedtext).isDisplayed())
				isDisplayed = true;
		} else
			isDisplayed = false;
		return isDisplayed;
	}

	public WebElement getErrorModalDownloadButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//div[contains(@class,'modal')]//button[text()='Download']",
				"mainFrame");
	}

	public void clickErrorModalDownloadButton() throws Exception {
		WebElement uploadButton = getErrorModalDownloadButton();
		SeleniumHelperClass.isClickable(uploadButton, 10);
		SeleniumHelperClass.click(uploadButton);
	}

	public ArrayList<String> getErrorCsvFileContent(String csvFile) throws IOException {
		logger.info("FIle path " + csvFile);
		BufferedReader br = new BufferedReader(new FileReader(csvFile));
		String line;
		ArrayList<String> arrList = new ArrayList<String>();
		;
		while ((line = br.readLine()) != null) {
			arrList.add(line);

		}
		br.close();
		return arrList;
	}

	public WebElement errorModalOkBtnRedesign() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//button[text()='Ok']", "mainFrame"));
	}

	public void clickErrorModalOkBtnRedesign() throws Exception {
		WebElement okButton = errorModalOkBtnRedesign();
		SeleniumHelperClass.isClickable(okButton, 10);
		SeleniumHelperClass.click(okButton);
	}

	public WebElement createPositionRadioButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='uploadParams' and @value='CREATE']", "mainFrame");
	}

	public WebElement updatePositionRadioButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='uploadParams' and @value='UPDATE']", "mainFrame");
	}

	public WebElement createAndUpdatePositionRadioButton() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='uploadParams' and @value='CREATE_AND_UPDATE']",
				"mainFrame");
	}

	public void clickCreatePositionRadioButton() throws Exception {
		WebElement button = createPositionRadioButton();
		SeleniumHelperClass.isClickable(button, 10);
		SeleniumHelperClass.click(button);
	}

	public void clickUpdatePositionRadioButton() throws Exception {
		WebElement button = updatePositionRadioButton();
		SeleniumHelperClass.isClickable(button, 10);
		SeleniumHelperClass.click(button);
	}

	public void clickCreateAndUpdatePositionRadioButton() throws Exception {
		WebElement button = createAndUpdatePositionRadioButton();
		SeleniumHelperClass.isClickable(button, 10);
		SeleniumHelperClass.click(button);
	}

	public void clickEditPageVersionsButton() throws Exception {
		logger.info("Start Clicking the Versions button on Edit Position Page.");
		WebElement button = getEditPositionPageVersionsButton();
		SeleniumHelperClass.isClickable(button, 10);
		SeleniumHelperClass.click(button);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		logger.info("Successfully Clicked on the Versions button on Edit Position Page.");
	}

	public WebElement getVersionThreeDotsBasedonindex(String index) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@id='" + index
						+ "_subHeading']/parent::div/following-sibling::div/div/button//*[local-name()='svg']",
				"mainFrame"));
	}

	public WebElement getVersionThreeDotsBasedonindexbutton(String index) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@id='" + index + "_subHeading']/parent::div/following-sibling::div/div/button", "mainFrame"));
	}

	public WebElement getVersionPageAuditOrDeleteButton(String option) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[contains(@class,'dropdown show')]//div//descendant::button/span[text()='" + option + "']",
				"mainFrame"));
	}

	// To click on the Audit or delete button for each version
	public void addversionClickOnThreeDotsWithSelectingAuditOrDelete(String index, String option) throws Exception {
		logger.info("Start clicking on the " + option + " of the Versions Side panel of Edit Position Page.");
		SeleniumHelperClass.moveToElement(getVersionThreeDotsBasedonindex(index));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN / 2);
		SeleniumHelperClass.waitUntilElementDisplayed(getVersionThreeDotsBasedonindexbutton(index), 30);
		SeleniumHelperClass.click(getVersionThreeDotsBasedonindexbutton(index));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		SeleniumHelperClass.click(getVersionPageAuditOrDeleteButton(option));
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX * 2);
		logger.info("Successfully clicked on the " + option + " of the Versions Side panel of Edit Position Page.");
	}

	public String getauditVersionSliderHeader() throws Exception {
		logger.info("Get the Header of the Audit Version Slider panel.");
		return SeleniumHelperClass.findWebElementbyid("modalTitleId", "mainFrame").getText();
	}

	public String getauditVersionAllResultText() throws Exception {
		logger.info("Get the All Results Text of the Audit Version Slider panel.");
		return SeleniumHelperClass
				.findWebElementbyXpath("(//*[@id='fixed-header'])[2]//div[@class='d-flex align-center']", "mainFrame")
				.getText();
	}

	public WebElement auditVersionCancelButton() throws Exception {
		logger.info("Get the Cancel button of the Audit Version Slider panel.");
		return SeleniumHelperClass
				.findWebElementbyXpath("//div[@role='document']//button[text()='Cancel']", "mainFrame");
	}

	public WebElement auditVersionCrossButton() throws Exception {
		logger.info("Get the Cross button of the Audit Version Slider panel.");
		return SeleniumHelperClass
				.findWebElementbyXpath("//button[@data-testid='slide-panel-close-button']", "mainFrame");
	}

	public WebElement auditVersionDownloadButton() throws Exception {
		logger.info("Get the Download button of the Audit Version Slider panel.");
		return SeleniumHelperClass
				.findWebElementbyXpath("//*[@id='0' and text()='Download']", "mainFrame");
	}

	public void clickAuditVersionDownloadButton() throws Exception {
		logger.info("Click the Download button of the Audit Version Slider panel.");
		SeleniumHelperClass.isClickable(auditVersionDownloadButton(), 3);
		SeleniumHelperClass.click(auditVersionDownloadButton());
		logger.info("Successfully clicked the Download button of the Audit Version Slider panel.");
	}

	public HashMap<String, String> auditVersionRowData(int rowNum) throws Exception {
		logger.info("Get the audit row data for " + (rowNum + 1) + " row from the Audit Version Slider panel.");
		ArrayList<String> columnIdList = new ArrayList<String>(Arrays.asList("modifiedBy", "positionName",
				"effectiveStart", "effectiveEnd", "action", "modifiedField", "previousValue", "newValue"));
		HashMap<String, String> tableData = new HashMap<String, String>();
		String colData = "";
		for (String colId : columnIdList) {
			WebElement colNameElement = SeleniumHelperClass.findWebElementsInXpath(
					"(//div[@id='myGrid']//div[@name='center']//div[@role='row']/div[@col-id='" + colId + "'])",
					"mainFrame").get(rowNum);
			colData = colNameElement.getText();
			colNameElement.click();
			Actions act = new Actions(SetWebDrivers.getDriver());
			act.sendKeys(Keys.TAB).build().perform();
			tableData.put(colId, colData);
			logger.info(colId + " : " + colData);
		}

		logger.info("tableData size: " + tableData.size());
		return tableData;
	}

	public ArrayList<HashMap<String, String>> positionAuditVersionTableData() throws Exception {
		logger.info("Get the audit table data from the Audit Version Slider panel.");
		ArrayList<HashMap<String, String>> auditVersionDataTable = new ArrayList<HashMap<String, String>>();

		int rows = SeleniumHelperClass.findWebElementsInXpath(
				"//div[@id='myGrid']//div[@name='center']//div[@role='rowgroup']/div", "mainFrame").size();
		logger.info("Total Audit table rows : " + rows);

		for (int i = 0; i < rows; i++) {
			auditVersionDataTable.add(auditVersionRowData(i));
		}

		SeleniumHelperClass.findWebElementbyXpath(
						"//div[@role='columnheader' and @col-id='newValue']//div[@class='ag-header-cell-label']", "mainFrame")
				.click();
		Actions act = new Actions(SetWebDrivers.getDriver());
		act.sendKeys(Keys.TAB).build().perform();
		return auditVersionDataTable;
	}

	public ArrayList<String> getAuditVersionsHeadersList() throws Exception {
		logger.info("Get the Column Headers list from the Audit Version Slider panel.");
		ArrayList<String> columnIdList = new ArrayList<String>(
				Arrays.asList("modifiedDate", "modifiedBy", "positionName", "effectiveStart", "effectiveEnd", "action",
						"modifiedField", "previousValue", "newValue"));
		ArrayList<String> columnNameList = new ArrayList<String>();
		String colName = "";
		for (String colId : columnIdList) {
			WebElement colNameElement = SeleniumHelperClass.findWebElementbyXpath(
					"//div[@role='columnheader' and @col-id='" + colId + "']//div[@class='ag-header-cell-label']",
					"mainFrame");
			colName = colNameElement.getText();
			colNameElement.click();
			Actions act = new Actions(SetWebDrivers.getDriver());
			act.sendKeys(Keys.TAB).build().perform();
			columnNameList.add(colName);
		}
		SeleniumHelperClass.findWebElementbyXpath(
				"//div[@role='columnheader' and @col-id='modifiedDate']//div[@class='ag-header-cell-label']",
				"mainFrame").click();

		return columnNameList;
	}

	/**
	 * Verify method to create position with all the fields and business group search functionality.
	 * @param posName
	 * @param title
	 * @param person
	 * @param businessGroupValue
	 * @param saveOption
	 * @throws Exception
	 */
	public void createPositionWithALlTheFieldsWithBusinessGroupSearch(String posName, String title,String person, String businessGroupValue,
																	  String saveOption) throws Exception {
		if (!posName.isEmpty()) {
			clearAndSend(getPositionInputFields("Position Name"), posName);
		}
		if (!title.isEmpty()) {
			selectFromSlider(returnTitleInput(), returnSliderPageInputFieldXpath(), title, "mainframe");
		}
		if (!businessGroupValue.isEmpty()) {
			selectValueFromSliderWithSearch(businessGroupValue, true);
		}
		if (!person.isEmpty()) {
			selectFromSlider(returnPositionInput(), returnSliderPageInputFieldXpath(), person, "mainframe");
		}

		getPeopleRedesignSaveOptionsFromDropdownWithWait(saveOption);
	}

	public void selectValueFromSliderWithSearch(String selectValue, boolean isSearchfield)
			throws Exception {
		waitInMS(SeleniumHelperClass.system_SpeedlimitMAX);
		logger.info("Switched to slider page");
		waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
		if (isSearchfield ) {

			waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
			boolean status = SeleniumHelperClass.isElementPresent("xpath",
					"//div[@class='floating-icons-wrapper']/child::button[2]//*[local-name()='svg']");
			if (status) {
				SeleniumHelperClass.click(getBusinessGroupElipseButton());
			}
			businessGroupSliderSearch().sendKeys(selectValue);
			WebElement searchButton = businessGroupSliderSearchIcon();
			SeleniumHelperClass.waitForElmentToBeReady(searchButton);
			searchButton.click();
			waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
			SeleniumHelperClass.click(getSliderRow(selectValue));
			waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);

		} else {
			SeleniumHelperClass.click(getBusinessGroupElipseButton());
			SeleniumHelperClass.scrollElementIntoViewUsingJS(getSliderRow(selectValue));
			SeleniumHelperClass.waitForElmentToBeReady(getSliderRow(selectValue));
			SeleniumHelperClass.click(getSliderRow(selectValue));
			waitInMS(SeleniumHelperClass.system_SpeedlimitMIN);
		}
		SeleniumHelperClass.click(get_AdvanceSearch_SliderSelectButton());
	}
}