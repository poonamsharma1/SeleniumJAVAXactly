package com.xactly.incent.organization;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.ListIterator;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.xactly.icm.xtoolkit.service.XService;
import com.xactly.icm.xtoolkit.wso.DeleteResponse;
import com.xactly.icm.xtoolkit.wso.ErrorCode;
import com.xactly.icm.xtoolkit.wso.PersonWSO;
import com.xactly.icm.xtoolkit.wso.PositionHierarchyTypeWSO;
import com.xactly.icm.xtoolkit.wso.PositionHierarchyWSO;
import com.xactly.icm.xtoolkit.wso.PositionWSO;
import com.xactly.icm.xtoolkit.wso.SearchResponse;
import com.xactly.icm.xtoolkit.wso.TitleWSO;
import com.xactly.icm.xtoolkit.wso.UploadRequest;
import com.xactly.icm.xtoolkit.wso.UploadResponse;
import com.xactly.icm.xtoolkit.wso.UploadXObjectResponse;
import com.xactly.icm.xtoolkit.wso.XObject;
import com.xactly.icm.xtoolkit.wso.XObjectErrorCode;

public class UploadsValidations {
	public static Logger logger = Logger.getLogger(UploadsValidations.ObjectType.class.getName());
	public enum ObjectType { PEOPLE, POSITION, HIERARCHY, NAMED_RELATIONSHIP};
	public enum UploadMode { CREATE, UPDATE, CREATEUPDATE };
	ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
	private File uploadFile;
	private String filePath;
	private List<TitleWSO> titleWSOList ;
	private List<PersonWSO> peopleWSOList;
	private List<PositionWSO> positionsWSOList;
	String objTypeForUpload = "";
	MyUploadsItems ui = new MyUploadsItems();
	

	/**
	 * uploads the file using connect api 
	 * @param obj ObjectType Enum of different object types for upload
	 * @param fileName name of the file to be uploaded
	 * @param service
	 * @param uploadMode Enum indicating its create, update or create&update mode
	 * @throws Exception
	 */
	public void uploadObject(ObjectType obj, String fileName, XService service, UploadMode uploadMode) throws Exception {
		uploadFile = getUploadFileAndsetObjectType(obj, fileName);
		UploadResponse uploadResponse = getUploadResponse(uploadFile, service, uploadMode);
		boolean isSucceed = true;
		isSucceed = ui.isUploadSuceed(isSucceed, uploadResponse);
		Assert.assertTrue(isSucceed, "Exception occurred while Uploading "+uploadFile.getName()+" file");
	}
	
	/**
	 * upload file method for negative test scenarios which returns the error messages from the upload response
	 * To be used when we are expecting error in uploading Objects(i.e ErrorCode will not be empty)
	 * @param obj ObjectType Enum of different object types for upload
	 * @param fileName fileName name of the file to be uploaded
	 * @param service
	 * @param uploadMode Enum indicating its create, update or create&update mode
	 * @return error messages
	 * @throws Exception
	 */
	public String uploadObjectToVerifyError(ObjectType obj, String fileName, XService service, UploadMode uploadMode)throws Exception{
		uploadFile = getUploadFileAndsetObjectType(obj, fileName);
		UploadResponse uploadResponse = getUploadResponse(uploadFile, service, uploadMode);
		ErrorCode[] errorCodes = uploadResponse.getErrorCodes();
		//logger.info(errorCodes.length);
		if(errorCodes.length==1)
			return errorCodes[0].getReason();
		else
		{
			String errorMessagesList = "";
			for (int i = 0; i < errorCodes.length; i++) {
				/*ErrorCode ec = errorCodes[i];
				logger.info("Error Code: " + ec.getCode() + "\n");
				logger.info("Error Text: " + ec.getReason() + "\n");
				logger.info("Stack: " + ec.getStackTrace() + "\n");*/
				errorMessagesList = errorMessagesList +"\n"+ errorCodes[i].getReason();
			}
			return errorMessagesList;
		}
	}
		
	/**
	 * Returns a File object from the filename provided and sets the Object type to be used later on during upload
	 * @param obj ObjectType Enum of different object types for upload
	 * @param fileName name of the file to be uploaded
	 * @return File for uploading
	 */
	public File getUploadFileAndsetObjectType(ObjectType obj, String fileName){
		String folderName = "";
		switch (obj) {
		case PEOPLE: {
			objTypeForUpload = "PersonXLSX";
			folderName = "PeopleUpload";
			break;
		}
		case POSITION: {
			objTypeForUpload = "Position";
			folderName = "PositionsUpload";
			break;
		}
		case HIERARCHY: {
			objTypeForUpload = "HIERARCHY";
			folderName = "HierarchyUpload";
			break;
		}
		case NAMED_RELATIONSHIP: {
			objTypeForUpload = "";
			folderName = "";
			break;
		}
		}
		
		classLoader = this.getClass().getClassLoader();
		filePath = classLoader.getResource("com.xactly.incent.organization//"+folderName+"//" + fileName).getFile();
		uploadFile = new File(filePath);
		return uploadFile;
	}
	
	
	/**
	 * uploads the file provided thru connect api and return the response
	 * @param uploadFile File object of the file to be uploaded
	 * @param service
	 * @param uploadMode Enum indicating its create, update or create&update mode
	 * @return upload response
	 * @throws Exception
	 */
	public UploadResponse getUploadResponse(File uploadFile, XService service, UploadMode uploadMode) throws Exception{
		boolean create = true;
		boolean update = true;
		switch (uploadMode) {
		case CREATE: {
			update = false;
			break;
		}
		case UPDATE: {
			create = false;
			break;
		}
		case CREATEUPDATE: {
			break;
		}
		}
		byte[] fileBytes = ui.getBytesFromFile(uploadFile);		
		UploadResponse uploadResponse = service.upload(fileBytes, objTypeForUpload, create, update);
		return uploadResponse;
	}
	
	/**
	 * verify the people uploaded through search connect api using the same file used during upload
	 * @param fileName name of the file to be uploaded
	 * @param service
	 * @throws Exception
	 */
	public void verifyUploadedPeople(String fileName, XService service) throws Exception{
		//here uploadFile is initialized previously during uploadObject
		logger.info("Searching contents in File : "	+ uploadFile.getName());
		peopleWSOList  = new ArrayList<PersonWSO>();
		peopleWSOList = ui.createPersonWSO(uploadFile);
		logger.info("No of items in people upload file------------->"+peopleWSOList.size());		
		Assert.assertTrue(peopleWSOList.size() > 0, "No data in People file");
		SoftAssert sa = new SoftAssert();
		for (PersonWSO personWSO : peopleWSOList) {
			try{
				SearchResponse searchResponse = service.search(personWSO);
				sa.assertTrue(searchResponse.getSize() > 0, "Search Failed for "+personWSO.getFirstName());
				logger.info("Search successful for person "+personWSO.getFirstName());
			}
			catch(Exception e){
				sa.fail("Search Failed for person "+personWSO.getFirstName()+" with "+e.getMessage());
			}
		}
		sa.assertAll();
	}
	
	/**
	 * verify the position uploaded through search connect api using the same file used during upload
	 * @param fileName name of the file to be uploaded
	 * @param service
	 * @throws Exception
	 */
	public void verifyUploadedPosition(String fileName, XService service) throws Exception{
		//here uploadFile is initialized previously during uploadObject
		logger.info("Searching contents in File : "	+ uploadFile.getName());
		positionsWSOList = ui.createPositionWSO(uploadFile);
		logger.info("No of items in position upload file------------->"+positionsWSOList.size());		
		Assert.assertTrue(positionsWSOList.size() > 0, "No data in Position file");
		SoftAssert sa = new SoftAssert();
		for (PositionWSO positionWSO : positionsWSOList) {
			try{
				SearchResponse searchResponse = service.search(positionWSO);
				//logger.info("search size " +searchResponse.getSize());
				sa.assertTrue(searchResponse.getSize() > 0, "Search Failed for "+positionWSO.getName());
			}
			catch(Exception e){
				sa.fail("Search Failed for position "+positionWSO.getName()+" with "+e.getMessage());
			}
		}
		sa.assertAll();
	}
	
	
	
	
	/**
	 * uploads the given excel file of People and creates a PersonWSO object for each person with all details mentioned in the excel
	 * @param obj ObjectType Enum of different object types for upload
	 * @param fileName name of the file to be uploaded
	 * @param service
	 * @param mode
	 * @return PersonWSO
	 * @throws Exception
	 */
	public PersonWSO uploadAndCreatePersonWSO(ObjectType obj, String fileName, XService service, UploadMode mode)throws Exception{
		PersonWSO p = new PersonWSO();
		uploadObject(ObjectType.PEOPLE, fileName, service, mode);
		List<PersonWSO> pList = ui.createPersonWSOWithAllData(uploadFile);
		if (pList.size()>1)
			Assert.fail("More than one Person found in the uploaded File!");
		else
			p = pList.get(0);
		return p;
	}
	
	/**
	 * This method takes an array of PersonWSO objects which are in a particular order so as to match the search records order from search response
	 * Then each element from two arrays are compared for all details after downcasting the XObject to PersonWSO
	 * Using SoftAssert ensures all person's all values are compared before throwing exception
	 * @param uploadedPersons
	 * @param service
	 * @throws Exception
	 */
	public void verifyMultiplePeopleVersions(PersonWSO[] uploadedPersons, XService service) throws Exception{
		PersonWSO personToSearch = ui.createPersonWSOWithEmployeeId(uploadedPersons[0].getEmployeeId());
		SearchResponse searchResponse = service.search(personToSearch);
		XObject[] searchedPersons = searchResponse.getSearchRecords();
		logger.info("searched "+searchedPersons.length+" & uploaded "+uploadedPersons.length);
		if(uploadedPersons.length == searchedPersons.length){
			SoftAssert sa = new SoftAssert();
			for(int i=0; i<uploadedPersons.length;i++){
				XObject x = searchedPersons[i];
				if(x instanceof PersonWSO) {
					PersonWSO p = (PersonWSO)x;
					assertPersonMatch(p, uploadedPersons[i], sa);
				}
				else
					Assert.fail("This is not an instance of PersonWSO!");
			}
			sa.assertAll();
		}
		else
			Assert.fail("The no of people versions do not match with search record!");
		
	}
	
	/**
	 * This method takes in two PersonWSO objects and compares all values
	 * More fields can be added for comparison
	 * Date field in particular cannot be compared directly, hence we are verifying day, month and year(Null or start of time here refers to 1stjan1970, hence compared to that)
	 * @param searchedPerson
	 * @param uploadedPerson
	 * @param sa
	 * @throws Exception
	 */
	public void assertPersonMatch(PersonWSO searchedPerson, PersonWSO uploadedPerson, SoftAssert sa) throws Exception{
		String errMsg = " is not matching for version "+searchedPerson.getVersion();
		sa.assertEquals(searchedPerson.getEmployeeId(), uploadedPerson.getEmployeeId(), "Employee ID"+errMsg);
		sa.assertEquals(searchedPerson.getRegion(), uploadedPerson.getRegion(), "Region"+errMsg);
		sa.assertEquals(searchedPerson.getPersonalTarget(), uploadedPerson.getPersonalTarget(), "Personal Target"+errMsg);
		sa.assertEquals(searchedPerson.getFirstName(), uploadedPerson.getFirstName(), "First Name"+errMsg);
		sa.assertEquals(searchedPerson.getDescription(), uploadedPerson.getDescription(), "Description"+errMsg);
		
		if(uploadedPerson.getEffectiveStartDate()!= null){
			sa.assertEquals(searchedPerson.getEffectiveStartDate().get(Calendar.YEAR), uploadedPerson.getEffectiveStartDate().get(Calendar.YEAR), "Effective Start Date - Year"+errMsg);
			sa.assertEquals(searchedPerson.getEffectiveStartDate().get(Calendar.MONTH), uploadedPerson.getEffectiveStartDate().get(Calendar.MONTH), "Effective Start Date - Month"+errMsg);
			sa.assertEquals(searchedPerson.getEffectiveStartDate().get(Calendar.DAY_OF_MONTH), uploadedPerson.getEffectiveStartDate().get(Calendar.DAY_OF_MONTH), "Effective Start Date - Day"+errMsg);
		}
		else{
			sa.assertEquals(searchedPerson.getEffectiveStartDate().get(Calendar.YEAR), 1970, "Effective Start Date - Year"+errMsg);
			sa.assertEquals(searchedPerson.getEffectiveStartDate().get(Calendar.MONTH), 0, "Effective Start Date - Month"+errMsg);
			sa.assertEquals(searchedPerson.getEffectiveStartDate().get(Calendar.DAY_OF_MONTH), 1, "Effective Start Date - Day"+errMsg);
		}
	}
	
	/**
	 * uploads the given excel file of Position and creates a PositionWSO object for each person with all details mentioned in the excel
	 * @param obj ObjectType Enum of different object types for upload
	 * @param fileName name of the file to be uploaded
	 * @param service
	 * @param mode Enum indicating its create, update or create&update mode
	 * @return PositionWSO
	 * @throws Exception
	 */
	public PositionWSO uploadAndCreatePositionWSO(String fileName, XService service, UploadMode mode)throws Exception{
		PositionWSO p = new PositionWSO();
		uploadObject(ObjectType.POSITION, fileName, service, mode);
		List<PositionWSO> pList = ui.createPositionWSOWithAllData(filePath);
		if (pList.size()>1)
			Assert.fail("More than one Position found in the uploaded File!");
		else
			p = pList.get(0);
		return p;
	}
	
	/**
	 * This method takes an array of PositionWSO objects which are in a particular order so as to match the search records order from search response
	 * Then each element from two arrays are compared for all details after downcasting the XObject to PositionWSO
	 * Using SoftAssert ensures all Position's all values are compared before throwing exception
	 * @param uploadedPositions
	 * @param service
	 * @throws Exception
	 */
	public void verifyMultiplePositionVersions(PositionWSO[] uploadedPositions, XService service) throws Exception{
		PositionWSO positionToSearch = ui.createPositionWSOWithName(uploadedPositions[0].getName());
		SearchResponse searchResponse = service.search(positionToSearch);
		XObject[] searchedPosition = searchResponse.getSearchRecords();
		logger.info("searched "+searchedPosition.length+" & uploaded "+uploadedPositions.length);
		if(uploadedPositions.length == searchedPosition.length){
			SoftAssert sa = new SoftAssert();
			for(int i=0; i<uploadedPositions.length;i++){
				XObject x = searchedPosition[i];
				if(x instanceof PositionWSO) {
					PositionWSO p = (PositionWSO)x;
					assertPositionMatch(p, uploadedPositions[i], sa);
				}
				else
					Assert.fail("This is not an instance of PositionWSO!");
			}
			sa.assertAll();
		}
		else
			Assert.fail("The no of position versions do not match with search record!");
		
	}
	
	/**
	 * This method takes in two PositionWSO objects and compares all values
	 * More fields can be added for comparison
	 * Date field in particular cannot be compared directly, hence we are verifying day, month and year(Null or start of time here refers to 1stjan1970, hence compared to that)
	 * @param searchedPosition
	 * @param uploadedPosition
	 * @param sa SoftAssert object to collect all assertions before terminating
	 * @throws Exception
	 */
	public void assertPositionMatch(PositionWSO searchedPosition, PositionWSO uploadedPosition, SoftAssert sa) throws Exception{
		String errMsg = " is not matching for version "+searchedPosition.getVersion();
		sa.assertEquals(searchedPosition.getName(), uploadedPosition.getName(), "Position Name"+errMsg);
		sa.assertEquals(searchedPosition.getDescription(), uploadedPosition.getDescription(), "Description"+errMsg);
		if(uploadedPosition.getEffectiveStartDate()!= null){
			sa.assertEquals(searchedPosition.getEffectiveStartDate().get(Calendar.YEAR), uploadedPosition.getEffectiveStartDate().get(Calendar.YEAR), "Effective Start Date - Year"+errMsg);
			sa.assertEquals(searchedPosition.getEffectiveStartDate().get(Calendar.MONTH), uploadedPosition.getEffectiveStartDate().get(Calendar.MONTH), "Effective Start Date - Month"+errMsg);
			sa.assertEquals(searchedPosition.getEffectiveStartDate().get(Calendar.DAY_OF_MONTH), uploadedPosition.getEffectiveStartDate().get(Calendar.DAY_OF_MONTH), "Effective Start Date - Day"+errMsg);
		}
		else{
			sa.assertEquals(searchedPosition.getEffectiveStartDate().get(Calendar.YEAR), 1970, "Effective Start Date - Year"+errMsg);
			sa.assertEquals(searchedPosition.getEffectiveStartDate().get(Calendar.MONTH), 0, "Effective Start Date - Month"+errMsg);
			sa.assertEquals(searchedPosition.getEffectiveStartDate().get(Calendar.DAY_OF_MONTH), 1, "Effective Start Date - Day"+errMsg);
		}
	}
	
	/**
	 * verifies if a particular version of position has a linked person
	 * @param positionWSO position version in question
	 * @param uploadedPerson person to be verified as linked
	 * @param service
	 * @throws Exception
	 */
	public void verifyPersonLinked(PositionWSO positionWSO, PersonWSO uploadedPerson, XService service) throws Exception{
		SoftAssert sa = new SoftAssert();
		PositionWSO requiredVersion = getRequiredPositionVersion(positionWSO, service);
		
		//get person details through position's participant id
		PersonWSO p = new PersonWSO();
		p.setId(requiredVersion.getParticipant());
		SearchResponse searchResponse1 = service.search(p);
		XObject[] searchedPersons = searchResponse1.getSearchRecords();
		sa.assertTrue(searchedPersons.length==1, "Person found from Position search not successful");
		PersonWSO person1 = (PersonWSO)searchedPersons[0];
		
		//get person details through uploaded person
		SearchResponse searchResponse2 = service.search(uploadedPerson);
		XObject[] searchedPersons2 = searchResponse2.getSearchRecords();
		sa.assertTrue(searchedPersons2.length==1, "Uploaded Person search not successful");
		PersonWSO person2 = (PersonWSO)searchedPersons2[0];
		
		sa.assertEquals(person2.getEmployeeId(), person1.getEmployeeId(), "Person not matched!");
		
		sa.assertAll();
	}
	
	/**
	 * verifies if no person is linked to a particular position version
	 * @param positionWSO position version in question
	 * @param service
	 * @throws Exception
	 */
	public void verifyPersonDelinked(PositionWSO positionWSO, XService service) throws Exception{
		PositionWSO requiredVersion = getRequiredPositionVersion(positionWSO, service);
		Assert.assertTrue(requiredVersion.getParticipant()==null, "The Position Version still has a person linked!");
	}
	
	/**
	 * searches for positions based on first name of position object provided and 
	 * returns the required version matching the effective start dates(Assumes start date is not Start of Time)
	 * @param uploadedVersion position version in question
	 * @param service
	 * @return
	 * @throws Exception
	 */
	public PositionWSO getRequiredPositionVersion(PositionWSO uploadedVersion, XService service) throws Exception{
		PositionWSO requiredVersion = null;
		SoftAssert sa = new SoftAssert();
		PositionWSO positionToSearch = ui.createPositionWSOWithName(uploadedVersion.getName());
		SearchResponse sr = service.search(positionToSearch);
		XObject[] searchedPosition = sr.getSearchRecords();
		//4 is the no of files/position versions we are uploading
		sa.assertTrue(searchedPosition.length==4, "searched position is not valid");
		for(XObject x: searchedPosition ){
			PositionWSO pos = (PositionWSO)x;
			if((pos.getEffectiveStartDate().get(Calendar.YEAR)== uploadedVersion.getEffectiveStartDate().get(Calendar.YEAR))&& (pos.getEffectiveStartDate().get(Calendar.MONTH)== uploadedVersion.getEffectiveStartDate().get(Calendar.MONTH)) &&(pos.getEffectiveStartDate().get(Calendar.DAY_OF_MONTH)==uploadedVersion.getEffectiveStartDate().get(Calendar.DAY_OF_MONTH))){
				requiredVersion = pos;
			}
		}
		sa.assertTrue(requiredVersion!=null, "Required Version of Position was not found!");
		sa.assertAll();
		return requiredVersion;
	}
	
	/**
	 * gets the UploadXObjectResponse on uploading a hierarchy file
	 * @param fileName name of the file to be uploaded
	 * @param versionName version name to be provided (display name)
	 * @param effectiveStartDate
	 * @param service
	 * @return
	 * @throws Exception
	 */
	public UploadXObjectResponse getHierarchyUploadResponse(String fileName, String versionName, int effectiveStartDate, XService service) throws Exception{
		uploadFile = getUploadFileAndsetObjectType(ObjectType.HIERARCHY, fileName);
		byte[] fileBytes = ui.getBytesFromFile(uploadFile);
		PositionHierarchyTypeWSO hierarchyObj = ui.createPositionHierarchyTypeWSOForUpload(versionName, effectiveStartDate);
		
		UploadRequest uploadRequest = new UploadRequest();
		uploadRequest.setFormat("CSV");
		uploadRequest.setObjectType(objTypeForUpload);

		UploadXObjectResponse uploadResponse = service.uploadXObject(uploadRequest, fileBytes, hierarchyObj);
		return uploadResponse;
	}

	
	/**
	 * uploads the hierarchy file and asserts if it was successful
	 * @param fileName name of the file to be uploaded
	 * @param versionName version name to be provided (display name)
	 * @param effectiveStartDate
	 * @param service
	 * @throws Exception
	 */
	public void uploadHierarchy(String fileName, String versionName, int effectiveStartDate, XService service) throws Exception{
		UploadXObjectResponse uploadResponse = getHierarchyUploadResponse(fileName, versionName, effectiveStartDate, service);
		Assert.assertTrue(uploadResponse.isResult(), "Upload of Hierarchy Failed!");
	}
	
	/**
	 * verifies if the uploaded hierarchy matches the searched hierarchy using the connect APIs
	 * verifies the hierarchy type object is present on search and also if all relationships under it are present
	 * the loop runs in reverse order to search and delete relationships so that we avoid dependency on other positions
	 * all of these are deleted after search
	 * @param fileName name of the file to be uploaded
	 * @param versionName version name to be provided (display name)
	 * @param effectiveStartDate
	 * @param service
	 * @throws Exception
	 */
	public void verifyUploadedHierarchy(String fileName, String versionName, int effectiveStartDate, XService service) throws Exception{
		XObject[] srecords = null;
		PositionHierarchyTypeWSO searchedHierarchyType=null;
		List<PositionHierarchyWSO> hierarchyWSOList = ui.createPositionHierarchyWSO(uploadFile);
		SoftAssert sa = new SoftAssert();
		PositionHierarchyTypeWSO hierarchyTypeObj = ui.createPositionHierarchyTypeWSOForSearch(effectiveStartDate);
		try {
			ListIterator<PositionHierarchyWSO> li = hierarchyWSOList.listIterator(hierarchyWSOList.size());
			// Iterate in reverse.
			while (li.hasPrevious()) {
				PositionHierarchyWSO p1 = li.previous();
				SearchResponse searchResponse = service.search(p1);
				srecords = searchResponse.getSearchRecords();
				sa.assertTrue(srecords!=null&&srecords.length==1, "Search failed for Hierarchy relation "+p1.getToPositionName() + ":" + p1.getFromPositionName());
				PositionHierarchyWSO p2 = (PositionHierarchyWSO) searchResponse.getSearchRecords()[0];
				logger.info(p2.getToPositionName() + ":::::::" + p2.getFromPositionName());
				DeleteResponse delResponse = service.deleteVersion(p2, "deleting");
				sa.assertTrue(delResponse.isResult(), "Unable to delete the relation "+p2.getToPositionName() + ":" + p2.getFromPositionName());
			}
			SearchResponse sr = service.search(hierarchyTypeObj);
			logger.info(sr.getSize());
			srecords = sr.getSearchRecords();
			sa.assertTrue(srecords != null && srecords.length >= 0, "The Hierarchy Tybe Object is null!");
			if(sr.getSize() > 0){
				searchedHierarchyType = (PositionHierarchyTypeWSO) srecords[0];
			}
			
		}
		finally{
			PositionHierarchyTypeWSO toDelete;
			if(searchedHierarchyType!=null)
				toDelete = searchedHierarchyType;
			else
				toDelete = hierarchyTypeObj;
			DeleteResponse delResponse1 = service.deleteVersion(toDelete, "deleting..");
			logger.info(delResponse1.isResult());
			sa.assertTrue(delResponse1.isResult(), "Delete of Hierarchy Type Failed! ");
			sa.assertAll();
		}
	}
	
	/**
	 * verifies the error messages shown by the application on uploading invalid data through the hierarchy upload files
	 * @param fileName name of the file to be uploaded
	 * @param versionName version name to be provided (display name)
	 * @param effectiveStartDate
	 * @param service
	 * @return Error message received from the connect API response's error codes
	 * @throws Exception
	 */
	public String uploadHierarchyToVerifyError(String fileName, String versionName, int effectiveStartDate, XService service) throws Exception{
		UploadXObjectResponse uploadResponse = getHierarchyUploadResponse(fileName, versionName, effectiveStartDate, service);
        XObjectErrorCode[] errorCodes = uploadResponse.getErrorCodes();
		return  errorCodes[0].getReason();
	}
	
	/**
	 * verifies the error message shown when trying to delete an hierarchy relationship in wrong order, i.e it has positions existing under its level
	 * here the loop to verify each relationships runs in the same order as insertion(from csv file)
	 * the hierarchy type must be deleted at the end
	 * @param fileName name of the file to be uploaded
	 * @param versionName version name to be provided (display name)
	 * @param effectiveStartDate
	 * @param service
	 * @param expError String of the error message expected
	 * @return actual error message received from the response
	 * @throws Exception
	 */
	public String verifyHierarchyRelationshipDeletionError(String fileName, String versionName, int effectiveStartDate, XService service, String expError) throws Exception{
		String errorMessage = "";
		PositionHierarchyTypeWSO searchedHierarchyType = null;
		XObject[] srecords = null;
		SoftAssert sa = new SoftAssert();
		uploadHierarchy(fileName, versionName, effectiveStartDate, service);
		PositionHierarchyTypeWSO hierarchyTypeObj = ui.createPositionHierarchyTypeWSOForSearch(effectiveStartDate);
		try {
			SearchResponse sr = service.search(hierarchyTypeObj);
			srecords = sr.getSearchRecords();
			searchedHierarchyType = (PositionHierarchyTypeWSO) srecords[0];
			
			List<PositionHierarchyWSO> hierarchyWSOList = ui.createPositionHierarchyWSO(uploadFile);
			ListIterator<PositionHierarchyWSO> li = hierarchyWSOList.listIterator();
			while (li.hasNext()) {
				PositionHierarchyWSO p1 = li.next();
				SearchResponse searchResponse = service.search(p1);
				srecords = searchResponse.getSearchRecords();
				sa.assertTrue(srecords != null && srecords.length == 1, "Search failed for Hierarchy relation "
						+ p1.getToPositionName() + ":" + p1.getFromPositionName());
				PositionHierarchyWSO p2 = (PositionHierarchyWSO) searchResponse.getSearchRecords()[0];
				DeleteResponse delResponse = service.deleteVersion(p2, "deleting");
				if (!delResponse.isResult())
					sa.assertTrue(delResponse.getErrorCodes()[0].getReason().equals(expError),
							"Upload Hierachy allows delete of relationships in wrong order!");
				sa.assertAll();
			}
		}
		finally{
			DeleteResponse delResponse1 = service.deleteVersion(searchedHierarchyType, "deleting..");
			Assert.assertTrue(delResponse1.isResult(), "Delete of Hierarchy Type Failed! "+searchedHierarchyType.getDisplayName());
		}
		return errorMessage;
		
	}
	

	public UploadXObjectResponse uploadHierarchywithuserInputdate(String fileName, String versionName,String date, int effectiveStartDate, XService service) throws Exception{
		UploadXObjectResponse uploadResponse = getHierarchyUploadResponsewithuserInputdate(fileName, versionName,date, effectiveStartDate, service);
		
		return uploadResponse;
		
	}
	public UploadXObjectResponse getHierarchyUploadResponsewithuserInputdate(String fileName, String versionName,String date, int effectiveStartDate, XService service) throws Exception{
		uploadFile = getUploadFileAndsetObjectType(ObjectType.HIERARCHY, fileName);
		byte[] fileBytes = ui.getBytesFromFile(uploadFile);
		PositionHierarchyTypeWSO hierarchyObj = ui.createPositionHierarchyTypeWSOForUploadwithUserinputDate(versionName, date,effectiveStartDate);
		
		UploadRequest uploadRequest = new UploadRequest();
		uploadRequest.setFormat("CSV");
		uploadRequest.setObjectType(objTypeForUpload);

		UploadXObjectResponse uploadResponse = service.uploadXObject(uploadRequest, fileBytes, hierarchyObj);
		return uploadResponse;
	}
	public boolean verifyHierarchyRelationshipDeletion(String fileName, String versionName, int effectiveStartDate, XService service) throws Exception{
		PositionHierarchyTypeWSO searchedHierarchyType = null;
		XObject[] srecords = null;
		PositionHierarchyTypeWSO hierarchyTypeObj = ui.createPositionHierarchyTypeWSOForSearchwithversionname(versionName,effectiveStartDate);
		try {
			SearchResponse sr = service.search(hierarchyTypeObj);
			srecords = sr.getSearchRecords();
			int len=srecords.length;
			logger.info("lenth is "+len);
			searchedHierarchyType = (PositionHierarchyTypeWSO) srecords[0];
			if (len<=1) {
				logger.info("no delete required");
			}
			else {
			File uploadFile = new File(classLoader.getResource("com.xactly.incent.organization//HierarchyUpload//" + fileName).getFile());
			List<PositionHierarchyWSO> hierarchyWSOList = ui.createPositionHierarchyWSO(uploadFile);
			ListIterator<PositionHierarchyWSO> li = hierarchyWSOList.listIterator();
			while (li.hasNext()) {
				PositionHierarchyWSO p1 = li.next();
				SearchResponse searchResponse = service.search(p1);
				srecords = searchResponse.getSearchRecords();
				PositionHierarchyWSO p2 = (PositionHierarchyWSO) searchResponse.getSearchRecords()[0];
				logger.info(p2.getToPositionName() + ":::::::" + p2.getFromPositionName());
				DeleteResponse delResponse = service.deleteVersion(p2, "deleting");
			}
		}	
		}
		finally{
				
				DeleteResponse delResponse1 = service.deleteVersion(searchedHierarchyType, "deleting..");
				
			}
		return false;
		
		
		
	}
}



