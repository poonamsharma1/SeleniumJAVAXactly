package com.xactly.incent.organization;

import java.net.URL;
import java.util.Calendar;
import java.util.GregorianCalendar;

import com.jayway.restassured.response.Response;
import com.xactly.xcommons.restapi.RestAPIHelperClass;
import org.apache.axis.client.Stub;
import org.apache.log4j.Logger;
import org.testng.asserts.SoftAssert;

import com.xactly.icm.xtoolkit.service.DiscoveryServiceSoapBindingStub;
import com.xactly.icm.xtoolkit.service.XService;
import com.xactly.icm.xtoolkit.service.XServiceServiceLocator;
import com.xactly.icm.xtoolkit.wso.DeleteResponse;
import com.xactly.icm.xtoolkit.wso.ErrorCode;
import com.xactly.icm.xtoolkit.wso.LoginResponse;
import com.xactly.icm.xtoolkit.wso.PersonWSO;
import com.xactly.icm.xtoolkit.wso.SaveResponse;
import com.xactly.icm.xtoolkit.wso.SearchResponse;
import com.xactly.icm.xtoolkit.wso.UserWSO;
import com.xactly.icm.xtoolkit.wso.XObject;
import com.xactly.xcommons.app.LoginToApplication;

public class PeopleAPI {
	public static Logger logger = Logger.getLogger(PeopleAPI.class.getName());
	SoftAssert sassert = new SoftAssert();
	public int year, month ,date;
	public boolean flag;

	public Response logindo;
    public String wsdl_urll = LoginToApplication.symProPath.getProperty("connect.baseURI")+"/icm/services/DiscoveryService";

	public void deletePerson(String username, String password, String DISCOVERY_SERVICE_URL,String empID) throws Exception{
		
		logger.info("Logging in using wsdl URL: "+DISCOVERY_SERVICE_URL);
		XService service = new XServiceServiceLocator().getDiscoveryService(new URL(DISCOVERY_SERVICE_URL));
		((DiscoveryServiceSoapBindingStub) service).setMaintainSession(true);
		LoginResponse response = service.login(username,password, "Incent");
		logger.info("isAuthenticated :" + response.isAuthenticated());
		logger.info("getSessionId :" + response.getSessionId());
		boolean loginStatus=false;
		if (!response.isAuthenticated()) {
			logger.info("Login failed");
			sassert.assertTrue(loginStatus, "Toolkit login has failed");
		} else {
			loginStatus = true;
			sassert.assertTrue(loginStatus, "Toolkit login assertion failed");
			logger.info("Login successful by user "+username);
			((DiscoveryServiceSoapBindingStub) service).clearHeaders();
			String sessionId = response.getSessionId();
			String serverUrl = response.getServerUrl();
			logger.info("serverUrl :" + response.getServerUrl());
			((DiscoveryServiceSoapBindingStub) service)._setProperty(Stub.ENDPOINT_ADDRESS_PROPERTY, serverUrl);
			((DiscoveryServiceSoapBindingStub) service)
					.setHeader(new XServiceServiceLocator().getServiceName().getNamespaceURI(), "SessionId", sessionId);
			((DiscoveryServiceSoapBindingStub) service).setHeader(
					new XServiceServiceLocator().getServiceName().getNamespaceURI(), "UserName", username);
		}

		PersonWSO personWSO = new  PersonWSO();
		personWSO.setEmployeeId(empID);
		DeleteResponse deleteResponse = new  DeleteResponse();
		SearchResponse searchResponse = service.search(personWSO);
		XObject[] srXObjs = searchResponse.getSearchRecords();
		//System.out.println("Count after search by employee ID : "+srXObjs.length);
        if ( srXObjs != null ){
        	personWSO = (PersonWSO)srXObjs[0];
        	deleteResponse = service.delete(personWSO);
        	ErrorCode[] errorCodes = deleteResponse.getErrorCodes();
     	   
        	for (int i = 0; i < errorCodes.length; i++) {
       		  logger.info("Error Code: " + errorCodes[i].getCode() +"\n");
     		  logger.info("Error Text: " + errorCodes[i].getReason() +"\n");
     		  logger.info("Stack: " + errorCodes[i].getStackTrace() +"\n");

            }
     	    logger.info("Expected response : true\n");
    		logger.info("API completed: "+deleteResponse);
    		String resp = deleteResponse.toString();
    	logger.info("Asserting deleted data");
		PersonWSO personWSOafterdel = new  PersonWSO();
		personWSOafterdel.setEmployeeId(empID);
		SearchResponse searchResponseAfterDel = service.search(personWSOafterdel);
		XObject[] srXObjsAfterDel = searchResponseAfterDel.getSearchRecords();
    	sassert.assertNull(srXObjsAfterDel,"Delete person Assertion failed for employee ID: "+empID);
        }
        else if( srXObjs == null ) {
        	logger.info("Unable to find person with emp ID: "+empID);
        	sassert.assertNull(srXObjs,"Delete person failed for employee ID: "+empID);
        	
        }

	}
	
	public void deletePersonIfExists(String username, String password, String DISCOVERY_SERVICE_URL,String empID) throws Exception{
		
		logger.info("Logging in using wsdl URL: "+DISCOVERY_SERVICE_URL);
		XService service = new XServiceServiceLocator().getDiscoveryService(new URL(DISCOVERY_SERVICE_URL));
		((DiscoveryServiceSoapBindingStub) service).setMaintainSession(true);
		LoginResponse response = service.login(username,password, "Incent");
		logger.info("isAuthenticated :" + response.isAuthenticated());
		logger.info("getSessionId :" + response.getSessionId());
		boolean loginStatus=false;
		if (!response.isAuthenticated()) {
			logger.info("Login failed");
			sassert.assertTrue(loginStatus, "Toolkit login has failed");
		} else {
			loginStatus = true;
			sassert.assertTrue(loginStatus, "Toolkit login assertion failed");
			logger.info("Login successful by user "+username);
			((DiscoveryServiceSoapBindingStub) service).clearHeaders();
			String sessionId = response.getSessionId();
			String serverUrl = response.getServerUrl();
			logger.info("serverUrl :" + response.getServerUrl());
			((DiscoveryServiceSoapBindingStub) service)._setProperty(Stub.ENDPOINT_ADDRESS_PROPERTY, serverUrl);
			((DiscoveryServiceSoapBindingStub) service)
					.setHeader(new XServiceServiceLocator().getServiceName().getNamespaceURI(), "SessionId", sessionId);
			((DiscoveryServiceSoapBindingStub) service).setHeader(
					new XServiceServiceLocator().getServiceName().getNamespaceURI(), "UserName", username);
		}

		PersonWSO personWSO = new  PersonWSO();
		personWSO.setEmployeeId(empID);
		DeleteResponse deleteResponse = new  DeleteResponse();
		SearchResponse searchResponse = service.search(personWSO);
		XObject[] srXObjs = searchResponse.getSearchRecords();
        if ( srXObjs != null){
        	personWSO = (PersonWSO)srXObjs[0];
        	deleteResponse = service.delete(personWSO);
        	ErrorCode[] errorCodes = deleteResponse.getErrorCodes();
     	   
        	for (int i = 0; i < errorCodes.length; i++) {
       		  logger.info("Error Code: " + errorCodes[i].getCode() +"\n");
     		  logger.info("Error Text: " + errorCodes[i].getReason() +"\n");
     		  logger.info("Stack: " + errorCodes[i].getStackTrace() +"\n");
            }
     	    logger.info("Expected response : true\n");
		}
        else if  ( srXObjs == null) {
        	logger.info("No object found during search for Employee ID: "+empID);
        	sassert.assertNull(srXObjs,"Assertion of search for employee ID: "+empID+" failed");
        }
		logger.info("API completed: "+deleteResponse);
		String resp = deleteResponse.toString();
	}

	/**
	 * This method searches an already existing person by empid and creates a new version from the effective start date(yy,mm,day)
	 */
	public void addVersion(XService service,String DISCOVERY_SERVICE_URL,String empID,int yy, int mm,int day) throws Exception{

		PersonWSO personWSO = new  PersonWSO();
		personWSO.setEmployeeId(empID);
		SaveResponse saveResponse = new  SaveResponse();
		SearchResponse searchResponse = service.search(personWSO);
		XObject[] srXObjs = searchResponse.getSearchRecords();
		//TimeZone ist = TimeZone.getTimeZone("IST");
		//Calendar effectiveStartDateVersion = Calendar.getInstance(ist);
		Calendar effectiveStartDateVersion = Calendar.getInstance();
		effectiveStartDateVersion.set(yy,mm,day);

		if ( srXObjs != null){
			personWSO = (PersonWSO)srXObjs[0];
			saveResponse=service.addVersion(personWSO, effectiveStartDateVersion);
			System.out.println("Expected response : true\n");
			boolean flag = saveResponse.isResult();
			System.out.println("flag:"+flag);
			ErrorCode[] errorCodes =saveResponse.getErrorCodes();
			if (errorCodes !=null) {
				for (int i = 0; i < errorCodes.length; i++) {
					logger.info("Error Code: " + errorCodes[i].getCode() +"\n");
					logger.info("Error Text: " + errorCodes[i].getReason() +"\n");
					logger.info("Stack: " + errorCodes[i].getStackTrace() +"\n");
				}
				logger.info("Expected response : true\n");
			}
			PersonWSO personWSO2 = new  PersonWSO();
			personWSO2.setEmployeeId(empID);
			SearchResponse searchResponse2= service.search(personWSO2);
			XObject[] srXObjs2 = searchResponse2.getSearchRecords();
			PersonWSO p1=(PersonWSO) srXObjs2[1];
			year = p1.getEffectiveStartDate().get(Calendar.YEAR);
			month = p1.getEffectiveStartDate().get(Calendar.MONTH);
			date=p1.getEffectiveStartDate().get(Calendar.DAY_OF_MONTH);
			}
		else if  ( srXObjs == null) {
			logger.info("No object found during search for Employee ID: "+empID);
		}
		logger.info("API completed: "+saveResponse);
		String resp = saveResponse.toString();
	}

	//deletes a version if it exists
	public Boolean deleteVersion(XService service,String DISCOVERY_SERVICE_URL,String empID) throws Exception{
		String resp=null;
		flag=true;
		PersonWSO personWSO = new  PersonWSO();
		personWSO.setEmployeeId(empID);
		DeleteResponse deleteResponse = new  DeleteResponse();
		SearchResponse searchResponse = service.search(personWSO);
		XObject[] srXObjs = searchResponse.getSearchRecords();

		if ( srXObjs != null ){
			if (srXObjs.length>1)
			{
				personWSO = (PersonWSO)srXObjs[1];
				deleteResponse = service.deleteVersion(personWSO, "Deleting through Connect");
				ErrorCode[] errorCodes = deleteResponse.getErrorCodes();
				for (int i = 0; i < errorCodes.length; i++) {
					logger.info("Error Code: " + errorCodes[i].getCode() +"\n");
					logger.info("Error Text: " + errorCodes[i].getReason() +"\n");
					logger.info("Stack: " + errorCodes[i].getStackTrace() +"\n");
				}
				logger.info("Expected response : true\n");
				logger.info("API completed: "+deleteResponse);
				resp = deleteResponse.toString();
				PersonWSO personWSOafterdel = new  PersonWSO();
				personWSOafterdel.setEmployeeId(empID);
				if(personWSOafterdel.getVersion()!= null) {
					logger.info("Version still exists , version not deleted....");
					flag=false;
				}
			}
			else {
				logger.info("Version does not exists for emp ID: "+empID);	
				flag=true;
			}
		}
		else if( srXObjs == null ) {
			logger.info("Unable to find person with emp ID: "+empID);
		}
		return flag;
	}
	
	/*
	 * 
	 * Auth:bchauhan
	 * 
	 * ANT-653:Toolkit PersonWSO: Save action is able to update "Start of Time" to whatever dates we pass
	 * 
	 * 
	 * */
	


	public void PersonUpdateAction(String wsdl_url,String username, 
			String password,String EffectiveStartDate,String setEmployeeId,
			String setFirstName,String PASSED,String FAILED) throws Exception {
		
		logger.info("Logging in using wsdl URL: "+wsdl_urll);
		String url=wsdl_urll;
		XService service = new XServiceServiceLocator().getDiscoveryService(new URL(url));
		((DiscoveryServiceSoapBindingStub) service).setMaintainSession(true);
		LoginResponse response = service.login(username,password, "Incent");
		logger.info("isAuthenticated :" + response.isAuthenticated());
		logger.info("getSessionId :" + response.getSessionId());
		boolean loginStatus=false;
		if (!response.isAuthenticated()) {
			logger.info("Login failed");
			sassert.assertTrue(loginStatus, "Toolkit login has failed");
		} else {
			loginStatus = true;
			sassert.assertTrue(loginStatus, "Toolkit login assertion failed");
			logger.info("Login successful by user "+username);
			((DiscoveryServiceSoapBindingStub) service).clearHeaders();
			String sessionId = response.getSessionId();
			String serverUrl = response.getServerUrl();
			logger.info("serverUrl :" + response.getServerUrl());
			((DiscoveryServiceSoapBindingStub) service)._setProperty(Stub.ENDPOINT_ADDRESS_PROPERTY, serverUrl);
			((DiscoveryServiceSoapBindingStub) service)
			.setHeader(new XServiceServiceLocator().getServiceName().getNamespaceURI(), "SessionId", sessionId);
			((DiscoveryServiceSoapBindingStub) service).setHeader(
					new XServiceServiceLocator().getServiceName().getNamespaceURI(), "UserName", username);
		}

		java.util.Date EFFECTIVE_START_DATE = new java.util.Date();
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MM/dd/yyyy");
		try {
			EFFECTIVE_START_DATE = sdf.parse(EffectiveStartDate);
			logger.info(EFFECTIVE_START_DATE);
		} catch (java.text.ParseException p) {
			logger.info(p.toString() + "\n");
		}
		Calendar EFFECTIVE_STARTcalender = new GregorianCalendar();
		EFFECTIVE_STARTcalender.setTime(EFFECTIVE_START_DATE);
		PersonWSO personWSO = new PersonWSO();
		personWSO.setEffectiveStartDate(EFFECTIVE_STARTcalender);
		personWSO.setEmployeeId(setEmployeeId);

		SearchResponse searchResponse1 = service.search(personWSO);
		XObject[] srXObjs1 = searchResponse1.getSearchRecords();
		logger.info(personWSO.getEffectiveStartDate());
		logger.info(personWSO.getEffectiveEndDate());
		if (srXObjs1 != null && srXObjs1.length > 0) {
			personWSO = (PersonWSO) srXObjs1[0];

			logger.info("Person Records Returned: " + srXObjs1.length + "\n");
			logger.info("personWSO found: personWSO.getId() = " + personWSO.getId() + "\n");

		} else {
			logger.info("personWSO Not Found: getUser() " + personWSO.getUser() + "\n");
		}

		personWSO.setFirstName(setFirstName);
		personWSO.setEffectiveStartDate(EFFECTIVE_STARTcalender);

		SaveResponse saveResponse = service.saveVersion(personWSO);

		logger.info("Service Result: " + saveResponse.isResult() + "\n");

		if (saveResponse.isResult()) {
			logger.info(PASSED);

		} else {
			ErrorCode[] errorCodes = saveResponse.getErrorCodes();
			if (errorCodes != null)

			{

				for (int i = 0; i < errorCodes.length; i++) {
					logger.info("errorCode: " + errorCodes[i].getCode() + "\n");
					logger.info("errorMsg: " + errorCodes[i].getReason() + "\n");
					logger.info("Stack Trace: " + errorCodes[i].getStackTrace() + "\n");
				}
			}

			logger.info(FAILED);
		}
	}


	public Calendar PersonEffectiveStartDate(String wsdl_url,String username, 
			String password,String EffectiveStartDate,String EmpId,String PASSED,String FAILED) throws Exception {

		logger.info("Logging in using wsdl URL: "+wsdl_urll);
		String url=wsdl_urll;
		XService service = new XServiceServiceLocator().getDiscoveryService(new URL(url));
		((DiscoveryServiceSoapBindingStub) service).setMaintainSession(true);
		LoginResponse response = service.login(username,password, "Incent");
		logger.info("isAuthenticated :" + response.isAuthenticated());
		logger.info("getSessionId :" + response.getSessionId());
		boolean loginStatus=false;
		if (!response.isAuthenticated()) {
			logger.info("Login failed");
			sassert.assertTrue(loginStatus, "Toolkit login has failed");
		} else {
			loginStatus = true;
			sassert.assertTrue(loginStatus, "Toolkit login assertion failed");
			logger.info("Login successful by user "+username);
			((DiscoveryServiceSoapBindingStub) service).clearHeaders();
			String sessionId = response.getSessionId();
			String serverUrl = response.getServerUrl();
			logger.info("serverUrl :" + response.getServerUrl());
			((DiscoveryServiceSoapBindingStub) service)._setProperty(Stub.ENDPOINT_ADDRESS_PROPERTY, serverUrl);
			((DiscoveryServiceSoapBindingStub) service)
			.setHeader(new XServiceServiceLocator().getServiceName().getNamespaceURI(), "SessionId", sessionId);
			((DiscoveryServiceSoapBindingStub) service).setHeader(
					new XServiceServiceLocator().getServiceName().getNamespaceURI(), "UserName", username);
		}


		java.util.Date EffectiveStartDate1 = new java.util.Date();
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MM/dd/yyyy");
		try {
			EffectiveStartDate1 = sdf.parse(EffectiveStartDate);
			logger.info(EffectiveStartDate);
		} catch (java.text.ParseException p) {
			logger.info(p.toString() + "\n");
		}

		Calendar EFFECTIVE_STARTcalender = new GregorianCalendar();
		EFFECTIVE_STARTcalender.setTime(EffectiveStartDate1);
		PersonWSO personWSO = new PersonWSO();
		UserWSO userWSO = new UserWSO();
		personWSO.setEmployeeId(EmpId);
		logger.info("getting effective date"+personWSO.getEffectiveStartDate());
		return EFFECTIVE_STARTcalender;

	}

	public String deletePeopleAPI(String employeeID) throws Exception{

		RestAPIHelperClass rest = new RestAPIHelperClass();

		String endPointUrl = "/xicm/metadata/v1/persons/" + employeeID;

		logger.info("delete people endpoint URL "+endPointUrl);
		String resp = rest.deleteRestAPI(endPointUrl);

		return resp.toString();

	}
}
