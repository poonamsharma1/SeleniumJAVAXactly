package com.xactly.incent.organization;

import java.util.List;

public class ChangePositionWSO {

	private String changePositionToggleName;
	
	private String effectiveStartDate;

	private String effectiveEndDate;

	private String newPositionName;
	
	private String title;

	private String businessGroup;

	private String warningMessage;

	private List<AffectedPositionWSO> affectedPositionWSOList;

	public String getChangePositionToggleName() {
		return changePositionToggleName;
	}

	public void setChangePositionToggleName(String changePositionToggleName) {
		this.changePositionToggleName = changePositionToggleName;
	}
	
	public String getEffectiveStartDate() {
		return effectiveStartDate;
	}

	public void setEffectiveStartDate(String effectiveStartDate) {
		this.effectiveStartDate = effectiveStartDate;
	}

	public String getEffectiveEndDate() {
		return effectiveEndDate;
	}

	public void setEffectiveEndDate(String effectiveEndDate) {
		this.effectiveEndDate = effectiveEndDate;
	}

	public String getNewPositionName() {
		return newPositionName;
	}

	public void setNewPositionName(String positionName) {
		this.newPositionName = positionName;
	}
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getBusinessGroup() {
		return businessGroup;
	}

	public void setBusinessGroup(String businessGroup) {
		this.businessGroup = businessGroup;
	}

	public String getWarningMessage() {
		return warningMessage;
	}

	public void setWarningMessage(String warningMessage) {
		this.warningMessage = warningMessage;
	}

	public List<AffectedPositionWSO> getAffectedPositionWSOList() {
		return affectedPositionWSOList;
	}

	public void setAffectedPositionWSOList(List<AffectedPositionWSO> affectedPositionWSOList) {
		this.affectedPositionWSOList = affectedPositionWSOList;
	}
}

class AffectedPositionWSO {

	private String positionName;

	private String personName;

	private String action;

	private String currentValue;

	private String newValue;
	
	public String getPositionName() {
		return positionName;
	}

	public void setPositionName(String positionName) {
		this.positionName = positionName;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getCurrentValue() {
		return currentValue;
	}

	public void setCurrentValue(String currentValue) {
		this.currentValue = currentValue;
	}

	public String getNewValue() {
		return newValue;
	}

	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}
}
