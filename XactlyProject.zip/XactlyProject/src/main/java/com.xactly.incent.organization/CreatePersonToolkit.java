package com.xactly.incent.organization;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.log4j.Logger;

import com.xactly.icm.xtoolkit.service.XService;
import com.xactly.icm.xtoolkit.wso.BusinessGroupWSO;
import com.xactly.icm.xtoolkit.wso.CustomField;
import com.xactly.icm.xtoolkit.wso.ErrorCode;
import com.xactly.icm.xtoolkit.wso.PersonWSO;
import com.xactly.icm.xtoolkit.wso.SaveResponse;
import com.xactly.icm.xtoolkit.wso.SearchResponse;
import com.xactly.icm.xtoolkit.wso.UnitTypeWSO;
import com.xactly.icm.xtoolkit.wso.UserWSO;
import com.xactly.icm.xtoolkit.wso.VersionReasonTypeWSO;
import com.xactly.icm.xtoolkit.wso.VersionReasonTypeWSOArea;
import com.xactly.icm.xtoolkit.wso.XObject;



/**
 * 
 * @author smohapatra
 * @Date 17 Feb 2020
 */


public class CreatePersonToolkit {

	public static Logger logger = Logger.getLogger(CreatePersonToolkit.class.getName());

	public PersonWSO createPeople(String email, String prefix, String firstName, String middleName, String lastName,
			String employeeId, String region, String hiredate, String terminationDate, String bigDecimal,
			String unitType, String ptunitType, String csName, String csDateType, String csvalue, XService service)
			throws RemoteException {

		PersonWSO personWSO = new PersonWSO();
		UserWSO userWSO = new UserWSO();
		userWSO.setEmail(email);
		logger.info("srXObjs.length: " + userWSO.getEmail());
		SearchResponse searchResponse = service.search(userWSO);
		XObject[] srXObjs = searchResponse.getSearchRecords();
		if (srXObjs != null && srXObjs.length >= 0) {
			userWSO = (UserWSO) srXObjs[0];
			personWSO.setUser(userWSO.getId());
			logger.info("Updated User Information");
		}
		personWSO.setPrefix(prefix);
		personWSO.setFirstName(firstName);
		personWSO.setMiddleName(middleName);
		personWSO.setLastName(lastName);
		personWSO.setEmployeeId(employeeId);
		personWSO.setRegion(region);

		java.util.Date HIRE_DATE = new java.util.Date();
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MM/dd/yyyy");
		try {
			HIRE_DATE = sdf.parse(hiredate);
		} catch (java.text.ParseException p) {
		}
		Calendar HIRE_DATEcalender = new GregorianCalendar();
		HIRE_DATEcalender.setTime(HIRE_DATE);
		personWSO.setHireDate(HIRE_DATEcalender);

		java.util.Date TERMINATION_DATE = new java.util.Date();
		java.text.SimpleDateFormat sdf2 = new java.text.SimpleDateFormat("MM/dd/yyyy");
		try {
			TERMINATION_DATE = sdf2.parse(terminationDate);
		} catch (java.text.ParseException p) {
		}
		Calendar TERMINATION_DATEcalender = new GregorianCalendar();
		TERMINATION_DATEcalender.setTime(TERMINATION_DATE);

		personWSO.setTerminationDate(TERMINATION_DATEcalender);
		personWSO.setPersonalTarget(new BigDecimal(bigDecimal));

		UnitTypeWSO unittypeWSO1 = new UnitTypeWSO();
		unittypeWSO1.setName(unitType);
		SearchResponse searchResponse1 = service.search(unittypeWSO1);
		XObject[] srXObjs1 = searchResponse1.getSearchRecords();
		if (srXObjs1 != null && srXObjs1.length == 1) {
			unittypeWSO1 = (UnitTypeWSO) srXObjs1[0];
		}
		personWSO.setPersonalTargetUnitTypeId(unittypeWSO1.getId());
		UnitTypeWSO unittypeWSO2 = new UnitTypeWSO();
		unittypeWSO2.setName(ptunitType);
		SearchResponse searchResponse2 = service.search(unittypeWSO2);
		XObject[] srXObjs2 = searchResponse2.getSearchRecords();
		if (srXObjs2 != null && srXObjs2.length == 1) {
			unittypeWSO2 = (UnitTypeWSO) srXObjs2[0];
		}
		personWSO.setPaymentCurrencyUnitTypeId(unittypeWSO2.getId());

		VersionReasonTypeWSO versionReasonTypeWSO = new VersionReasonTypeWSO();
		versionReasonTypeWSO.setArea(VersionReasonTypeWSOArea.fromString("Person Version"));
		versionReasonTypeWSO.setType("Hire");

		SearchResponse searchResponse5 = service.search(versionReasonTypeWSO);
		XObject[] srXObjs5 = searchResponse5.getSearchRecords();
		if (srXObjs5 != null && srXObjs5.length > 0) {
			versionReasonTypeWSO = (VersionReasonTypeWSO) srXObjs5[0];
		}

		logger.info("VTID =" + versionReasonTypeWSO.getUuid());

		java.text.SimpleDateFormat sdf3 = new java.text.SimpleDateFormat("MM/dd/yyyy");
		Calendar calendar = Calendar.getInstance();
		CustomField[] customFields = new CustomField[1];
		CustomField customField = new CustomField();
		customField.setName(csName);
		customField.setDataType(csDateType);
		customField.setStringValue(csvalue);
		customFields[0] = customField;

		personWSO.setCustomFields(customFields);

		BusinessGroupWSO businessGroupWSO = new BusinessGroupWSO();
		businessGroupWSO.setName("Default Business Group");
		SearchResponse searchResponse4 = service.search(businessGroupWSO);
		XObject[] srXObjs4 = searchResponse4.getSearchRecords();
		if (srXObjs4 != null && srXObjs4.length == 1) {
			businessGroupWSO = (BusinessGroupWSO) srXObjs4[0];
		}
		personWSO.setBusinessGroupId(businessGroupWSO.getId());

		SaveResponse saveResponse = service.save(personWSO);
		logger.info("Service Result: " + saveResponse.isResult() + "\n");
		logger.info("Passed " + saveResponse.getSavedIds()[0]);
		logger.info("Save User Result: " + saveResponse.isResult() + "\n");
		ErrorCode[] errorCodes = saveResponse.getErrorCodes();
		if (errorCodes != null) {
			for (int i = 0; i < errorCodes.length; i++) {

				logger.info("Error Code: " + errorCodes[i].getCode() + "\n");
				logger.info("Error Msg: " + errorCodes[i].getReason() + "\n");
				logger.info("Stack Trace: " + errorCodes[i].getStackTrace() + "\n");

			}
		}

		if (saveResponse.isResult()) {
			service.search(personWSO);
			logger.info("save successful" + saveResponse);
			return personWSO;
		} else {

			logger.info("save unsuccessful" + saveResponse);
			return null;
		}

	}
}
