package com.xactly.incent.organization;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
//import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.asserts.SoftAssert;

import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.Response;
import com.xactly.incent.navigation.LeftNavigationUtil;
import com.xactly.xcommons.restapi.RestAPIHelperClass;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

/**
 * @author vbalusu
 *
 */
public class Titles {
	public static Logger logger = Logger.getLogger(Titles.class.getName());
	RestAPIHelperClass rest = new RestAPIHelperClass();

	public WebElement get_otitles_link() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("A_Titles", "topFrame"));
	}

	public WebElement get_otitles_link_NewUI() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("ORGANIZATION_NAV-ORGANIZATION_TITLES", "topFrame"));
	}
	
	public WebElement get_otitle_name() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("name_title_edit", "ceditframe"));
	}

	public WebElement get_otitle_pay() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("payPeriodType_title_edit", "ceditframe"));
	}

	public WebElement get_otitle_name_search() throws Exception {
		return (SeleniumHelperClass.findWebElementbyName("Title", "contentframe"));
	}

	public WebElement get_otitle_desc() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("description_title_edit", "ceditframe"));
	}

	public Select get_otitle_category() throws Exception {
		return (SeleniumHelperClass.selectFromDropdown("categoryName_title_edit", "ceditframe"));
	}

	public WebElement get_otitle_save() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("saveButton", "ceditframe"));
	}

	public WebElement get_otitle_save_title() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("menuSave_a_0", "ceditframe"));
	}

	public WebElement get_otitle_search() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("searchButton", "contentframe"));
	}
	
	public WebElement get_otitle_clear() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("clearButton", "contentframe"));
	}

	public WebElement get_otitle_textBox() throws Exception{
		return (SeleniumHelperClass.findWebElementbyName("Title", "contentFrame"));
	}
	
	public WebElement get_otitle_categoryDropdown() throws Exception{
		return (SeleniumHelperClass.findWebElementbyid("category", "contentFrame"));
	}
	
	public WebElement get_otitle_create_title() throws Exception {
		return (SeleniumHelperClass.findWebElementbyLink("Create Title", "MainFrame"));
	}

	public WebElement get_otitle_delete_title() throws Exception {
		return (SeleniumHelperClass.findWebElementbyLink("Delete Title", "MainFrame"));
	}

	public WebElement get_otitle_edit_title() throws Exception {
		return (SeleniumHelperClass.findWebElementbyLink("Edit Title", "MainFrame"));
	}

	public WebElement get_otitle_view_title() throws Exception {
		return (SeleniumHelperClass.findWebElementbyLink("View Title", "MainFrame"));
	}

	public WebElement get_otitle_table() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("tableFixed", "contentframe"));
	}

	public WebElement get_otitle_uploadtitle() throws Exception {
		// return
		// (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='ext-gen127']/span","mainFrame"));
		return (SeleniumHelperClass.findWebElementbyXpath(".//a/span[text()='Upload Title']", "mainFrame"));
	}

	public WebElement get_otitle_audit_title() throws Exception {
		return (SeleniumHelperClass.findWebElementbyLink("Audit Title", "MainFrame"));
	}

	public WebElement getAudit_Name() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//td[3]/div[1]"));
	}

	public WebElement getAudit_Desc() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//td[4]/div[1]"));
	}

	public WebElement getAudit_TitleCategory() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//td[6]/div[1]"));
	}

	public WebElement getTitleUpload_Template() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='ttl']/form/div[2]/a/b", "uploadtitleframe"));
	}
	
	public WebElement getTitleSearch_ResultTotal() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("total", "contentFrame"));
	}

	public void clickPeoplePage() throws Exception {

		SeleniumHelperClass.findWebElementbyid("TAB_MIDDLE_ORGANIZATION_TAB", "TopFrame").click();
		SeleniumHelperClass.findWebElementbyid("A_Titles", "topFrame").click();
		SeleniumHelperClass.acceptAlert();// this is added to handle the alert
											// which comes when we click on the
											// sublinks in organization,Can be
											// removed once dev fix this issue.
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	}
	public List<WebElement> getTitleFieldNames()throws Exception{
		return SeleniumHelperClass.findWebElements("//*[@id='tableFixed']/tbody/tr[1]", "mainFrame");
	}
	public String get_SearchResultCount() throws Exception {
		String count = SeleniumHelperClass.findWebElementbyid("total", "contentFrame").getText();
		count = count.split(":")[1];
		return count.trim();
	}

	public Titles(String testtype) throws Exception {
		if (testtype.equalsIgnoreCase("gui")) {
			new Organization("gui");
			//Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
			SeleniumHelperClass.isVisible(get_otitles_link(),SeleniumHelperClass.system_SpeedlimitMAX*3);
			//SeleniumHelperClass.findWebElementbyid("A_Titles", "topFrame").click();
			get_otitles_link().click();
			//logger.info("Clicked on Titles link");
			//Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
			SeleniumHelperClass.isVisible(get_otitle_create_title(), SeleniumHelperClass.system_SpeedlimitMAX);
			logger.info("Titles constructor done");
		}
		
		else if (testtype.equalsIgnoreCase("gui-new")) {
			new Organization("gui-new");
			SeleniumHelperClass.isVisible(get_otitles_link_NewUI(),SeleniumHelperClass.system_SpeedlimitMAX*3);
			LeftNavigationUtil.clickOnTitleTab();
			SeleniumHelperClass.isVisible(get_otitle_create_title(), SeleniumHelperClass.system_SpeedlimitMAX);
			logger.info("Titles constructor done");
		}
	}

	public Titles() {
	}

	public void createTitle(String name, String desc, String category, String pay) throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_otitle_create_title().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_otitle_name().sendKeys(name);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_otitle_desc().sendKeys(desc);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_otitle_pay().sendKeys(pay);
		get_otitle_category().selectByVisibleText(category);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		// get_otitle_save().click();
		SeleniumHelperClass.secondaryClick(get_otitle_save());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_otitle_save_title().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	}

	public void searchTitle(String name) throws Exception {
		//Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		SeleniumHelperClass.isVisible(get_otitle_name_search(),SeleniumHelperClass.system_SpeedlimitMAX*4);
		get_otitle_name_search().clear();
		get_otitle_name_search().sendKeys(name);
		SeleniumHelperClass.isVisible(get_otitle_search(), 10);
		//Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*2);
		get_otitle_search().click();
		SeleniumHelperClass.isVisible(get_otitle_table(), SeleniumHelperClass.system_SpeedlimitMAX*4);
		logger.info("Search result count: "+Integer.parseInt(get_SearchResultCount()));

	}

	public void deleteFirstTitle(String name) throws Exception {
		searchTitle(name);
		logger.info("Search is completed, now deleting");
		if (Integer.parseInt(get_SearchResultCount()) > 0) {
			SeleniumHelperClass.click(SeleniumHelperClass.findWebElementbyCssSelector("#listTable_search_list > tr", "contentFrame"));
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
			SeleniumHelperClass.click(get_otitle_delete_title());
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
			SeleniumHelperClass.AcceptAlerts("Do you really want to delete the selected item?");
		}
	}

	public void deleteTitle(String name) throws Exception {
		//logger.info("Delete main started");
		SeleniumHelperClass.isVisible(get_otitle_name_search(), SeleniumHelperClass.system_SpeedlimitMAX*2);
		//logger.info("Search in delete started");
		logger.info("Deleting title name: "+name);
		searchTitle(name);
		//logger.info("Search in delete completed");
		SeleniumHelperClass.waitForElmentToBeReady(getTitleTable("Title", 1));
		SeleniumHelperClass.isVisible(getTitleTable("Title", 1), SeleniumHelperClass.system_SpeedlimitMAX*5);
		getTitleTable("Title", 1).click();
		//logger.info("Click on Title table entry in delete completed");
		SeleniumHelperClass.isVisible(get_otitle_delete_title(), SeleniumHelperClass.system_SpeedlimitMAX*4);
		//Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_otitle_delete_title().click();
		//logger.info("Click on Delete title in delete completed");
		SeleniumHelperClass.AcceptAlerts("Do you really want to delete the selected item?");
		logger.info("Alert accepted in Delete");
		//Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);

	}
	
	public void deleteTitleWithAssert(String name) throws Exception {
		//logger.info("Delete main started");
		SoftAssert Assert = new SoftAssert();
		SeleniumHelperClass.isVisible(get_otitle_name_search(), SeleniumHelperClass.system_SpeedlimitMAX*2);
		//logger.info("Search in delete started");
		logger.info("Deleting title name: "+name);
		searchTitle(name);
		//logger.info("Search in delete completed");
		SeleniumHelperClass.isVisible(getTitleTable("Title", 1), SeleniumHelperClass.system_SpeedlimitMAX*5);
		getTitleTable("Title", 1).click();
		//logger.info("Click on Title table entry in delete completed");
		SeleniumHelperClass.isVisible(get_otitle_delete_title(), SeleniumHelperClass.system_SpeedlimitMAX*4);
		//Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_otitle_delete_title().click();
		//logger.info("Click on Delete title in delete completed");
		SeleniumHelperClass.AcceptAlerts("Do you really want to delete the selected item?");
		logger.info("Alert accepted in Delete");
		SeleniumHelperClass.waitForElmentToBeReady(getTitleSearch_ResultTotal());
		Assert.assertEquals(get_SearchResultCount(), 0,"Delete title assertion failed");

	}

	public void editTitle(String name, String desc, String category, String pay) throws Exception {
		searchTitle(name);
		getTitleTable("Title", 1).click();
		get_otitle_edit_title().click();
		get_otitle_desc().clear();
		get_otitle_desc().sendKeys(desc);
		get_otitle_pay().sendKeys(pay);
		get_otitle_category().selectByVisibleText(category);
		get_otitle_save().click();
		get_otitle_save_title().click();
	}

	public WebElement getTitleTable(String columnName, int rowNum) throws Exception {
		//Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		return (SeleniumHelperClass.getTableData(get_otitle_table(), columnName, rowNum));
	}

	public void uploadTitle(String url) throws Exception {
		SeleniumHelperClass.uploadFiles(get_otitle_uploadtitle(), url, "uploadTitleFrame");
		SeleniumHelperClass.isElementPresent("xpath", "//*[@id=\"ttl\"]/form/div[1]/span/b");
		logger.info("Out of Upload title pop-up");
	}

	public List<String> verifyAuditDetails() throws Exception {
		List<String> Auditdetails = new ArrayList<String>();
		String parentWindow = null;
		try {
			get_otitle_audit_title().click();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
			parentWindow = SeleniumHelperClass.switchToPopupWindow();
			// String AuditName=getAudit_Name().getText();
			// String AuditDescription=getAudit_Desc().getText();

			String AuditTitle = getAudit_Name().getText();
			String Auditdesc = getAudit_Desc().getText();
			String AuditCategory = getAudit_TitleCategory().getText();
			Auditdetails.add(AuditTitle);
			Auditdetails.add(Auditdesc);
			Auditdetails.add(AuditCategory);
			SetWebDrivers.getDriver().close();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);

			SeleniumHelperClass.switchToWindow(parentWindow);
		} catch (Exception e) {
			SeleniumHelperClass.switchToWindow(parentWindow);
		}
		return Auditdetails;

	}

	public List<String> InputElements(String title, String desc, String category) throws Exception {

		List<String> InputDetails = new ArrayList<String>();
		InputDetails.add(title);
		InputDetails.add(desc);
		InputDetails.add(category);
		return InputDetails;
	}

	public WebElement downloadTitles() throws Exception {

		return SeleniumHelperClass.findWebElementbyLink("Download Titles", "mainFrame");
	}

	public void createTitle(String name, String desc, String category) throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_otitle_create_title().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_otitle_name().sendKeys(name);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_otitle_desc().sendKeys(desc);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_otitle_category().selectByVisibleText(category);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		// get_otitle_save().click();
		SeleniumHelperClass.secondaryClick(get_otitle_save());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_otitle_save_title().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	}

	public String getUploadFileLocation(String file) {
		return this.getClass().getClassLoader().getResource(file).getFile();
	}

	public void downloadTemplate(String ARfile, String ARdownloadLoc) throws Exception {
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		logger.info("Parent Window: " + parentWindow);
		get_otitle_uploadtitle().click();
		SeleniumHelperClass.isElementPresent("xpath", "//*[@id=\"ttl\"]/form/div[1]/span/b");
		logger.info("Switching to the Upload Titles Pop-up");
		SeleniumHelperClass.switchToPopupWindow();
		SeleniumHelperClass.isVisible(getTitleUpload_Template(), 10);
		SeleniumHelperClass.isClickable(getTitleUpload_Template(), 10);
		SeleniumHelperClass.moveToElement(getTitleUpload_Template());
		SeleniumHelperClass.clickOnWebElementWithAction(getTitleUpload_Template());
		logger.info("File Download is in progress");
		isFileDownloaded(ARdownloadLoc, ARfile, 60);
		SetWebDrivers.getDriver().close();
		SetWebDrivers.getDriver().switchTo().window(parentWindow);
		logger.info("Out of Upload Title pop-up");
	}

	public boolean isFileDownloaded(String downloc, String fileName,int timeout) { 
		boolean flag = false;
		for(int j = 1 ; j<timeout;j++) {
			File dir = new File(downloc);
			File[] dir_contents = dir.listFiles();
			for (int i = 0; i < dir_contents.length; i++) 
			{
				if (dir_contents[i].getName().equals(fileName)) {
					return flag = true;
				} else
				{
					 flag = false;
				}	
			}
			 try { Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN); } catch(Exception e) {}
			 timeout = timeout-3;
		}
		return flag;
	}


	public String uploadTitleWithRestrictedChars(String url) throws Exception {
		String actualErrorMsg = uploadInvalidDataFiles(get_otitle_uploadtitle(), url, "uploadTitleFrame");
		SeleniumHelperClass.isElementPresent("xpath", "//*[@id=\"ttl\"]/form/div[1]/span/b");
		logger.info("Out of Upload title pop-up");
		return actualErrorMsg;
	}

	public String uploadInvalidDataFiles(WebElement uploadElement, String url, String frame) throws Exception {
		String errorMsg = null;
		String parentWindow = SetWebDrivers.getDriver().getWindowHandle();
		uploadElement.click();
		SeleniumHelperClass.isElementPresent("xpath", "//*[@id=\"ttl\"]/form/div[1]/span/b");
		Set<String> windowHandlers = SetWebDrivers.getDriver().getWindowHandles();
		logger.info(windowHandlers);
		for (String windowHandle : windowHandlers) {
			if (!windowHandle.equals(parentWindow)) {

				SetWebDrivers.getDriver().switchTo().window(windowHandle);
				try {

					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
					SetWebDrivers.getDriver().switchTo().frame(frame);
					WebElement uploadField = SeleniumHelperClass.findWebElementbyXpath("//input[@type='file']");
					uploadField.sendKeys(url);
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);					SeleniumHelperClass.findWebElementbyXpath(".//*[@type='submit']").click();
					Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
					SeleniumHelperClass.isVisible(SeleniumHelperClass.findWebElementbyTagName("body"), 10);
					String bodyText = SeleniumHelperClass.findWebElementbyTagName("body", "").getText();
					logger.info(bodyText);

					if (bodyText.contains("File was uploaded successfully")) {
						logger.info("sync upload was successfull");
						WebElement ok = SeleniumHelperClass.findWebElementbyXpath(".//*[@onclick='done()']");
						ok.click();

					} else if (bodyText.contains(
							"Your upload request is being processed and when completed will appear in the myUploads page.")) {
						logger.info("async upload was successfull");
						SeleniumHelperClass.findWebElementbyXpath(".//*[@type='button']").click();
						/*
						 * WebElement
						 * OK=SeleniumHelperClass.findWebElementbyXpath
						 * (".//*[@onclick='doOk()']"); OK.click();
						 */
						// SeleniumHelperClass.findWebElementbyXpath(".//*[@type='button']").click();
					}

					else if (bodyText.contains("This import process is now running in the background.")) {
						logger.info("Upload was successfull");
						logger.info("File Upload is successfull.");
						SeleniumHelperClass.findWebElementbyXpath(".//*[@type='button']").click();
					}
					errorMsg = bodyText;

				} catch (Exception e) {
					SetWebDrivers.getDriver().switchTo().window(parentWindow);
					throw new Exception(e);
				}

			}
		}
		SetWebDrivers.getDriver().switchTo().window(parentWindow);

		return errorMsg;
	}
	
	/**
	 * This method get the title id form title name 
	 * @param applogin
	 * @param titleName
	 * @return
	 * @throws Exception
	 */
	public long getTitleId(Response applogin, String titleName) throws Exception {
		RestAPIHelperClass resthelper = new RestAPIHelperClass();
		String titleid = resthelper.postHttpRequest(applogin,
				"/xicm/misc.search.do?Description=&Title="+titleName+"&category=&function=&level=&market=&url=organization.title.search.list.do&view=Custom Search");
		String searchTitle = "dn=\""+titleName+"\" di='" ;		
		
		int starttitleindex = titleid.indexOf(searchTitle)
				+ searchTitle.length();
		int endtitleindex = titleid.indexOf("'", starttitleindex);
		titleid = titleid.substring(starttitleindex, endtitleindex);
		logger.info("titleid: " + titleid);
		
		return Long.parseLong(titleid);
	}
	
	public String getTitleList() throws Exception{ 
		String req = "/v1/paycurve/0/assignment/list?assignmentType=TITLE";
		String resp = rest.getRestAPI(req);
		return resp;
	}
	
	public List<Map<String, Object>> getTitlesAsMap() throws Exception {
		
		List<Map<String, Object>> titles = new ArrayList<Map<String, Object>>();
		String getTitlesResponse = getTitleList();
		List<Long>  titleIdList = JsonPath.read(getTitlesResponse, "$..items.assignmentId");
		List<String>  titleNameList = JsonPath.read(getTitlesResponse, "$..items.name");
		logger.info("********************" + titleIdList.size());
		for(int i = 0; i < titleIdList.size(); i++) {
			Map<String, Object> title = new HashMap<String, Object>();
			title.put("titleId", titleIdList.get(i));
			title.put("name", titleNameList.get(i));
			title.put("description", null);
			
			titles.add(title);
		}
		
		return titles;
	}
		
		
	public boolean deleteE2ETitle(String TitleNames) throws Exception {
		Titles title = new Titles(SetWebDrivers.getNavigationType());
		logger.info("Deleting an existing title "+TitleNames);
		title.deleteTitle(TitleNames);
		new Titles("gui");
		title.searchTitle(TitleNames);
		boolean res = getTitleFieldNames().size()>0;
		logger.info("Deleted Title Successfully");
		return res;
		
		

	}

}
