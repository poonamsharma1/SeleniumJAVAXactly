package com.xactly.incent.orders;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;

import com.jayway.jsonpath.JsonPath;
import com.xactly.icm.xtoolkit.wso.ErrorCode;
import com.xactly.icm.xtoolkit.wso.UploadResponse;
import com.xactly.incent.ppa.AdhocAtionsAPIScenarios;
import com.xactly.xcommons.restapi.RestAPIHelperClass;

import net.minidev.json.JSONArray;

public class BGSBatchesAPI {
	
	public static Logger logger = Logger.getLogger(BGSBatchesAPI.class.getName());
	 RestAPIHelperClass rest = new RestAPIHelperClass();
	 OrderStageAPI orderStage = new OrderStageAPI();
	 AdhocAtionsAPIScenarios adhoc = new AdhocAtionsAPIScenarios();

	public void deleteAllBatchesInPeriod(String startPeriodId, String endPeriodId) {
			String getBatchesResponse=rest.getRestAPI("/queue/batches?limit=50&offset=0&sortfield=batchName&order=asc&startPeriod="+startPeriodId+"&endPeriod="+endPeriodId);
			JSONArray batchidArray = JsonPath.read(getBatchesResponse, "$..id");
			int noOfBatches = batchidArray.size();
			for (int i=0 ; i<noOfBatches ; i++) {
				adhoc.deleteBatch(batchidArray.get(i).toString());
			}
	}
	
		 
	public int getCountOfBatches(String startPeriodId, String endPeriodId) {
		String getBatchesResponse=rest.getRestAPI("/queue/batches?limit=50&offset=0&sortfield=batchName&order=asc&startPeriod="+startPeriodId+"&endPeriod="+endPeriodId);
		JSONArray batchidArray = JsonPath.read(getBatchesResponse, "$..id");
		return batchidArray.size();
	}
	public Integer getOrdersCount(String periodName,  List<String> searchText,  List<String> searchField) throws Exception{
		Integer orderCount = JsonPath.read(orderStage.getOrdersCount(periodName,searchText,searchField), "$.count");
		return orderCount;
	}
	
	public byte[] getBytesFromFile(File uploadFile1) throws Exception {
		FileInputStream is = new FileInputStream(uploadFile1);
        long length = uploadFile1.length();
        if(length > 2147483647L) {
            throw new Exception("File too large");
        } else {
            byte[] bytes = new byte[(int)length];
            int offset = 0;

            int numRead1;
            for(boolean numRead = false; offset < bytes.length && (numRead1 = is.read(bytes, offset, bytes.length - offset)) >= 0; offset += numRead1) {
                ;
            }

            if(offset < bytes.length) {
                throw new IOException("Could not completely read file " + uploadFile1.getName());
            } else {
                is.close();
                return bytes;
            }
        }
    }
	
	public boolean isUploadSuceed(boolean isSucceed, UploadResponse uploadResponse)
	{
		ErrorCode[] errorCodes = uploadResponse.getErrorCodes();
        if (errorCodes == null || errorCodes.length == 0)
            return isSucceed;

        for (int i = 0; i < errorCodes.length; i++) {

            ErrorCode ec = errorCodes[i];
            logger.info("Error Code: " + ec.getCode() +"\n");
            logger.info("Error Text: " + ec.getReason() +"\n");
            logger.info("Stack: " + ec.getStackTrace() +"\n");
            isSucceed= false;
        }
		return isSucceed;
	}
	
	public String getBusinessGroup(Object batchID)
	{
	String getBusinessGroup = rest.getRestAPI("/queue/batches/" + batchID + "/");
	return getBusinessGroup;
	}
	public String getOrdersInPeriod(String startPeriodId,String endPeriodId)
	{
	String getOrders = rest.getRestAPI("/queue/batches?limit=50&offset=0&sortfield=batchName&order=asc&startPeriod="+ startPeriodId + "&endPeriod=" + endPeriodId + "&");
	return getOrders;
	}
}
