package com.xactly.incent.orders;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.xactly.xcommons.selenium.SeleniumHelperClass;

public class ReleaseHistory {
	public static Logger logger = Logger.getLogger(ReleaseHistory.class.getName());
	public ReleaseHistory(String testtype) throws Exception

	{
		if(testtype.equalsIgnoreCase("gui"))
		{
			new Orders("gui");
			SeleniumHelperClass.findWebElementbyid("A_Process Status", "topFrame").click();
			get_history_link().click(); 
			Thread.sleep(1000);

		}
	}
	
	public WebElement get_history_link() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("historyLink","mainFrame"));
	}
	
	public WebElement get_history_searchtext() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("history-search-text","mainFrame"));
	}
	
	public WebElement get_history_search_button() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("history-search-button","mainFrame"));
	}
	
	public WebElement get_history_search_drilldown() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='history-list']/li/div","mainFrame"));
	}
	
	public WebElement get_history_current_status_label() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='history-list']/li[1]/div/div[2]/fieldset/div[2]/div[1]/div[2]/div[4]/div[1]/span[1]","mainFrame"));
	}
		
	public WebElement get_history_searched_current_status() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='history-list']/li[1]/div/div[2]/fieldset/div[2]/div[1]/div[2]/div[4]/div[1]/span[2]","mainFrame"));
	}
		
	public WebElement get_history_results_processsed_label() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='history-list']/li[1]/div/div[2]/fieldset/div[2]/div[1]/div[2]/div[5]/div[2]/span[1]","mainFrame"));
	}
	
	public WebElement get_history_searched_results_processsed() throws Exception {
			return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='history-list']/li[1]/div/div[2]/fieldset/div[2]/div[1]/div[2]/div[5]/div[2]/span[2]","mainFrame"));
	}
	
	public WebElement get_history_results_failed_label() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='history-list']/li[1]/div/div[2]/fieldset/div[2]/div[1]/div[2]/div[6]/div[2]/span[1]","mainFrame"));
	}
		
	public WebElement get_history_searched_results_failed() throws Exception {
	  return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='history-list']/li[1]/div/div[2]/fieldset/div[2]/div[1]/div[2]/div[6]/div[2]/span[2]","mainFrame"));
		}
		
	public Select get_history_fromperiod() throws Exception {
		return (SeleniumHelperClass.selectFromDropdownwithelements("id","periods-selectFrom","mainFrame"));
	}

	public Select get_history_toperiod() throws Exception {
		return (SeleniumHelperClass.selectFromDropdownwithelements("id","periods-selectTo","mainFrame"));
	}
	
	public WebElement get_release_finalize_filter() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[1]/div[1]/div[3]/input[6]","mainFrame"));
	}
	
	public WebElement get_history_finalize_filter() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[1]/div[1]/div[3]/input[8]","mainFrame"));
	}
	
	public WebElement get_history_unfinalize_filter() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[1]/div[1]/div[3]/input[9]","mainFrame"));
	}
	
	
	public WebElement get_finalize_history_search_drilldown() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='history-list']/li[1]/div","mainFrame"));
	}
	
	public WebElement get_finalize_history_drilldown_Success_label() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='history-list']/li[1]/div/div[2]/fieldset/div[2]/div[1]/div[2]/div[2]/div/label","mainFrame"));
	}
	
	public WebElement get_finalize_history_drilldown_Success() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='history-list']/li[1]/div/div[2]/fieldset/div[2]/div[1]/div[2]/div[2]/div/span","mainFrame"));
	}
	
	public WebElement get_finalize_history_drilldown_fail_label() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='history-list']/li[1]/div/div[2]/fieldset/div[2]/div[1]/div[2]/div[3]/div/label","mainFrame"));
	}
	
	public WebElement get_finalize_history_drilldown_fail() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='history-list']/li[1]/div/div[2]/fieldset/div[2]/div[1]/div[2]/div[3]/div/span","mainFrame"));
	}
	
	public WebElement get_unfinalize_history_drilldown_Status_label() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='history-list']/li[1]/div/div[2]/fieldset/div[2]/div[1]/div[2]/div[3]/div/label","mainFrame"));
	}
	
	public WebElement get_unfinalize_history_drilldown_Status_Mgs() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='history-list']/li[1]/div/div[2]/fieldset/div[2]/div[1]/div[2]/div[3]/div/span","mainFrame"));
	}
	                                                       
	
	
	
	/* to view the status of completed or failed commission release*/
	String status;
	public void releaseHistoryStatus(String releaseName) throws Exception
	{
		Thread.sleep(500);
		get_release_finalize_filter().click();
		get_history_searchtext().clear();
		get_history_searchtext().sendKeys(releaseName);
		Thread.sleep(1000);
		get_history_search_button().click();
		Thread.sleep(2000);
		get_history_search_drilldown().click();
		
		Thread.sleep(2000);		
			
		String statusLabel = get_history_current_status_label().getText();
	    status = get_history_searched_current_status().getText();
		String resProcessedLabel = get_history_results_processsed_label().getText();
		String resProcessed = get_history_searched_results_processsed().getText();
		String resFailedLabel = get_history_results_failed_label().getText();
		String resFailed = get_history_searched_results_failed().getText();
		
		logger.info(statusLabel+" " +status);
		logger.info(resProcessedLabel+" " +resProcessed);
		logger.info(resFailedLabel+" " +resFailed);
	}
	
	String SuccessBG;
	String FailedBG;
	
	String StatusLabel;
	String Status;
}