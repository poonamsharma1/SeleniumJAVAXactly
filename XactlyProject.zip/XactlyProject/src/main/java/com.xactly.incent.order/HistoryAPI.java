package com.xactly.incent.orders;
import org.testng.Reporter;
import com.jayway.jsonpath.JsonPath;
import org.apache.log4j.Logger;
import com.xactly.xcommons.restapi.RestAPIHelperClass;

public class HistoryAPI {
	
	RestAPIHelperClass rest = new RestAPIHelperClass();
	public static Logger logger = Logger.getLogger(HistoryAPI.class.getName());
	//Used to get the history items list
	public String getQueueHistoryDetails(Long startPeriodId, Long endPeriodId)
	{			
		logger.info("Getting Queue History List ..");
		String resp = rest.getRestAPI("/queue/history?limit=100&offset=0&sortfield=processTime&order=desc&searchtext=&startPeriod="+startPeriodId+"&endPeriod="+endPeriodId+"");
		logger.info("Queue History list response: "+resp);
		return resp;
	}
	
	//Used to get the details of the history event
	public String getQueueHistoryEventDetail(String historyId, String status)
	{			
		logger.info("Getting Queue History Details ..");
		String resp = rest.getRestAPI("/queue/history/"+historyId+"/detail?status="+status+"");
		logger.info("Queue History Event Detail response: "+resp);
		return resp;
	}
	
	//Used to get the diagnostics of the history event
	// runType = adhoc or spp or pg
	// actionType = Calc_Credits or 
	public String getQueueHistoryEventDiagnostics(String runType, String historyId, Long batchId, String stepActionInstanceId, String actionType)
	{			
		logger.info("Getting Queue History Diagnostics Details ..");
		
		String resp = "";
		if (runType.equalsIgnoreCase("spp") || runType.equalsIgnoreCase("pg")){
			resp = rest.getRestAPI("/queue/batches/"+batchId+"/diagnostics?eventId="+historyId+"&actionInstanceId="+stepActionInstanceId+""
					+ "&action="+actionType+"&actionInstanceStatus=COMPLETED");
		}
		if (runType.equalsIgnoreCase("adhoc")){
			resp = rest.getRestAPI("/queue/batches/"+batchId+"/diagnostics?eventId="+historyId+"");
		}
		
		logger.info("Queue History Event Diagnostics response: "+resp);
		return resp;
	}
}
