package com.xactly.incent.orders;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.xactly.xcommons.selenium.SeleniumHelperClass;

public class OrdersStaging {
	
	public Select get_ord_period() throws Exception {
		return (SeleniumHelperClass.selectFromDropdown("periodId","listFrame"));
	}
	public WebElement get_ocode_name() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyid("show_orderCode_orderstage_edit","editFrame"));
	}
	
	public WebElement get_icode_name() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("show_itemCode_orderstage_edit","editFrame"));
	}
		
	public WebElement get_quantity_name() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("quantity_orderstage_edit","editFrame"));
	}
	
	public WebElement get_amt_name() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyid("amount_orderstage_edit","editFrame"));
	}
	
	public Select get_amtunit_type() throws Exception {
		return (SeleniumHelperClass.selectFromDropdown("amountUnitTypeId_orderstage_edit","editFrame"));
	}
	
	public WebElement get_inct_date() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyid("incentiveDate_orderstage_edit","editFrame"));
	}
	
	public WebElement get_ord_date() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyid("orderDate_orderstage_edit","editFrame"));
	}
	
	public Select get_ord_type() throws Exception {
		return (SeleniumHelperClass.selectFromDropdown("orderTypeId_orderstage_edit","editFrame"));
	}
	
	public WebElement get_ord_disc() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyid("discount_orderstage_edit","editFrame"));
	}
	
	public WebElement get_ord_desc() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyid("description_orderstage_edit","editFrame"));
	}
	
	public WebElement get_ord_personbutton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("(//button[@type='button'])[19]","editFrame"));
	}
	
	public WebElement get_ord_splitper() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyid("splitAmountPercent_0","editFrame"));
	}
	
	public WebElement get_ord_delete() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("deleteButton2","listFrame"));
	}
	
	public WebElement get_ord_deleteSelected() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("menuDelete_a_0","listFrame"));
	}
	
	public WebElement get_ord_deleteperiod() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("menuDelete_a_1","listFrame"));
	}
	
	public WebElement get_ord_save() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("saveButton","editFrame"));
	}
	
	public WebElement get_ord_clear() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("clearButton","editFrame"));
	}
	
	public WebElement get_ord_search() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("searchButton","editFrame"));
	}
	
	public WebElement get_ord_table() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("tableFixed","listFrame"));
	}

    public OrdersStaging(String testtype) throws Exception
	
	{
		if(testtype.equalsIgnoreCase("gui"))
		{
			new Orders("gui");
			SeleniumHelperClass.findWebElementbyid("A_Order Staging","topFrame").click();
			Thread.sleep(1000);
			//GetProperties.setBusinessgrouptable(SetWebDrivers.tableDet.getProperty("incent.order.orderstaging"));
		
		}
	}
	
    public void wait(WebElement obj, String value) throws Exception
	{
		while(!obj.getAttribute("value").equals(value))
		{
			continue;
		}
	}
    
    public void selectPeriod(String periodid) throws Exception
    {
    	get_ord_period().selectByVisibleText(periodid);
    	
    }
    public void createOrders(String periodid, String ocode, String icode, String bname, String pname, String qty, String cname, String gname, 
    		String discount, String amt, String utype, String idate, String odate, String otype, String desc, String personeid, String sltper) throws Exception{
    	selectPeriod(periodid);
    	get_ord_clear().click();
    	Thread.sleep(500);
    	get_ocode_name().sendKeys(ocode);
    	Thread.sleep(500);
       	get_icode_name().sendKeys(icode);
    	SeleniumHelperClass.selectFromPopup("b_batchName_orderstage_edit","batchName_edit_batchName", bname,"editFrame");
    	Thread.sleep(1000);
    	SeleniumHelperClass.selectFromPopup("b_productName_orderstage_edit","name_edit_productName",pname,"editFrame");
    	Thread.sleep(1000);
    	get_quantity_name().sendKeys(qty);
    	Thread.sleep(500);
    	SeleniumHelperClass.selectFromPopup("b_customerName_orderstage_edit","name_edit_customerName", cname,"editFrame");
    	Thread.sleep(1000);
    	SeleniumHelperClass.selectFromPopup("b_geoName_orderstage_edit","name_edit_geoName", gname,"editFrame");
    	Thread.sleep(1000);
    	get_amt_name().sendKeys(amt);
    	Thread.sleep(500);
    	get_amtunit_type().selectByVisibleText(utype);
    	Thread.sleep(500);
    	get_inct_date().sendKeys(idate);
    	Thread.sleep(500);
    	get_ord_date().sendKeys(odate);
    	Thread.sleep(500);
    	get_ord_type().selectByVisibleText(otype);
    	Thread.sleep(1000);
    	get_ord_disc().sendKeys(discount);
    	Thread.sleep(500);
    	get_ord_desc().sendKeys(desc);
    	Thread.sleep(500);
    	//get_ord_custStr().sendKeys(csfield);
    	//SeleniumHelperClass.selectFromPopup("//div/button//button[@type='button'])[19]","employeeId_assignment_participantName", personeid,"editFrame");
    	get_ord_personbutton().click();
    	Thread.sleep(1000);
    	SeleniumHelperClass.selectFromPopupxpath("employeeId_assignment_participantName", personeid);
    	Thread.sleep(1000);
    	get_ord_splitper().sendKeys(sltper);
    	Thread.sleep(15000);
    	get_ord_save().click();
    	//Thread.sleep(1000);
    	//wait(get_ocode_name(),"");
    }
	
    public WebElement getorderstagingTable(String columnName, int rowNum) throws Exception
	{	
    	
    	Thread.sleep(3000);
		WebElement obj =SeleniumHelperClass.getTableCell( get_ord_table(),columnName,  rowNum) ;
		Thread.sleep(1000);
//		WebElement obj = SeleniumHelperClass.clickFirstRowOfTable(get_ord_table());
//		Thread.sleep(1000);
//		return (SeleniumHelperClass.getTableData(get_ord_table(), columnName,rowNum));
		return obj;
	}
    
    public void searchOrder(String periodid, String ocode, String icode,String bname) throws Exception
    {
    	selectPeriod(periodid);
    	get_ord_clear().click();
    	get_ocode_name().sendKeys(ocode);
    	get_icode_name().sendKeys(icode);
    	SeleniumHelperClass.selectFromPopup("b_batchName_orderstage_edit","batchName_edit_batchName", bname,"editFrame");
    	get_ord_search().click();
    	Thread.sleep(10000);
    }
    
    public void editOrderPCG(String periodid, String desc) throws Exception
    {
    	
    	//SeleniumHelperClass.selectFromPopup("b_productName_orderstage_edit","name_edit_productName",pname,"editFrame");
    	//SeleniumHelperClass.selectFromPopup("b_customerName_orderstage_edit","name_edit_customerName", cname,"editFrame");
    	//SeleniumHelperClass.selectFromPopup("b_geoName_orderstage_edit","name_edit_geoName", gname,"editFrame");
    	get_ord_desc().sendKeys(desc);
    	get_ord_save().click();
    	wait(get_ocode_name(),"");
    	get_ord_search().click();
    	Thread.sleep(10000);
    }
    
	
	public void deletebatchOrder(String periodid, String bname) throws Exception {
		selectPeriod(periodid);
		get_ord_delete().click();
		Thread.sleep(500);
		SeleniumHelperClass.selectFromPopup("menuDelete_a_2","batchName_edit_batchName", bname,"listFrame");
		Thread.sleep(500);
		SeleniumHelperClass.AcceptAlerts("Delete all orders in batch"+" "+bname+"?");
		Thread.sleep(1000);
		
	}
	
}



