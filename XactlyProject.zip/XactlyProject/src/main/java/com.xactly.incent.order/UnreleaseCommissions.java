package com.xactly.incent.orders;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.*;
import java.awt.event.KeyEvent;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.xml.rpc.ServiceException;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;

import com.google.common.io.Files;
import com.google.gson.Gson;
import com.xactly.icm.xtoolkit.service.XService;
import com.xactly.icm.xtoolkit.wso.ErrorCode;
import com.xactly.icm.xtoolkit.wso.QueueRegionResponse;
import com.xactly.incent.xactlyadmin.XactlyAdmin;
import com.xactly.xcommons.connectapi.LoginToConnect;
import com.xactly.xcommons.selenium.GetProperties;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

public class UnreleaseCommissions {
	public static Logger logger = Logger.getLogger(UnreleaseCommissions.class.getName());

public UnreleaseCommissions(String testtype) throws Exception
	
	{
		/*if(testtype.equalsIgnoreCase("gui"))
		{ 
			new XactlyAdmin("gui");
			SeleniumHelperClass.findWebElementbyid("A_Process Status","topFrame").click();
			get_queuetab_link().click(); 
			Thread.sleep(5000);
		}*/
	}

public WebElement get_queue_link() throws Exception {
//	SetWebDrivers.getDriver().switchTo().frame("sFrame").switchTo().frame("uiclientFrame").switchTo().frame("mainFrame");
	return (SeleniumHelperClass.findWebElementbyid("queueLink"));
}

public WebElement get_Morelink() throws Exception 
{
	return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='showHideSecondaryLinks']/span[1]", "mainframe"));
}

public WebElement get_unrelease_commissionlink() throws Exception 
{
	return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='queueUnRelease']/span/span","mainFrame"));
}

public WebElement get_unrelease_releasegrp() throws Exception 
{
	return(SeleniumHelperClass.findWebElementbyid("unreleaseGroup","mainFrame"));
}

public WebElement get_searchtext_releasegrp() throws Exception 
{
	return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='relGrp-search-text']","mainFrame"));
}

public WebElement get_searchicon_releasegrp() throws Exception 
{
	return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='relGrp-search-button']","mainFrame"));
}

public WebElement select_releasegrp_value() throws Exception {
	return(SeleniumHelperClass.findWebElementbyXpath(".//ul[@id='releaseGrp-list']/li/div/span/input","mainFrame"));
}

public WebElement save_releasegrp_value() throws Exception {
	return(SeleniumHelperClass.findWebElementbyXpath(".//div[@id='modal-container']/div[3]/span[2]/div","mainFrame"));
}

public WebElement get_unrelease_template() throws Exception 
{
	return(SeleniumHelperClass.findWebElementbyid("unreleaseTemplate","mainFrame"));
}

public WebElement uploadFileForUnreleaseCommission() throws Exception{

	WebElement uploadField=SeleniumHelperClass.findWebElementbyXpath("//input[@type='file']");	
	return uploadField;
	}

public WebElement add_to_Queue() throws Exception {
	return(SeleniumHelperClass.findWebElementbyXpath(".//*[@id='unreleaseDone']/div","mainFrame"));
}

public void unreleasecomm(String releasegroup) throws Exception
	{
	Thread.sleep(1000);
	get_queue_link().click();
	get_Morelink().click();
	get_unrelease_commissionlink().click();
	get_unrelease_releasegrp().click();
	Thread.sleep(500);
	get_searchtext_releasegrp().sendKeys(releasegroup);
	Thread.sleep(1000);
	get_searchicon_releasegrp().click();
	Thread.sleep(1000);
	select_releasegrp_value().click();
	Thread.sleep(1000);
	save_releasegrp_value().click();
	}

public void unreleasecomm_template() throws Exception
{
	Thread.sleep(1000);
	get_queue_link().click();
	get_Morelink().click();
	get_unrelease_commissionlink().click();
	get_unrelease_template().click();
	Thread.sleep(500);
	
	ClassLoader classLoader=getClass().getClassLoader();
	File file=new File(classLoader.getResource("BusinessAdminHeldcomm.csv").getFile());
	WebElement upfile=uploadFileForUnreleaseCommission();
	String fpath=file.getAbsolutePath();
	logger.info("upload file is "+fpath);
	upfile.sendKeys(fpath);
	Thread.sleep(3000);
	
	add_to_Queue().click();
	
}


}
