package com.xactly.incent.orders;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.rpc.ServiceException;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.xactly.icm.xtoolkit.service.XService;
import com.xactly.icm.xtoolkit.wso.ErrorCode;
import com.xactly.icm.xtoolkit.wso.QueueRegionResponse;
import com.xactly.xcommons.connectapi.LoginToConnect;
import com.xactly.xcommons.selenium.GetProperties;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

public class ReleaseCommissionsFromQueue {
	public static Logger logger = Logger.getLogger(ReleaseCommissionsFromQueue.class.getName());
	public ReleaseCommissionsFromQueue(String testtype) throws Exception

	{
		if(testtype.equalsIgnoreCase("gui"))
		{
			//new Orders("gui");
			SeleniumHelperClass.findWebElementbyid("A_Process Status", "topFrame").click();

			GetProperties.setReleasegrouptable(SetWebDrivers.tableDet.getProperty("incent.orders.releasegroup"));
			Thread.sleep(5000);
		}
	}
	
	public WebElement get_release_commissionlink() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='queueRelease']/span/span[2]","mainFrame"));
	}
	
	public WebElement add_release_grouplink() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='queueReleaseGroupLink']/i","mainFrame"));
	}
	
	public WebElement create_release_groupbutton() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='createReleaseGroup']/span/span","mainFrame"));
	}
	
	public WebElement put_release_groupname() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='queueReleaseName']","mainFrame"));
	}
	
	public WebElement put_release_groupdesc() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='queueReleaseDescription']","mainFrame"));
	}
	
	public WebElement get_release_group_save() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='modal-container']/div[3]/span[2]","mainFrame"));
	}
	
	public WebElement get_release_group_searchtext() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='relGrp-search-text']","mainFrame"));
	}
	
	public WebElement get_release_group_searchbutton() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='relGrp-search-button']","mainFrame"));
	}
	
	public WebElement get_release_group_searchedCheckbox() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='releaseGrp-list']/li[1]/div/span[1]/input","mainFrame"));
	}
	
	public WebElement get_release_group_select() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='modal-container']/div[3]/span[2]","mainFrame"));
	}
	
	public WebElement get_release_upload_button() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='release-upload-file-new']","mainFrame"));
	}
	
	public WebElement get_release_calendar_button() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='selectedDate']/button","mainFrame"));
	}

	public WebElement get_release_commissions_button() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='modal-container']/div[3]/span[2]","mainFrame"));
	}
	
	public WebElement get_release_cancel_button() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='modal-container']/div[3]/span[1]/span","mainFrame"));
		//  .//span[contains(@data-i18n,'cancel')]
		
	}
	
	public WebElement getqueueTableRow(String columnName, int rowNum) throws Exception
	{	
    	WebElement obj =SeleniumHelperClass.getTableCell_NewUI_getrow(columnName,  rowNum, "list ui-sortable", "mainFrame") ;
		Thread.sleep(1000);
		return obj;
	}
	
	public String getreleasegroupTableRow(String columnName, String Value, String relgrpId) throws Exception
	{	
    	String groupId =SeleniumHelperClass.getResultIDFromDB(GetProperties.releasegrouptable, relgrpId, columnName, Value);
		Thread.sleep(2000);
		logger.info("group_id" +groupId);
		return groupId;
	}
	
	
	
	public void createreleasegroup(String rgName, String rgDesc) throws Exception
	{
		
		//creaate Release group
		get_release_commissionlink().click();
		add_release_grouplink().click();
		create_release_groupbutton().click();
		put_release_groupname().sendKeys(rgName);
		put_release_groupdesc().sendKeys(rgDesc);
		get_release_group_save().click();
		Thread.sleep(1000);
		get_release_cancel_button().click();
		Thread.sleep(1000);
		get_release_cancel_button().click();
	}
	
	
	public void releaseCommissionfromconnect(String ufile ,String releaseGroupId,String releaseCDate,String comment, String regionType,String regionId) throws MalformedURLException, RemoteException, ServiceException, IOException
{
	logger.info("Connect service is up");
	LoginToConnect connect = new LoginToConnect();
	XService service =connect.login("Incent","release.commission.api");
	
	byte[] fileBytes = getFileContent(ufile);
	
	SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
	sdf.setLenient(false);
	Date relDate = null;
	try {
	    relDate = sdf.parse(releaseCDate);
	} catch (ParseException pe){
		logger.info("Invalid date: "+releaseCDate);
		pe.printStackTrace();
	}
	
    Calendar releaseDate = Calendar.getInstance();
    releaseDate.setTime(relDate);
	
	long releaseGroupIdLong = -1L;
	if (releaseGroupId != null && !"".equals(releaseGroupId)) {
		releaseGroupIdLong = Long.parseLong(releaseGroupId);
	}
	QueueRegionResponse queueResponse = service.addCommissionReleaseTemplateToQueue(fileBytes, releaseGroupIdLong, releaseDate, comment, regionType, regionId);
	if (!queueResponse.isResult()) {
		logger.info("Test Case : Failed\n");
		ErrorCode[] errorCodes = queueResponse.getErrorCodes();
		for (ErrorCode error : errorCodes) {
			logger.info("Error Reason: " + error.getReason());
	}
	}
	
	if (queueResponse.isResult()) {
				logger.info("Call successful");
		logger.info("Queue region Id: "
				+ queueResponse.getRegionId());
		logger.info("Test Case : Passed\n");



	}
}
	
	private static byte[] getFileContent(String releaseTempleFile) {

		byte[] fileBytes = null;
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		InputStream inputStream = null;
		try {

			inputStream = new FileInputStream(releaseTempleFile);
			byte[] binaryBuffer = new byte[4096];
			int bytesToRead = 0;

			while ((bytesToRead = inputStream.read(binaryBuffer)) != -1) {
				bos.write(binaryBuffer, 0, bytesToRead);
			}

			if (bos != null) {
				fileBytes = bos.toByteArray();
			}
		} catch (Exception ex) {
			ex.printStackTrace();

		} finally {
			try {
				if (bos != null) {
					bos.close();
				}
				if (inputStream != null) {
					inputStream.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return fileBytes;

	}

	
	
}
