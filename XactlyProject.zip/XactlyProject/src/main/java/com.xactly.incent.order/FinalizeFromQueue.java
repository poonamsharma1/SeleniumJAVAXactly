package com.xactly.incent.orders;

import org.apache.log4j.Logger;

import com.jayway.jsonpath.JsonPath;
import com.xactly.xcommons.restapi.RestAPIHelperClass;
import com.xactly.xcommons.selenium.GetProperties;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

import net.minidev.json.JSONArray;

public class FinalizeFromQueue {
	public static Logger logger = Logger.getLogger(FinalizeFromQueue.class.getName());
	public FinalizeFromQueue(String testtype) throws Exception

	{
		if(testtype.equalsIgnoreCase("gui"))
		{
			new Orders("gui");
			SeleniumHelperClass.findWebElementbyid("A_Process Status", "topFrame").click();
			GetProperties.setCalendartable(SetWebDrivers.tableDet.getProperty("incent.setup.calendar"));
			GetProperties.setBusinessgrouptable(SetWebDrivers.tableDet.getProperty("incent.setup.businessgroup"));
			GetProperties.setUsertable(SetWebDrivers.tableDet.getProperty("incent.setup.user"));
			Thread.sleep(5000);
		}
	}
	
		
	public FinalizeFromQueue() {
	}


	RestAPIHelperClass rest = new RestAPIHelperClass();
	public String finalizeInQueue(String periodId, String businessGroupId, String incall) throws Exception
	{	
		logger.info("adding finalize to queue...");
		//Gson gson = new Gson();
		//rest.loginToIncent("incent.queue.period.finalize");
		//String request = "/xqueue/services/queue/"+SeleniumHelperClass.getBusinessId()+"/events/finalizeevents";
		//String queueInfo = "{\"periodId\":\""+periodId+"\",\"queueEventType\":\"Finalize\",\"userId\":\""+userId+"\",\"businessGroupIdList\":[\""+businessGroupId+"\"]}";
		
		String request = "/queue/events/finalizeevents";		
		String queueInfo = "{\"periodId\":\""+periodId+"\",\"includeAll\":\""+incall+"\",\"queueEventType\":\"Finalize\",\"businessGroupIdList\":[\""+businessGroupId+"\"]}";
		
		logger.info("queueInfo "+queueInfo);            
		String resp = rest.postRestAPI(request,queueInfo);	
		return resp;
	}
	
	public String finalizeInQueueforValidation(String periodId, String businessGroupId, String incall, int statcode) throws Exception
	{	
		logger.info("adding finalize to queue...");
		String request = "/queue/events/finalizeevents";		
		String queueInfo = "{\"periodId\":\""+periodId+"\",\"includeAll\":\""+incall+"\",\"queueEventType\":\"Finalize\",\"businessGroupIdList\":[\""+businessGroupId+"\"]}";
		
		logger.info("queueInfo "+queueInfo);            
		String resp = rest.postRestAPI(request,queueInfo, statcode);	
		return resp;
	}
	
	public String getperiodTableRow(String columnName, String Value, String periodId) throws Exception
	{	
		String Period_id =SeleniumHelperClass.getResultIDFromDB(GetProperties.calendartable, periodId, columnName, Value);
		Thread.sleep(2000);
		return Period_id;
	}
	
	public String getbusinessgroupTableRow(String columnName, String Value, String bgroupId) throws Exception
	{	
		String bgroup_id =SeleniumHelperClass.getResultIDFromDB(GetProperties.businessgrouptable, bgroupId, columnName, Value);
		Thread.sleep(2000);
		return bgroup_id;
	}
	
	public String searchDrawName(String drawName) throws Exception
	{	
		
		logger.info("searching Draw person...");
		
		
	String resp=	rest.getRestAPI("/incentives/v1/config/draws?searchfield=searchText&searchtext="+drawName+"");
	
	return resp;
		
		
	}
	
	public Object getDrawId(String searchDrawNameResp ) {
		
		JSONArray DrawId= JsonPath.read(searchDrawNameResp,
				"$..drawId");
		logger.info("DrawId:"+DrawId.get(0));
		
		return DrawId.get(0);
	}
	
	public Object getAssignmentId(String searchDrawNameResp ) {
		
		JSONArray assignmentId= JsonPath.read(searchDrawNameResp,
				"$..assignmentId");
		logger.info("assignmentId:"+assignmentId.get(0));
		
		return assignmentId.get(0);
	}
	
	public String editDrawPerson(String drawId) throws Exception
	{	
		
		logger.info("edit Draw Amount page...");
		
		
		String resp=rest.getRestAPI("/incentives/v1/config/draws/"+drawId+"");
		return resp;
	}
	
	public String editDrawPercentage(String periodId,String drawName,String drawId,String drawPercentage) throws Exception
	{	
		
		logger.info("edit draw percentage...");
		
		String request = "/incentives/v1/config/draws/"+drawId+"";	
		String queueInfo="{\"drawId\":"+drawId+",\"name\":\""+drawName+"\",\"version\":3,\"unitTypeId\":118923907,\"periodId\":"+periodId+",\"totalAssignments\":null,\"drawType\":\"3\",\"description\":\"\",\"earningGroupId\":null,\"earningGroup\":null,\"recoveryPercentage\":\""+drawPercentage+"\",\"tags\":[],\"assignments\":null,\"createdDate\":null,\"createdByName\":null,\"modifiedDate\":null,\"modifiedByName\":null,\"modifiedDateStr\":null,\"visible\":false}";		
		logger.info("queueInfo "+queueInfo);            
		String resp = rest.putRestAPI(request,queueInfo);	
		return resp;
	}
	
	public String editDrawAmount(String periodId,String drawName,String drawId,String drawAmount,String assingmentId) throws Exception
	{	
		
		logger.info("edit draw amount...");
		
		String request = "/incentives/v1/config/draws/"+drawId+"/assignments/"+assingmentId+"/";	
		String queueInfo="{\"assignmentId\":"+assingmentId+",\"name\":null,\"drawName\":null,\"drawId\":"+drawId+",\"positionId\":null,\"positionName\":\"POSR8\",\"personId\":122422129,\"personName\":\"SE4 Person (SE4)\",\"details\":[{\"periodId\":118923849,\"projectedAmount\":0,\"isEditable\":true,\"existingOrNew\":\"Existing\"},{\"periodId\":"+periodId+",\"projectedAmount\":"+drawAmount+",\"isEditable\":true,\"existingOrNew\":\"Existing\"},{\"periodId\":118923853,\"projectedAmount\":0,\"isEditable\":true,\"existingOrNew\":\"New\"},{\"periodId\":118923855,\"projectedAmount\":0,\"isEditable\":true,\"existingOrNew\":\"New\"},{\"periodId\":118923857,\"projectedAmount\":0,\"isEditable\":true,\"existingOrNew\":\"New\"},{\"periodId\":118923859,\"projectedAmount\":0,\"isEditable\":true,\"existingOrNew\":\"New\"},{\"periodId\":118923861,\"projectedAmount\":0,\"isEditable\":true,\"existingOrNew\":\"New\"},{\"periodId\":118923863,\"projectedAmount\":0,\"isEditable\":true,\"existingOrNew\":\"New\"},{\"periodId\":118923865,\"projectedAmount\":0,\"isEditable\":true,\"existingOrNew\":\"New\"},{\"periodId\":118923867,\"projectedAmount\":0,\"isEditable\":true,\"existingOrNew\":\"New\"},{\"periodId\":118923869,\"projectedAmount\":0,\"isEditable\":true,\"existingOrNew\":\"New\"},{\"periodId\":118923871,\"projectedAmount\":0,\"isEditable\":true,\"existingOrNew\":\"New\"}],\"deletable\":false}";
		logger.info("queueInfo "+queueInfo);            
		String resp = rest.putRestAPI(request,queueInfo);	
		return resp;
	}
	
}