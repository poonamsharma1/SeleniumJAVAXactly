package com.xactly.incent.orders;

import com.xactly.xcommons.selenium.SeleniumHelperClass;
import org.openqa.selenium.WebElement;

public class ValidationRules {

    public ValidationRules(String testtype) throws Exception

    {
        if(testtype.equalsIgnoreCase("gui"))
        {
            new Orders("gui");
            WebElement validationRulesTab = SeleniumHelperClass.findWebElementbyid("ORDERS_TAB_VALIDATION_RULES", "topFrame");
            SeleniumHelperClass.isVisible(validationRulesTab, 10);
            validationRulesTab.click();
            Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
        }
        else if(testtype.equalsIgnoreCase("gui-new"))
        {
            new Orders("gui-new");
            WebElement validationRulesTab = SeleniumHelperClass.findWebElementbyid("ORDERS_NAV-VALIDATION_RULES", "topFrame");
            SeleniumHelperClass.isVisible(validationRulesTab, 10);
            validationRulesTab.click();
            Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
        }
    }

    public WebElement saveButton() throws Exception{
        return SeleniumHelperClass.findWebElementbyid("saveButton", "editFrame");
    }

}
