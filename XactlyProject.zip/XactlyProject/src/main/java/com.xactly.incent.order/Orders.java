package com.xactly.incent.orders;

import org.openqa.selenium.WebElement;

import com.xactly.incent.navigation.LeftNavigationUtil;
import com.xactly.xcommons.selenium.SeleniumHelperClass;

public class Orders {
	public Orders(String testtype) throws Exception

	{
		if(testtype.equalsIgnoreCase("gui"))
		{	
			WebElement tab_setup = SeleniumHelperClass.findWebElementbyid("TAB_MIDDLE_ORDERS_TAB","TopFrame");
			SeleniumHelperClass.isVisible(tab_setup, 10);
			//tab_setup.click();
			SeleniumHelperClass.secondaryClick(tab_setup);
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		
		}
		else if(testtype.equalsIgnoreCase("gui-new"))
		{
			LeftNavigationUtil.openLeftNavigation();
			LeftNavigationUtil.openOrdersTab();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		}
	}
}
