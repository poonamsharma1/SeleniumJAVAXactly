package com.xactly.incent.orders;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.asserts.SoftAssert;

import com.xactly.incent.navigation.LeftNavigationUtil;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

public class OrdersSubtab {
	public static Logger logger = Logger.getLogger(OrdersSubtab.class.getName());
	public OrdersSubtab(String testtype) throws Exception

	{
		if(testtype.equalsIgnoreCase("gui"))
		{	new Orders("gui");
			WebElement tab_setup = SeleniumHelperClass.findWebElementbyid("ORDERS_TAB_ORDERS_READ_WRITE","topFrame");
			tab_setup.click();
		}
		else if(testtype.equalsIgnoreCase("gui-new"))
		{	new Orders("gui-new");
		    LeftNavigationUtil.clickOnOrders_OrdersTab();
		}
	}
	
	public WebElement clickDateDropdown() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id=\"s2id_periods\"]/a/span[2]/b", "mainFrame");
	}
	
	public WebElement clickApr2021() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//li/div[text()='APR-2021 (Open)']", "mainFrame");
	}
	
	public WebElement clickSearch() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@class='search-button-area']/span", "mainFrame");
	}
	
	public WebElement iT01OrderItem() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@class='list-item-row border-bottom orders-row']", "mainFrame");
	}
	
	public void hoverOverSearch() throws Exception {
		SeleniumHelperClass.mouseHover(iT01OrderItem());
	}
	
	public WebElement clickCreateNewOrderItem() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[text()='Create New Order Item']", "mainFrame");
	}
	
	public WebElement clickCancelonCreateNewOrderItem() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[text()='Cancel']/parent::span", "mainFrame");
	}
	
	public WebElement searchOrderCode() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='selectOrderCode']", "mainFrame");
	}
	
	public WebElement clickEditOrderItem() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//div/button/span[text()='Edit']", "mainFrame");
	}
	
	public Boolean verifySelectOrderCodePopupisPresent() {
		return SeleniumHelperClass.isElementPresent("xpath", "//*[text()='Select Order Code']");
	}
	
	public Boolean verifyBatchNameisPresent() {
		return SeleniumHelperClass.isElementPresent("xpath", ".//input[@id='batchName']");
	}
	
	public WebElement getCreateNewSearchBtn() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//span[@id='createNewSearch']/span", "mainFrame");
	}
	
	public WebElement getSearchNameField() throws Exception{
		return SeleniumHelperClass.findWebElementbyid("inputTitle", "mainFrame");
	}
	
	public WebElement getToDateCalendar() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//span[@class='searchCriteria']/div/div[2]//button", "mainFrame");
	}
	
	public WebElement getFromDateCalendar() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//span[@class='searchCriteria']/div/div[1]//button", "mainFrame");
	}
	
	public WebElement getCalendarDiv() throws Exception{
		return SeleniumHelperClass.findWebElementbyid("ui-datepicker-div", "mainFrame");
	}
	
	public WebElement getCalendarYearDropDown() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//*[@class ='ui-datepicker-year']", "mainFrame");
	}
	
	public WebElement getPrevMonth() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//*[@class ='ui-datepicker-prev ui-corner-all']", "mainFrame");
	}
	
	public WebElement getNextMonth() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//a[@title='Next']", "mainFrame");
	}
	
	public WebElement getMonthName() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//span[@class='ui-datepicker-month']", "mainFrame");
	}
	
	public WebElement getCalendarDatesTable() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//table[@class='ui-datepicker-calendar']", "mainFrame");
	}
	
	public WebElement getDate(String dateDigit) throws Exception{
		//usage : for 7th of a month --> //table[@class='ui-datepicker-calendar']/tbody//tr//td/a[text()='7']
		String xpath = "//table[@class='ui-datepicker-calendar']/tbody//tr//td/a[text()='"+dateDigit+"']";
		return SeleniumHelperClass.findWebElementbyXpath(xpath, "mainFrame");
	}
	
	public WebElement getToDateField() throws Exception{
		return SeleniumHelperClass.findWebElementbyid("searchFieldsToundefined", "mainFrame");
	}
	
	public WebElement getFromDateField() throws Exception{
		return SeleniumHelperClass.findWebElementbyid("searchFieldsFromundefined", "mainFrame");
	}
	
	public WebElement getCreateBtn() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//span[text()='Create']", "mainFrame");
	}
	
	public WebElement getAllSavedSearchesLink() throws Exception{
		return SeleniumHelperClass.findWebElementbyLink("All Saved Searches", "mainFrame");
	}
	
	public WebElement getSavedSearchByName(String name) throws Exception {
		String xpath = "//ul[@id='savedSearchLists']//li/div/span[@title='"+name+"']";
		return SeleniumHelperClass.findWebElementbyXpath(xpath, "mainFrame");
	}
	
	public List<WebElement> getSavedSearchByNameForAssertion(String name) throws Exception {
		String xpath = "//ul[@id='savedSearchLists']//li/div/span[@title='"+name+"']";
		return SeleniumHelperClass.findWebElementsInXpath(xpath, "mainFrame");
	}
	
	public WebElement getDeleteSearchByName(String name) throws Exception {
		String xpath = "//ul[@id='savedSearchLists']//li/div/span[@title='"+name+"']/..//button/span[@title='Delete']";
		return SeleniumHelperClass.findWebElementbyXpath(xpath, "mainFrame");
	}
	
	public WebElement getStagingLink() throws Exception{
		return SeleniumHelperClass.findWebElementbyLink("Staging", "mainFrame");
	}
	
	public WebElement getProcessedLink() throws Exception{
		return SeleniumHelperClass.findWebElementbyLink("Processed", "mainFrame");
	}
	
	public WebElement getResultCountElement() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//span[@id='results-total']", "mainFrame");
	}
	
	public WebElement getConfirmDelete() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//div[@id='modal-container']//div[@data-i18n='delete']", "mainFrame");
	}
	
	/**
	 * Creates a new search for orders with the given name and date range
	 * @param name
	 * @param toDate expects to be in format "14 November 2017"
	 * @param fromDate expects to be in format "14 November 2017"
	 * @throws Exception
	 */
	public void createNewSearch(String name, String toDate, String fromDate) throws Exception{
		SoftAssert sa = new SoftAssert();
		getCreateNewSearchBtn().click();
		sa.assertTrue(SeleniumHelperClass.isVisible(getSearchNameField(), 10), "Create new search page is not yet loaded!");
		getSearchNameField().sendKeys(name);
		sa.assertTrue(SeleniumHelperClass.isVisible(getFromDateCalendar(), 5), "date field not visible!");
		getFromDateCalendar().click();
		setDate(fromDate);
		getToDateCalendar().click();
		setDate(toDate);
		getCreateBtn().click();
		sa.assertAll();
		logger.info("New search successfully created");
	}
	
	/**
	 * sets the given date on a calendar element by carefully first selecting the month through iteration 
	 * and year through a drop down and the date from its table
	 * @param date expects to be in format "14 November 2017"
	 * @throws Exception
	 */
	public void setDate(String date) throws Exception{
		logger.info(date);
		String dateDivision[] = date.split(" ");
		SoftAssert sa = new SoftAssert();
		sa.assertTrue(SeleniumHelperClass.isVisible(getCalendarDiv(), 10), "Calendar division not visible!");
		//set month
		int monthCount=0;
		while(monthCount<12){
			String month = getMonthName().getText();
			if(!month.equals(dateDivision[1])){
				monthCount++;
				sa.assertTrue(SeleniumHelperClass.isVisible(getNextMonth(), 10), "Next month button not visible!");
				getNextMonth().click();
			}
			else{
				break;
			}
		}
		sa.assertEquals(getMonthName().getText(), dateDivision[1], "Month not found!");
		//set year
		new Select(getCalendarYearDropDown()).selectByVisibleText(dateDivision[2]);
		//set date
		sa.assertTrue(SeleniumHelperClass.isVisible(getCalendarDatesTable(), 10), "Dates table is not visible!");
		getDate(dateDivision[0]).click();
		sa.assertAll();
	}
	
	/**
	 * fetched the saved search item for further process
	 * @param name
	 * @throws Exception
	 */
	public void getSavedSearch(String name) throws Exception{
		Assert.assertTrue(SeleniumHelperClass.isClickable(getAllSavedSearchesLink(), 10), "All saved search link Not clickable!");
		getAllSavedSearchesLink().click();
		Assert.assertTrue(SeleniumHelperClass.isVisible(getSavedSearchByName(name), 10), "Saved search Not Visible!");
		getSavedSearchByName(name).click();
		logger.info("Found the saved search");
	}
	
	/**
	 * returns the result count for search items under Staging
	 * @return
	 * @throws Exception
	 */
	public int getStagingResultCount() throws Exception{
		Assert.assertTrue(SeleniumHelperClass.isClickable(getStagingLink(), 10), "Staging link not clickable!");
		getStagingLink().click();
		return getResultCount();
	}
	
	/**
	 * returns the result count for search items under Processed
	 * @return
	 * @throws Exception
	 */
	public int getProcessedResultCount() throws Exception{
		//Assert.assertTrue(SeleniumHelperClass.isClickable(getProcessedLink(), 10), "Staging link not clickable!");
		getProcessedLink().click();
		return getResultCount();
	}
	
	/**
	 * deletes the saved search with the passed name
	 * @param name
	 * @throws Exception
	 */
	public void deleteSavedSearch(String name) throws Exception{
		Assert.assertTrue(SeleniumHelperClass.isClickable(getAllSavedSearchesLink(), 10), "All saved search link Not clickable!");
		getAllSavedSearchesLink().click();
		Actions act = new Actions(SetWebDrivers.getDriver());
		act.moveToElement(getSavedSearchByName(name)).perform();
		Assert.assertTrue(SeleniumHelperClass.isVisible(getDeleteSearchByName(name), 10), "Saved search Not Visible for delete!");
		getDeleteSearchByName(name).click();
		Assert.assertTrue(SeleniumHelperClass.isClickable(getConfirmDelete(), 10), "Confirm delete button not clickable");
		getConfirmDelete().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		Assert.assertTrue(getSavedSearchByNameForAssertion(name).size()==0, "Saved Search deletion failed!");
	}
	
	/**
	 * basic cleanup step to first check if a search with same name exists and delete if yes
	 * @param name
	 * @throws Exception
	 */
	public void cleanUpSearch(String name) throws Exception{
		getAllSavedSearchesLink().click();
		if(getSavedSearchByNameForAssertion(name).size()!=0){
			deleteSavedSearch(name);
		}
	}
	
	/**
	 * returns the result count value of the current page
	 * @return
	 * @throws Exception
	 */
	public int getResultCount() throws Exception{
		Assert.assertTrue(SeleniumHelperClass.isVisible(getResultCountElement(), 10), "Result Count not visible!");
	    String result = getResultCountElement().getText();
	    result = result.substring(result.indexOf('(')+1, result.indexOf(')')).trim();
	    return Integer.parseInt(result);
	}
	
	
}
