package com.xactly.incent.orders;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONException;

import com.google.gson.Gson;
import com.jayway.jsonpath.JsonPath;
import com.xactly.common.wso.report.IncentiveResult;
import com.xactly.xcommons.restapi.RestAPIHelperClass;

import net.minidev.json.parser.ParseException;
public class CalculationAPI {
	public static Logger logger = Logger.getLogger(CalculationAPI.class.getName());
	static RestAPIHelperClass rest = new RestAPIHelperClass();

	public String incentives(String batchId, String queueEventType) throws SQLException, ClassNotFoundException, JSONException, IOException, ParseException
	{
		logger.info("incentivecalc...");
		Gson gson = new Gson();
		String request = "/queue/events/batchevents";
		
		String queueInfo = " {\"eventList\":[{\"batchId\":\""+batchId+"\",\"queueEventType\":\""+queueEventType+"\"}]}";
		
		
		String resp = rest.postRestAPI(request,queueInfo);	
		return resp;
	}
	
	public static String getBatchStatusResponse(String startperiodId, String endPeriodId) throws SQLException, ClassNotFoundException, JSONException, IOException, ParseException
	{	
	
		String request = "/queue/batches?sortfield=batchName&order=asc&startPeriod="+startperiodId+"&endPeriod="+endPeriodId+"";		
		String resp = rest.getRestAPI(request);	
		//logger.info("REsp:"+resp);
		
		return resp;
	}//This method is created for the engg demo
	
	/*public static HashMap<String,String>  getIncentiveStatementValues(String resp){
		HashMap<String,String> results=new HashMap<String, String>();
		results.put("credits",""+JsonPath.read(resp, ".fullReportSections[1]['resultGroups'][0]['results'][0]['record']['children'][1]['children'][0]['value']"));
		results.put("commissions",""+JsonPath.read(resp, ".fullReportSections[2]['resultGroups'][0]['results'][0]['record']['children'][1]['children'][0]['value']"));
		results.put("bonus",""+JsonPath.read(resp, ".fullReportSections[4]['resultGroups'][0]['results'][0]['record']['children'][1]['children'][0]['value']"));
		results.put("payments",""+JsonPath.read(resp, ".fullReportSections[0]['resultGroups'][0]['results'][0]['record']['children'][1]['children'][0]['value']"));
		return results;
	}	*/
	
	private static BigDecimal getPeriodValue(IncentiveResult record, String periodName) 
	{
		if(record.getPeriodName().equalsIgnoreCase(periodName)){
			return record.getValue();
		}else {
			if(record.getChildren() != null && record.getChildren().size() > 0){
				for(IncentiveResult childRecord : record.getChildren()){
					BigDecimal value = getPeriodValue(childRecord, periodName);
					if(value != null){
						return value;
					}
				}
			}
		}
		
		return null;
	}
	public static List<String> getBatchStatus(String resp, int noOfBatches){
		 List<String> statusList=new ArrayList<String>();
		 for(int i=0;i<noOfBatches;i++){
			
			//logger.info(JsonPath.read(resp,"$["+i+"]['batchStatus']"));
			statusList.add(""+ JsonPath.read(resp,"$["+i+"]['batchStatus']"));
			//logger.info("statusList:"+statusList);
		 }
		 
		 return statusList;
	}
	
}