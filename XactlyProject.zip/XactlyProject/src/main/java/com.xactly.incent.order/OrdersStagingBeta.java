package com.xactly.incent.orders;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.xactly.incent.navigation.LeftNavigationUtil;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;
import org.testng.asserts.SoftAssert;

public class OrdersStagingBeta {
public static Logger logger = Logger.getLogger(OrdersStagingBeta.class.getName());
	public OrdersStagingBeta(String testtype) throws Exception {
		if (testtype.equalsIgnoreCase("gui")) {
			new Orders("gui");
			SeleniumHelperClass.findWebElementbyid("A_Orders", "topFrame").click();
			SeleniumHelperClass.isVisible(get_ord_search(), 10);
			Thread.sleep(1000);
		}
		else {
			new Orders("gui-new");
			LeftNavigationUtil.clickOnOrders_OrdersTab();
			//SeleniumHelperClass.isVisible(get_ord_search(), 10);
			Thread.sleep(1000);
		}
	}
	public OrdersStagingBeta(){
		
	}


	/* For Item Code */
	/*	public WebElement get_icode_name() throws Exception {
	return (SeleniumHelperClass.findWebElementbyid("itemCode", "mainframe"));
	}*/

	/* Delete Orders */

	/* For selecting Delete Orders Options link */
	/*	public WebElement get_delete_options() throws Exception {
	return (SeleniumHelperClass.findWebElementbyid("deleteOrders", "mainFrame"));
	}

	 For selecting Delete Selected Orders link 
	public WebElement get_delete_selected_orders() throws Exception {
	return (SeleniumHelperClass.findWebElementbyid("deleteByOrders", "mainFrame"));
	}

	 For selecting Delete All Orders in Period 
	public WebElement get_delete_all_orders_in_period() throws Exception {
	return (SeleniumHelperClass.findWebElementbyCssSelector("#DeleteByPeriod > span","mainFrame"));
	}

	 For selecting Delete All Orders in Batch link 
	public WebElement get_delete_all_orders_in_batch() throws Exception {
	return (SeleniumHelperClass.findWebElementbyid("DeleteByBatch", "mainFrame"));
	}

	public WebElement get_confirm_delete_button() throws Exception {
	return (SeleniumHelperClass.findWebElementbyid("confirm-button","mainframe"));
	}

	public WebElement get_confirm_delete_from_staging_checkbox() throws Exception {
	return (SeleniumHelperClass.findWebElementbyid("deleteFromStaging","mainframe"));
	}*/

	/* For clicking on Processed link 
	public WebElement get_processed_link() throws Exception {
	return (SeleniumHelperClass.findWebElementbyXpath("//li[@id='processedLink']/a", "mainFrame"));
	}

	 For clicking on Staging link 
	public WebElement get_staging_link() throws Exception {
	return (SeleniumHelperClass.findWebElementbyXpath("//li[@id='stagingLink']/a", "mainFrame"));
	}*/


	/* Delete Orders */

	/* Clicking the Search Button */
	public WebElement get_ord_searchfilters() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("searchFilters", "mainframe"));
	}


	/* Clicking the Search Button */
	public WebElement get_ord_search_link() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[@class='btn-inline-icon search_button']", "mainframe"));
	}

	public List<WebElement> get_pageNation_links() throws Exception {
		return (SeleniumHelperClass.findWebElementsInXpath("//span[@class='page-link']", "mainframe",40));
	}


	/* Clicking the Search Button */
	public WebElement get_ord_count() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[@id='results-total-new']", "mainframe"));
	}

	public WebElement get_ord_text() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[@id='aml-list-title-label']", "mainframe"));
	}

	/* For selecting Delete Orders Options link */
	public WebElement get_delete_options() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("deleteOrders", "mainFrame"));
	}

	/* For selecting Delete All Orders in Batch link */
	public WebElement get_delete_all_orders_in_batch() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("DeleteByBatch", "mainFrame"));
	}

	public WebElement get_confirm_delete_button() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("confirm-button","mainframe"));
	}

	/*	public WebElement get_search_button() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("searchBtn","mainFrame"));
		}*/

	// For clicking on Processed link
	public WebElement get_processed_link() throws Exception {
		return (SeleniumHelperClass.findWebElementbyLink("Processed", "mainFrame"));
	}

	public WebElement get_search_button() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("searchBtn","mainFrame"));
	}	

	//For clicking on Staging link
	public WebElement get_staging_link() throws Exception {
		return (SeleniumHelperClass.findWebElementbyLink("Staging", "mainFrame"));
	}

	/* For Order Code */
	public WebElement get_ocode_name() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("orderCode", "mainframe"));
	}

	/* For Item Code */
	public WebElement get_icode_name() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("itemCode", "mainframe"));
	}

	public Select get_ord_period() throws Exception {
		return (SeleniumHelperClass.selectFromDropdownwithelements(
				"xpath",
				"/html/body/div[2]/div[1]/div[2]/div[2]/div[1]/div[2]/form/div/div[2]/div[1]/span[2]/div",
				"mainframe"));
	}

	public void selectPeriod(String periodname) throws Exception {
		get_ord_period().selectByVisibleText(periodname);
	}

	//Search button in Basic Search page
	public WebElement get_search_button_in_BasicSearch() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("searchBtn","mainFrame"));
	}

	//Left Column Search Periods

	public WebElement get_orders_period_dropdown() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='s2id_periods']/a/span","mainFrame"));
	}

	public List<WebElement> get_orders_allPeriods() throws Exception {
		return (SeleniumHelperClass.findWebElements("//div[@id='select2-drop']/ul/li/div","mainFrame"));
	}

	public WebElement select_Order_Period(int item) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='select2-drop']/ul/li["+item+"]/div", "mainframe"));
	}

	public void selectOrderPeriod(String periodName) throws Exception {
		int periodsLength = get_orders_allPeriods().size();
		for (int i=1; i<=periodsLength; i++){
			System.out.printf("Period Name: ",select_Order_Period(i).getText());
			if (select_Order_Period(i).getText().equalsIgnoreCase(periodName)){
				select_Order_Period(i).click();
				//	System.out.printf("CLICKED.. ");
				break;
			}
		}
	}

	//Advanced Search Periods

	public WebElement get_msorders_period_dropdown() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("(//div[@id='s2id_periods']/a/span)[3]","mainFrame"));
	}

	public void selectMSOrderPeriod(String periodName) throws Exception {
		int periodsLength = get_orders_allPeriods().size();
		for (int i=1; i<=periodsLength; i++){
			System.out.printf("Period Name: ",select_Order_Period(i).getText());
			if (select_Order_Period(i).getText().equalsIgnoreCase(periodName)){
				select_Order_Period(i).click();
				//	System.out.printf("CLICKED.. ");
				break;
			}
		}
	}

	public Select get_ord_periodsContent() throws Exception {
		return (SeleniumHelperClass.selectFromDropdown("periodsContent", "mainframe"));
	}

	public List<WebElement> get_ord_ordertypes() throws Exception {
		SeleniumHelperClass
		.findWebElementbyXpath(
				"//div[@id='orderDetailsView']/div[2]/div/form/div[3]/div[2]/div[5]/span[2]/span/span",
				"mainframe").click();
		Thread.sleep(3000);
		return (SeleniumHelperClass
				.findWebElements(
						"//div[@id='orderDetailsView']/div[2]/div/form/div[3]/div[2]/div[5]/span[2]/div/div/ul/li",
						"mainframe"));
	}

	public WebElement select_OrderType_Create(int item) throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath(
						"//div[@id='orderDetailsView']/div[2]/div/form/div[3]/div[2]/div[5]/span[2]/div/div/ul/li["
								+ item + "]", "mainframe"));
	}

	public void selectOrderTypes(String orderTypes) throws Exception {
		// ((Select) get_ord_ordertypes()).selectByVisibleText(orderTypes);
		int orderTypesLength = get_ord_ordertypes().size();
		for (int i = 1; i <= orderTypesLength; i++) {
			System.out.printf("Elements Name: ", select_OrderType_Create(i)
					.getText());
			if (select_OrderType_Create(i).getText().equalsIgnoreCase(
					orderTypes)) {
				select_OrderType_Create(i).click();
				System.out.printf("CLICKED.. ");
			}

		}
	}

	public WebElement get_ord_ordertypesInBasicSearch() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath(
				"//*[@id='orderTypes']/option[2]",
				"mainframe");
	}

	public Select select_OrderType_BasicSearch() throws Exception {
		return (SeleniumHelperClass.selectFromDropdownwithelements("xpath", "//select[@id='orderTypes']", "mainframe"));

	}

	public void selectOrderTypesInBasicSearch(String orderTypes) throws Exception {
		// ((Select) get_ord_ordertypes()).selectByVisibleText(orderTypes);
		get_ord_ordertypesInBasicSearch().click();
		Thread.sleep(2000);
		select_OrderType_BasicSearch().selectByVisibleText(orderTypes);
	}

	/* For Amount Unit Type while creating order */
	public List<WebElement> get_AmountUnit_types() throws Exception {
		SeleniumHelperClass.findWebElementbyCssSelector("span.dropdown-title.unit-type-id", "mainframe").click();
		Thread.sleep(3000);
		return (SeleniumHelperClass
				.findWebElements(
						"//div[@id='orderDetailsView']/div[2]/div/form/div/div[3]/div/div/div/span[2]/div[2]/div/ul/li",
						"mainframe"));
	}

	public WebElement select_AmountUnitType_Create(int item) throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath(
						"//div[@id='orderDetailsView']/div[2]/div/form/div/div[3]/div/div/div/span[2]/div[2]/div/ul/li["
								+ item + "]", "mainframe"));
	}

	public void selectAmountUnitTypes(String amountUnitType) throws Exception {
		// ((Select) get_ord_ordertypes()).selectByVisibleText(orderTypes);
		int amountUnitTypesLength = get_AmountUnit_types().size();
		for (int i = 1; i <= amountUnitTypesLength; i++) {
			System.out.printf("Elements Name: ",
					select_AmountUnitType_Create(i).getText());
			if (select_AmountUnitType_Create(i).getText().equalsIgnoreCase(
					amountUnitType)) {
				select_AmountUnitType_Create(i).click();
				System.out.printf("CLICKED.. ");
			}

		}
	}

	public Select get_ord_unittype() throws Exception {
		return (SeleniumHelperClass.selectFromDropdown("amountUnitType", "mainframe"));
	}

	/* For from Incentive Date */
	public WebElement get_fromDate() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("fromDate", "mainframe"));
	}

	/* For To Incentive Date */
	public WebElement get_toDate() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("toDate", "mainframe"));
	}

	/* For just Incentive Date */
	public WebElement get_incentiveDate() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("incentiveDate", "mainframe"));
	}

	// For Add person
	public WebElement get_addPerson() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("assignmentBtn", "mainframe"));
	}

	// For Find Person in pop up
	public WebElement get_findPerson() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("search-text", "mainframe"));
	}

	// For Search person
	public WebElement get_searchButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("search-button", "mainframe"));
	}

	// For Person Check box

	public WebElement get_personCheckbox() throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath(
						"//div[2]/div[2]/div/div[2]/div[2]/div[2]/div[2]/div[2]/ul/li/div/span[1]/input",
						"mainFrame"));
	}

	// For Select person button
	public WebElement get_selectPerson() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@id='personView']/div/div/span[2]", "mainframe"));
	}

	/* Clicking the Search Button */
	public WebElement get_ord_search() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[@id='searchBtn']", "mainframe"));
	}

	public Select get_ord_status() throws Exception {
		return (SeleniumHelperClass.selectFromDropdown("status", "mainframe"));
	}

	public void selectStatus(String status) throws Exception {
		get_ord_status().selectByValue(status);
	}

	/* For from Status Date */
	public WebElement get_fromStatusDate() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("fromStatusDate", "mainframe"));
	}

	/* For To Status Date */
	public WebElement get_toStatusDate() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("toStatusDate", "mainframe"));
	}

	/* For from Incentive Date */
	public WebElement get_fromIncentiveDate() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("fromIncentiveDate",	"mainframe"));
	}

	/* For To Incentive Date */
	public WebElement get_toIncentiveDate() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("toIncentiveDate", "mainframe"));
	}

	/* For from Order Date */
	public WebElement get_fromOrderDate() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("fromOrderDate", "mainframe"));
	}

	/* For To Order Date */
	public WebElement get_toOrderDate() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("toOrderDate", "mainframe"));
	}

	/* For Just Order Date */
	public WebElement get_orderDate() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("orderDate", "mainframe"));
	}

	// Click on Select Batch Name link
	public WebElement get_selectBatchName() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("selectBatchName", "mainframe"));
	}

	// Click on Select Batch Name link
	public WebElement get_selectBatchNameInCreateOrders() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("selectBatchName", "mainFrame"));

	}

	// For Find BATCH in pop up
	public WebElement get_findBatch() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("search-text", "mainframe"));
	}

	// For Search person
	public WebElement get_searchBatchButton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("search-button", "mainframe"));
	}

	// For Batch Check box
	public WebElement get_BatchCheckbox() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//input[@name='selectedElement']", "mainframe"));
		//	return (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='element-list']/li/div/span/input", "mainframe"));
	}

	// For Select batch button
	public WebElement get_selectBatch() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='batchView']/div/div/span[2]", "mainframe"));
	}

	/* For Amount From */
	public WebElement get_ord_fromAmount() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("fromAmount", "mainframe"));
	}

	/* For Amount To */
	public WebElement get_ord_toAmount() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("toAmount", "mainframe"));
	}

	/* For Just Amount */
	public WebElement get_ord_Amount() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("amount", "mainframe"));
	}

	/* Clicking the Advanced Search Link */
	public WebElement click_adv_search() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("adv-search-top", "mainframe"));
	}

	/* Doing a Advanced Search */
	public WebElement do_adv_search() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("advanceSearchBtn", "mainframe"));
	}

	/* Doing a Left Filter Search */
	public WebElement do_leftFilter_search() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("searchBtnTop", "mainframe"));
	}

	/* Clicking the Create New Order */
	public WebElement click_createNewOrder() throws Exception {
		//	return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='inner-content']/div/div/div/span/span","mainframe"));
		return (SeleniumHelperClass.findWebElementbyXpath("//span[@id='createNewOrder']/span","mainframe"));
	}

	/* Doing a Save */
	public WebElement click_Order_Create() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@id='orderDetailsView']/div/span[2]/span[2]", "mainframe"));
	}

	/* Clicking a Edit Order */
	public WebElement do_EditOrder() throws Exception {
		return (SeleniumHelperClass.findWebElementbyCssSelector("css=button.pill-button.action-button"));
	}

	/***********************************************************************************************************************************/

	// For search for data in the pop up
	public WebElement enterColumnNameFld() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("search-text", "mainframe"));
	}

	// Click on Search after entering the data
	public WebElement searchColumnNameBtn() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("search-button", "mainframe"));
	}

	// For selecting the searched data
	public WebElement selectColumnCkbx() throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath(
						"/html/body/div[2]/div[2]/div/div[2]/div[2]/div[2]/div[2]/div[2]/ul/li/div/span[1]/input",
						"mainframe"));
	}

	// Click on the select button
	public WebElement selectColumnBtn() throws Exception {
		//return (SeleniumHelperClass.findWebElementbyXpath("//div[2]/div[2]/div/div/div/span[2]", "mainframe"));
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='selectColumnsView']/div/div/span[2]", "mainframe"));
	}


	/*	public WebElement editFavSavedSearch() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='savedSearchLists']/li/div/div/button", "mainframe"));

	}
	 */	

	/*	public WebElement searchSavedSearch() throws Exception {
		// return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='inner-content']/div[2]/div[3]/div/ul[2]/li/div[4]/span","mainframe"));
		return (SeleniumHelperClass.findWebElementbyXpath("//li/div/span","mainframe"));
	}*/

	public WebElement searchSavedSearch(int item) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//li[" + item + "]/div/span","mainframe"));
	}

	public WebElement deleteFavSavedSearch() throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath(
						"//div[2]/div[1]/div[2]/div[2]/div[3]/div/ul[2]/li[1]/div[4]/i",
						"mainframe"));
	}

	public WebElement confirmDeleteOnPopup() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("confirm-button", "mainframe"));
	}

	/***********************************************************************************************************************************/

	/************************************************************************************************************************************/

	public WebElement get_OrderCode_InSearchResultsRow(int item) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//ul[@id='orders-list']/li[" + item + "]/div/span[4]", "mainframe"));
	}

	public WebElement get_ItemCode_InSearchResultsRow(int item) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//ul[@id='orders-list']/li[" + item + "]/div/span[5]",	"mainframe"));
	}

	public WebElement get_DeleteButton_InSearchResultsRow(int item) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//ul[@id='orders-list']/li[" + item + "]/div/div/button[3]", "mainframe"));
		// return
		// (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='orders-list']/li["+item+"]/div[@class='list-item-row border-bottom orders-row']/div[@class='pill-button-grp']/button[@data-action='delete']/span",
		// "mainframe"));
	}

	public WebElement get_CopyButton_InSearchResultsRow(int item) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//ul[@id='orders-list']/li[" + item + "]/div/div/button[2]", "mainframe"));

	}

	public WebElement get_EditButton_InSearchResultsRow(int item) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//ul[@id='orders-list']/li[" + item + "]/div/div/button[1]", "mainframe"));

	}

	public WebElement get_ConfirmDeleteButton_InSearchResultsRow() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("confirm-button", "mainframe"));
	}

	public WebElement get_OrderCode_InExpandRow(int item) throws Exception {
		return (SeleniumHelperClass
				.findWebElementbyXpath(
						"//ul[@id='orders-list']/li["
								+ item
								+ "]/div/div[3]/fieldset/div[3]/div/div[3]/div[2]/div/span", "mainframe"));
	}

	public WebElement get_ItemCode_InExpandRow(int item) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//ul[@id='orders-list']/li["
						+ item
						+ "]/div/div[3]/fieldset/div[3]/div/div[3]/div[3]/div/span", "mainframe"));
	}

	public WebElement get_BatchName_InExpandRow(int item) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//ul[@id='orders-list']/li["
						+ item
						+ "]/div/div[3]/fieldset/div[3]/div/div[3]/div[5]/div/span", "mainframe"));
	}

	public WebElement get_OrderType_InExpandRow(int item) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//ul[@id='orders-list']/li["
						+ item
						+ "]/div/div[3]/fieldset/div[3]/div[1]/div[3]/div[6]/div/span",	"mainframe"));
	}

	/*public WebElement get_OrderType_InExpandRow(int item) throws Exception {
	return (SeleniumHelperClass
			.findWebElementbyXpath(
					"//ul[@id='orders-list']/li["
							+ item
							+ "]/div/div[3]/fieldset/div[3]/div/div[4]/div[6]/div/span",
					"mainframe"));
     }*/


	public WebElement get_result_count() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("results-total","mainframe"));
	}


	//To get the gear icon in Orders -> Staging - Gear Icon of Saved Searches
	public WebElement get_saved_search_gear_icon() throws Exception {
		return (SeleniumHelperClass.findWebElementbyCssSelector("i.fa.fa-search", "mainframe"));
	}

	//To save as new saved search from Orders -> Staging - Gear Icon of Saved Searches
	public WebElement get_save_as_new_saved_search_gear_icon() throws Exception {
		return (SeleniumHelperClass.findWebElementbyCssSelector("a.save-as-new-saved-search", "mainframe"));
	}

	//To edit saved search from Orders -> Staging - Gear Icon of Saved Searches
	public WebElement get_edit_saved_search_gear_icon() throws Exception {
		return (SeleniumHelperClass.findWebElementbyCssSelector("a.edit-saved-search", "mainframe"));
	}

	//To add as favorite saved search from Orders -> Staging - Gear Icon of Saved Searches
	public WebElement get_add_as_favorite_saved_search_gear_icon() throws Exception {
		return (SeleniumHelperClass.findWebElementbyCssSelector("a.favorite-saved-search", "mainframe"));
	}


	public List<String> get_order_staging_search_by_column_data(String header) throws Exception{
		List data = new ArrayList();
		int resultCount = get_result_count_int();
		logger.info("Search Count:"+resultCount);
		int headerPosition =1;
		String headers = SeleniumHelperClass.findWebElementbyXpath("//div[2]/div[1]/div[2]/div[2]/div[2]/div[1]/div[3]/div[2]/div/div[1]", "mainframe").getText();
		logger.info("headers:"+headers);
		int headersCount = headers.split("\\n").length;
		logger.info("header size:"+headersCount);
		for (int h=0; h<= headersCount;h++){
			if (headers.split("\\n")[h].equalsIgnoreCase(header)){
				headerPosition = h+2;
				break;
			}
		}	
		for(int d =1; d<=resultCount;d++){
			data.add(SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']/li["+d+"]/div/div/div/span["+headerPosition+"]", "mainframe").getText());
		}
		logger.info("Data: " +data);
		return data;		

	}

	//Get item code Name in list of processed orders 
	public WebElement get_item_code_in_processed_orders(int i) throws Exception{
		return (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']/li["+i+"]/div/div/div[1]/span[5]", "mainframe"));
	}


	//Get Expanded row number in processed order
	int expanded_row_number_processed_order;



	public int getExpanded_row_number_processed_order() {
		return expanded_row_number_processed_order;
	}

	public void setExpanded_row_number_processed_order(int expanded_row_number_processed_order) {
		this.expanded_row_number_processed_order = expanded_row_number_processed_order;
	}

	//Expand row based on item code processed orders 
	public void expand_row_based_item_code_in_processed_orders(String itemCode) throws Exception{
		int resultCount = get_result_count_int();			
		for (int r=1;r<=resultCount;r++){
			if (get_item_code_in_processed_orders(r).getText().contentEquals(itemCode)){
				SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']/li["+r+"]/div/div/div/span[5]", "mainframe").click();
				setExpanded_row_number_processed_order(r);
				break;
			}
		}

	}

	//click credits link in expand row of processed orders 
	public WebElement get_credits_in_processed_orders() throws Exception{
		int rowNum = getExpanded_row_number_processed_order();
		return (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[4]/fieldset/div[3]", "mainframe"));
		//return (SeleniumHelperClass.findWebElementbyXpath("html/body/div[2]/div[1]/div[2]/div[2]/div[2]/div[1]/div[3]/div[2]/div/div[2]/ul/li[1]/div/div[3]/fieldset/div[3]", "mainframe"));
	}

	//click commissions link in expand row of processed orders 
	public WebElement get_commissions_in_processed_orders() throws Exception{
		int rowNum = getExpanded_row_number_processed_order();
		return (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[4]/fieldset/div[4]", "mainframe"));
	}	

	//click Bonuses link in expand row of processed orders 
	public WebElement get_bonuses_in_processed_orders() throws Exception{
		int rowNum = getExpanded_row_number_processed_order();
		return (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[4]/fieldset/div[5]", "mainframe"));
	}	


	//get Credits required data based on person Name
	public HashMap<String, String> get_credits_data_based_on_person_name_in_processed_orders(String requiredDataHeader) throws Exception{
		HashMap<String, String> resultSet = new HashMap<String, String>();
		int rowNum = getExpanded_row_number_processed_order();
		List<WebElement> recordCount = SeleniumHelperClass.findWebElements("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[3]/fieldset/div[6]/div[3]/table/tbody/tr", "mainframe");
		List<WebElement> headerCount = SeleniumHelperClass.findWebElements("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[3]/fieldset/div[6]/div[3]/table/thead/tr/th", "mainframe");
		int requiredHeaderPosition=1;
		int personHeaderPosition=1;
		for (int h=1; h<=headerCount.size();h++){
			if (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[3]/fieldset/div[6]/div[3]/table/thead/tr/th["+h+"]", "mainframe").getText().contentEquals("Person Name")){
				personHeaderPosition = h;
			}
			if (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[3]/fieldset/div[6]/div[3]/table/thead/tr/th["+h+"]", "mainframe").getText().contentEquals(requiredDataHeader)){
				requiredHeaderPosition = h;
			}					 
		}

		for (int r=1; r<= recordCount.size(); r++){
			String personName = SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[3]/fieldset/div[6]/div[3]/table/tbody/tr["+r+"]/td["+personHeaderPosition+"]", "mainframe").getText();
			String value = SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[3]/fieldset/div[6]/div[3]/table/tbody/tr["+r+"]/td["+requiredHeaderPosition+"]", "mainframe").getText();
			resultSet.put(personName, value);
		}

		logger.info("HashSet"+resultSet);
		return resultSet;
	}	

	//get Commisions required data based on person Name
	public HashMap<String, String> get_commissions_data_based_on_person_name_in_processed_orders(String requiredDataHeader) throws Exception{
		HashMap<String, String> resultSet = new HashMap<String, String>();
		int rowNum = getExpanded_row_number_processed_order();
		List<WebElement> recordCount = SeleniumHelperClass.findWebElements("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[3]/fieldset/div[6]/div[4]/table/tbody/tr", "mainframe");
		List<WebElement> headerCount = SeleniumHelperClass.findWebElements("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[3]/fieldset/div[6]/div[4]/table/thead/tr/th", "mainframe");
		int requiredHeaderPosition=1;
		int personHeaderPosition=1;
		for (int h=1; h<=headerCount.size();h++){
			if (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[3]/fieldset/div[6]/div[4]/table/thead/tr/th["+h+"]", "mainframe").getText().contentEquals("Person Name")){
				personHeaderPosition = h;
			}
			if (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[3]/fieldset/div[6]/div[4]/table/thead/tr/th["+h+"]", "mainframe").getText().contentEquals(requiredDataHeader)){
				requiredHeaderPosition = h;
			}					 
		}

		for (int r=1; r<= recordCount.size(); r++){
			String personName = SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[3]/fieldset/div[6]/div[4]/table/tbody/tr["+r+"]/td["+personHeaderPosition+"]", "mainframe").getText();
			String value = SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[3]/fieldset/div[6]/div[4]/table/tbody/tr["+r+"]/td["+requiredHeaderPosition+"]", "mainframe").getText();
			resultSet.put(personName, value);
		}

		logger.info("HashSet"+resultSet);
		return resultSet;
	}

	//get Bonuses required data based on person Name
	public HashMap<String, String> get_Bonuses_data_based_on_person_name_in_processed_orders(String requiredDataHeader) throws Exception{
		HashMap<String, String> resultSet = new HashMap<String, String>();
		int rowNum = getExpanded_row_number_processed_order();
		List<WebElement> recordCount = SeleniumHelperClass.findWebElements("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[3]/fieldset/div[6]/div[5]/table/tbody/tr", "mainframe");
		List<WebElement> headerCount = SeleniumHelperClass.findWebElements("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[3]/fieldset/div[6]/div[5]/table/thead/tr/th", "mainframe");
		int requiredHeaderPosition=1;
		int personHeaderPosition=1;
		for (int h=1; h<=headerCount.size();h++){
			if (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[3]/fieldset/div[6]/div[5]/table/thead/tr/th["+h+"]", "mainframe").getText().contentEquals("Person Name")){
				personHeaderPosition = h;
			}
			if (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[3]/fieldset/div[6]/div[5]/table/thead/tr/th["+h+"]", "mainframe").getText().contentEquals(requiredDataHeader)){
				requiredHeaderPosition = h;
			}					 
		}

		for (int r=1; r<= recordCount.size(); r++){
			String personName = SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[3]/fieldset/div[6]/div[5]/table/tbody/tr["+r+"]/td["+personHeaderPosition+"]", "mainframe").getText();
			String value = SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']/li["+rowNum+"]/div/div/div[3]/fieldset/div[6]/div[5]/table/tbody/tr["+r+"]/td["+requiredHeaderPosition+"]", "mainframe").getText();
			resultSet.put(personName, value);
		}

		logger.info("HashSet"+resultSet);
		return resultSet;
	}	

	//Favorite Saved Searches on Basic Search Page
	public WebElement get_favorite_saved_searches() throws Exception{
		return (SeleniumHelperClass.findWebElementbyLink("Favorite Saved Searches", "mainframe"));
	}

	//My Saved Searches on Basic Search Page
	public WebElement get_my_saved_searches() throws Exception{
		return (SeleniumHelperClass.findWebElementbyLink("My Saved Searches", "mainframe"));
	}
	//Get Saved Search List
	public List<WebElement> get_saved_searches_list() throws Exception{
		return (SeleniumHelperClass.findWebElements("//ul[@id='savedSearchLists']/li/div","mainframe"));
		//return (SeleniumHelperClass.findWebElements("//div[@id='inner-content']/div[2]/div[3]/div/ul[2]/li", "mainframe"));
	}

	//Get Required Saved Search from a List
	public WebElement get_saved_search(int i) throws Exception{
		return (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='savedSearchLists']/li["+i+"]/div/span", "mainframe"));
		//return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='inner-content']/div[2]/div[3]/div/ul[2]/li["+i+"]/div", "mainframe"));
	}

	//Search By Saved Search Name
	public WebElement search_by_saved_search(int i) throws Exception{
		//	return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='inner-content']/div[2]/div[3]/div/ul[2]/li["+i+"]/div[4]/span", "mainframe"));
		return (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='savedSearchLists']/li["+i+"]/div/span", "mainframe"));
	}	



	//Edit By Saved Search Name
	public WebElement edit_by_saved_search(int i) throws Exception{
		Actions action = new Actions(SetWebDrivers.getDriver());
		Thread.sleep(2000);
		WebElement editSavedSearch = SeleniumHelperClass.findWebElementbyXpath("//ul[@id='savedSearchLists']/li["+i+"]/div/span","mainframe");
		SeleniumHelperClass.findWebElementbyXpath("//ul[@id='savedSearchLists']/li["+i+"]/div/span[2]","mainframe").click();
		action.moveToElement(editSavedSearch);
		//return SeleniumHelperClass.findWebElementbyXpath("//ul[@id='savedSearchLists']/li["+i+"]/div/div/button","mainframe");
		return SeleniumHelperClass.findWebElementbyXpath("//li["+i+"]/div/div/button","mainframe");
	}	


	public WebElement copy_by_saved_search(int i) throws Exception{
		Actions action = new Actions(SetWebDrivers.getDriver());
		Thread.sleep(2000);
		WebElement copySavedSearch = SeleniumHelperClass.findWebElementbyXpath("//ul[@id='savedSearchLists']/li["+i+"]/div/span","mainframe");
		SeleniumHelperClass.findWebElementbyXpath("//ul[@id='savedSearchLists']/li["+i+"]/div/span[2]","mainframe").click();
		action.moveToElement(copySavedSearch);
		//return SeleniumHelperClass.findWebElementbyXpath("//ul[@id='savedSearchLists']/li["+i+"]/div/div/button","mainframe");
		return SeleniumHelperClass.findWebElementbyXpath("//li["+i+"]/div/div/button[2]","mainframe");
	}	

	//Delete By Saved Search Name
	public WebElement delete_by_saved_search(int i) throws Exception{
		Actions action = new Actions(SetWebDrivers.getDriver());
		Thread.sleep(2000);
		WebElement deleteSavedSearch = SeleniumHelperClass.findWebElementbyXpath("//ul[@id='savedSearchLists']/li["+i+"]/div/span","mainframe");
		SeleniumHelperClass.findWebElementbyXpath("//ul[@id='savedSearchLists']/li["+i+"]/div/span[2]","mainframe").click();
		action.moveToElement(deleteSavedSearch);
		return SeleniumHelperClass.findWebElementbyXpath("//ul[@id='savedSearchLists']/li["+i+"]/div/div/button[3]","mainframe");
	}	

	public void search_BySavedSearch(String savedSearchName) throws Exception{
		int countOfSavedSearches = get_saved_searches_list().size();
		logger.info("Saved Searches List: "+countOfSavedSearches);
		for (int s=1; s<=countOfSavedSearches; s++){
			if (get_saved_search(s).getText().contentEquals(savedSearchName)){
				search_by_saved_search(s).click();
				break;
			}
		}
	}

	public void edit_BySavedSearch(String savedSearchName, String editedSavedSearchName) throws Exception{
		int countOfSavedSearches = get_saved_searches_list().size();
		logger.info("No of Saved Searches: "+countOfSavedSearches);
		for (int s=1; s<countOfSavedSearches; s++){
			if (get_saved_search(s).getText().contentEquals(savedSearchName)){
				edit_by_saved_search(s).click();
				get_savedsearch_name().clear();
				get_savedsearch_name().sendKeys(editedSavedSearchName);
				create_savedSearch().click();
				logger.info("Action: "+edit_by_saved_search(s));
				Thread.sleep(2000);

				break;
			}
		}
	}

	public void copy_BySavedSearch(String savedSearchName, String copiedSavedSearchName) throws Exception{
		int countOfSavedSearches = get_saved_searches_list().size();
		logger.info("No of Saved Searches: "+countOfSavedSearches);
		for (int s=1; s<countOfSavedSearches; s++){
			if (get_saved_search(s).getText().contentEquals(savedSearchName)){
				copy_by_saved_search(s).click();
				get_savedsearch_name().clear();
				get_savedsearch_name().sendKeys(copiedSavedSearchName);
				create_savedSearch().click();
				logger.info("Action: "+copy_by_saved_search(s));
				Thread.sleep(2000);

				break;
			}
		}

	}

	public void delete_BySavedSearch(String savedSearchName) throws Exception{
		int countOfSavedSearches = get_saved_searches_list().size();
		logger.info("No of Saved Searches: "+countOfSavedSearches);
		for (int s=1; s<countOfSavedSearches; s++){
			if (get_saved_search(s).getText().contentEquals(savedSearchName)){
				delete_by_saved_search(s).click();
				SeleniumHelperClass.findWebElementbyid("confirm-button", "mainframe").click();
				break;
			}

		}
	}

	// Click on the select button for item code selection
	public WebElement get_item_code_select_button_saved_search() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='details-search-fields']/li[4]/span[3]/div/i", "mainframe"));
	}

	public WebElement select_button_on_item_code_pop_up_saved_search() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='itemCodeView']/div/div/span[2]", "mainframe"));
	}

	public boolean isPageLoading() throws Exception{
		//assertTrue(isElementPresent(By.cssSelector("div.k-loading-image")));
		if(SeleniumHelperClass.findWebElementbyCssSelector("div.k-loading-image", "mainframe").isDisplayed()){
			logger.info("Page is Loading");				
			return true;
		}else{
			logger.info("Page Loaded");
			return false;
		}

	}

	/************************************************************************************************************************************/

	/* methods on Orders Search Results Page */

	public int get_result_count_int() throws Exception {

		Thread.sleep(2000);
		String result = get_result_count().getText();
		Thread.sleep(2000);
		int result_int = result.length();
		Thread.sleep(2000);
		result = result.substring(result.indexOf('(')+1, result.indexOf(')')).trim();
		Thread.sleep(2000);
		return Integer.parseInt(result);
	}

	/* methods on Orders Saved Search Results Page */

	public void copyOrder(String ocode, String icode, String newOrdercode,
			String newItemCode) throws Exception {
		SeleniumHelperClass.goToFrame("mainFrame");
		Thread.sleep(3000);
		Thread.sleep(3000);
		int result_count = get_result_count_int();
		for (int r = 1; r <= result_count; r++) {
			if (get_OrderCode_InSearchResultsRow(r).getText().equalsIgnoreCase(
					ocode)
					&& get_ItemCode_InSearchResultsRow(r).getText()
					.equalsIgnoreCase(icode)) {
				Actions action = new Actions(SetWebDrivers.getDriver());
				Thread.sleep(2000);
				get_OrderCode_InSearchResultsRow(r).click();
				action.moveToElement(get_OrderCode_InSearchResultsRow(r));
				Thread.sleep(1000);
				action.moveToElement(get_CopyButton_InSearchResultsRow(r))
				.click().perform();
				Thread.sleep(2000);
				break;

			}

		}
		get_ocode_name().clear();
		get_ocode_name().sendKeys(newOrdercode);
		Thread.sleep(1000);
		get_icode_name().clear();
		get_icode_name().sendKeys(newItemCode);
		Thread.sleep(1000);
		click_Order_Create().click();

	}

	public void editOrder(String ocode, String icode, String amount) throws Exception {
		SeleniumHelperClass.goToFrame("mainFrame");
		Thread.sleep(3000);
		int result_count = get_result_count_int();
		for (int r = 1; r <= result_count; r++) {
			if (get_OrderCode_InSearchResultsRow(r).getText().equalsIgnoreCase(
					ocode)
					&& get_ItemCode_InSearchResultsRow(r).getText()
					.equalsIgnoreCase(icode)) {
				Actions action = new Actions(SetWebDrivers.getDriver());
				Thread.sleep(2000);
				get_OrderCode_InSearchResultsRow(r).click();
				action.moveToElement(get_OrderCode_InSearchResultsRow(r));
				Thread.sleep(1000);
				action.moveToElement(get_EditButton_InSearchResultsRow(r))
				.click().perform();
				Thread.sleep(2000);
				break;

			}

		}
		get_ord_Amount().clear();
		get_ord_Amount().sendKeys(amount);
		Thread.sleep(1000);
		click_Order_Create().click();

	}

	public List getOrderDetailsByExpandingtheRow(String ocode, String icode) throws Exception {
		List orderDetails = new ArrayList();
		SeleniumHelperClass.goToFrame("mainFrame");
		Thread.sleep(3000);
		int result_count = get_result_count_int();
		for (int r = 1; r <= result_count; r++) {
			if (get_OrderCode_InSearchResultsRow(r).getText().equalsIgnoreCase(
					ocode)
					&& get_ItemCode_InSearchResultsRow(r).getText()
					.equalsIgnoreCase(icode)) {

				get_OrderCode_InSearchResultsRow(r).click();
				orderDetails.add(get_OrderCode_InExpandRow(r).getText());
				orderDetails.add(get_ItemCode_InExpandRow(r).getText());
				orderDetails.add(get_BatchName_InExpandRow(r).getText());
				orderDetails.add(get_OrderType_InExpandRow(r).getText());
			}
		}
		return orderDetails;

	}

	/************************************************************************************************************************************/

	/*
	 * Basic Search [PeriodName, OrderCode, ItemCode, OrderType, FromDate,
	 * ToDate]
	 */

	public void basicSearch(String periodName, String ocode, String icode, String orderTypes,
			String fromDate, String toDate, String findperson) throws Exception {

		WebDriver driver = SetWebDrivers.getDriver();
		JavascriptExecutor js = (JavascriptExecutor) driver;

		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);

		get_ocode_name().sendKeys(ocode);
		Thread.sleep(1000);
		get_icode_name().sendKeys(icode);
		// selectOrderTypes(orderTypes);
		if (orderTypes != "") {
			selectOrderTypesInBasicSearch(orderTypes);
		}

		Thread.sleep(1000);
		js.executeScript("document.getElementById('fromDate').removeAttribute('disabled')");
		Thread.sleep(1000);
		get_fromDate().sendKeys(fromDate);
		Thread.sleep(2000);
		js.executeScript("document.getElementById('toDate').removeAttribute('disabled')");
		Thread.sleep(2000);
		get_toDate().sendKeys(toDate);
		Thread.sleep(1000);
		get_addPerson().click();
		Thread.sleep(1000);
		get_findPerson().sendKeys(findperson);
		Thread.sleep(1000);
		get_searchButton().click();
		Thread.sleep(1000);
		get_personCheckbox().click();
		Thread.sleep(1000);
		get_selectPerson().click();
		Thread.sleep(1000);
		get_ord_search().click();
		Thread.sleep(2000);
	}

	public void searchWithOrderAndItemCode(String ocode, String icode, String periodName) throws Exception {
		Thread.sleep(2000);
		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);
		get_ocode_name().sendKeys(ocode);
		Thread.sleep(1000);
		get_icode_name().sendKeys(icode);
		Thread.sleep(1000);
		get_ord_search().click();
		Thread.sleep(2000);
	}

	public void searchWithPeriod(String periodName) throws Exception {

		Thread.sleep(2000);	
		get_orders_period_dropdown().click();
		Thread.sleep(2000);
		selectOrderPeriod(periodName);
		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(2000);
	}



	public void basicSearchOSWithOrderCode(String periodName, String ocode) throws Exception {

		Thread.sleep(2000);
		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);
		get_ocode_name().sendKeys(ocode);
		Thread.sleep(1000);
		get_ord_search().click();
		Thread.sleep(2000);
	}

	public void basicSearchOSWithItemCode(String periodName, String icode) throws Exception {

		Thread.sleep(2000);
		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);
		get_icode_name().sendKeys(icode);
		Thread.sleep(1000);
		get_ord_search().click();
		Thread.sleep(2000);
	}

	/************************************************************************************************************************************/

	/*
	 * Basic Search [PeriodName, OrderCode, ItemCode, OrderType, FromDate,
	 * ToDate]
	 */

	public void basicSearchOSWithOrderType(String periodName, String orderTypes) throws Exception {
		Thread.sleep(2000);
		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);

		if (orderTypes != "") {
			selectOrderTypesInBasicSearch(orderTypes);
		}
		Thread.sleep(1000);
		get_ord_search().click();
		Thread.sleep(2000);
	}

	/************************************************************************************************************************************/

	/*
	 * Basic Search [PeriodName, OrderCode, ItemCode, OrderType, FromDate,
	 * ToDate]
	 */

	public void basicSearchOSWithIncentiveDate(String periodName, String fromDate, String toDate) throws Exception {

		WebDriver driver = SetWebDrivers.getDriver();
		JavascriptExecutor js = (JavascriptExecutor) driver;

		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);		
		js.executeScript("document.getElementById('fromDate').removeAttribute('disabled')");
		Thread.sleep(1000);		
		get_fromDate().sendKeys(fromDate);
		Thread.sleep(2000);
		js.executeScript("document.getElementById('toDate').removeAttribute('disabled')");
		Thread.sleep(1000);
		get_toDate().sendKeys(toDate);		
		Thread.sleep(1000);
		get_ord_search().click();
		Thread.sleep(2000);
	}

	/************************************************************************************************************************************/

	/*
	 * Basic Search [PeriodName, OrderCode, ItemCode, OrderType, FromDate,
	 * ToDate]
	 */

	public void basicSearchOSWithAssignment(String periodName, String findperson) throws Exception {

		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);		
		get_addPerson().click();
		Thread.sleep(1000);
		get_findPerson().sendKeys(findperson);
		Thread.sleep(1000);
		get_searchButton().click();
		Thread.sleep(1000);
		get_personCheckbox().click();
		Thread.sleep(1000);
		get_selectPerson().click();
		Thread.sleep(1000);
		get_ord_search().click();
		Thread.sleep(2000);
	}

	public void createOrder(String periodName, String ocode, String icode, String incentiveDate, String Amount, String amountUnitType,
			String orderDate, String Assignment, String batchName) throws Exception {

		WebDriver driver = SetWebDrivers.getDriver();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		SeleniumHelperClass.goToFrame("mainFrame");
		Thread.sleep(1000);
		click_createNewOrder().click();
		Thread.sleep(1000);
		Thread.sleep(1000);
		/*		get_orders_period_dropdown().click();
		Thread.sleep(2000);
		selectOrderPeriod(periodName);
		Thread.sleep(2000);*/
		get_msorders_period_dropdown().click();
		Thread.sleep(2000);
		selectMSOrderPeriod(periodName);
		Thread.sleep(2000);
		get_ocode_name().sendKeys(ocode);
		Thread.sleep(1000);
		get_icode_name().sendKeys(icode);
		Thread.sleep(1000);
		get_selectBatchNameInCreateOrders().click();
		// get_selectBatchNameInCreateOrders();
		Thread.sleep(1000);
		get_findBatch().sendKeys(batchName);
		Thread.sleep(1000);
		get_searchBatchButton().click();
		Thread.sleep(1000);
		get_BatchCheckbox().click();
		Thread.sleep(1000);
		get_selectBatch().click();
		Thread.sleep(1000);
		js.executeScript("document.getElementById('incentiveDate').removeAttribute('disabled')");
		get_incentiveDate().sendKeys(incentiveDate);
		get_ocode_name().click();
		Thread.sleep(1000);
		/*if (orderType != "") {
			selectOrderTypes(orderType);
		}
		Thread.sleep(1000);*/
		get_ord_Amount().sendKeys(Amount);
		Thread.sleep(1000);
		if (amountUnitType != "") {
			selectAmountUnitTypes(amountUnitType);
		}
		Thread.sleep(1000);
		js.executeScript("document.getElementById('orderDate').removeAttribute('disabled')");
		get_orderDate().sendKeys(orderDate);
		get_ocode_name().click();
		Thread.sleep(1000);

		/*get_addPerson().click(); Thread.sleep(1000);
		 get_findPerson().sendKeys(Assignment); Thread.sleep(1000);
		 get_searchButton().click(); Thread.sleep(1000);
		 get_personCheckbox().click(); Thread.sleep(1000);
		 get_selectPerson().click();*/

		Thread.sleep(1000);
		click_Order_Create().click();
		Thread.sleep(1000);

	}

	/***********************************************************************************************************************************/

	public void editOrder(String periods, String ocode) throws Exception {

		WebDriver driver = SetWebDrivers.getDriver();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		// logger.info("again switching to frame");
		SeleniumHelperClass.goToFrame("mainFrame");
		selectPeriod(periods);
		get_ocode_name().sendKeys(ocode);
		Thread.sleep(3000);
		get_ord_search().click();
		// Thread.sleep(3000);
		do_EditOrder().click();
		click_Order_Create().click();
		Thread.sleep(1000);
	}

	/***********************************************************************************************************************************/

	/* Create Saved Search */


	/* Create New Saved Search Name */
	public WebElement get_savedsearch_name() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("inputTitle", "mainframe"));
	}


	/* Saving Saved Search */
	public WebElement create_savedSearch() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(
				"//div[@id='savedSearchDetailsView']/div[3]/span/span[2]", "mainframe"));
	}

	/* Clicking the new ss Link */
	public WebElement click_createNewSavedSearch() throws Exception {
		//return (SeleniumHelperClass.findWebElementbyLink("+ Create New Saved Search", "mainframe"));
		return (SeleniumHelperClass.findWebElementbyXpath("//span[@id='createNewSearch']/span", "mainframe"));
	}

	/* Clicking yes add to Favorite */
	public WebElement yes_AddToFav() throws Exception {
		return (SeleniumHelperClass.findWebElementbyCssSelector("#tag-visible-button > span","mainframe"));
	}


	/* Enter item Code */
	public WebElement get_itemCode_name_saved_search() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("(//input[@id='itemCode'])[2]","mainframe"));
	}

	/* Clicking Add Columns link */
	public WebElement add_Columns() throws Exception {
		return (SeleniumHelperClass.findWebElementbyLink("Add Columns",	"mainframe"));
	}

	public void doSearchOnSavedSearch(String savedSearchName) throws Exception {
		//searchSavedSearch().click();
		int countOfSavedSearches = get_saved_searches_list().size();
		logger.info("No of Saved Searches: "+countOfSavedSearches);
		for (int s=1; s<countOfSavedSearches; s++){
			if (get_saved_search(s).getText().contentEquals(savedSearchName)){
				searchSavedSearch(s).click();
				break;
			}

		}
	}

	public void advSearchWithOrderCodeItemCode(String periodName, String orderCode, String itemCode) throws Exception {

		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(2000);
		click_adv_search().click();
		Thread.sleep(2000);		
		get_msorders_period_dropdown().click();
		Thread.sleep(1000);
		selectMSOrderPeriod(periodName);
		Thread.sleep(2000);
		get_ocode_name().sendKeys(orderCode);
		Thread.sleep(1000);
		get_icode_name().sendKeys(itemCode);
		Thread.sleep(1000);
		do_adv_search().click();
		Thread.sleep(1000);
	}

	public void advSearchWithIncentiveDate(String periodName, String fromIncentiveDate, String toIncentiveDate) throws Exception {

		WebDriver driver = SetWebDrivers.getDriver();
		JavascriptExecutor js = (JavascriptExecutor) driver;

		Thread.sleep(1000);
		get_ord_search().click();
		Thread.sleep(2000);
		click_adv_search().click();
		Thread.sleep(2000);		
		get_msorders_period_dropdown().click();
		Thread.sleep(1000);
		selectMSOrderPeriod(periodName);
		Thread.sleep(2000);
		js.executeScript("document.getElementById('fromIncentiveDate').removeAttribute('disabled')");
		Thread.sleep(1000);
		get_fromIncentiveDate().sendKeys(fromIncentiveDate);
		Thread.sleep(1000);
		js.executeScript("document.getElementById('toIncentiveDate').removeAttribute('disabled')");
		Thread.sleep(1000);
		get_toIncentiveDate().sendKeys(toIncentiveDate);
		Thread.sleep(1000);
		do_adv_search().click();
		Thread.sleep(1000);

	}

	public void advSearchWithOrderDate(String periodName, String fromOrderDate, String toOrderDate) throws Exception {

		WebDriver driver = SetWebDrivers.getDriver();
		JavascriptExecutor js = (JavascriptExecutor) driver;

		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(2000);
		click_adv_search().click();
		Thread.sleep(2000);		
		get_msorders_period_dropdown().click();
		Thread.sleep(1000);
		selectMSOrderPeriod(periodName);
		Thread.sleep(2000);
		js.executeScript("document.getElementById('fromOrderDate').removeAttribute('disabled')");
		Thread.sleep(1000);
		get_fromOrderDate().sendKeys(fromOrderDate);
		Thread.sleep(1000);
		js.executeScript("document.getElementById('toOrderDate').removeAttribute('disabled')");
		Thread.sleep(1000);
		get_toOrderDate().sendKeys(toOrderDate);
		Thread.sleep(1000);
		do_adv_search().click();
		Thread.sleep(2000);
	}

	public void advSearchByBatchName(String periodName, String batchName) throws Exception {

		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(2000);
		click_adv_search().click();
		Thread.sleep(2000);		
		get_msorders_period_dropdown().click();
		Thread.sleep(1000);
		selectMSOrderPeriod(periodName);
		Thread.sleep(2000);
		get_selectBatchName().click();
		Thread.sleep(2000);
		get_findBatch().sendKeys(batchName);
		Thread.sleep(1000);
		get_searchBatchButton().click();
		Thread.sleep(2000);
		get_BatchCheckbox().click();
		Thread.sleep(1000);
		get_selectBatch().click();
		Thread.sleep(2000);
		do_adv_search().click();
		Thread.sleep(2000);
	}	

	public void advSearchWithAmount(String periodName, String amount) throws Exception {

		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(2000);
		click_adv_search().click();
		Thread.sleep(2000);		
		get_msorders_period_dropdown().click();
		Thread.sleep(1000);
		selectMSOrderPeriod(periodName);
		Thread.sleep(2000);
		get_ord_Amount().sendKeys(amount);
		Thread.sleep(1000);
		do_adv_search().click();
		Thread.sleep(2000);
	}

	public void advSearchWithAssignment(String periodName, String assignment) throws Exception {

		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(2000);
		click_adv_search().click();
		Thread.sleep(2000);		
		get_msorders_period_dropdown().click();
		Thread.sleep(1000);
		selectMSOrderPeriod(periodName);
		Thread.sleep(2000);
		get_addPerson().click();
		Thread.sleep(2000);
		get_findPerson().sendKeys(assignment);
		Thread.sleep(1000);
		get_searchButton().click();
		Thread.sleep(2000);
		get_personCheckbox().click();
		Thread.sleep(1000);
		get_selectPerson().click();
		Thread.sleep(2000);
		do_adv_search().click();
		Thread.sleep(1000);
	}

	/*
	 * Basic Search [PeriodName, OrderCode, ItemCode, OrderType, FromDate,
	 * ToDate]
	 */

	public void basicSearchProcessedOrders(String ocode, String icode, String orderTypes, String periodName,
			String fromDate, String toDate, String findperson) throws Exception {

		WebDriver driver = SetWebDrivers.getDriver();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Thread.sleep(2000);
		get_processed_link().click();

		Thread.sleep(1000);

		get_ocode_name().sendKeys(ocode);
		Thread.sleep(1000);
		get_icode_name().sendKeys(icode);
		Thread.sleep(1000);
		if (orderTypes != "") {
			selectOrderTypesInBasicSearch(orderTypes);
		}
		Thread.sleep(2000);
		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(2000);		
		js.executeScript("document.getElementById('fromDate').removeAttribute('disabled')");
		Thread.sleep(1000);
		get_fromDate().sendKeys(fromDate);
		Thread.sleep(2000);
		js.executeScript("document.getElementById('toDate').removeAttribute('disabled')");
		Thread.sleep(1000);
		get_toDate().sendKeys(toDate);
		Thread.sleep(1000);
		get_addPerson().click();
		Thread.sleep(2000);
		get_findPerson().sendKeys(findperson);
		Thread.sleep(1000);
		get_searchButton().click();
		Thread.sleep(2000);
		get_personCheckbox().click();
		Thread.sleep(1000);
		get_selectPerson().click();
		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(2000);
	}

	// POOC

	public void basicSearchPOWithOrderCode(String ocode) throws Exception {

		Thread.sleep(2000);
		get_processed_link().click();
		Thread.sleep(2000);
		get_ocode_name().sendKeys(ocode);
		Thread.sleep(1000);
		get_ord_search().click();
		Thread.sleep(2000);
	}

	public void basicSearchPOWithItemCode(String icode) throws Exception {

		Thread.sleep(2000);
		get_processed_link().click();
		Thread.sleep(2000);
		get_icode_name().sendKeys(icode);
		Thread.sleep(1000);
		get_ord_search().click();
		Thread.sleep(2000);
	}

	public void basicSearchPOWithOrderCodeItemCode(String ocode, String icode) throws Exception {

		Thread.sleep(2000);
		get_processed_link().click();
		Thread.sleep(2000);
		get_ocode_name().sendKeys(ocode);
		Thread.sleep(1000);
		get_icode_name().sendKeys(icode);
		Thread.sleep(1000);
		get_ord_search().click();
		Thread.sleep(2000);
	}

	public void basicSearchPOWithOrderType(String orderTypes) throws Exception {

		Thread.sleep(2000);
		get_processed_link().click();
		Thread.sleep(2000);
		if (orderTypes != "") {
			selectOrderTypesInBasicSearch(orderTypes);
		}
		Thread.sleep(1000);
		get_ord_search().click();
		Thread.sleep(2000);
	}

	public void basicSearchPOWithPeriod(String periodName) throws Exception {

		Thread.sleep(2000);
		get_processed_link().click();
		Thread.sleep(2000);
		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);
		get_ord_search().click();
		Thread.sleep(2000);
	}

	public void basicSearchPOWithIncentiveDate(String fromDate, String toDate ) throws Exception {

		WebDriver driver = SetWebDrivers.getDriver();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Thread.sleep(2000);
		get_processed_link().click();
		Thread.sleep(2000);
		js.executeScript("document.getElementById('fromDate').removeAttribute('disabled')");
		Thread.sleep(1000);
		get_fromDate().sendKeys(fromDate);
		Thread.sleep(2000);
		js.executeScript("document.getElementById('toDate').removeAttribute('disabled')");
		Thread.sleep(1000);
		get_toDate().sendKeys(toDate);
		Thread.sleep(1000);
		get_ord_search().click();
		Thread.sleep(2000);
	}

	public void basicSearchPOWithAssignment(String person) throws Exception {

		Thread.sleep(2000);
		get_processed_link().click();		
		Thread.sleep(2000);
		get_addPerson().click();
		Thread.sleep(2000);
		get_findPerson().sendKeys(person);
		Thread.sleep(1000);
		get_searchButton().click();
		Thread.sleep(2000);
		get_personCheckbox().click();
		Thread.sleep(1000);
		get_selectPerson().click();
		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(2000);
	}

	// POOC

	public void advSearchPOWithOrderCodeItemCode(String periodName, String orderCode, String itemCode) throws Exception {

		Thread.sleep(2000);
		get_processed_link().click();
		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(3000);
		click_adv_search().click();
		Thread.sleep(2000);		
		get_msorders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);
		get_ocode_name().sendKeys(orderCode);
		Thread.sleep(1000);
		get_icode_name().sendKeys(itemCode);
		Thread.sleep(1000);
		do_adv_search().click();
		Thread.sleep(2000);
	}

	public void advSearchPOWithIncentiveDate(String periodName, String fromIncentiveDate, String toIncentiveDate) throws Exception {

		WebDriver driver = SetWebDrivers.getDriver();
		JavascriptExecutor js = (JavascriptExecutor) driver;

		Thread.sleep(2000);
		get_processed_link().click();
		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(3000);
		click_adv_search().click();
		Thread.sleep(2000);		
		get_msorders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);
		js.executeScript("document.getElementById('fromIncentiveDate').removeAttribute('disabled')");
		Thread.sleep(1000);
		get_fromIncentiveDate().sendKeys(fromIncentiveDate);
		Thread.sleep(1000);
		js.executeScript("document.getElementById('toIncentiveDate').removeAttribute('disabled')");
		Thread.sleep(1000);
		get_toIncentiveDate().sendKeys(toIncentiveDate);
		Thread.sleep(1000);
		do_adv_search().click();
		Thread.sleep(2000);
	}

	public void advSearchPOWithOrderDate(String periodName, String fromOrderDate, String toOrderDate) throws Exception {

		WebDriver driver = SetWebDrivers.getDriver();
		JavascriptExecutor js = (JavascriptExecutor) driver;

		Thread.sleep(2000);
		get_processed_link().click();
		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(3000);
		click_adv_search().click();
		Thread.sleep(2000);		
		get_msorders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);
		js.executeScript("document.getElementById('fromOrderDate').removeAttribute('disabled')");
		Thread.sleep(1000);
		get_fromOrderDate().sendKeys(fromOrderDate);
		Thread.sleep(1000);
		js.executeScript("document.getElementById('toOrderDate').removeAttribute('disabled')");
		Thread.sleep(1000);
		get_toOrderDate().sendKeys(toOrderDate);
		Thread.sleep(1000);
		do_adv_search().click();
		Thread.sleep(2000);
	}

	public void advSearchPOByBatchName(String periodName, String batchName) throws Exception {

		Thread.sleep(2000);
		get_processed_link().click();
		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(3000);
		click_adv_search().click();
		Thread.sleep(2000);		
		get_msorders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);
		get_selectBatchName().click();
		Thread.sleep(2000);
		get_findBatch().sendKeys(batchName);
		Thread.sleep(1000);
		get_searchBatchButton().click();
		Thread.sleep(2000);
		get_BatchCheckbox().click();
		Thread.sleep(1000);
		get_selectBatch().click();
		Thread.sleep(2000);
		do_adv_search().click();
		Thread.sleep(2000);
	}	


	public void advSearchPOWithAmount(String periodName, String amount) throws Exception {

		Thread.sleep(2000);		
		get_processed_link().click();
		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(3000);
		click_adv_search().click();
		Thread.sleep(2000);		
		get_msorders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);
		get_ord_Amount().sendKeys(amount);
		Thread.sleep(1000);
		do_adv_search().click();
		Thread.sleep(2000);
	}

	public void advSearchPOWithAssignment(String periodName, String assignment) throws Exception {

		Thread.sleep(2000);
		get_processed_link().click();
		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(3000);
		click_adv_search().click();
		Thread.sleep(2000);		
		get_msorders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);
		get_addPerson().click();
		Thread.sleep(2000);
		get_findPerson().sendKeys(assignment);
		Thread.sleep(1000);
		get_searchButton().click();
		Thread.sleep(2000);
		get_personCheckbox().click();
		Thread.sleep(1000);
		get_selectPerson().click();
		Thread.sleep(2000);
		do_adv_search().click();
		Thread.sleep(2000);
	}


	public void leftClmnFilterSearchOSWithOrderCode(String periodName, String ocode) throws Exception {

		Thread.sleep(2000);		
		get_ord_search().click();
		Thread.sleep(2000);
		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);
		get_ocode_name().sendKeys(ocode);
		Thread.sleep(1000);
		do_leftFilter_search().click();
		Thread.sleep(2000);
	}


	public void leftClmnFilterSearchPOWithOrderCode(String periodName, String ocode) throws Exception {

		Thread.sleep(2000);
		get_processed_link().click();
		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(2000);		
		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);
		get_ocode_name().sendKeys(ocode);
		Thread.sleep(1000);
		do_leftFilter_search().click();
		Thread.sleep(2000);
	}

	public void leftClmnFilterSearchOSWithItemCode(String periodName, String icode)	throws Exception {

		Thread.sleep(2000);		
		get_ord_search().click();
		Thread.sleep(2000);
		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(2000);
		get_icode_name().sendKeys(icode);
		Thread.sleep(1000);
		do_leftFilter_search().click();
		Thread.sleep(2000);
	}

	public void leftClmnFilterSearchPOWithItemCode(String periodName, String icode) throws Exception {

		Thread.sleep(2000);
		get_processed_link().click();
		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(2000);
		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);
		get_icode_name().sendKeys(icode);
		Thread.sleep(1000);
		do_leftFilter_search().click();
		Thread.sleep(2000);	}

	public void leftClmnFilterSearchPOWithOrderCodeAndItemCode(String periodName, String ocode, String icode) throws Exception {

		Thread.sleep(2000);
		get_processed_link().click();
		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(2000);
		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);
		get_ocode_name().sendKeys(ocode);
		Thread.sleep(1000);
		get_icode_name().sendKeys(icode);
		Thread.sleep(1000);
		do_leftFilter_search().click();
		Thread.sleep(2000);
	}

	public void leftClmnFilterSearchOSwithIncentiveDate(String periodName, String fromIncentiveDate, String toIncentiveDate) throws Exception {

		WebDriver driver = SetWebDrivers.getDriver();
		JavascriptExecutor js = (JavascriptExecutor) driver;

		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(2000);		
		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(2000);
		js.executeScript("document.getElementById('fromIncentiveDate').removeAttribute('disabled')");
		get_fromIncentiveDate().sendKeys(fromIncentiveDate);
		Thread.sleep(1000);
		js.executeScript("document.getElementById('toIncentiveDate').removeAttribute('disabled')");
		get_toIncentiveDate().sendKeys(toIncentiveDate);
		Thread.sleep(1000);
		do_leftFilter_search().click();
		Thread.sleep(1000);
	}

	public void leftClmnFilterSearchPOWithIncentiveDate(String periodName, String fromIncentiveDate, String toIncentiveDate) throws Exception {

		WebDriver driver = SetWebDrivers.getDriver();
		JavascriptExecutor js = (JavascriptExecutor) driver;

		Thread.sleep(2000);
		get_processed_link().click();
		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(2000);
		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);
		js.executeScript("document.getElementById('fromIncentiveDate').removeAttribute('disabled')");
		Thread.sleep(1000);
		get_fromIncentiveDate().sendKeys(fromIncentiveDate);
		Thread.sleep(1000);
		js.executeScript("document.getElementById('toIncentiveDate').removeAttribute('disabled')");
		Thread.sleep(1000);
		get_toIncentiveDate().sendKeys(toIncentiveDate);
		Thread.sleep(1000);
		do_leftFilter_search().click();
		Thread.sleep(2000);
	}

	public void leftClmnFilterSearchOSWithOrderType(String periodName,String orderTypes) throws Exception {

		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(2000);		
		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);

		if (orderTypes != "") {
			selectOrderTypesInBasicSearch(orderTypes);			
		}
		do_leftFilter_search().click();
		Thread.sleep(1000);
	}


	public void leftClmnFilterSearchPOWithOrderType(String periodName,String orderTypes) throws Exception {

		Thread.sleep(2000);
		get_processed_link().click();
		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(2000);
		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);

		//selectOrderTypes(orderTypes);		 
		if (orderTypes != "") {
			selectOrderTypesInBasicSearch(orderTypes);			
		}
		Thread.sleep(1000);
		do_leftFilter_search().click();
		Thread.sleep(2000);
	}

	public void leftClmnFilterSearchOSWithAssignment(String periodName,String Assignment) throws Exception {

		Thread.sleep(2000);
		get_ord_search().click();
		Thread.sleep(2000);
		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);		
		get_addPerson().click();
		Thread.sleep(2000);
		get_findPerson().sendKeys(Assignment);
		Thread.sleep(1000);
		get_searchButton().click();
		Thread.sleep(1000);
		get_personCheckbox().click();
		Thread.sleep(1000);
		get_selectPerson().click();
		Thread.sleep(2000);
		do_leftFilter_search().click();
		Thread.sleep(1000);
	}

	public WebElement getOrdersStagingTable(String headerName, int rowNum, String frameName) throws Exception
	{	
		Thread.sleep(5000);		
		WebElement obj = SeleniumHelperClass.getTableCell_NewUI(headerName, rowNum,"list", frameName);
		Thread.sleep(5000);

		return obj;
	}


	public int totalNoOfOredrResultShown() throws Exception{
		Thread.sleep(5000);
		return SeleniumHelperClass.findWebElements(".//ul[@id='orders-list']/li","mainFrame").size();
	}

	  public WebElement getFromDate() throws Exception{
	    	return SeleniumHelperClass.findWebElementbyXpath("//input[@id='fromDate']//..//i[@class='fa fa-calendar filter-calender add-on']", "mainFrame");
	    }

	public String getFromDateOrders() throws Exception{
		String script = "return document.getElementById('fromDate').value";
		getFromDate().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		SeleniumHelperClass.selectDate("8");
		String date = SeleniumHelperClass.ExecuteJavaScript(script);
		return date;
		
	}
	
	public WebElement getStatusDate() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath("//span[@class='col status-date-col']", "mainFrame");
	}
	
	public String getStatusDateOrders() throws Exception{
		String date = getStatusDate().getText();
		date = date.substring(0, 10);
        return date;
	}



	public void verifyOrderCountWithPageNation(String expected) throws Exception {
		SoftAssert Assert = new SoftAssert();
		Thread.sleep(2000);
		List<WebElement> pageNationlinks= get_pageNation_links();
		for(int i=1;i<pageNationlinks.size();i++){
			List<WebElement> pageNationlinks1= get_pageNation_links();
			pageNationlinks1.get(i).click();
			String orderText = get_ord_text().getText();
			Assert.assertEquals(orderText, "Orders", "orders text is not matched");
			String ordercount = get_ord_count().getText();
			boolean isexist= ordercount.contains(expected);
			Assert.assertEquals(isexist,true,"orders count is not matched");
		}
		Assert.assertAll();

	}

	public void verifyOrderCount(String expected) throws Exception {
		SoftAssert Assert = new SoftAssert();
		Thread.sleep(2000);
		String orderText= get_ord_text().getText();
		Assert.assertEquals(orderText,"Orders","orders text is not matched");
		Thread.sleep(1000);
		String ordercount = get_ord_count().getText();
		boolean isexist= ordercount.contains(expected);
		Assert.assertEquals(isexist,true,"orders count is not matched");
		Assert.assertAll();

	}
	public void basicSearchOSWithPeriodName(String periodName) throws Exception {

		Thread.sleep(2000);
		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(periodName);
		Thread.sleep(1000);
		get_ord_search_link().click();
		Thread.sleep(2000);
	}


}