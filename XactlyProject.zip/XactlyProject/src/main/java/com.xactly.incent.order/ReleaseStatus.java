package com.xactly.incent.orders;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.xactly.xcommons.selenium.SeleniumHelperClass;

public class ReleaseStatus {

	public ReleaseStatus() throws Exception{
		SeleniumHelperClass.findWebElementbyid("TAB_MIDDLE_ORDERS_TAB", "topFrame").click();
		SeleniumHelperClass.findWebElementbyid("A_Release", "topFrame").click();
	}

	public ReleaseStatus(String testtype) throws Exception {
		if (testtype.equalsIgnoreCase("gui")) {
			new Orders("gui");
			SeleniumHelperClass.findWebElementbyid("A_Release", "topFrame").click();
		} else if (testtype.equalsIgnoreCase("gui-new")) {
			new Orders("gui-new");
			WebElement tab_setup = SeleniumHelperClass.findWebElementbyid("ORDERS_NAV-Release", "topFrame");
			tab_setup.click();
		}
	}

	public Select getType() throws Exception{
		return SeleniumHelperClass.selectFromDropdown("releasedItemType_releaseStatus_edit", "editFrame");
	}
	
	public Select getCurrentState() throws Exception{
		return SeleniumHelperClass.selectFromDropdown("currentState_releaseStatus_edit", "editFrame");
	}
	
	public WebElement getSearchBtn() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("searchButton", "editFrame");
	}
	
	public WebElement getClearBtn() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("clearButton", "editFrame");
	}
	
	public void checkStatus(String type) throws Exception {
		while (true){
		getClearBtn().click();
		getType().selectByVisibleText(type);
		getCurrentState().selectByVisibleText("In Progress");
		getSearchBtn().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		if (SeleniumHelperClass.getNumberOfResultsFromUI("listFrame") == 0)
			break;
		}
		
	}
}
