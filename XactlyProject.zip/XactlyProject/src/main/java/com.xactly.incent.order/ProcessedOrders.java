package com.xactly.incent.orders;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.xactly.incent.navigation.LeftNavigationUtil;
import com.xactly.incent.results.PPA_Results;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

public class ProcessedOrders {
	public static Logger logger = Logger.getLogger(ProcessedOrders.class.getName());
	public ProcessedOrders(String testtype) throws Exception
	{
		if(testtype.equalsIgnoreCase("gui"))
		{	new Orders("gui");
			WebElement tab_setup = SeleniumHelperClass.findWebElementbyid("ORDERS_TAB_ORDERS_READ_WRITE","topFrame");
			tab_setup.click();
		}
		else if (testtype.equalsIgnoreCase("gui-new")) {
			new Orders("gui-new");
			LeftNavigationUtil.clickOnOrders_OrdersTab();
		}
	}
	
	PPA_Results res = new PPA_Results("");
	
	public WebElement getStagingLink() throws Exception{
		return SeleniumHelperClass.findWebElementbyLink("Staging", "mainFrame");
	}
	
	public WebElement getProcessedLink() throws Exception{
		return SeleniumHelperClass.findWebElementbyLink("Processed", "mainFrame");
	}
	
	// * For Period Filter *//

	// * For Period Drop Down *//
	public WebElement get_period_dropdown() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("s2id_periods", "mainFrame")); }
	
	// * For As Of Period Drop Down *//
	public WebElement get_as_of_period_dropdown() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("s2id_as-of-period", "mainFrame")); }

	// * For Period Search in Drop Down *//
	public WebElement searchIn_period_dropdown() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='select2-drop']/div/input", "mainFrame")); }

	// * For Period Select in Drop Down *//
	public WebElement select_period() throws Exception {
		return (SeleniumHelperClass.findWebElementbyclass("select2-result-label")); }
	
	// * For Search Button *//
	public WebElement get_search_button() throws Exception {
	return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='searchBtn']", "mainFrame")); }
	
	// * For Search Count *//
	public WebElement getcount() throws Exception{
		Thread.sleep(5000);
	    return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='results-total']","mainFrame"));}
	
	// * For Download Link *//
	public WebElement get_download_link() throws Exception{
		Thread.sleep(5000);
	    return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='downloadOrders']/span","mainFrame"));}
	
	// * For Download Name *//
	public WebElement get_download_name_inputbox() throws Exception{
		Thread.sleep(5000);
	    return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='downloadFilename']","mainFrame"));}
	
	// * For OK Button in Download overlay *//
	public WebElement get_ok_button() throws Exception{
		Thread.sleep(5000);
	    return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='downloadDone']/div","mainFrame"));}
	
	// * For OK Button in Download Confirmation *//
	public WebElement get_ok_button_confirmation() throws Exception{
		Thread.sleep(5000);
	    return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='confirm-button']","mainFrame"));}
	
	public WebElement getOrdersSubLink(String subLink) throws Exception{
		return SeleniumHelperClass.findWebElementbyLink(""+subLink+"", "mainFrame");
	}
	
	public WebElement get_item_code() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("itemCode","mainFrame"));
		}
	
	public WebElement get_orderdetails_Overlay() throws Exception{
		return (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']//li/div[contains(@class,'orders-row')]","mainFrame"));}

	public WebElement get_explandCreditsSection() throws Exception{
		return SeleniumHelperClass.findWebElementbyXpath(".//ul[@id='orders-list']//li[1]//div[@data-i18n='credits']", "mainFrame");
	}

	public WebElement get_creditAmount() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//table[@class='assignemnts-table']//th[@data-i18n='amount']/../../following-sibling::tbody//td[@class='numeric-fields']","mainFrame"));
	}
	
	// * Processed Orders PPA Download 

	public void processedOrdersPPADownload(String periodName,String asOfPeriodName,String expectedCount,String downloadFileName) throws Exception {
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*3);
		getProcessedLink().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*3);
		get_period_dropdown().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		searchIn_period_dropdown().sendKeys(periodName);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		select_period().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_as_of_period_dropdown().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		searchIn_period_dropdown().sendKeys(asOfPeriodName);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		select_period().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_search_button().click();	
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_download_link().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_download_name_inputbox().sendKeys(downloadFileName);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_ok_button().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*3);
		get_ok_button_confirmation().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		
		}
		
	// * Download file from myDownloads folder
	
	public void mydownloads(String downloadFileName) throws Exception {
		logger.info("Downloading file from myDownloads folder");
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		res.getDownloadLinkonHeaderFrame(SetWebDrivers.getNavigationType());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		WebDriver w = SetWebDrivers.getDriver();
		w.switchTo().defaultContent();
		res.get_mydownload_serachbox().sendKeys(downloadFileName);
		res.get_mydownload_serachicon().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		res.get_mydownload_download().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		res.get_mydownload_serachbox().clear();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		res.get_mydownload_serachicon().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		res.get_myDownload_close().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		}
	
	//Search by ItemCode in Staging and Processed Orders
	public void searchOrdersbyItemCode(String subLink,String periodName,String asOfPeriodName,String itemCode) throws Exception {
		if (subLink == "Processed")
		{
			getOrdersSubLink(subLink).click();
			SeleniumHelperClass.isVisible(get_period_dropdown(),60);
			get_period_dropdown().click();
			searchIn_period_dropdown().sendKeys(periodName);
			select_period().click();
			SeleniumHelperClass.isVisible(get_search_button(),60);
			get_as_of_period_dropdown().click();
			searchIn_period_dropdown().sendKeys(asOfPeriodName);
			select_period().click();
		}
		else 
		{
			get_period_dropdown().click();
			searchIn_period_dropdown().sendKeys(periodName);
			select_period().click();	
		}
		SeleniumHelperClass.isVisible(get_search_button(),60);
		get_item_code().click();
		get_item_code().clear();
		get_item_code().sendKeys(itemCode);
		get_search_button().click();			
		}
	
	public void searchOrdersbyItemCodeNonPPP(String subLink,String periodName,String itemCode) throws Exception {
		if (subLink == "Processed")
		{
			SeleniumHelperClass.clickElementUsingJavascriptExecutor(getOrdersSubLink(subLink));
			SeleniumHelperClass.isVisible(get_period_dropdown(),60);
			get_period_dropdown().click();
			searchIn_period_dropdown().sendKeys(periodName);
			select_period().click();
			SeleniumHelperClass.isVisible(get_search_button(),60);
		}
		else
		{
			get_period_dropdown().click();
			searchIn_period_dropdown().sendKeys(periodName);
			select_period().click();
		}
		SeleniumHelperClass.isVisible(get_search_button(),60);
		get_item_code().click();
		get_item_code().clear();
		get_item_code().sendKeys(itemCode);
		get_search_button().click();
	}

	public String getCreditAmountforOrder() throws Exception {
		SeleniumHelperClass.clickElementUsingJavascriptExecutor(get_orderdetails_Overlay());
		SeleniumHelperClass.click(get_explandCreditsSection());
		String creditAmount=get_creditAmount().getText().trim();
		return creditAmount;
	}
	
}
		
