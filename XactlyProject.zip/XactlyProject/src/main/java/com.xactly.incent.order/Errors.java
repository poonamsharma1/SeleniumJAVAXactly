package com.xactly.incent.orders;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.xactly.xcommons.selenium.SeleniumHelperClass;

public class Errors {
	public static Logger logger = Logger.getLogger(Errors.class.getName());
public Errors(String testtype) throws Exception
	
	{
		if(testtype.equalsIgnoreCase("gui"))
		{
			new Orders("gui");
			SeleniumHelperClass.findWebElementbyid("A_Process Status", "topFrame").click();
			get_errors_link().click();
			Thread.sleep(1000);
		
		}
	}

public WebElement get_queue_link() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("queueLink","mainFrame"));
}

public WebElement get_errors_link() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("errorsLink","mainFrame"));
}

public WebElement get_batches_link() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("batchesLink","mainFrame"));
}

public WebElement get_batches_from_period_dropdown() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='s2id_periods-selectFrom']/a/span[2]/b","mainFrame"));
}

public WebElement get_batches_to_period_dropdown() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='s2id_periods-selectTo']/a/span[2]/b","mainFrame"));
}

public List<WebElement> get_batches_allperiods() throws Exception {
return (SeleniumHelperClass.findWebElements("//div[@id='select2-drop']/ul/li/div","mainFrame"));
}

public WebElement select_batches_period(int item) throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='select2-drop']/ul/li["+item+"]/div", "mainframe"));
}

public void selectbatchesperiod(String periodName) throws Exception {
	int periodsLength = get_batches_allperiods().size();
	for (int i=1; i<=periodsLength; i++){
		System.out.printf("Period Name: ",select_batches_period(i).getText());
		if (select_batches_period(i).getText().equalsIgnoreCase(periodName)){
			select_batches_period(i).click();
			System.out.printf("CLICKED.. ");
			break;
		}
	}
}


public WebElement get_batches_search_textbox() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("batches-search-text","mainFrame"));
}

public WebElement get_batches_search_icon() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("batches-search-button","mainFrame"));
}

public WebElement get_batches_search_clear_icon() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("batches-clear-search","mainFrame"));
}

public WebElement select_batch_checkbox() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='batch-list']/li/div/div/span/input","mainFrame"));
}

public WebElement get_calculate_through_incentives_link() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='batchLinkCalIncentives']/span","mainFrame"));
}

public WebElement get_download_button() throws Exception {
return (SeleniumHelperClass.findWebElementbyLink("Download Error Log", "mainFrame"));
}

public WebElement get_search_box() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("errors-search-text","mainFrame"));
}

public WebElement get_search_button() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("errors-search-button","mainFrame"));
}

public WebElement select_startprocessing_button() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='queueStartOrPause']/span/span[2]", "mainFrame"));
}

public WebElement select_pauseprocessing_button() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='queueStartOrPause']/span[2]/span[2]", "mainFrame"));
}

public List<WebElement> Queue_row() throws Exception {
return (SeleniumHelperClass.findWebElements("//ul[@id='queue-list']/li/div", "mainframe"));
}

public WebElement get_otg_rowselect() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='error-list']/li[1]/div","mainFrame"));
}

public WebElement get_error_message() throws Exception {
	return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='error-list']/li/div/div[2]/fieldset/div[2]/div/div[1]/div[1]/span[2]","mainFrame"));
}

public WebElement get_error_search_clear() throws Exception {
	return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='errors-clear-search']","mainFrame"));
}

public Select get_history_fromperiod() throws Exception {
	return (SeleniumHelperClass.selectFromDropdownwithelements("id","periods-selectFrom","mainFrame"));
}

public Select get_history_toperiod() throws Exception {
	return (SeleniumHelperClass.selectFromDropdownwithelements("id","periods-selectTo","mainFrame"));
}

public WebElement get_finalize_error_msg() throws Exception {
	return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='error-list']/li[1]/div/div[2]/fieldset/div[2]/div/div/div/span[2]","mainFrame"));
}

public WebElement get_finalize_search_row() throws Exception {
	return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='error-list']/li[1]/div","mainFrame"));
}


/* to download error from failed calculation or validation */
public void downloaderror(String name) throws Exception
{
	get_errors_link().click();
	get_search_box().sendKeys(name);
	get_search_button().click();
	get_otg_rowselect().click();
	get_download_button().click();
}

/* to download error from failed commission release*/
public void downloadReleaseError(String name) throws Exception
{
	get_errors_link().click();
	Thread.sleep(1000);
	get_error_search_clear().click();
	Thread.sleep(1000);
	get_search_box().sendKeys(name);
	Thread.sleep(3000);
	get_search_button().click();
	Thread.sleep(3000);
	get_otg_rowselect().click();
	logger.info("Error type:" +get_error_message().getText());
	get_download_button().click();
	
}
String errMsg;
public void getfinalizeError(String fPeriod,String tPeriod) throws Exception
{
	Thread.sleep(500);
	get_history_fromperiod().selectByVisibleText(fPeriod);
	get_history_toperiod().selectByVisibleText(tPeriod);
	get_finalize_search_row().click();
	errMsg = get_finalize_error_msg().getText();
}
}


