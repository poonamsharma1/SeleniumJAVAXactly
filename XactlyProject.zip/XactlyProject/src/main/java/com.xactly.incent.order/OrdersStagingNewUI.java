package com.xactly.incent.orders;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
//import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.xactly.incent.navigation.LeftNavigationUtil;
import com.xactly.xcommons.selenium.DBConnections;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

public class OrdersStagingNewUI {
	
	public static Logger logger = Logger.getLogger(OrdersStagingNewUI.class.getName());
	private int count;
	public OrdersStagingNewUI()
	{
		
	}
public OrdersStagingNewUI(String testtype) throws Exception
	
	{
		if(testtype.equalsIgnoreCase("gui"))
		{
			try {
				new Orders("gui");
			
			WebElement orderTab = SeleniumHelperClass.findWebElementbyid("A_Orders", "topFrame");
			SeleniumHelperClass.isVisible(orderTab, 10);
			orderTab.click();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else if(testtype.equalsIgnoreCase("gui-new"))
		{
			new Orders("gui-new");
			LeftNavigationUtil.clickOnOrders_OrdersTab();
		} 

	}		
public static String get_createOrderPeriod() {
	return (".//*[@id='s2id_periods']/a/span[1]");
}


public static String get_CustomUnitType() {
	return (".//*[@id='s2id_number1UnitTypeId']/a/span[1]");
}

public WebElement get_orders_period_dropdown() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='s2id_periods']/a","mainFrame"));
}

public List<WebElement> get_orders_allPeriods() throws Exception {
return (SeleniumHelperClass.findWebElements("//div[@id='select2-drop']/ul/li/div","mainFrame"));
}

public WebElement select_Order_Period(int item) throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='select2-drop']/ul/li["+item+"]/div", "mainframe"));
}

public void selectOrderPeriod(String periodName) throws Exception {
	int periodsLength = get_orders_allPeriods().size();
	for (int i=1; i<=periodsLength; i++){
		System.out.printf("Period Name: ",select_Order_Period(i).getText());
		if (select_Order_Period(i).getText().equalsIgnoreCase(periodName)){
			select_Order_Period(i).click();
			System.out.printf("CLICKED.. ");
			break;
		}
	}
}

	public WebElement getBatchAlreadtExists() throws Exception{
		return (SeleniumHelperClass.findWebElementbyid("errorGutter","mainFrame"));
	}
	public WebElement getBatchpopupClose() throws Exception{
		return (SeleniumHelperClass.findWebElementbyXpath("//h3[@id='batch-create-header']//parent::div//button[@data-dismiss='modal']","mainFrame"));
	}

public WebElement get_order_code() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("orderCode","mainFrame"));
}

public WebElement get_item_code() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("itemCode","mainFrame"));
}

public WebElement get_search_button() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("searchBtn","mainFrame"));
}

public WebElement get_assignment_button() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("assignmentBtn","mainFrame"));
}

public WebElement select_search_icon() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("search-button","mainFrame"));
}

public WebElement get_change_Order_assignment_button() throws Exception {
return (SeleniumHelperClass.findWebElementbyCssSelector("#changeOrderAssignment > span","mainFrame"));
}

public WebElement get_search_text() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("search-text","mainFrame"));
}

public WebElement get_add_person() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='personView']/div/div/span[2]","mainFrame"));
}

public WebElement get_split_amount() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='assingmentTable']/li/div[2]/input","mainFrame"));
}

public WebElement select_save() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("create","mainFrame"));
}

public WebElement select_person_checkbox() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//div[2]/div[2]/div/div[2]/div[2]/div[2]/div[2]/div[2]/ul/li/div/span[1]/input","mainFrame"));
}

public WebElement select_person() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='personView']/div/div/span[2]","mainFrame"));
}

public WebElement get_result_count() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("results-total", "mainFrame"));
}

public WebElement select_result() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='orders-list']/li/div/span/input", "mainFrame"));
}

public WebElement get_assigntobatch() throws Exception {
return (SeleniumHelperClass.findWebElementbyCssSelector("#assignToBatch > span.ordersActionLink", "mainFrame"));
}

public WebElement select_assigntobatchSave() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'Save')]", "mainFrame"));
}

/*public WebElement select_assigntobatchSave() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='batchView']/div/div/span[2]", "mainFrame"));
}*/

public WebElement select_result_row() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='orders-list']/li[1]/div", "mainFrame"));
}

public WebElement get_errorlog() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='orders-list']/li/div/div[3]/fieldset/div[3]/div[1]/div[1]/a", "mainFrame"));
}

/* Columns in ErrorLog PopUp */
public WebElement get_errorlog_fieldname(int i) throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='errorLogTable']/tbody/tr["+i+"]/td[1]", "mainFrame"));
}

public WebElement get_errorlog_fieldvalue(int i) throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='errorLogTable']/tbody/tr["+i+"]/td[2]", "mainFrame"));
}

public WebElement get_errorlog_fielderrormessage(int i) throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='errorLogTable']/tbody/tr["+i+"]/td[3]", "mainFrame"));
}

/* Clicking the Advanced Search Link */
public WebElement click_adv_search() throws Exception {
	return (SeleniumHelperClass.findWebElementbyid("adv-search-top",
			"mainframe"));
}

/* For Order Code */
public WebElement get_ocode_name() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("orderCode", "mainframe"));
}

/* For Item Code */
public WebElement get_icode_name() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("itemCode", "mainframe"));
}

/* To select Checkbox */
public WebElement select_checkbox() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//input[@name='selectedElement']", "mainFrame"));
}

//Click on Select Batch Name link
public WebElement get_selectBatchName() throws Exception {
	return (SeleniumHelperClass.findWebElementbyid("selectBatchName",
			"mainframe"));
}

// For Find BATCH in pop up
public WebElement get_findBatch() throws Exception {
	return (SeleniumHelperClass.findWebElementbyid("search-text",
			"mainframe"));
}

// For Search person
public WebElement get_searchBatchButton() throws Exception {
	return (SeleniumHelperClass.findWebElementbyid("search-button",
			"mainframe"));
}

// For Batch Check box
public WebElement get_BatchCheckbox() throws Exception {
//	return (SeleniumHelperClass.findWebElementbyXpath("//input[@name='selectedElement']", "mainframe"));
	return (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='element-list']/li/div/span/input", "mainframe"));
}

// For Select batch button
public WebElement get_selectBatch() throws Exception {
	return (SeleniumHelperClass.findWebElementbyXpath(
			"//div[@id='batchView']/div/div/span[2]", "mainframe"));
}


public int get_result_count_int() throws Exception{
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
    String result = get_result_count().getText();
    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
    int result_int = result.length();
    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
    result = result.substring(result.indexOf('(')+1, result.indexOf(')')).trim();
    return Integer.parseInt(result);
}

/* Delete Orders */

/* For selecting Delete Orders Options link */
public WebElement get_delete_options() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("deleteOrders", "mainFrame"));
}

/* For selecting Delete Selected Orders link */
public WebElement get_delete_selected_orders() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("deleteByOrders", "mainFrame"));
}

/* For selecting Delete All Orders in Period */
public WebElement get_delete_all_orders_in_period() throws Exception {
return (SeleniumHelperClass.findWebElementbyCssSelector("#DeleteByPeriod > span","mainFrame"));
}

/* For selecting Delete All Orders in Batch link */
public WebElement get_delete_all_orders_in_batch() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("DeleteByBatch", "mainFrame"));
}

public WebElement get_confirm_delete_button() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("confirm-button","mainframe"));
}

public WebElement get_confirm_delete_from_staging_checkbox() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("deleteFromStaging","mainframe"));
}

/* For Validation Message */
public WebElement get_validation_message() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("uiActionMsgContent", "mainFrame"));
}

/* To Select Delete button in Delete Orders by Period PopUp */
public WebElement select_delete_button() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='periodView']/div/div/span[2]", "mainframe"));
}

public List<WebElement> delete_Queue_row() throws Exception {
return (SeleniumHelperClass.findWebElements("//ul[@id='queue-list']/li/div", "mainframe"));
}

/* For clicking on Processed link */
public WebElement get_processed_link() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//li[@id='processedLink']/a", "mainFrame"));
}

public WebElement get_createOrderItem() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//span[@id='createNewOrder']/span", "mainFrame"));
}

public WebElement get_addBatch() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='createButton']/span","mainFrame"));
}

public WebElement get_selectPeriodDropDown(String periodid) throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='select2-drop']/ul//li/div[text()='"+periodid+"']","mainFrame"));
}

public WebElement get_searchBatch() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//input[@id='search-text']","mainFrame"));
}

public WebElement get_searchButton() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//a[@id='search-button']","mainFrame"));
}

public WebElement get_filtersSearchButton() throws Exception {
return (SeleniumHelperClass.findWebElementbyid("searchBtnTop","mainFrame"));
}
public WebElement get_tickSearchBatch() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='element-list']/li/div/span","mainFrame"));
}	

public WebElement get_selectSearchBatch() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='batchTypeView']/div/div/span[2]","mainFrame"));
}

public WebElement get_OI_Boolean_Req_CF_DD() throws Exception {
	return (SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'OI_Boolean_Req')]//..//..//span[@class='select2-arrow']","mainFrame"));		
	}

public WebElement select_CustomField_Value(String value) throws Exception {
	return (SeleniumHelperClass.findWebElementbyXpath("//div[contains(text(),'"+value+"')]","mainFrame"));		
	}

public WebElement get_OI_DDList_Req_CF_DD() throws Exception {
	return (SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'OI_DDList_Req')]//..//..//span[@class='select2-arrow']","mainFrame"));		
	}

public WebElement get_OI_String_Opt_CF() throws Exception {
	return (SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'OI_String_Opt')]//..//input[@class='searchInputTextBox']","mainFrame"));		
	}

public WebElement get_OI_Number_Req_CF() throws Exception {
	return (SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'OI_Number_Req')]//..//input[@class='searchInputTextBox']","mainFrame"));		
	}

public WebElement get_OI_Number_Req_UnitType_CF_DD() throws Exception {
	return (SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'OI_Number_Req UnitType')]//..//..//span[@class='select2-arrow']","mainFrame"));			
	}

public WebElement get_Required_CF_Valiadtion_Message(String Value) throws Exception {
	return (SeleniumHelperClass.findWebElementbyXpath("//span[@data-validation-msg='"+Value+"']","mainFrame"));			
	}
//***************************************************************************************************************************************************************//

/* Assign to Batch */

	public void assigntobatch(String OrderPeriod, String OrderCode, String ItemCode, String BatchName1, String BatchName2)
	throws Exception {		
		OrdersStagingBeta orderBeta = new OrdersStagingBeta(SetWebDrivers.getNavigationType());
		get_orders_period_dropdown().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		//logger.info("Size"+ ord.get_orders_allperiods().size());
		selectOrderPeriod(OrderPeriod);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_search_button().click();
		click_adv_search().click();
		Thread.sleep(1000);		
		get_icode_name().sendKeys(ItemCode);
		Thread.sleep(1000);	
		get_ocode_name().sendKeys(OrderCode);
		Thread.sleep(1000);	
		orderBeta.get_selectBatchName().click();
		Thread.sleep(1000);	
		orderBeta.get_findBatch().sendKeys(BatchName1);
		Thread.sleep(1000);
		Thread.sleep(1000);
		orderBeta.get_searchBatchButton().click();
		Thread.sleep(1000);
		orderBeta.get_BatchCheckbox().click();
		Thread.sleep(1000);	
		Thread.sleep(1000);	
		orderBeta.get_selectBatch().click();
		Thread.sleep(1000);
		Thread.sleep(1000);	
		orderBeta.do_adv_search().click();
		//orderBeta.do_leftFilter_search().click();
		select_result().click();
		get_assigntobatch().click();
		get_search_text().sendKeys(BatchName2);
		select_search_icon().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		orderBeta.get_BatchCheckbox().click();
		Thread.sleep(1000);
		select_assigntobatchSave().click();
		Thread.sleep(1000);
		String Validation = get_validation_message().getText();
		
		logger.info(Validation);
		Thread.sleep(1000);
		Thread.sleep(1000);
		Assert.assertEquals(Validation, "Added to batch","Assertion Failed");
		Thread.sleep(1000);		
	}	

//***************************************************************************************************************************************************************// 
	
/* Change Order Assignment */
	
	 public void changeorderassignment(String OrderPeriod, String OrderCode, String Person1, String Person2, String SplitAmount) 
	 throws Exception {
		OrdersStagingNewUI ord = new OrdersStagingNewUI(SetWebDrivers.getNavigationType());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_orders_period_dropdown().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		selectOrderPeriod(OrderPeriod);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);			
		get_order_code().click();
		get_order_code().clear();
		ord.get_order_code().sendKeys(OrderCode);
		ord.get_assignment_button().click();
		ord.get_search_text().sendKeys(Person2);
		ord.select_search_icon().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		ord.select_person_checkbox().click();
		ord.select_person().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		ord.get_search_button().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		int count = ord.get_result_count_int();
		logger.info("count: "+count);
		Assert.assertTrue((count==0),"Count not equal to Zero");
		new OrdersStagingNewUI(SetWebDrivers.getNavigationType());
		ord.get_orders_period_dropdown().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		ord.selectOrderPeriod(OrderPeriod);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);			
		ord.get_order_code().clear();
		ord.get_order_code().sendKeys(OrderCode);
		ord.get_assignment_button().click();
		ord.get_search_text().clear();
		ord.get_search_text().sendKeys(Person1);
		ord.select_search_icon().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		ord.select_person_checkbox().click();
		ord.select_person().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		ord.get_search_button().click();
		ord.select_result().click();
		ord.get_change_Order_assignment_button().click();
		ord.get_search_text().clear();
		ord.get_search_text().sendKeys(Person2);
		ord.select_search_icon().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		ord.select_person_checkbox().click();
		ord.get_add_person().click();
		ord.get_split_amount().sendKeys(SplitAmount);
		ord.select_save().click();
		new OrdersStagingNewUI(SetWebDrivers.getNavigationType());
		ord.get_orders_period_dropdown().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		ord.selectOrderPeriod(OrderPeriod);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);			
		ord.get_order_code().clear();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		ord.get_order_code().sendKeys(OrderCode);
		ord.get_assignment_button().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		ord.get_search_text().clear();
		ord.get_search_text().sendKeys(Person2);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		ord.select_search_icon().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		ord.select_person_checkbox().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		ord.select_person().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		ord.get_search_button().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		int count1 = ord.get_result_count_int();
		logger.info("count1: "+count1);
		Assert.assertTrue((count1==1),"Count not equal to One");
	 }
	 
//***************************************************************************************************************************************************************//

/* Delete Staging Orders from new UI */	
			
	public void deletestagingorders(String OrderPeriod, String OrderCode, String ItemCode, String BatchName, String Period) 
	throws Exception {
		Errors processstatus = new Errors("gui");
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		try{
	    	processstatus.select_pauseprocessing_button().click();
            				
			}catch(Exception e){
				throw new Exception("Queue is already in Pause",e);				
			}
		finally{		
	    OrdersStagingNewUI ord = new OrdersStagingNewUI(SetWebDrivers.getNavigationType());
	    OrdersStagingBeta orderBeta = new OrdersStagingBeta(SetWebDrivers.getNavigationType());
	  	
	   
/* Deleting Selected Staging Orders */
	   
	    get_orders_period_dropdown().click();
	    Thread.sleep(1000);
	    selectOrderPeriod(OrderPeriod);
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    get_order_code().clear();
	    get_order_code().sendKeys(OrderCode);
	    get_item_code().clear();
	    get_item_code().sendKeys(ItemCode);
	    get_search_button().click();
	    Thread.sleep(1000);
	    select_result().click();
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    get_delete_options().click();
	    get_delete_selected_orders().click();
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    //SeleniumHelperClass.AcceptAlerts("Delete Selected order(s)?");
	    get_confirm_delete_button().click();
	    Thread.sleep(1000);
/*	    String Validation = ord.get_validation_message().getText();
	    Thread.sleep(1000);
	    logger.info(Validation);
	    Thread.sleep(1000);
	    Thread.sleep(1000);
	    Thread.sleep(1000);
	    Assert.assertEquals(Validation, "Added to Queue","Assertion Failed");
	    Thread.sleep(1000);
	    Thread.sleep(1000);		*/	
/* Deleting Staging Orders in a Batch */
	  
	    get_delete_options().click();
	    get_delete_all_orders_in_batch().click();
	    orderBeta.get_findBatch().sendKeys(BatchName);
	    orderBeta.get_searchBatchButton().click();
	    Thread.sleep(1000);
	    orderBeta.get_BatchCheckbox().click();
	    orderBeta.get_selectBatch().click();
	    Thread.sleep(1000);
	    //SeleniumHelperClass.AcceptAlerts("Delete all orders in batch JAN-2016_BATCH_3");
	    get_confirm_delete_button().click();
	    Thread.sleep(1000);
/*	    String Validation1 = ord.get_validation_message().getText();
	    Thread.sleep(1000);
	    logger.info(Validation1);
	    Thread.sleep(1000);
	    Thread.sleep(1000);
	    Assert.assertEquals(Validation1, "Added to Queue","Assertion Failed");
	    Thread.sleep(1000);*/
			
/* Deleting Staging Orders in a Period */
	   
	    get_delete_options().click();
	    get_delete_all_orders_in_period().click();
	    get_search_text().sendKeys(Period);
	    select_search_icon().click();
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    select_checkbox().click();
	    select_delete_button().click();
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    //SeleniumHelperClass.AcceptAlerts("Delete all orders in period JAN-2016");
	    get_confirm_delete_button().click();
	    Thread.sleep(1000);
/*	    String Validation2 = ord.get_validation_message().getText();
	    Thread.sleep(1000);
	    logger.info(Validation2);
	    Thread.sleep(1000);
	    Thread.sleep(1000);
	    Assert.assertEquals(Validation2, "Added to Queue","Assertion Failed");
	    Thread.sleep(1000);*/
				
/* Navigating to Process Status-> Queue page to validate Delete Queue completion */
		   
	    new Errors("gui");
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	    try{
		    processstatus.select_startprocessing_button().click();
		    }catch(Exception e){
		    	logger.info("Queue is already in Process");		
			}	
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    logger.info("no of rows"+ ord.delete_Queue_row().size());
	    int rowCount;
	    long startTime;
	    long endTime;
	    long timeDifference;
	    startTime= System.currentTimeMillis();
			do {
				rowCount = ord.delete_Queue_row().size();
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
				endTime = System.currentTimeMillis();
				timeDifference = (endTime - startTime);
				//logger.info("roCount:"+ rowCount);
			}while (rowCount>0 && (TimeUnit.MILLISECONDS.toSeconds(timeDifference))<=120);
			
			logger.info("Delete Complete");
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
			Assert.assertEquals(rowCount, 0);
				
/* Navigating to Orders->Orders to validate Delete Orders Completed Successfully */
				
	    new OrdersStagingNewUI(SetWebDrivers.getNavigationType());
	    ord.get_orders_period_dropdown().click();
	    Thread.sleep(1000);
	    ord.selectOrderPeriod("JAN-2016 (Open)");
	    Thread.sleep(1000);
	    get_search_button().click();
	    Thread.sleep(3000);
	    int count = ord.get_result_count_int();
	    logger.info("count: "+count);
	    Assert.assertTrue((count==0),"Count not equal to Zero");
	       }
		 }
		
			
	    
//***************************************************************************************************************************************************************//
	
	/* Delete Staging Orders by Batch */	
	
	public void deleteOrdersByBatch(String OrderPeriod, String OrderCode, String ItemCode, String BatchName, String Period) 
	throws Exception {
		Errors processstatus = new Errors("gui");
		  Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	   
		try{
			processstatus.select_pauseprocessing_button().click();

				}catch(Exception e){
					logger.info("Queue is already in Pause");				
				}
			finally{
		
		
	    OrdersStagingNewUI ord = new OrdersStagingNewUI(SetWebDrivers.getNavigationType());
	    OrdersStagingBeta orderBeta = new OrdersStagingBeta("");
	   
			
/* Deleting Staging Orders in a Batch */
	  
	    get_orders_period_dropdown().click();
	    Thread.sleep(1000);
	    selectOrderPeriod(OrderPeriod);
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    get_delete_options().click();
	    get_delete_all_orders_in_batch().click();
	    orderBeta.get_findBatch().sendKeys(BatchName);
	    orderBeta.get_searchBatchButton().click();
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    orderBeta.get_BatchCheckbox().click();
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    orderBeta.get_selectBatch().click();
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    //SeleniumHelperClass.AcceptAlerts("Delete all orders in batch JAN-2016_BATCH_3");
	    get_confirm_delete_button().click();
	    Thread.sleep(1000);
	   /* String Validation1 = ord.get_validation_message().getText();
	    logger.info(Validation1);
	    Assert.assertEquals(Validation1, "Added to Queue","Assertion Failed");
	    Thread.sleep(1000);
		*/	
			
				
/* Navigating to Process Status-> Queue page to validate Delete Queue completion */
		   
	    new Errors("gui");
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	    
		try{
			
			processstatus.select_startprocessing_button().click();

				}catch(Exception e){
					logger.info("Queue is already in process");				
				}
			
						
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    logger.info("no of rows"+ ord.delete_Queue_row().size());
	    int rowCount;
	    long startTime;
	    long endTime;
	    long timeDifference;
	    startTime= System.currentTimeMillis();
			do {
				rowCount = ord.delete_Queue_row().size();
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
				endTime = System.currentTimeMillis();
				timeDifference = (endTime - startTime);
				//logger.info("roCount:"+ rowCount);
			}while (rowCount>0 && (TimeUnit.MILLISECONDS.toSeconds(timeDifference))<=120);
			
			logger.info("Delete Complete");
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
			Assert.assertEquals(rowCount, 0);
				
/* Navigating to Orders->Orders to validate Delete Orders Completed Successfully */
				
	    new OrdersStagingNewUI(SetWebDrivers.getNavigationType());
	    ord.get_orders_period_dropdown().click();
	    Thread.sleep(1000);
	    ord.selectOrderPeriod(Period);
	    Thread.sleep(1000);
	    get_search_button().click();
	    Thread.sleep(1000);
	    int count = ord.get_result_count_int();
	    logger.info("count: "+count);
	    Assert.assertTrue((count==0),"Count not equal to Zero");
		}
			
	}
	
	//*******************
	
	public void deleteOrdersByPeriod(String OrderPeriod, String OrderCode, String ItemCode, String BatchName, String Period) 
	throws Exception {
		Errors processstatus = new Errors("gui");
		processstatus.get_queue_link();
		  Thread.sleep(10000);
		try{
			processstatus.select_pauseprocessing_button().click();

				}catch(Exception e){
					logger.info("Queue is already in Pause");					
				}
			finally{
	    OrdersStagingNewUI ord = new OrdersStagingNewUI(SetWebDrivers.getNavigationType());
	    OrdersStagingBeta orderBeta = new OrdersStagingBeta("");
	   
/* Deleting Staging Orders in a Period */
	   
	    get_delete_options().click();
		  Thread.sleep(10000);

	    get_delete_all_orders_in_period().click();
	    get_search_text().sendKeys(Period);
	    select_search_icon().click();
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    select_checkbox().click();
	    select_delete_button().click();
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    //SeleniumHelperClass.AcceptAlerts("Delete all orders in period JAN-2016");
	    get_confirm_delete_button().click();
	    /*Thread.sleep(1000);
	    String Validation2 = ord.get_validation_message().getText();
	    Thread.sleep(1000);
	    logger.info(Validation2);
	    Assert.assertEquals(Validation2, "Added to Queue","Assertion Failed");
	    Thread.sleep(1000);
		*/		
/* Navigating to Process Status-> Queue page to validate Delete Queue completion */
		   
	    new Errors("gui");
		processstatus.get_queue_link();

	    Thread.sleep(10000);
	    try{
		    processstatus.select_startprocessing_button().click();
		    }catch(Exception e){
		    	logger.info("Queue is already in process");					
			}
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    logger.info("no of rows"+ ord.delete_Queue_row().size());
	    int rowCount;
	    long startTime;
	    long endTime;
	    long timeDifference;
	    startTime= System.currentTimeMillis();
			do {
				rowCount = ord.delete_Queue_row().size();
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
				endTime = System.currentTimeMillis();
				timeDifference = (endTime - startTime);
				//logger.info("roCount:"+ rowCount);
			}while (rowCount>0 && (TimeUnit.MILLISECONDS.toSeconds(timeDifference))<=120);
			
			logger.info("Delete Complete");
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
			Assert.assertEquals(rowCount, 0);
				
/* Navigating to Orders->Orders to validate Delete Orders Completed Successfully */
				
	    new OrdersStagingNewUI(SetWebDrivers.getNavigationType());
	    ord.get_orders_period_dropdown().click();
	    Thread.sleep(1000);
	    ord.selectOrderPeriod(Period);
	    Thread.sleep(1000);
	    get_search_button().click();
	    Thread.sleep(1000);
	    int count = ord.get_result_count_int();
	    logger.info("count: "+count);
	    Assert.assertTrue((count==0),"Count not equal to Zero");
		}
			}
	
	//*************************
	
	
	
	
	
	
	
	
	
	
	
	
  
/* Orders ErrorLog */
	    
	public void orderserrorlog(String FromPeriod, String ToPeriod, String BatchName, String OrderCode) 
	throws Exception {
		Errors processstatus = new Errors("gui");	      
	    processstatus.get_batches_link().click();
	    Thread.sleep(6000);
	    processstatus.get_batches_from_period_dropdown().click();
	    Thread.sleep(1000);
	    processstatus.selectbatchesperiod(FromPeriod);
	    Thread.sleep(1000);
	    processstatus.get_batches_to_period_dropdown().click();
	    Thread.sleep(1000);
	    processstatus.selectbatchesperiod(ToPeriod);
	    Thread.sleep(1000);	
	    processstatus.get_batches_search_textbox().sendKeys(BatchName);
	    processstatus.get_batches_search_icon().click();
	    Thread.sleep(1000);
	    processstatus.select_batch_checkbox().click();
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
	    processstatus.get_calculate_through_incentives_link().click();
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
	    processstatus.get_queue_link().click();
	    Thread.sleep(1000);
	    logger.info("no of rows"+ processstatus.Queue_row().size());
	    Thread.sleep(1000);
	    int rowCount;
	    long startTime;
	    long endTime;
	    long timeDifference;		
		startTime= System.currentTimeMillis();
			do {
				rowCount = processstatus.Queue_row().size();
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
				endTime = System.currentTimeMillis();
				timeDifference = (endTime - startTime);
				//logger.info("roCount:"+ rowCount);
			}while (rowCount>0 && (TimeUnit.MILLISECONDS.toSeconds(timeDifference))<=120);
			
			logger.info("Calculate Through Incentives Complete");
			Thread.sleep(1000);
			Assert.assertEquals(rowCount, 0);
				
/* Navigate to Orders page to check the ErrorLog */				
		  
		new OrdersStagingNewUI(SetWebDrivers.getNavigationType());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_orders_period_dropdown().click();
		Thread.sleep(1000);
		selectOrderPeriod(FromPeriod);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		get_order_code().clear();
		get_order_code().sendKeys(OrderCode);
		get_search_button().click();
		select_result_row().click();
		Thread.sleep(1000);
		get_errorlog().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);  
		
/* Comparing the expected and actual result	*/
		  
	    Map<String,String> actualSet= new TreeMap<String, String>();		 
	    Map<String,String> expectedSet= new TreeMap<String, String>();
	 
	    String expectedSetKey1 = "StagingOrderItem TotalAmount" + "60";
	    String expectedSetValue1 = "Amount Error - Amount Error: Cannot be more than 40";
	    expectedSet.put(expectedSetKey1, expectedSetValue1);
	 
	    String expectedSetKey2 = "Geography" + "US";
	    String expectedSetValue2 = "Geography Error - Geography Error: Geography cannot be other than INDIA";
	    expectedSet.put(expectedSetKey2, expectedSetValue2);
	 
	    String expectedSetKey3 = "StagingOrderItem Quantity" + "15.0";
	    String expectedSetValue3 = "Quantity Error - Quantity Error: Quantity cannot be more than 10";
	    expectedSet.put(expectedSetKey3, expectedSetValue3);
	 
	    for(int error=1;error<=3;error++){	
	      Thread.sleep(1000);
		  String key = get_errorlog_fieldname(error).getText() + get_errorlog_fieldvalue(error).getText();
		  Thread.sleep(1000);
		  actualSet.put(key, get_errorlog_fielderrormessage(error).getText());
	   }
	    //logger.info("Actual Set :"+actualSet);
	    //logger.info("Expected Set :"+expectedSet);
	  
	    for(Iterator<String> it = actualSet.keySet().iterator();it.hasNext();)
	   {
		  String key = it.next();
		  Thread.sleep(1000);
		  String ExpectedResult = expectedSet.get(key);	
		  Thread.sleep(1000);
		  String ActualResult = actualSet.get(key);
		  
		  logger.info("ExpectedResult" + ExpectedResult);
		  logger.info("ActualResult" + ActualResult);
		  Thread.sleep(1000);
		  Assert.assertEquals(ActualResult, ExpectedResult, "Assertion failed Actual is "+ActualResult+" and Expected is "+ExpectedResult+"");
	  }    	  
	}
	
//***************************************************************************************************************************************************************//   
	  
/* Delete Processed Orders */
		
	public void deleteprocessedorders(String ToPeriod, String FromPeriod, String BatchName1, String BatchName2, String OrderPeriod, String OrderCode, String ItemCode ) 
	throws Exception {   	
     
/* Calculating/Processing the Orders */
	    	
	    OrdersStagingNewUI ord = new OrdersStagingNewUI("");
	    OrdersStagingBeta orderBeta = new OrdersStagingBeta("");
	    Errors processstatus = new Errors("gui");	      
	    processstatus.get_batches_link().click();
	    Thread.sleep(6000);
	    processstatus.get_batches_from_period_dropdown().click();
	    Thread.sleep(1000);
	    processstatus.selectbatchesperiod(FromPeriod);
	    Thread.sleep(1000);
	    processstatus.get_batches_to_period_dropdown().click();
	    Thread.sleep(1000);
	    processstatus.selectbatchesperiod(ToPeriod);
	    Thread.sleep(1000);	
	    processstatus.get_batches_search_textbox().clear();
	    processstatus.get_batches_search_textbox().sendKeys(BatchName1);
	    processstatus.get_batches_search_icon().click();
	    Thread.sleep(1000);
	    processstatus.select_batch_checkbox().click();
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
	    processstatus.get_calculate_through_incentives_link().click();
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    processstatus.get_batches_search_clear_icon().click();
	    Thread.sleep(1000);	
	    processstatus.get_batches_search_textbox().sendKeys(BatchName2);
	    processstatus.get_batches_search_icon().click();
	    Thread.sleep(1000);
	 	processstatus.select_batch_checkbox().click();
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
	    processstatus.get_calculate_through_incentives_link().click();
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    processstatus.get_queue_link().click();
	    Thread.sleep(1000);
	    logger.info("no of rows"+ processstatus.Queue_row().size());
	    int rowCount;
	    long startTime;
	    long endTime;
	    long timeDifference;		
		startTime= System.currentTimeMillis();
			do {
				rowCount = processstatus.Queue_row().size();
				//logger.info("roCount:"+ rowCount);
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
				endTime = System.currentTimeMillis();
				timeDifference = (endTime - startTime);
			}while (rowCount>0 &&(TimeUnit.MILLISECONDS.toSeconds(timeDifference))<=120);
			
			logger.info("Calculate Through Incentives Complete");
			Thread.sleep(1000);
			Assert.assertEquals(rowCount, 0);
			
//	    processstatus.select_pauseprocessing_button().click();
		   
/* Deleting Selected Processed Orders */
				
	    new OrdersStagingNewUI(SetWebDrivers.getNavigationType());	
	    get_processed_link().click();
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    get_orders_period_dropdown().click();
	    Thread.sleep(1000);
	    selectOrderPeriod(FromPeriod);
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    get_order_code().clear();
	    get_order_code().sendKeys(OrderCode);
	    get_item_code().clear();
	    get_item_code().sendKeys(ItemCode);
	    get_search_button().click();
	    Thread.sleep(1000);
	    select_result().click();
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    get_delete_options().click();
	    get_delete_selected_orders().click();
	    Thread.sleep(1000);
/*	    get_confirm_delete_from_staging_checkbox().click();
	    get_confirm_delete_button().click();
	    Thread.sleep(1000);
	    String Validation = ord.get_validation_message().getText();
	    logger.info(Validation);
	    Assert.assertEquals(Validation, "Added to Queue","Assertion Failed");
	    Thread.sleep(1000);*/
		
/* Deleting Processed Orders in a Batch */
			  
	    get_delete_options().click();
	    get_delete_all_orders_in_batch().click();
	    orderBeta.get_findBatch().sendKeys(BatchName1);
	    orderBeta.get_searchBatchButton().click();
	    Thread.sleep(1000);
	    orderBeta.get_BatchCheckbox().click();
	    orderBeta.get_selectBatch().click();
	    Thread.sleep(1000);
	    get_confirm_delete_from_staging_checkbox().click();
	    get_confirm_delete_button().click();
	    Thread.sleep(1000);
/*	    String Validation1 = ord.get_validation_message().getText();
	    logger.info(Validation1);
	    Assert.assertEquals(Validation1, "Added to Queue","Assertion Failed");
	    Thread.sleep(1000);*/
				
/* Deleting Processed Orders in a Period */
		   
	    get_delete_options().click();
	    get_delete_all_orders_in_period().click();
	    get_search_text().sendKeys(OrderPeriod);
	    select_search_icon().click();
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    select_checkbox().click();
	    select_delete_button().click();
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	   	get_confirm_delete_from_staging_checkbox().click();
	    get_confirm_delete_button().click();
	    Thread.sleep(1000);
/*	    String Validation2 = ord.get_validation_message().getText();
	    logger.info(Validation2);
	    Assert.assertEquals(Validation2, "Added to Queue","Assertion Failed");
	    Thread.sleep(1000);*/
				
/* Navigating to Process Status-> Queue page to validate Delete Queue completion */
		   
	    new Errors("gui");
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    try{
		    processstatus.select_startprocessing_button().click();
		    }catch(Exception e){
		    	logger.info("Queue is already in Pause");					
			}
		    
		    finally{
	    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	    logger.info("no of rows"+ ord.delete_Queue_row().size());
	    int rowCount1;
	    long startTime1;
	    long endTime1;
	    long timeDifference1;		
		startTime1= System.currentTimeMillis();
			do {
				rowCount1 = ord.delete_Queue_row().size();
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
				endTime1 = System.currentTimeMillis();
				timeDifference1 = (endTime1 - startTime1);
			}while (rowCount1>0 && (TimeUnit.MILLISECONDS.toSeconds(timeDifference1))<=120);
			
			logger.info("Delete Complete");
			Assert.assertEquals(rowCount, 0);
				
/* Navigating to Orders->Orders->Staging to validate Delete Staging Orders Completed Successfully */
				
	    new OrdersStagingNewUI(SetWebDrivers.getNavigationType());
	    ord.get_orders_period_dropdown().click();
	    Thread.sleep(1000);
	    ord.selectOrderPeriod(OrderPeriod);
	    Thread.sleep(1000);
	    get_search_button().click();
	    Thread.sleep(1000);
	    int count = ord.get_result_count_int();
	    logger.info("count: "+count);
	    Assert.assertTrue((count==0),"Count not equal to Zero");
		   
/*  Navigating to Orders->Orders->Processed to validate Delete Processed Orders Completed Successfully */
	    new OrdersStagingNewUI(SetWebDrivers.getNavigationType());	
	    get_processed_link().click();
	    ord.get_orders_period_dropdown().click();
	    Thread.sleep(1000);
	    ord.selectOrderPeriod(FromPeriod);
	    Thread.sleep(1000);
	    get_search_button().click();
	    Thread.sleep(4000);
	    int count1 = ord.get_result_count_int();
	    logger.info("count: "+count1);
	    Assert.assertTrue((count1==0),"Count not equal to Zero");
		}
}
	
	public void createBatch(String name, String periodid, String desc, String batchType) throws Exception
	{
		Boolean flag=false;
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*3);	
		get_batch_name().sendKeys(name);
		get_batch_desc().sendKeys(desc);
		Thread.sleep(1000);		
		//get_batch_period_icon().click();
		 get_batch_period_icon_Order().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		
		List<WebElement> batchSelect=SeleniumHelperClass.findWebElementsInXpath(".//*[@id='select2-drop']/ul/li", "mainFrame");
		
		for (WebElement webElement : batchSelect) {
			logger.info("batchSelect:"+webElement.getText());
			
			if(webElement.getText().equals(periodid)&&(flag==false)) {
				flag=true;
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);				
				get_selectPeriodDropDown(periodid).click();			
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
				get_batchType().click();
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);		
			    get_searchBatch().sendKeys(batchType);			
			    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);			
			    get_searchButton().click();
			    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
			    get_tickSearchBatch().click();;
			    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
			    get_selectSearchBatch().click();
			    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
			    get_batchSave().click();
			    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
						
			break;
			
			
		}
			
		}	
		
				
	}
	
public WebElement get_batch_period_icon_Order() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='s2id_periodname']/a/span[2]/b","mainFrame"));
		
	}
	
	public WebElement get_batchType() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//a[@id='selectBatchType']","mainFrame"));
	}
	
	public WebElement get_batch_name() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@name='batchName']","mainFrame"));
	}
	
	public WebElement get_batch_desc() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@name='description']","mainFrame"));
	}
	
	public WebElement get_batchSave() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='saveBatch']","mainFrame"));
	}
	
	public WebElement get_verifyBatchName() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='element-list']/li/div/span[2]","mainFrame"));
	}	
	
public WebElement get_OptionalField() throws Exception {
//return SeleniumHelperClass.findWebElementbyXpath(".//*[@id='createOrdersSection']/form/div[3]/div[1]/span");
	return SeleniumHelperClass.findWebElementbyXpath("//span[@data-i18n='optionalFields']");
	}
	
public WebElement get_CustomeField() throws Exception {
return SeleniumHelperClass.findWebElementbyXpath(".//*[@id='createOrdersSection']/form/div[4]/div[1]/span");
	}
public void movetoRequiredField(WebElement requiredSection ) throws Exception {
		
	WebDriver driver =SetWebDrivers.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	executor.executeScript("arguments[0].scrollIntoView(true);", requiredSection );
	Thread.sleep(500); 
	
	}
public WebElement get_batchSearchButton() throws Exception {
		
		//return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[1]/div[2]/div[2]/span/a","mainFrame"));
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='search-button']","mainFrame"));
	}

public WebElement get_searchStatus(String batchName) throws Exception {
	
	return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='orders-list']//li/div/span[@title='"+batchName+"']/preceding-sibling::span[6]","mainFrame"));
}


public void viewBatchname(String batchName) throws Exception {
	logger.info("view batch name");
	
	SeleniumHelperClass.executeJavaScriptScroll(get_searchBatchName(batchName));
	

}

public void viewBatchnameStatus(String batchName) throws Exception {
	logger.info("view batch name");
	
	SeleniumHelperClass.executeJavaScriptScroll( get_searchStatus(batchName));
	
	
}

public WebElement getIncentiveDate() throws Exception {
	return (SeleniumHelperClass.findWebElementbyid("incentiveDate","mainFrame"));
	
	
}
public void enableDatefield(String IncentiveDate) throws Exception {
	
	JavascriptExecutor js = (JavascriptExecutor)SetWebDrivers.getDriver(); 
	js.executeScript("return document.getElementById('incentiveDate').disabled=false;");
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	getIncentiveDate().sendKeys(IncentiveDate);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
}

public WebElement get_headerErrorMsg() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='errorGutter']"));
}

public WebElement get_selectPerson() throws Exception {
//return (SeleniumHelperClass.findWebElementbyXpath("//div[@class='assignments-section-content']/div[2]/span/span","mainFrame"));

return (SeleniumHelperClass.findWebElementbyXpath("//span[@data-i18n='selectPerson']","mainFrame"));
}

public WebElement get_searchFilterPerson() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='search-text']","mainFrame"));
}

public WebElement get_searchButtonPerson() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='search-button']","mainFrame"));
}

public WebElement get_tickSelectPerson() throws Exception {
//return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='element-list']/li/div/span[1]/input","mainFrame"));

return (SeleniumHelperClass.findWebElementbyXpath("//input[@name='selectedElement']","mainFrame"));
}

public WebElement get_selectButton() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='personView']/div[1]/div/span[2]","mainFrame"));
}

public WebElement get_splitAmount() throws Exception {
//return (SeleniumHelperClass.findWebElementbyXpath(".//div[@class='assignments-section-content']//div//div/input","mainFrame"));
	
	return (SeleniumHelperClass.findWebElementbyXpath("//input[@data-field='person-percentage']","mainFrame"));
}

/*public WebElement get_customDate() throws Exception {
	
	return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='number1']","mainFrame"));
}*/

public WebElement get_detailOrderAmount() throws Exception {
	
	return (SeleniumHelperClass.findWebElementbyXpath("//div[@data-i18n='standardOrderFields']/../div[2]/div[2]/span[2]","mainFrame"));
	
	
}

public WebElement get_AssignmentTabClick() throws Exception {
	
	return (SeleniumHelperClass.findWebElementbyXpath("//div[@data-i18n='assignments']","mainFrame"));
}

public WebElement getOrderType() throws Exception {
	
	return (SeleniumHelperClass.findWebElementbyXpath("//div[@data-i18n='optionalOrderFields']/../div[2]/div[2]/span[2]","mainFrame"));
}

public WebElement getOrderTypeSelect(String orderTypeSelection) throws Exception {
	
	return (SeleniumHelperClass.findWebElementbyXpath(".//*[@class='lists-dropdown order-type-detail']/ul/li[text()='"+orderTypeSelection+"']","mainFrame"));
}

public WebElement getClickOrderType() throws Exception {
	
	return (SeleniumHelperClass.findWebElementbyXpath("//*[@class='dropdown-title optional order-type-detail']/i","mainFrame"));
}

public void selectOrderTypeOptional(String orderTypeSelection) throws Exception {
	
	Boolean flag=false;
	
	getClickOrderType() .click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	
	List<WebElement> orderTypes=SeleniumHelperClass.findWebElementsInXpath(".//*[@class='lists-dropdown order-type-detail']/ul[1]/li", "mainFrame");
	
	for (WebElement webElement : orderTypes) {
		
		logger.info("OrderType:"+webElement.getText());
		if(webElement.getText().equalsIgnoreCase(orderTypeSelection) && (flag==false)) {
			
			flag=true;
			getOrderTypeSelect(orderTypeSelection).click();
			logger.info("clicked");

		}
		
	}
	
}

public WebElement get_searchOrderCode() throws Exception {
	
	return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='orderCode']","mainFrame"));
}

public WebElement get_detailsSection() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//li/div/span[2]","mainFrame"));

}

public WebElement get_detailsSplit() throws Exception {

return (SeleniumHelperClass.findWebElementbyXpath(".//*[@class='numeric-fields']"));
}


public WebElement get_processed() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='processedLink']/a","mainFrame"));
}

public WebElement getCustomDate() throws Exception {
	return (SeleniumHelperClass.findWebElementbyid("date1","mainFrame"));
	
}

public void enableCustomDatefield(String customDate) throws Exception {
	
	JavascriptExecutor js = (JavascriptExecutor)SetWebDrivers.getDriver(); 
	js.executeScript("return document.getElementById('date1').disabled=false;");
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	getCustomDate().sendKeys(customDate);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	
	
}

public void enableClearCustomDatefield() throws Exception {
	
	JavascriptExecutor js = (JavascriptExecutor)SetWebDrivers.getDriver(); 
	js.executeScript("return document.getElementById('date1').disabled=false;");
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	getCustomDate().clear();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	
	
}

public WebElement get_Staged() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='stagingLink']/a","mainFrame"));
}

public WebElement get_deletePopup() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//span[@id='confirm-button']/div","mainFrame"));
	
}

public WebElement get_noOrdersList() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='results-total']","mainFrame"));
	
}

public WebElement get_ItemErrorMessage() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@data-validation-parent='itemCode']//span[@data-validation-msg='itemCode']","mainFrame"));
	
}

public WebElement get_searchBatchName(String batchName) throws Exception {
//return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='orders-list']//li/div/span[@title='"+batchName+"']","mainFrame"));
	
	return (SeleniumHelperClass.findWebElementbyXpath(".//span[@title='"+batchName+"']","mainFrame"));
}

public WebElement get_IncentiveErrorMessage() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@data-validation-parent='incentiveDate']//span[@data-validation-msg='incentiveDate']","mainFrame"));
}

public WebElement get_AmountErrorMessage() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@data-validation-parent='amount']//span[@data-validation-msg='amount']","mainFrame"));
}

public WebElement get_BatchErrorMessage() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@data-validation-parent='batchName']//span[@data-validation-msg='batchName']","mainFrame"));
		
}

public WebElement getEditButton(String batchName) throws Exception {
	
	return (SeleniumHelperClass.findWebElementbyXpath(".//*[@title='"+batchName+"']/../div[1]/button[@class='pill-button action-button' and @data-action='edit']"));
}
public WebElement getDeleteButton(String batchName) throws Exception {
	
	return (SeleniumHelperClass.findWebElementbyXpath(".//*[@title='"+batchName+"']/../div[1]/button[@class='pill-button action-button' and @data-action='delete']"));
}

public WebElement getRandomDeleteButton() throws Exception {
	
	return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='orders-list']/li/div/div[1]/button[@class='pill-button action-button' and @data-action='delete']"));
}

public WebElement getEditBatchButton(String batchName) throws Exception {
	
	return (SeleniumHelperClass.findWebElementbyXpath(".//span[text()='"+batchName+"']/../div[1]/button[@class='pill-button action-button' and @data-action='edit']"));
}
public WebElement getDeleteBatchButton(String batchName) throws Exception {
	
	return (SeleniumHelperClass.findWebElementbyXpath(".//span[text()='"+batchName+"']/../div[1]/button[@class='pill-button action-button' and @data-action='delete']"));
}


public void getEditBatchRecord(String batchName) throws Exception {
	
	SeleniumHelperClass.findWebElementAndEnableDisplay("pill-button-grp", "mainFrame","0");
	Thread.sleep(5000);    
	getEditBatchButton(batchName).click(); 
}

public void getDeleteBatchRecord(String batchName) throws Exception {
	
	SeleniumHelperClass.findWebElementAndEnableDisplay("pill-button-grp", "mainFrame","0");
	Thread.sleep(5000);
	getDeleteBatchButton(batchName).click(); 
	
}
public void getEditOrderRecord(String batchName) throws Exception {
	
	SeleniumHelperClass.findWebElementAndEnableDisplay("pill-button-grp", "mainFrame","0");
	Thread.sleep(5000);    
	getEditButton(batchName).click(); 
}

public void getDeleteOrderRecord(String batchName) throws Exception {
	
	SeleniumHelperClass.findWebElementAndEnableDisplay("pill-button-grp", "mainFrame","0");
	Thread.sleep(5000);
	getDeleteButton(batchName).click(); 
	
}

public void getRandomDeleteOrderRecord() throws Exception {
	
	SeleniumHelperClass.findWebElementAndEnableDisplay("pill-button-grp", "mainFrame","0");
	Thread.sleep(5000);
	getRandomDeleteButton().click(); 
	
}

public String getBatchNameDisable() throws Exception {
	
	return (SeleniumHelperClass.findWebElementbyXpath("//input[@disabled='']").getAttribute("input"));
}


/*public WebElement getIncentDate() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='createOrdersSection']/form/div[1]/div[3]/div[1]/div/div/button","mainFrame"));
}
*/

/*public WebElement get_incentDateYear() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='ui-datepicker-div']/div/div/select[1]"));
}*/

public WebElement get_Amount() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='amount']","mainFrame"));
}
public WebElement get_createOrder() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@data-i18n='createOrder']/following-sibling::span/span[@data-i18n='create']","mainFrame"));
}

public WebElement getSaveOrder() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@data-i18n='editOrder']/following-sibling::span/span[@data-i18n='save']","mainFrame"));
}

public WebElement get_batch_period_icon() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='s2id_periods']/a/span[2]/b","mainFrame"));
	
}


public WebElement get_searchOrderName(String batchName) throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='orders-list']//li/div/span[@title='"+batchName+"']/preceding-sibling::span[4]","mainFrame"));
}

public WebElement getDetailCustomDate() throws Exception {
	
	return (SeleniumHelperClass.findWebElementbyXpath("//div[@data-i18n='customOrderFields']/../div[2]/div[1]/span[@class='detail-row data-field']","mainFrame"));
}

/*public WebElement getSelectOrder() throws Exception {

	return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='orders-list']/li/div/span[1]","mainFrame"));
	
}*/

public void createOrderWithRequiredCustomFields(String orderCode,String itemCode,String batchName,String incentiveDate,String amount,String cfBooleanValue,String cfDDListValue,String cfNumberValue,String cfNumberUnitType,String periodName) throws Exception {
	
	OrdersStagingBeta orderBeta = new OrdersStagingBeta(SetWebDrivers.getNavigationType());
	get_createOrderItem().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_order_code().sendKeys(orderCode);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_item_code().sendKeys(itemCode);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	SeleniumHelperClass.click(get_selectBatchName());
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_findBatch().sendKeys(batchName);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_batchSearchButton().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
    orderBeta.get_BatchCheckbox().click();
    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	orderBeta.get_selectBatch().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	enableDatefield(incentiveDate);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_Amount().sendKeys(amount);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_OI_Boolean_Req_CF_DD().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	select_CustomField_Value(cfBooleanValue).click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_OI_DDList_Req_CF_DD().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	select_CustomField_Value(cfDDListValue).click();;
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_OI_Number_Req_CF().sendKeys(cfNumberValue);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
	get_OI_Number_Req_UnitType_CF_DD().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	select_CustomField_Value(cfNumberUnitType).click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_createOrder().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);	
	
	//Searching for created order
	get_orders_period_dropdown().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	selectOrderPeriod(periodName);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);			
	get_order_code().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
	get_order_code().clear();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
	get_order_code().sendKeys(orderCode);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
	get_item_code().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
	get_item_code().clear();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
	get_item_code().sendKeys(itemCode);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
	get_search_button().click();	
}

public void createOrderWithRequiredandOptionalCustomFields(String orderCode,String itemCode,String batchName,String incentiveDate,String amount,String cfBooleanValue,String cfDDListValue,String cfDateValue,String cfNumberValue,String cfNumberUnitType,String cfStringValue, String periodName) throws Exception {

	OrdersStagingBeta orderBeta = new OrdersStagingBeta(SetWebDrivers.getNavigationType());
	get_createOrderItem().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_order_code().sendKeys(orderCode);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_item_code().sendKeys(itemCode);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_selectBatchName().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_findBatch().sendKeys(batchName);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_batchSearchButton().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
    orderBeta.get_BatchCheckbox().click();
    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	orderBeta.get_selectBatch().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	enableDatefield(incentiveDate);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_Amount().sendKeys(amount);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_OI_Boolean_Req_CF_DD().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	select_CustomField_Value(cfBooleanValue).click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_OI_DDList_Req_CF_DD().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	select_CustomField_Value(cfDDListValue).click();;
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	enableCustomDatefield(cfDateValue);
	get_OI_Number_Req_CF().sendKeys(cfNumberValue);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
	get_OI_Number_Req_UnitType_CF_DD().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	select_CustomField_Value(cfNumberUnitType).click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_OI_String_Opt_CF().sendKeys(cfStringValue);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_createOrder().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);	
	
	//Searching for created order
	get_orders_period_dropdown().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	selectOrderPeriod(periodName);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);			
	get_order_code().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
	get_order_code().clear();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
	get_order_code().sendKeys(orderCode);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
	get_item_code().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
	get_item_code().clear();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
	get_item_code().sendKeys(itemCode);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
	get_search_button().click();
	
}

public void createOrderWithRequiredCustomFieldsErrorValidation(String orderCode,String itemCode,String batchName,String incentiveDate,String amount) throws Exception {
	
	OrdersStagingBeta orderBeta = new OrdersStagingBeta(SetWebDrivers.getNavigationType());
	get_createOrderItem().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_order_code().sendKeys(orderCode);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_item_code().sendKeys(itemCode);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_selectBatchName().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_findBatch().sendKeys(batchName);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_batchSearchButton().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
    orderBeta.get_BatchCheckbox().click();
    Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	orderBeta.get_selectBatch().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	enableDatefield(incentiveDate);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_Amount().sendKeys(amount);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	get_createOrder().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
	movetoRequiredField(get_CustomeField());
}

//***************************************************************************************************************************************************************//   

public int getbusinessIDfromDB(String email,DBConnections db) throws ClassNotFoundException, SQLException, InterruptedException{
    String businessID = db.connect_Db_string("select Business_ID from XC_USER where EMAIL like '"+email+"'","BUSINESS_ID");
    logger.info(businessID);
    return Integer.parseInt(businessID);
}

public int getPeriodIDfromDB(String periodName,int businessID,DBConnections db) throws ClassNotFoundException, SQLException, InterruptedException{
        String periodID=db.connect_Db_string("select PERIOD_ID from XC_Period where NAME like '"+periodName+"' and BUSINESS_ID='"+businessID+"'","PERIOD_ID");
        logger.info(periodID);
        return Integer.parseInt(periodID);
    }

public int getOrdersCountfromDB(int periodID,String OrderCode,String ItemCode,DBConnections db) throws ClassNotFoundException, SQLException, InterruptedException{
	String countquery = "Select count(*) count from XC_ORDER_STAGE where period_id = '"+periodID+"' and Order_Code like '"+OrderCode+"' and  Item_Code like '"+ItemCode+"'";
    ArrayList<String> orderCount = db.connect_Db(countquery, "count");
        logger.info(orderCount);
        return Integer.parseInt(orderCount.get(0));  
    }

public WebElement AutoChkBox() throws Exception {
	return  SeleniumHelperClass.findWebElementbyid("autoCreate","mainFrame");
}

public WebElement ResultRow() throws Exception {
	return  SeleniumHelperClass.findWebElementbyXpath("//*[@id='orders-list']/li[1]/div/span[2]","mainFrame");
}

/*Bchauhan
 * ANT-3880-->Creating WebElement for Customs Fields available on Create order Page
 * 
 * 
 * 
 * 
 * */

public boolean EditOrderrec(String batchName) throws Exception {
	
	SeleniumHelperClass.findWebElementAndEnableDisplay("pill-button-grp", "mainFrame","0");
	SeleniumHelperClass.isVisible(getEditButton(batchName), 10);
	getEditButton(batchName).click();
	return true; 
}

public WebElement selectBatchName() throws Exception {
	return  SeleniumHelperClass.findWebElementbyXpath("//div[@class='popup-select-item-controls top order-pop-controls-button']/span[2]","mainFrame");
}
 public void clickonBatch() throws Exception {
		WebDriver driver = SetWebDrivers.getDriver();
		Actions action = new Actions(driver);
		action.click(get_addBatch()).build().perform();

} 
 public WebElement EnterDesc() throws Exception {
	return SeleniumHelperClass.findWebElementbyXpath("//div/textarea[@id='description']", "mainFrame");
 }
 public WebElement EnterDescount() throws Exception {
	return SeleniumHelperClass.findWebElementbyXpath("//div/input[@id='discount']", "mainFrame");
 }
 public WebElement EnterQuantity() throws Exception {
	return SeleniumHelperClass.findWebElementbyXpath("//div/input[@id='quantity']", "mainFrame");
 }
public void ClickedOrderTypeOptional(String orderTypeSelection) throws Exception {	
	getClickOrderType() .click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	WebElement ele=SeleniumHelperClass.findWebElementbyXpath(".//*[@class='lists-dropdown order-type-detail']/ul[1]/li", "mainFrame");
	SeleniumHelperClass.isVisible(ele, 10);
	ele.click();
		}
		
public String selectOrdercheckbox() throws Exception {
SeleniumHelperClass.findWebElementbyXpath("//input[@name='orderListItem']", "mainFrame").click();
String OrderText= (SeleniumHelperClass.findWebElementbyXpath("//div[@class='list-item-row border-bottom orders-row']/span[2]", "mainFrame")).getText();
return OrderText;
}


	public boolean CreateNewOrder(String orderCode,String itemCode,String incentiveDate,String amount,
								  String name,String periodid,String desc,String batchType,
								  String EnterBatchName,String PersonaName,
								  String cfBooleanValue,String cfDDListValue,String  cfDateValue,String cfNumberValue,
								  String cfNumberUnitType, String cfStringValue, String periodName,String  ExcpectStatus,String priodname,String nPeriod) throws Exception {

		ProcessesStatus pStatus = new ProcessesStatus("");
		ProcessedOrders porders = new ProcessedOrders("");
		logger.info("Creating New Order the Order :" +orderCode);
		get_createOrderItem().click();
		Thread.sleep(5000);
		get_order_code().sendKeys(orderCode);
		Thread.sleep(1000);
		get_item_code().sendKeys(itemCode);
		SeleniumHelperClass.waitForElmentToBeReady(getIncentiveDate());
		SeleniumHelperClass.click(getIncentiveDate());
		Thread.sleep(3000);
		enableDatefield(incentiveDate);
		Thread.sleep(1000);
		get_Amount().sendKeys(amount);
		Thread.sleep(1000);
		pStatus.get_processbatch_period_icon().click();
		porders.searchIn_period_dropdown().sendKeys(priodname);
		porders.select_period().click();
		SeleniumHelperClass.isVisible(get_search_button(),60);
		get_selectBatchName().click();
		logger.info("Adding New Batch :" +name);
		SeleniumHelperClass.isVisible(get_addBatch(),SeleniumHelperClass.system_SpeedlimitMIN);
		clickonBatch();
		get_batch_name().sendKeys(name);
		get_batch_desc().sendKeys(desc);
		get_batch_period_icon_Order().click();
		pStatus.selectbatchesperiod(priodname);
		SeleniumHelperClass.isVisible(get_batchType(), 10);
		get_batchType().click();
		get_tickSearchBatch().click();
		SeleniumHelperClass.doubleClick(get_tickSearchBatch());
		//DoubleClick();
		SeleniumHelperClass.isVisible(get_batchSave(), 10);
		SeleniumHelperClass.click(get_batchSave());
		logger.info("Successfully!! Added New Batch :" + name);
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		get_searchBatch().sendKeys(name);
		SeleniumHelperClass.click(get_searchBatchButton());
		SeleniumHelperClass.click(get_BatchCheckbox());
		SeleniumHelperClass.click(selectBatchName());
		EnterDesc().sendKeys(cfBooleanValue);
		EnterDescount().sendKeys(cfDDListValue);
		ClickedOrderTypeOptional(cfNumberValue);
		EnterQuantity().sendKeys(cfNumberUnitType);
		SeleniumHelperClass.click(get_createOrder());
		get_batch_period_icon().click();
		porders.searchIn_period_dropdown().sendKeys(priodname);
		porders.select_period().click();
		SeleniumHelperClass.click(get_search_button());
		get_searchOrderCode().sendKeys(orderCode);
		SeleniumHelperClass.isVisible(get_filtersSearchButton(),SeleniumHelperClass.system_SpeedlimitMIN);
		//SeleniumHelperClass.isVisible(get_filtersSearchButton(), 10);
		get_filtersSearchButton().click();
		Assert.assertEquals(selectOrdercheckbox(), ExcpectStatus);
		SeleniumHelperClass.click(get_filtersSearchButton());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		EditOrderrec(orderCode);
		logger.info("SuccessFully!!Created New Order :" +orderCode);
		return true;
	}

public boolean EditExistingOrder(String orderCode,String amount1,String editedDesc ,String enterDescount,String ExcpectStatus ) throws Exception {
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	logger.info("Editing Existing Order :" +orderCode);
	get_Amount().clear();
	get_Amount().sendKeys(amount1);
	EnterDesc().clear();
	EnterDesc().sendKeys(editedDesc);
	EnterDescount().clear();
	EnterDescount().sendKeys(enterDescount);
	SeleniumHelperClass.click(getSaveOrder());	
	Assert.assertEquals(selectOrdercheckbox(), ExcpectStatus);
	logger.info("Successfully!!Edited the Order :" +orderCode);
	return true;
}

public boolean DeleteCreatedOredr(String orderCode,String name) throws Exception {
	logger.info("Deleting the Order :" +orderCode);
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	SeleniumHelperClass.click(getDeleteButton(orderCode));
	SeleniumHelperClass.isVisible(get_confirm_delete_button(),SeleniumHelperClass.system_SpeedlimitMIN);
	//SeleniumHelperClass.isVisible(get_confirm_delete_button(), 10);
	SeleniumHelperClass.click(get_confirm_delete_button());
    return true;
}

public boolean DeleteCreatedBatches(String name,String FromPeriod,String ndPeriod) throws Exception {
	logger.info("Deleting the Batch :"+name);
	Batches bat = new Batches(SetWebDrivers.getNavigationType());
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	bat.deleteBatch(name, FromPeriod,ndPeriod);
	logger.info("sucessfully!! Deleted the Batch :"+name);
    return true;
	
}

public WebElement getOrdersSubLink(String subLink) throws Exception{
	return SeleniumHelperClass.findWebElementbyLink(""+subLink+"", "mainFrame");
}

public WebElement getOrdersTableData(String searchData) throws Exception {
	return SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'"+searchData+"')]/ancestor::div[1][contains(@class,'list-item-row border-bottom orders-row')]/span[2]","mainFrame");
}

public WebElement getOrdersSubTab(String searchData,String subTab) throws Exception {
	WebElement element = getOrdersTableData(searchData);
	SeleniumHelperClass.waitForElmentToBeReady(element);
	SeleniumHelperClass.click(element);
	return SeleniumHelperClass.findWebElementInWebElement(element,"xpath","//ancestor::div[1]/div[3]//div[text()='"+subTab+"']","mainFrame");
}

public WebElement getCustomFieldsData(WebElement element, String cfName) throws Exception {
	return SeleniumHelperClass.findWebElementInWebElement(element, "xpath", "//following-sibling::div[2]//span[text()='"+cfName+"']/ancestor::span[1]/following-sibling::span","mainFrame");
}

public void searchOrdersbyOrderItemCode(String subLink,String period,String itemCode) throws Exception {
	if (subLink == "Processed")
	{
		SeleniumHelperClass.click(getOrdersSubLink(subLink));
		SeleniumHelperClass.isVisible(get_search_button(),60);
	}
	SeleniumHelperClass.click(get_orders_period_dropdown());
	selectOrderPeriod(period);
	SeleniumHelperClass.isVisible(get_search_button(),60);
	SeleniumHelperClass.click(get_item_code());
	get_item_code().clear();
	get_item_code().sendKeys(itemCode);
	SeleniumHelperClass.isVisible(get_search_button(),60);
	SeleniumHelperClass.click(get_search_button());
}
}
