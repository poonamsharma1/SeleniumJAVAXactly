package com.xactly.incent.orders;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jayway.jsonpath.JsonPath;
import com.xactly.common.xqueue.wso.BatchWSO;
import com.xactly.xcommons.restapi.RestAPIHelperClass;

import net.minidev.json.JSONArray;

public class BatchesAPI 
{	public static Logger logger = Logger.getLogger(BatchesAPI.class.getName());
	RestAPIHelperClass rest = new RestAPIHelperClass();
	
	
	//Used to Get Batch Details Based on BatchId
	public String getBatchDetails(Long batchId) throws Exception{
		
		logger.info("Getting Batch Details...");
		String resp = rest.getRestAPI("/queue/batches/"+batchId+"");			
		return resp;
	}
	
	//Used for Updating Batch Details
	public String updateBatchDetails(Long batchId, String batchName, Long periodId, String batchTypeId ) throws Exception{
		
		logger.info("Updating Batch Details...");
		String request = "/queue/batches/"+batchId+"";
		
		BatchWSO batchInfo = new BatchWSO();
		batchInfo.setId(batchId);
		batchInfo.setBatchName(batchName);
		batchInfo.setPeriodId(periodId);
		batchInfo.setBatchTypeId(batchTypeId);
		
		Gson gson = new GsonBuilder().create();
		logger.info("Json for updation of Batch Details : "+ gson.toJson(batchInfo));		
		String resp = rest.putRestAPI(request,gson.toJson(batchInfo));
		logger.info("Reponse for  updation of Batch Details: "+resp);
		return resp;		
	}
	
	
	//Used to Get Batch Diagnostics Based on BatchId
	public String getBatchDiagnostics(Long batchId) throws Exception{
		
		logger.info("Getting Batch Diagnostics...");
		String resp = rest.getRestAPI("/queue/batches/"+batchId+"/diagnostics");
		logger.info("Reponse for Batch Diagnostics: "+resp);
		return resp;
	}
	public int getCount(String path) {
		int count = 0;
		String totalCount = rest.getRestAPI(path);
		JSONArray Plid = JsonPath.read(totalCount, "$..count");
		count = (int) Plid.get(0);
		logger.info("Count is" + totalCount);
		return count;
	}
	
	public String deleteBatch(Long batchId) {
		logger.info("Deleting Batch...");
		String resp = rest.deleteRestAPI("/queue/batches/"+batchId);
		logger.info("Reponse for Batch Diagnostics: "+resp);
		return resp;
	}
	
}
