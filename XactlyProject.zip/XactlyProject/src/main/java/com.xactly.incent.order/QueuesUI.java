package com.xactly.incent.orders;

import java.util.List;

import org.apache.log4j.Logger;
//import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

@SuppressWarnings("static-access")
public class QueuesUI {
public static Logger logger = Logger.getLogger(QueuesUI.class.getName());
	SeleniumHelperClass helper = new SeleniumHelperClass();
	OrderStageAPI orders = new OrderStageAPI();
	
	public void setQueueState(String state) throws Exception{
		if (state.equalsIgnoreCase("Resumed"))
			helper.findWebElementbyid("startQueue","mainFrame").click();
		else if (state.equalsIgnoreCase("Paused"))
			helper.findWebElementbyid("pauseQueue","mainFrame").click();
	}
	
	public void addPGToQueue(String period, String pgName) throws Exception {
		helper.findWebElementbyid("AddProcess", "mainFrame").click();
		helper.findWebElementbyid("openAddProcessGroup", "mainFrame").click();
		selectPeriod(period);
		helper.findWebElementbyid("SelectProcessGroup", "mainFrame").click();
		WebElement pgContainer = helper.findWebElementbyid("processGrp-list", "mainFrame");
		List<WebElement> pgList = helper.findWebElementsInWebElement(pgContainer, "tag", "li","mainFrame");
		for (WebElement pg:pgList){
			if(helper.findWebElementInWebElement(pg, "css", ".processGrpName", "mainFrame").getText().equalsIgnoreCase(pgName)){
				helper.findWebElementInWebElement(pg, "css", "input[type='checkbox']", "mainFrame").click();
				helper.findWebElementbyCssSelector(".select-pgs-btn", "mainFrame").click();
				break;
			}
		}
		Thread.sleep(4000);
		helper.findWebElementbyid("confirm-button", "mainFrame").click();
		helper.findWebElementbyid("queueLink", "mainFrame").click();
	}
	
	public void AddSPPToQueue(String period) throws Exception {
		helper.findWebElementbyid("AddProcess", "mainFrame").click();
		helper.findWebElementbyid("openRunSinglePeriodProcess", "mainFrame").click();
		selectPeriod(period);
		helper.findWebElementbyid("confirm-button", "mainFrame").click();
	}

	public void selectPeriod(String period) throws Exception{
		helper.findWebElementbyCssSelector(".select2-arrow", "mainFrame").click();
		WebElement periodsResult = helper.findWebElementbyCssSelector(".select2-results", "mainFrame");
		List<WebElement> periods = helper.findWebElementsInWebElement(periodsResult, "tag", "li","mainFrame");
		for(WebElement per : periods){
			if(per.getText().contains(period)){
				per.click();
				break;
			}
		}
	}
	
	public String getQueueStatus() throws Exception{
		String status = null;
		
		String str = SeleniumHelperClass.findWebElementbyXpath("//div[@id='inner-content']/div[2]/div/span[2]", "mainFrame").getText();
		
		if (str.equalsIgnoreCase("The Queue is ready for processing."))
			return "ready";
		else if(str.equalsIgnoreCase("The Queue is currently paused."))
			return "pause";
		else if(str.equalsIgnoreCase("The Queue is currently processing."))
			return "processing";
		
		return status;
	}
	
	public WebElement getQueueTable() throws Exception {
		try{
			WebElement queue = helper.findWebElementbyid("queue-view", "mainFrame");
			return helper.findWebElementInWebElement(queue, "tag", "table", "mainFrame");
		} catch(Exception e){
			logger.info("Caught Exception at getQueueTable()");
			throw e;
		}
	}
	
	public WebElement getRow(int num) throws Exception{
		while(true){
			try{
				return helper.findWebElementbyXpath("//div[@id='inner-content']/div[2]/div[2]/table/tbody/tr["+num+"]", "mainFrame");
			}catch(StaleElementReferenceException e){
				logger.info("StaleElementReference caught at getRow(int num), Trying again");
			}catch(Exception e){
				logger.info("Caught Exception at getRow(int num)");
				throw e;
			}
		}
		
	}
	
	public WebElement getFirstRow() throws Exception {
		try{
			//WebElement table = getQueueTable();
			//return helper.findWebElementInWebElement(table, "xpath", ".//tbody", "mainFrame");
			return helper.findWebElementbyXpath("//div[@id='inner-content']/div[2]/div[2]/table/tbody","mainFrame");
		} catch(Exception e){
			logger.info("Caught Exception at getFirstRow()");
			throw e;
		}
		
	}
	
	public int getNumberOfRows() throws Exception{
		try{
			//WebElement table = getQueueTable();
			//WebElement tbody = helper.findWebElementInWebElement(table, "tag", "tbody", "mainFrame");
			WebElement tbody = helper.findWebElementbyXpath("//div[@id='inner-content']/div[2]/div[2]/table/tbody", "mainFrame");
			List<WebElement> rows = helper.findWebElementsInWebElement(tbody, "tag", "tr", "mainFrame");
			return rows.size();
		} catch(Exception e){
			logger.info("Caught Exception at getNumberOfRows()");
			throw e;
		}	
	}
	
	public void clickOverlay(WebElement ele) throws Exception{
		try{
			helper.findWebElementInWebElement(ele, "xpath", ".//td[4]/a/span[2]", "mainFrame").click();
		} catch(Exception e){
			logger.info("Caught Exception at clickOverlay()");
			throw e;
		}
	}
	
	public String getFirstItemInOverlay() throws Exception{
		try{
			String text = helper.findWebElementbyCssSelector("div.modal-body > table > tbody > tr > td", "mainFrame").getText();
			helper.findWebElementbyCssSelector(".done-button", "mainFrame").click();
			return text;
			
		} catch(Exception e){
			logger.info("Caught Expcetion at getFirstItemInOverlay()");
			throw e;
		}
	}
	
	public int getNumRowsInOverlay() throws Exception{
		try{
			
			WebElement ele = helper.findWebElementbyCssSelector("div.modal-body > table > tbody","mainFrame");
			int num =  helper.findWebElementsInWebElement(ele, "tag", "tr", "mainFrame").size();
			helper.findWebElementbyCssSelector(".done-button", "mainFrame").click();
			return num;
			
			
		} catch(Exception e){
			logger.info("Caught Expcetion at getFirstItemInOverlay()");
			throw e;
		}
	}
	
	public String getNameByCol(WebElement ele, String columnName) throws Exception{
		
		try{
		if(columnName.equalsIgnoreCase("order"))
			return helper.findWebElementInWebElement(ele, "xpath", ".//td[2]", "mainFrame").getText();
		else if(columnName.equalsIgnoreCase("name"))
			return helper.findWebElementInWebElement(ele, "xpath", ".//td[4]", "mainFrame").getText();
		else if(columnName.equalsIgnoreCase("type"))
			return helper.findWebElementInWebElement(ele, "xpath", ".//td[5]", "mainFrame").getText();
		else if(columnName.equalsIgnoreCase("period"))
			return helper.findWebElementInWebElement(ele, "xpath", ".//td[6]", "mainFrame").getText();
		
		return null;
		} catch(Exception e){
			logger.info("Caught Exception at getNameByCol()");
			throw e;
		}
	}
	
	public void selectRestartOpt(String opt) throws Exception{
		WebElement queueBtn = helper.findWebElementbyid("restartQueue", "mainFrame");
		Actions action = new Actions(SetWebDrivers.getDriver());
		action.moveToElement(queueBtn).click().build().perform();
		
		opt = opt.replace(" ", "");
		if(opt.equalsIgnoreCase("skipStep"))
			helper.findWebElementbyid("skipStep", "mainFrame").click();
		else if(opt.equalsIgnoreCase("skipThisBatch"))
			helper.findWebElementbyid("skipThisBatch", "mainFrame").click();
		else if(opt.equalsIgnoreCase("cancelGroup"))
			helper.findWebElementbyid("keepPartialResults", "mainFrame").click();
		else if(opt.equalsIgnoreCase("cancelStep"))
			helper.findWebElementbyid("deleteAllResults", "mainFrame").click();
		else 
			throw new Exception("The option you selected does not exsit. Please choose from\n1.Skip Step\n2.Skip This Batch\n3.Cancel Group\n4.Cancel Step");
		helper.findWebElementbyid("confirm-button", "mainFrame").click();
				
	}
	
	public void expandRow(WebElement row) throws Exception{
		WebElement action = helper.findWebElementInWebElement(row, "xpath", ".//span/span", "mainFrame"); 
		String currentAction = action.getAttribute("class");
		if(currentAction.equals("fa fa-chevron-right"))
			helper.findWebElementInWebElement(row, "css", "span.fa.fa-chevron-right", "mainFrame").click();
	}
	
	public void calpseRow(WebElement row) throws Exception{
		WebElement action = helper.findWebElementInWebElement(row, "xpath", ".//span/span", "mainFrame"); 
		String currentAction = action.getAttribute("class");
		if(currentAction.equals("fa fa-chevron-down"))
			helper.findWebElementInWebElement(row, "css", "span.fa.fa-chevron-down", "mainFrame").click();
		
	}
	
	public boolean checkIfBatchInPGIsFinished(String currentBatch) throws Exception {
		try{
			if(getNumberOfRows()>=3 && getNameByCol(getRow(3), "name").equals(currentBatch) && orders.getQueueStatus().toString().equalsIgnoreCase("Resumed")){
				return true;
			}
			else
				return false;
		}catch(NoSuchElementException e){
			return false;
		}catch(StaleElementReferenceException e){
			return false;
		}
	}
	
	public boolean checkIfBatchInSPPIsFinished(String currentBatch) throws Exception {
		try{
			if(getNumberOfRows() >= 4 && getNameByCol(getRow(4), "name").equals(currentBatch) && orders.getQueueStatus().toString().equalsIgnoreCase("Resumed")){
				return true;
			}
			else
				return false;
		}catch(NoSuchElementException e){
			return false;
		}catch(StaleElementReferenceException e){
			return false;
		}
	}
	
	public boolean checkIfErrorHandleInPGIsFinished(String currentBatch, int i) throws Exception {
		try{
			if(getNumberOfRows() > 2 && getNameByCol(getRow(2), "order").equals("1."+i) && getNameByCol(getRow(3), "name").equalsIgnoreCase(currentBatch)){
				return true;
			}
			else
				return false;
		}catch(NoSuchElementException e){
			return false;
		}catch(StaleElementReferenceException e){
			return false;
		}
	}
	
	public boolean checkIfStepInPGIsFinished(String currentStep) throws Exception {
		try{
			if(getNumberOfRows()>=2 && getNameByCol(getRow(2), "name").equalsIgnoreCase(currentStep)){
				return true;
			}
			else 
				return false;
		} catch(NoSuchElementException e){
			return false;
		} catch (StaleElementReferenceException e){
			return false;
		}
	}
	
	public boolean checkIfStepInSPPIsFinished(String currentStep) throws Exception {
		try{
			if(getNumberOfRows() >= 3 && getNameByCol(getRow(3), "name").equals(currentStep)){
				return true;
			}
			else 
				return false;
		} catch(NoSuchElementException e){
			return false;
		} catch(StaleElementReferenceException e){
			return false;
		}
	}
	
	public boolean checkIfPGInSPPIsFinished(String currentPG) throws Exception {
		try{
			if(getNumberOfRows() >= 2 && getNameByCol(getRow(2), "name").equals(currentPG)){
				return true;
			}
			else 
				return false;
		} catch(NoSuchElementException e){
			return false;
		} catch(StaleElementReferenceException e){
			return false;
		}
	}
}
