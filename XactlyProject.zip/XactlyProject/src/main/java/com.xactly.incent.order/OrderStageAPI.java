package com.xactly.incent.orders;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.minidev.json.JSONArray;

import org.apache.commons.io.FileUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.asserts.SoftAssert;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.Response;
import com.xactly.incent.FeatureCalculationAPI.FeatureCalculation_Releases;
import com.xactly.incent.WSO.CustomFieldWSO;
import com.xactly.incent.WSO.OrderSearchFilterWSO;
import com.xactly.incent.WSO.OrderSearchViewWSO;
import com.xactly.incent.WSO.OrderSearchWSO;
import com.xactly.incent.ppa.AdhocAtionsAPIScenarios;
import com.xactly.incent.setup.CustomFieldAPI;
import com.xactly.incent.setup.WSO.visibleLeafPeriodsWSO;
import com.xactly.xcommons.javahelper.GenericExclusionStrategy;
import com.xactly.xcommons.restapi.LoginToRestAPI;
import com.xactly.xcommons.restapi.RestAPIHelperClass;
import com.xactly.xcommons.selenium.Constants;
import org.apache.log4j.Logger;

public class OrderStageAPI
{
	public static Logger logger = Logger.getLogger(OrderStageAPI.class.getName());
	private static final String BATCH_NAME = "JAN-BATCH";
	private static final String PERIOD ="JAN-2019";
	RestAPIHelperClass rest = new RestAPIHelperClass();
	CustomFieldAPI customField = new CustomFieldAPI();
	SoftAssert sassert = new SoftAssert();

	private static Map<String, String> values;
	private static Map<String, String> values_text;

	static
	{
		values = new HashMap<String, String>();
		values.put("amountUnitTypeId", "/v1/orders/unitTypes/CURRENCY");
		values.put("orderTypeId", "/v1/typecodes/ordertypes");
	}

	static
	{
		values_text = new HashMap<String, String>();
		values_text.put("amountUnitTypeId", "/v1/orders/unitTypes/CURRENCY");
		values_text.put("orderTypeId", "/v1/typecodes/ordertypes");
	}

	public Object getOrdersPeriod(String periodName)
	{
		logger.info("Getting Order Staging Period..");
		String resp = rest.getRestAPI("/v1/periods/visibleleafperiods");
		JSONArray periodid = JsonPath.read(resp, "[?(@.name =="+periodName+")].id");
		logger.info("Response from getOrdersPeriod API : "+periodid);
		// logger.info(resp);
		JSONArray periodid1 = JsonPath.read(resp, "[?(@.name ==" + periodName + ")].id");
		logger.info("Response from getOrdersPeriod API : " + periodid);
		return periodid.get(0);
	}
	public Object getBatchTypeId(String batchType)
	{
		logger.info("Getting Batch Type Id..");
		String resp = rest.getRestAPI("/v1/batchtype?searchtext="+batchType+"&searchfield=name");
		JSONArray batchtypeID = JsonPath.read(resp, "[?(@.name =="+batchType+")].id");
		logger.info("Response from getBatchType API : "+batchType);
		return batchtypeID.get(0);
	}
	public Object getBusinessGroupId(String businessGroup)
	{
		logger.info("Getting BG  Id..");
		String resp = rest.getRestAPI("/v1/businessGroups/batch?searchtext="+businessGroup);
		JSONArray bgID = JsonPath.read(resp, "[?(@.name =="+businessGroup+")].id");
		logger.info("Response from getBatchType API : "+businessGroup);
		return bgID.get(0);
	}


	public String getFirstOpenPeriod()
	{
		logger.info("Getting First Open Period..");
		String resp = rest.getRestAPI("/v1/periods/firstOpenPeriod");
		logger.info(resp);
		logger.info("Response from Get first open period API : ");
		return resp;
	}

	public String getLastClosedPeriod()
	{
		logger.info("Getting Last Closed Period..");
		String resp = rest.getRestAPI("/v1/periods/lastFinalizedPeriod");
		logger.info(resp);
		logger.info("Response from Get first closed period API : ");
		return resp;
		
	}


	public Object getBatchStatus(String batchName, Long startPeriod, Long endPeriod)
	{
		logger.info("Getting Order Staging Period..");
		String resp = rest.getRestAPI("/queue/batches?startPeriod=" + startPeriod + "&endPeriod="
				+ endPeriod);
		logger.info(resp);
		JSONArray batchStatus = JsonPath.read(resp, "[?(@.batchName ==" + batchName
				+ ")].processStatus");
		logger.info("Response from getOrdersPeriod API : " + batchStatus);
		return batchStatus.get(0);
	}

	public Object getOrdersPeriodObjectInfo(String periodName, String objectName)
	{
		logger.info("Getting Order Staging Period Object Info..");
		String resp = rest.getRestAPI("/v1/periods/visibleleafperiods");
		// logger.info(resp);
		JSONArray objectInfo = JsonPath.read(resp, "[?(@.name ==" + periodName + ")]." + objectName
				+ "");
		logger.info("Response from getOrdersPeriod API : " + objectInfo);
		return objectInfo.get(0);
	}

	public Object getQueueStatus()
	{
		logger.info("Getting Queue Status..");
		String resp = rest.getRestAPI("/queue");
		// logger.info(resp);
		String queuestate = JsonPath.read(resp, "$.queueStateEnum");
		logger.info("Response from Queue Status API : " + queuestate);
		return queuestate;
	}

	public Object getQueueStateMessageCode()
	{
		logger.info("Getting Queue State Message Code..");
		String resp = rest.getRestAPI("/queue");
		// logger.info(resp);
		String queueStateMsgCode = JsonPath.read(resp, "$.stateMessageCode").toString();
		logger.info("Response from Queue Status API : " + queueStateMsgCode);
		return queueStateMsgCode;
	}

	// Used to get Queue State Message
	public Object getQueueStateMessage()
	{
		logger.info("Getting State Message..");
		String resp = rest.getRestAPI("/queue");
		// logger.info(resp);
		String queueStateMessage = JsonPath.read(resp, "$.stateMessage");
		logger.info("Response from State Message API : " + queueStateMessage);
		return queueStateMessage;
	}
	
	// Used to get Queue State Message along with status line
	public Object getQueueStateMessageWithBody()
	{
		logger.info("Getting State Message..");
		String resp = rest.getRestAPIRawResponse("/queue");
		// logger.info(resp);
		String queueStateMessage = JsonPath.read(resp, "$.stateMessage");
		logger.info("Response from State Message API : " + queueStateMessage);
		return queueStateMessage;
	}
	

	public String getQueueEventCount()
	{
		RestAPIHelperClass rest = new RestAPIHelperClass();
		logger.info("Getting Queue Event Status Count..");
		String res = rest.getRestAPI("/queue/events/count");
		Integer eventcount = JsonPath.read(res, "$.count");
		logger.info("Response from eventcount API : " + eventcount);
		String value = eventcount.toString();
		//logger.info("QueCount is :"+value+" for business : "+LoginToRestAPI.getUsername());

		return value;
	}

	// Used to set queue status : Paused or Resumed
	public String setQueueStatus(String queueStatus) throws SQLException, ClassNotFoundException,
			JSONException, IOException, ParseException
	{

		logger.info("Set Queue Status ...");
		String request = "/queue/?stateChange=" + queueStatus + "";
		String resp = rest.postRestAPI(request, "");
		logger.info("Reponse for Set Queue Status: " + resp);
		return resp;
	}

	// Used to set queue preference : QUEUE_PROCESS_THROUGH_ERROR
	public String setQueuePreference(int queuePreference) throws SQLException,
			ClassNotFoundException, JSONException, IOException, ParseException
	{

		logger.info("Set Queue Preference ...");
		String request = "/queue/preference";
		String data = "{\"name\":\"QUEUE_PROCESS_THROUGH_ERROR\",\"value\":\"" + queuePreference
				+ "\"}";

		logger.info("Set Queue Preference: " + data);
		String resp = rest.putRestAPI(request, data);
		logger.info("Reponse for Set Queue Preference: " + resp);
		return resp;
	}

	public String getProcessedOrdersCount(Long periodId)
	{
		logger.info("Getting Processed orders Count..");
		String res = rest.getRestAPI("/v1/orders/processed/count?searchtext=" + periodId
				+ "&searchfield=periodId");
		Integer count = JsonPath.read(res, "$.count");
		logger.info("Response Processed orders count API : " + count);
		String value = count.toString();
		return value;
	}

	public String getOrderStagingOrdersCount(Long periodId)
	{
		logger.info("Getting Order Staging orders Count..");
		String res = rest.getRestAPI("/v1/orders/count?searchtext=" + periodId
				+ "&searchfield=periodId");
		Integer count = JsonPath.read(res, "$.count");
		logger.info("Response from Order Staging orders Count API : " + count);
		String value = count.toString();
		return value;
	}

	// Submit period level events to queue
	public String submitPeriodLevelEventToQueue(Long periodId, String eventType)
			throws SQLException, ClassNotFoundException, JSONException, IOException, ParseException
	{

		logger.info("Submitting Event to Queue ...");
		String request = "/queue/events/periodevents";
		String data = "{\"eventList\":[{\"periodId\":" + periodId + ",\"queueEventType\":\""
				+ eventType + "\"}]}";

		logger.info("Json for Submitting Event to Queue: " + data);
		String resp = rest.postRestAPI(request, data);
		logger.info("Reponse for Submitting Event to Queue: " + resp);
		return resp;
	}

	// Submit batch level events to queue
	public String submitBatchLevelEventToQueue(Long batchId, String eventType) throws SQLException,
			ClassNotFoundException, JSONException, IOException, ParseException
	{

		logger.info("Submitting Event to Queue ...");
		String request = "/queue/events/batchevents";
		String data = "{\"eventList\":[{\"batchId\":" + batchId + ",\"queueEventType\":\""
				+ eventType + "\"}]}";

		logger.info("Json for Submitting Event to Queue: " + data);
		String resp = rest.postRestAPI(request, data);
		logger.info("Reponse for Submitting Event to Queue: " + resp);
		return resp;
	}

	// Submit UnreleaseCommissionByReleaseGroup events to queue
	public String submitUnreleaseCommissionByReleaseGroupToQueue(Long releaseGroupId, String eventType, String releaseGroupName) throws SQLException,
			ClassNotFoundException, JSONException, IOException, ParseException
	{

		logger.info("Submitting Event to Queue ...");
		String request = "/queue/events/unreleaseevents/byreleasegroup";
		String data = "{\"releaseGroupId\":\""+releaseGroupId+ "\",\"name\":\""+releaseGroupName+ "\",\"queueEventType\":\""+eventType+ "\"}";

		logger.info("Json for Submitting Event to Queue: " + data);
		String resp = rest.postRestAPI(request, data);
		logger.info("Reponse for Submitting Event to Queue: " + resp);
		return resp;
	}

	//Used for getting release GroupId based on Release Group Name
	public Object getReleaseGroupId(String releaseGroupName)
	{
		logger.info("Getting release GroupId...");
		String resp = rest.getRestAPI("/results/release/releasegroup?searchfield=name&searchtext="+releaseGroupName+"&sortfield=name&order=asc&limit=50&offset=0");
		// logger.info(resp);
		JSONArray releaseGroupId = JsonPath.read(resp, "[?(@.name ==" + releaseGroupName + ")].id");
		logger.info("Response from getCustomFields API : " + releaseGroupId);
		return releaseGroupId.get(0);
	}


	public Object getBatchID(String batchName, String periodID)
	{
		logger.info("Getting Batch ID..");
		String resp = rest.getRestAPI("/v1/userbatch?searchtext=" + batchName
				+ "&searchfield=batchName&searchtext=" + periodID + "&searchfield=periodId");
		JSONArray batchid = JsonPath.read(resp, "[?(@.batchName ==" + batchName + ")].id");
		String value = batchid.toString();
		logger.info(value);
		return batchid.get(0);
	}

	public String getAllBatches(String batchName, String periodID)
	{
		logger.info("Getting Batch ID..");
		String resp = rest.getRestAPI("/v1/userbatch?searchtext=" + batchName
				+ "&searchfield=batchName&searchtext=" + periodID + "&searchfield=periodId");
		return resp;
	}


	public Object getStandardFieldId(String fieldName)
	{
		logger.info("Getting Order Staging Standard Fields..");
		String resp = rest.getRestAPI("/v1/orders/fields");
		// logger.info(resp);
		JSONArray standardFieldId = JsonPath
				.read(resp, "[?(@.displayName ==" + fieldName + ")].id");
		logger.info("Response from getStandardFields API : " + standardFieldId);
		return standardFieldId.get(0);
	}

	public Object getCustomFieldId(String fieldName)
	{
		logger.info("Getting Order Staging Custom Fields..");
		String resp = rest.getRestAPI("/v1/orders/customfields");
		// logger.info(resp);
		JSONArray customFieldId = JsonPath.read(resp, "[?(@.displayName ==" + fieldName + ")].id");
		logger.info("Response from getCustomFields API : " + customFieldId);
		return customFieldId.get(0);
	}

	// To get the search text Id Eg: for OrderType, Amount Unit Type
	public Object getSearchTextId(String SearchText, String url)
	{
		logger.info("Getting Search text Id..");
		String resp = rest.getRestAPI(url);
		// logger.info(resp);
		JSONArray searchTextId = JsonPath.read(resp, "[?(@.name ==" + SearchText + ")].id");
		logger.info("Response from getSearchTextId API : " + SearchText);
		return searchTextId.get(0);
	}


	// To get the search text Eg: for OrderType, Amount Unit Type
	public Object getSearchText(String SearchTextId, String url)
	{
		logger.info("Getting Search text...");
		String resp = rest.getRestAPI(url);
		// logger.info(resp);
		JSONArray searchText = JsonPath.read(resp, "[?(@.id ==" + SearchTextId + ")].name");
		logger.info("Response from getSearchText API : " + SearchTextId);
		return searchText.get(0);
	}
	
	//Used for getting the count of orders
	public String getOrdersCount(String periodName, List<String> searchtext, List<String> searchfield)
			throws SQLException, ClassNotFoundException, JSONException, IOException, ParseException
	{

		logger.info("Get Orders Count ...");

		String request = "/v1/orders/count?" + "periodId=" + getOrdersPeriod(periodName)
				+ "&sortFields=orderCode";

		for (String s : searchtext)
		{
			request = request + "&searchtext=" + s;
		}

		for (String s : searchfield)
		{
			request = request + "&searchfield=" + s;
		}

		String resp = rest.getRestAPI(request);
		logger.info(resp);
		return resp;
	}

	public String getOrders(String periodName, List<String> searchtext, List<String> searchfield)
			throws SQLException, ClassNotFoundException, JSONException, IOException, ParseException
	{

		logger.info("Get Orders ...");

		String request = "orders?" + "periodId=" + getOrdersPeriod(periodName)
				+ "&sortFields=orderCode";

		for (String s : searchtext)
		{
			request = request + "&searchtext=" + s;
		}

		for (String s : searchfield)
		{
			request = request + "&searchfield=" + s;
		}

		String resp = rest.getRestAPI(request);
		logger.info(resp);
		return resp;
	}


	public String getOrders(String periodName, String searchtext, String searchfield,
							String customSearchText, String customSearchField) throws SQLException,
			ClassNotFoundException, JSONException, IOException, ParseException
	{

		logger.info("Get Orders1 ...");
		String request = "/v1/orders?" + "searchfield=periodId&searchtext="
				+ getOrdersPeriod(periodName) + "&sortFields=orderCode";

		if ((searchtext != null && !searchtext.equals(""))
				|| (searchfield != null && !searchfield.equals("")))
		{
			// logger.info("Going to Standard field Search");
			String[] searchFieldArray = searchfield.split(",");
			String[] searchTextArray = searchtext.split(",");

			if (searchFieldArray.length == searchTextArray.length)
			{
				for (int s = 0; s < searchFieldArray.length; s++)
				{
					String searchFieldId = getStandardFieldId(searchFieldArray[s]).toString();
					if (values.containsKey(searchFieldId))
					{
						String searchTextId = getSearchTextId(searchTextArray[s],
								values.get(searchFieldId)).toString();
						request = request + "&searchfield=" + searchFieldId + "&searchtext="
								+ searchTextId;
					}
					else
					{
						request = request + "&searchfield=" + searchFieldId + "&searchtext="
								+ searchTextArray[s];
					}
				}
			}
		}
		if ((customSearchText != null && !customSearchText.equals(""))
				&& (customSearchField != null && !customSearchField.equals("")))
		{
			// logger.info("Going to Custom field Search");
			String[] customSearchFieldArray = customSearchField.split(",");
			String[] customSearchTextArray = customSearchText.split(",");

			if (customSearchFieldArray.length == customSearchTextArray.length)
			{
				for (int s = 0; s < customSearchFieldArray.length; s++)
				{
					String customSearchFieldId = getCustomFieldId(customSearchFieldArray[s])
							.toString();
					request = request + "&searchfield=" + customSearchFieldId + "&searchtext="
							+ customSearchTextArray[s];
				}
			}
		}
		logger.info(request);
		String resp = rest.getRestAPI(request);
		logger.info(resp);
		return resp;
	}


	public String getStandardFields()
	{
		logger.info("Getting Order Staging Standard Fields..");
		String resp = rest.getRestAPI("/v1/orders/fields");
		// logger.info(resp);
		return resp;
	}

	public String getcustomFields()
	{
		logger.info("Getting Order Staging Custom Fields..");
		String resp = rest.getRestAPI("/v1/orders/customfields");
		// logger.info(resp);
		return resp;
	}


	public String getAllSavedSearches()
	{
		logger.info("Getting all saved searches..");
		String resp = rest.getRestAPI("/v1/orders/searches");
		// logger.info(resp);
		return resp;
	}


	public String getSavedSearchDetailByID(String savedSearchTitle)
	{
		logger.info("Getting saved search detail by ID..");
		String request = "/v1/orders/search/details/";

		String allSavedSearches = getAllSavedSearches();
		logger.info("All Saved Searches: " + allSavedSearches);

		Object savedSearchId = null;
		JSONArray jSavedSearchId = JsonPath.read(allSavedSearches, "[?(@.title =="
				+ savedSearchTitle + ")].id");
		savedSearchId = jSavedSearchId.get(0);

		request = request + savedSearchId;
		String resp = rest.getRestAPI(request);
		logger.info(resp);
		return resp;
	}


	public String createSavedSearch(String searchTitle, String isFavourite, String isActive,
									String searchCriteria, String customSearchCriteria) throws SQLException,
			ClassNotFoundException, JSONException, IOException, ParseException
	{

		logger.info("Create Saved Search...");
		String request = "/v1/orders";

		String id = null;
		List<OrderSearchViewWSO> searchViews = new ArrayList<OrderSearchViewWSO>();
		searchViews = null;
		List<OrderSearchFilterWSO> filterWso = new ArrayList<OrderSearchFilterWSO>();
		filterWso = createSearchFilter(searchCriteria, customSearchCriteria);

		OrderSearchWSO wso = new OrderSearchWSO();
		wso.setId(id);
		wso.setTitle(searchTitle);
		wso.setFavorite(isFavourite);
		wso.setActive(isActive);
		wso.setSearchFilters(filterWso);
		wso.setSearchViews(searchViews);

		Gson gson = new GsonBuilder().create();
		logger.info("Json for creation of Saved Search:" + gson.toJson(wso));

		String resp = rest.postRestAPI(request, gson.toJson(wso));
		logger.info("Reponse for Create Saved Search:" + resp);
		return resp;
	}

	public List<OrderSearchFilterWSO> createSearchFilter(String searchCriteria,
														 String customSearchCriteria) throws SQLException, ClassNotFoundException,
			JSONException, IOException, ParseException
	{

		logger.info("Create Search Filter...");
		String standardSearchFieldsData = getStandardFields();
		String customSearchFieldsData = getcustomFields();
		logger.info("Standard field Data:" + standardSearchFieldsData);
		logger.info("Custom field Data:" + customSearchFieldsData);

		List<OrderSearchFilterWSO> searchFilters = new ArrayList<OrderSearchFilterWSO>();

		// for standard fields
		if (searchCriteria != null && !searchCriteria.equals(""))
		{
			String[] searchCriteria_all = searchCriteria.split(";");

			for (int search = 0; search < searchCriteria_all.length; search++)
			{
				OrderSearchFilterWSO searchFilter = new OrderSearchFilterWSO();
				String[] searchInfo = searchCriteria_all[search].split(",");
				String id = null;
				String orderSearchId = null;
				String displayName = searchInfo[0];
				String columnId_string = null;
				String type_string = null;
				JSONArray rDisplayName = JsonPath.read(standardSearchFieldsData,
						"[?(@.displayName ==" + displayName + ")].displayName");
				if (rDisplayName.get(0).toString().equals(displayName))
				{
					JSONArray columnId = JsonPath.read(standardSearchFieldsData,
							"[?(@.displayName ==" + displayName + ")].id");
					columnId_string = columnId.get(0).toString();
					JSONArray type = JsonPath.read(standardSearchFieldsData, "[?(@.displayName =="
							+ displayName + ")].type");
					type_string = type.get(0).toString();
				}
				String fromValue = searchInfo[1];
				String toValue = null;
				if (searchInfo.length > 2)
				{
					toValue = searchInfo[2];
				}
				String active = "true";

				searchFilter.setId(id);
				searchFilter.setOrderSearchId(orderSearchId);
				searchFilter.setColumnId(columnId_string);
				searchFilter.setFromValue(fromValue);
				searchFilter.setToValue(toValue);
				searchFilter.setType(type_string);
				searchFilter.setDisplayName(displayName);
				searchFilter.setActive(active);

				searchFilters.add(searchFilter);
				// Gson gson = new GsonBuilder().create();
				// logger.info("Json:"+ gson.toJson(searchFilters));
			}
		}

		// for custom fields
		if (customSearchCriteria != null && !customSearchCriteria.equals(""))
		{
			String[] customSearchCriteria_all = customSearchCriteria.split(";");

			for (int search = 0; search < customSearchCriteria_all.length; search++)
			{
				OrderSearchFilterWSO searchFilter = new OrderSearchFilterWSO();
				String[] customSearchInfo = customSearchCriteria_all[search].split(",");
				String id = null;
				String orderSearchId = null;
				String displayName = customSearchInfo[0];
				String columnId_string = null;
				String type_string = "OrderItem";
				JSONArray rDisplayName = JsonPath.read(customSearchFieldsData,
						"[?(@.displayName ==" + displayName + ")].displayName");
				if (rDisplayName.get(0).toString().equals(displayName))
				{
					JSONArray columnId = JsonPath.read(customSearchFieldsData,
							"[?(@.displayName ==" + displayName + ")].id");
					columnId_string = columnId.get(0).toString();
				}
				String fromValue = customSearchInfo[1];
				String toValue = null;
				if (customSearchInfo.length > 2)
				{
					toValue = customSearchInfo[2];
				}
				String active = "true";

				searchFilter.setId(id);
				searchFilter.setOrderSearchId(orderSearchId);
				searchFilter.setColumnId(columnId_string);
				searchFilter.setFromValue(fromValue);
				searchFilter.setToValue(toValue);
				searchFilter.setType(type_string);
				searchFilter.setDisplayName(displayName);
				searchFilter.setActive(active);

				searchFilters.add(searchFilter);
			}
		}

		return searchFilters;
	}


	public String deleteSavedSearch(String savedSearchTitle) throws SQLException,
			ClassNotFoundException, JSONException, IOException, ParseException
	{

		logger.info("Delete Saved Search...");
		String request = "/v1/orders/search/";

		String allSavedSearches = getAllSavedSearches();
		logger.info("All Saved Searches: " + allSavedSearches);

		Object idToDelete = null;
		JSONArray jidToDelete = JsonPath.read(allSavedSearches, "[?(@.title ==" + savedSearchTitle
				+ ")].id");
		idToDelete = jidToDelete.get(0);

		request = request + idToDelete;
		String resp = rest.deleteRestAPI(request);
		logger.info(resp);
		return resp;
	}

	public String uploadOrders(File filePath) throws SQLException, ClassNotFoundException,
			JSONException, IOException, ParseException, InterruptedException
	{

		logger.info("Upload Orders...");
		String request = "/v1/orders/upload/?autocreate=false";

		String resp = rest.postRestAPIforUpload(request, filePath);
		return resp;

	}

	// Initiate Download for Staging orders download
	public String intiateDownloadOrders(String periodId, String downloadFileName)
			throws SQLException, ClassNotFoundException, JSONException, IOException, ParseException
	{

		logger.info("Download Orders...");
		String request = "/v1/orders/download/csv?searchtext=" + periodId
				+ "&searchfield=periodId&filename=" + downloadFileName + "&type=staging";

		String resp = rest.getRestAPI(request);
		return resp;

	}

	public Response getDownloadOrderStageTemplate() throws ClassNotFoundException, IOException
	{

		String apiRequest = "/v1/orders/download/template";

		logger.info("Start Download Order Stage Template...");

		//byte[] resp = rest.getDownloadXlsxRestAPI(apiRequest);
		Response resp = rest.getRestAPIResponse(apiRequest,LoginToRestAPI.getLoginresponse());
		logger.info("Completed Download Order Stage Template...");
		return resp;
	}

	//To create custom field and validate
	public Long createCustomFieldAndValidate(String objType,String displayName,String description,String dataType,Boolean isRequired, Integer fieldSubType,String valueList) throws ClassNotFoundException, JSONException, SQLException, IOException, ParseException
	{
		String response1 = customField.createCustomField(objType,displayName,description,dataType,isRequired,fieldSubType,valueList);
		GenericExclusionStrategy ges = new GenericExclusionStrategy(CustomFieldWSO.class, "createdDate","modifiedDate");
		Gson gson1 = new GsonBuilder().setExclusionStrategies(ges).create();
		CustomFieldWSO createResponse = gson1.fromJson(response1,CustomFieldWSO.class);

		sassert.assertNotNull(createResponse.getFlexId(), "Create Custom Field Failed");
		sassert.assertEquals(createResponse.getDisplayName(), displayName,"Custom Fields are not matching");
		return createResponse.getFlexId();
	}

	public void deleteCustomFieldAndValidate(String objType,Long customFieldID, String name) throws ClassNotFoundException, JSONException, SQLException, IOException, ParseException
	{
		String deleteOrderItemResponse = customField.customFieldDelete(objType,customFieldID);
		sassert.assertEquals(deleteOrderItemResponse, "","Delete Failed..");
		String ar_search_field=JsonPath.read( customField.searchCustomField(name), ".totalCount").toString().replace("[", "").replace("]","");
		sassert.assertEquals(ar_search_field,"0","Search Failed");
	}


	public void deleteOrderModule() throws Exception {

		AdhocAtionsAPIScenarios adhoc = new AdhocAtionsAPIScenarios();
		FeatureCalculation_Releases feature=new FeatureCalculation_Releases();
		Object periodID = getOrdersPeriod(PERIOD);
		Object batchID = getBatchID(BATCH_NAME, periodID.toString());
		Object delbyperiodPOrep = adhoc.DeleteOrdersByBatch(batchID.toString());
		adhoc.deleteProcessedordersbyPeriod(periodID.toString());
		feature.pollQueue();
		adhoc.deleteStagedordersbyPeriod(periodID.toString());
		feature.pollQueue();
	}


	
	public String getStagingOrderDetails(Long periodId)
	{
		logger.info("Getting Order Staging orders Count..");
		String res = rest.getRestAPI("/v1/orders?searchtext=" + periodId
				+ "&searchfield=periodId");
		logger.info("Response from Order Staging orders Search API : " + res);
		return res;
	}
	
	public String createOrderAPI(String rbody)
	{
		String requestURL="/v1/orders";
		String resp = rest.postRestAPI(requestURL,rbody);
		return resp;
	}
	
	public String getBatchPeriods() {
		logger.info("Getting Batch Periods..");
		String res = rest.getRestAPI("/queue/batches/periods");
		logger.info("Response from Order Staging orders Search API : " + res);
		return res;
	}
	
	public String getBatches(String startPeriod, String endPeriod) {
		logger.info("Getting batches with period range..");
		String res = rest.getRestAPI("/queue/batches?limit=50&offset=0&sortfield=batchName&order=asc&startPeriod="+startPeriod+"&endPeriod="+endPeriod);
		logger.info("Response for getting batches with period range..: " + res);
		return res;
	}
	
	public String getBatchesInSortedManner(String startPeriod, String endPeriod, String sortField, String pageOffset) {
		logger.info("Getting batches with period range..");
		String res = rest.getRestAPI("/queue/batches?limit=50&offset="+pageOffset+"&sortfield="+sortField+"&order=desc&startPeriod="+startPeriod+"&endPeriod="+endPeriod);
		logger.info("Response for getting batches with period range..: " + res);
		return res;
	}
	

	public String deleteOrdersUsingCF(String cF_ID) {
		
		logger.info("---- In Progress : delete Orders Using CF=" + cF_ID+ " ----");
		
		OrderStageAPI order = new OrderStageAPI();
		FeatureCalculation_Releases feature=new FeatureCalculation_Releases();
		
		// Sh_Step 1: Get the list of Open Periods of Batches having some orders
		logger.info("Getting Periods..");
		String resp = rest.getRestAPI("/v1/periods/visibleleafperiods");
		
		// Created array of Periods Bean Class-
		// ToDo: Can change the below 'gson' and WSO code
		Gson gson = new GsonBuilder().create();
		visibleLeafPeriodsWSO[] visibleLeafPeriods = gson.fromJson(resp, visibleLeafPeriodsWSO[].class);
		
		// 1.a Get First and Last period details-
		Long firstOpenPeriodID = visibleLeafPeriods[0].getId();
		Long lastOpenPeriodID = visibleLeafPeriods[ visibleLeafPeriods.length-1 ].getId();
		
		Map<String,String> mapOfBatchesHavingOrders = null;
		String sortParameter = "itemCount";
		String pageOffset = "0";
		
		mapOfBatchesHavingOrders = getBatchesHavingOrders(firstOpenPeriodID, lastOpenPeriodID, 
				mapOfBatchesHavingOrders, sortParameter, pageOffset);
		
		
		// > Now, for each batchID, submit the Order Delete Event 
		
		Set<String> batchIDs = mapOfBatchesHavingOrders.keySet();
		String status = null;
		
		// Below try-catch CODE is from - OrderAPITest :: deleteOrders() :- 
		try {
			for( String bId : batchIDs)
				order.submitBatchLevelEventToQueue(Long.valueOf(bId), "DeleteStagingOrdersByBatch");
//				order.submitBatchLevelEventToQueue(Long.valueOf(bId), "DeleteProcessedOrdersByBatch");

				
			feature.pollQueue();
			status = "";
		
		} catch (Exception e) {
			status = "something went wrong while deleting orders and polling queue";
			e.printStackTrace();
		}	
		return status;
	}


	/**
	 * 
	 * @param firstOpenPeriodID
	 * @param lastOpenPeriodID
	 * @param mapOfBatchesHavingOrders
	 * @param sortParameter
	 * @param pageOffSet
	 * @return list of period ids
	 * 
	 * This method takes 2 periods : FirstPeriodId and LastPeriodId	<br>
	 * Then, collects the periods of Batches having some orders ('itemCount' > 0)	<br>
	 * Then, Returns the map of Batch ID and Batch Name.
	 */
	
	public Map<String,String> getBatchesHavingOrders( Long firstOpenPeriodID, Long lastOpenPeriodID, 
					Map<String,String> mapOfBatchesHavingOrders, String sortParameter, String pageOffSet) {
		
		OrderStageAPI orders = new OrderStageAPI();
		
		// Getting Batched in Sorted fashion of given field 'sortParameter'-
		String jsonBatches = orders.getBatchesInSortedManner( firstOpenPeriodID+"", lastOpenPeriodID+"", sortParameter, pageOffSet);
		org.json.JSONArray jsonArrBatches = new org.json.JSONArray( jsonBatches );

		
		// Initialize Batches Map object, if having null - 
		if (mapOfBatchesHavingOrders == null) 
			mapOfBatchesHavingOrders = new HashMap<String,String>();
		
		
		for( int i = 0; i < jsonArrBatches.length(); i++ ) {
			
			org.json.JSONObject jsonObj = (org.json.JSONObject)jsonArrBatches.get(i);				// {"batchName":"JAN-2015-BATCH","periodId":79749325,"processStatus":"Not Processed","businessId":null,"description":null,"periodName":"JAN-2015","batchTypeName":"Commissionable Events","userName":null,"userId":null,"itemCount":1,"noOfProcessQueued":0,"allBusinessGroups":false,"id":233572,"batchTypeId":null,"businessGroups":null,"validationStatus":"New","batchStatus":null}
			Long itemCountInBatch = Long.valueOf( jsonObj.get("itemCount").toString() );
			
			// If Batch is having order, then save "Batch ID" and "Batch Name"-
			if ( ( itemCountInBatch ) > 0) 
				mapOfBatchesHavingOrders.put( jsonObj.get("id").toString(), jsonObj.get("batchName").toString() );
		}
		
		// If lastBatch's OrderCount > 0, then repeat the same steps to collect periods of other Batches on Page 2, 3, ... N),
		// Until lastBatchsItemCount = 0
		Long lastBatchsItemCount = Long.valueOf(((org.json.JSONObject) jsonArrBatches.get( jsonArrBatches.length()-1 ))
										.get("itemCount").toString());
		
		
		if ( lastBatchsItemCount > 0 ) {
			int currPage = Integer.valueOf(pageOffSet);
			pageOffSet = "" + (currPage + 50);		// Get next 50 Batches of next pg. Example: For Next Pg 4 => Set Offset == 150
			
			logger.info("---- Batch detail's Get request for page ="+ currPage/50 + " ----");
			
			// Getting Batches in next Page (offSet) :
			getBatchesHavingOrders( firstOpenPeriodID, lastOpenPeriodID, mapOfBatchesHavingOrders, sortParameter, pageOffSet );
		}
		
		// Return the details of Batches having some Orders..
		return mapOfBatchesHavingOrders;
	}
}

