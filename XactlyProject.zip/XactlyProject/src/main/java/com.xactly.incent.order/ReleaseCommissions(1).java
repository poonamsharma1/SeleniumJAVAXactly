package com.xactly.incent.orders;

import java.io.File;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.xactly.xcommons.selenium.GetProperties;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

public class ReleaseCommissions {
public static Logger logger = Logger.getLogger(ReleaseCommissions.class.getName());
	public ReleaseCommissions(String testtype) throws Exception

	{
		if(testtype.equalsIgnoreCase("gui"))
		{
			new Orders("gui");
			SeleniumHelperClass.findWebElementbyid("A_Process Status", "topFrame").click();

			GetProperties.setReleasegrouptable(SetWebDrivers.tableDet.getProperty("incent.orders.releasegroup"));
			Thread.sleep(5000);
		}
	}
	public WebElement get_Morelink() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='showHideSecondaryLinks']/span[1]", "mainframe"));
	}

	public WebElement get_release_commissionlink() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='queueRelease']/span/span","mainFrame"));
	}

	public WebElement add_release_grouplink() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='queueReleaseGroupLink']/i","mainFrame"));
	}

	public WebElement create_release_groupbutton() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='createReleaseGroup']/span/span","mainFrame"));
	}

	public WebElement put_release_groupname() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='queueReleaseName']","mainFrame"));
	}

	public WebElement search_release_value() throws Exception {
		return(SeleniumHelperClass.findWebElementbyid("relGrp-search-text","mainFrame"));
	}

	public WebElement search_release_find_lens() throws Exception {
		return(SeleniumHelperClass.findWebElementbyid("relGrp-search-button","mainFrame"));
	}

	
	public WebElement select_release_value() throws Exception {
		return(SeleniumHelperClass.findWebElementbyXpath(".//ul[@id='releaseGrp-list']/li/div/span/input","mainFrame"));
	}

	public WebElement save_release_value() throws Exception {
		return(SeleniumHelperClass.findWebElementbyXpath(".//div[@id='modal-container']/div[3]/span[2]/div","mainFrame"));
	}

	public WebElement enter_release_date() throws Exception {
	   return(SeleniumHelperClass.findWebElementbyXpath(".//input[@id='selectedDate-txt']","mainFrame"));
	}

	public WebElement uploadFileForReleaseCommission() throws Exception{

	WebElement uploadField=SeleniumHelperClass.findWebElementbyXpath("//input[@type='file']");	
	return uploadField;
		
				
	}

	public WebElement click_create_button() throws Exception {
			return(SeleniumHelperClass.findWebElementbyXpath(".//div[@id='modal-container']/div[3]/span[2]/div","mainFrame"));
		}
		
	public WebElement put_release_groupdesc() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='queueReleaseDescription']","mainFrame"));
	}

	public WebElement get_release_group_save() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='modal-container']/div[3]/span[2]","mainFrame"));
	}

	public WebElement get_release_group_searchtext() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='relGrp-search-text']","mainFrame"));
	}

	public WebElement get_release_group_searchbutton() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='relGrp-search-button']","mainFrame"));
	}

	public WebElement get_release_group_searchedCheckbox() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='releaseGrp-list']/li[1]/div/span[1]/input","mainFrame"));
	}

	public WebElement get_release_group_select() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='modal-container']/div[3]/span[2]","mainFrame"));
	}

	public WebElement get_release_upload_button() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='release-upload-file-new']","mainFrame"));
	}

	public WebElement get_release_calendar_button() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='selectedDate']/button","mainFrame"));
	}

	public WebElement get_release_commissions_button() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='modal-container']/div[3]/span[2]","mainFrame"));
	}

	public WebElement getqueueTableRow(String columnName, int rowNum) throws Exception
	{	
		WebElement obj =SeleniumHelperClass.getTableCell_NewUI_getrow(columnName,  rowNum, "list ui-sortable", "mainFrame") ;
		Thread.sleep(1000);
		return obj;
	}

	public void createreleasegroup(String rgName, String rgDesc) throws Exception
	{

		get_Morelink().click();
		get_release_commissionlink().click();
		add_release_grouplink().click();
		create_release_groupbutton().click();
		Thread.sleep(2000);
		put_release_groupname().sendKeys(rgName);
		Thread.sleep(2000);
		put_release_groupdesc().sendKeys(rgDesc);
		get_release_group_save().click();
		Thread.sleep(1000);
		
		search_release_value().sendKeys(rgName);
		Thread.sleep(2000);
		search_release_find_lens().click();
		Thread.sleep(2000);
		select_release_value().click();
		Thread.sleep(2000);
		save_release_value().click();
		Thread.sleep(2000);
		

		WebElement textbox = enter_release_date();
		 ((JavascriptExecutor) SetWebDrivers.getDriver()).executeScript("arguments[0].removeAttribute('disabled')",  textbox);
	
		textbox.sendKeys("10/02/2015");
		Thread.sleep(2000);
		
		ClassLoader classLoader=getClass().getClassLoader();
		File file=new File(classLoader.getResource("PartialCommission(3).csv").getFile());
		WebElement upfile=uploadFileForReleaseCommission();
		String res=file.getAbsolutePath();
				
		logger.info("upload file is "+res);
		
		upfile.sendKeys(res);
		Thread.sleep(3000);
		
		
		click_create_button().click();
			
			}

	public void createreleasegroupbz(String rgName, String rgDesc) throws Exception
	{

		get_Morelink().click();
		get_release_commissionlink().click();
		add_release_grouplink().click();
		create_release_groupbutton().click();
		Thread.sleep(2000);
		put_release_groupname().sendKeys(rgName);
		Thread.sleep(2000);
		put_release_groupdesc().sendKeys(rgDesc);
		get_release_group_save().click();
		Thread.sleep(1000);
		
		search_release_value().sendKeys(rgName);
		Thread.sleep(2000);
		search_release_find_lens().click();
		Thread.sleep(2000);
		select_release_value().click();
		Thread.sleep(2000);
		save_release_value().click();
		Thread.sleep(2000);
		

		WebElement textbox = enter_release_date();
		 ((JavascriptExecutor) SetWebDrivers.getDriver()).executeScript("arguments[0].removeAttribute('disabled')",  textbox);
	
		textbox.sendKeys("10/02/2015");
		Thread.sleep(2000);
		
		ClassLoader classLoader=getClass().getClassLoader();
		File file=new File(classLoader.getResource("BusinessAdminHeldcomm.csv").getFile());
		WebElement upfile=uploadFileForReleaseCommission();
		String fpath=file.getAbsolutePath();
				
		logger.info("upload file is "+fpath);
		
		upfile.sendKeys(fpath);
		Thread.sleep(3000);
		
		
		click_create_button().click();
			
			}
}