package com.xactly.incent.orders;


import java.util.Date;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;

import com.jayway.restassured.response.Response;
import com.xactly.incent.navigation.LeftNavigationUtil;
import com.xactly.xcommons.restapi.RestAPIHelperClass;
import com.xactly.xcommons.selenium.SeleniumHelperClass;

public class Batches {
	public static Logger logger = Logger.getLogger(Batches.class.getName());
	public boolean goToQueue=false;
	RestAPIHelperClass rest = new RestAPIHelperClass();

	public Batches(String testtype) throws Exception
	{
		if(testtype.equalsIgnoreCase("gui"))
		{
			new Orders("gui");				
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
			SeleniumHelperClass.isVisible(get_batch_link(), 20);
			//get_batch_link().click();
			SeleniumHelperClass.secondaryClick(get_batch_link());
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX *2);
		}  else if(testtype.equalsIgnoreCase("gui-new"))
		{
			new Orders("gui-new");	
			LeftNavigationUtil.clickOnProcessTab();
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
			SeleniumHelperClass.isVisible(get_batch_link(), 20);
			SeleniumHelperClass.secondaryClick(get_batch_link());
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX *2);
		}
	}
	
	public Batches() {
		
	}
	
	public WebElement get_batch_link() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("batchesLink","mainFrame"));
	}

	public WebElement get_createbatch_link() throws Exception {		
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='inner-content']/div/div/div/span/span", "mainFrame"));
	}

	public WebElement get_batch_name() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("batchName","mainFrame"));
	}

	public Select get_batch_period() throws Exception {
		return (SeleniumHelperClass.selectFromDropdownwithelements("id","periods-selectCreateBatch","mainFrame"));
	}

	public Select get_batch_fromperiod() throws Exception {
		return (SeleniumHelperClass.selectFromDropdownwithelements("id","periods-selectFrom","mainFrame"));
	}

	public Select get_batch_toperiod() throws Exception {
		return (SeleniumHelperClass.selectFromDropdownwithelements("id","periods-selectTo","mainFrame"));
	}

	public WebElement get_batch_desc() throws Exception {
		//return (SeleniumHelperClass.findWebElementbyid("batchDescription","mainFrame"));  description		
		return (SeleniumHelperClass.findWebElementbyid("description","mainFrame"));
	}

	public WebElement get_batch_searchtext() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("batches-search-text","mainFrame"));		
	}

	public WebElement get_batch_searchbutton() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("batches-search-button","mainFrame"));		
	}

	public WebElement get_batch_selectAll() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("selectBatchChkBox","mainFrame"));
	}

	public WebElement get_batch_save() throws Exception {
	//	return (SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'Save')]", "mainFrame"));		
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='batch-create']/div[3]/span[2]/div", "mainFrame"));
	}

	public WebElement get_batch_delete() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'Delete')]", "mainFrame"));
	}

	public WebElement get_calccredits_batch() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'Calculate Through Credits')]", "mainFrame"));
	}

	public WebElement get_calIncentives_batch() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("batchLinkCalIncentives", "mainFrame"));
	}

	public WebElement get_preCredit_batch() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("batchLinkResetPreCredits", "mainFrame"));
	}

	public WebElement get_preIncentives_batch() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("batchLinkResetPreIncentives", "mainFrame"));
	}

	public WebElement get_calcIncentives_batch() throws Exception {
		return (SeleniumHelperClass.findWebElementbyCssSelector("#batchLinkCalIncentives > span", "mainFrame"));
	}

	public WebElement get_Diagnostics() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='batch-list']/li/div/div[2]/fieldset/div[2]", "mainFrame"));
	}

	public WebElement get_orderProcessed() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='batch-list']/li/div/div[2]/fieldset/div[3]/div[2]/div/table[2]/tbody/tr[1]/td[2]", "mainFrame"));
	}

	public WebElement get_directcreditProduced() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='batch-list']/li/div/div[2]/fieldset/div[3]/div[2]/div/table[2]/tbody/tr[2]/td[2]", "mainFrame"));
	}

	public WebElement get_inDirectCreditProduced() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='batch-list']/li/div/div[2]/fieldset/div[3]/div[2]/div/table[2]/tbody/tr[3]/td[2]", "mainFrame"));
	}

	public WebElement get_commissionProduced() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='batch-list']/li/div/div[2]/fieldset/div[3]/div[2]/div/table[2]/tbody/tr[4]/td[2]", "mainFrame"));
	}

	public WebElement get_bonusProduced() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='batch-list']/li/div/div[2]/fieldset/div[3]/div[2]/div/table[2]/tbody/tr[5]/td[2]", "mainFrame"));
	}

	public WebElement get_ordersWithoutIncentives() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='batch-list']/li/div/div[2]/fieldset/div[3]/div[2]/div/table[2]/tbody/tr[6]/td[2]", "mainFrame"));
	}

	public WebElement get_ordersWithoutCredits() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='batch-list']/li/div/div[2]/fieldset/div[3]/div[2]/div/table[2]/tbody/tr[7]/td[2]", "mainFrame"));
	}

	public WebElement get_batch_search_first_record() throws Exception {
		return (SeleniumHelperClass.findWebElementbyCssSelector("span.batch-type-name-column", "mainFrame"));
	}
	
	public WebElement get_batch_addstep_save_btn() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[text()='Add']", "mainFrame"));
	}

	public WebElement get_batch_select_batchType_link() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("selectBatchType", "mainFrame"));
	}

	public WebElement get_batchPopUp_searchtext() throws Exception {		
		return (SeleniumHelperClass.findWebElementbyid("search-text","mainFrame"));
	}

	public WebElement get_batchPopUp_searchbutton() throws Exception {		
		return (SeleniumHelperClass.findWebElementbyid("search-button","mainFrame"));
	}

	public WebElement get_QueueLink() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='queueLink']", "mainFrame"));
	}

	public WebElement get_AddedByName() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//td[@title='MaximumCharacterBusinessToCheckTruncated']", "mainFrame"));
	}


	public void createBatch(String name, String periodid, String desc, String batchType) throws Exception
	{
		Thread.sleep(2000);
		SeleniumHelperClass.isClickable(get_batch_link(), 20);
		SeleniumHelperClass.click(get_batch_link());
		Thread.sleep(1000);
		SeleniumHelperClass.click(get_createbatch_link());
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*2);
		get_batch_name().sendKeys(name);
		get_batch_desc().sendKeys(desc);
		Thread.sleep(1000);		
		get_batch_period().selectByVisibleText(periodid);
		Thread.sleep(1000);
		SeleniumHelperClass.click(get_batch_select_batchType_link());
		Thread.sleep(1000);
		get_batchPopUp_searchtext().sendKeys(batchType);
		SeleniumHelperClass.click(get_batchPopUp_searchbutton());
		Thread.sleep(1000);
		SeleniumHelperClass.click(get_batch_search_first_record());
		SeleniumHelperClass.click(get_batch_addstep_save_btn());
		Thread.sleep(1000);
		
		Thread.sleep(1000);
		SeleniumHelperClass.click(get_batch_save());
		Thread.sleep(1000);
	}

	//To search for a batch from batch page
	public void searchBatch(String name, String startperiod, String endperiod) throws Exception
	{
		//get_batch_link().click();
		get_batch_fromperiod().selectByVisibleText(startperiod);
		Thread.sleep(5000);
		get_batch_toperiod().selectByVisibleText(endperiod);
		Thread.sleep(500);
		get_batch_searchtext().clear();
		get_batch_searchtext().sendKeys(name);
		Thread.sleep(500);
		SeleniumHelperClass.click(get_batch_searchbutton());
		Thread.sleep(2000);
	}

	public WebElement getbatchTable(String columnName, int rowNum) throws Exception	
	{	
		WebElement obj =SeleniumHelperClass.getTableCell_NewUI(columnName,  rowNum, "list","mainFrame") ;
		Thread.sleep(1000);
		return obj;
	}

	//To delete for a batch from batch page
	public void deleteBatch(String name, String startperiod, String endperiod) throws Exception
	{
		searchBatch(name, startperiod, endperiod);
		SeleniumHelperClass.click(getbatchTable("Name",1));
		SeleniumHelperClass.isVisible(get_batch_delete(), 30);
		SeleniumHelperClass.click(get_batch_delete());
		Thread.sleep(1000);
		SeleniumHelperClass.acceptDeleteConfirmation();
		Thread.sleep(2000);	
	}


	public HashMap<String,String> getDiagnostics()throws Exception	
	{
		HashMap<String,String> diagnostics=new HashMap<String,String>();
		SeleniumHelperClass.click(getbatchTable("Name",1));
		Thread.sleep(5000);
		SeleniumHelperClass.click(get_Diagnostics());
		String ordersprocessed=get_orderProcessed().getText();
		String creditproduced=get_directcreditProduced().getText();
		String indirectcreditproduced=get_inDirectCreditProduced().getText();
		String orderwithoutincentives=get_ordersWithoutIncentives().getText();
		String orderwithoutcredits=get_ordersWithoutCredits().getText();
		String commissionsproduced=get_commissionProduced().getText();
		String bonusproduced=get_bonusProduced().getText();
		diagnostics.put("orders", ordersprocessed);
		diagnostics.put("credits", creditproduced);
		diagnostics.put("icredits", indirectcreditproduced);
		diagnostics.put("commissions", commissionsproduced);
		diagnostics.put("bonus", bonusproduced);
		diagnostics.put("noincentives", orderwithoutincentives);
		diagnostics.put("nocredits", orderwithoutcredits);
		//		Thread.sleep(1000);
		return diagnostics;
	}

	public String getBatchStatus(String batchName,String period) throws Exception {//PreCredit,CreditCalculated,IncentivesCalculated
		searchBatch(batchName,period, period);
		String calcstatus=getbatchTable("Status",1).getText();	
		calcstatus=calcstatus.replace(" ", "").replace("-","");
		return calcstatus;
	}

	public void performCalculation(String action,String name, String startperiod, String endperiod) throws Exception 
	{  
		searchBatch(name, startperiod,endperiod);
		Queue que=new Queue();
		String calcstatus=getbatchTable("Status",1).getText();
		logger.info("Do   "+action);
		if(action.equals("CalculateCredits"))       
		{
			goToQueue=calculateCredits();
		}
		else if(action.equals("CalculateIncentives"))   
		{
			goToQueue=calculateIncentives();
		}
		else if(action.equals("Pre-Credits"))     
		{
			goToQueue=preCredit();
		}
		else if(action.equals("Pre-Incentives"))    
		{
			goToQueue=preIncentives();

		}

		if(goToQueue){
			Thread.sleep(2000);
			SeleniumHelperClass.click(que.get_queue_link());
			Thread.sleep(1000);
			que.start_Processing();
			Thread.sleep(1000);
			SeleniumHelperClass.click(get_batch_link()); 
			Thread.sleep(2000);
			SeleniumHelperClass.click(get_batch_link()); //in Queue page we have auto reload-So if we click at the time of reload click may not happen ,so clicking again before the next reload
			searchBatch(name, startperiod,endperiod);
			checkActionStatus(action);

		}
	}


	public boolean calculateCredits() throws Exception	
	{
		String calcstatus=getbatchTable("Processed Order Status",1).getText();
	//	String calcstatus=getbatchTable("Status",1).getText();
		logger.info("Current Status is  "+calcstatus);
		if(calcstatus.equals("Credit Calculated"))
		{
			logger.info("Credits already calculated"); 
			return false;
		}
		else
		{
			SeleniumHelperClass.click(get_batch_selectAll());
			SeleniumHelperClass.click(get_calccredits_batch());
			return true;

		}
	}


	public boolean calculateIncentives() throws Exception
	{
		String calcstatus=getbatchTable("Status",1).getText();	
		logger.info("Current Status is  "+calcstatus);
		if(calcstatus.equals("Incentives Calculated"))
		{
			logger.info("Incentives already calculated");
			return false;
		}
		else
		{
			SeleniumHelperClass.click(get_batch_selectAll());
			SeleniumHelperClass.click(get_calIncentives_batch());
			return true;
		}
	}

	public boolean preCredit() throws Exception
	{
		String calcstatus=getbatchTable("Processed Order Status",1).getText();
	//	String calcstatus=getbatchTable("Status",1).getText();	
		logger.info("Current Status is  "+calcstatus);
		if(calcstatus.equals("Pre-Credit"))
		{
			logger.info("Batch is in precredit mode");
			return false;
		}
		else
		{
			SeleniumHelperClass.click(get_batch_selectAll());
			SeleniumHelperClass.click(get_preCredit_batch());
			return true;
		}

	}

	public boolean preIncentives() throws Exception
	{
		String calcstatus=getbatchTable("Status",1).getText();	
		logger.info("Current Status is  "+calcstatus);
		if(calcstatus.equals("Credit Calculated"))
		{
			logger.info("Resst to preincentives");
			return false;
		}
		else
		{
			SeleniumHelperClass.click(get_batch_selectAll());
			SeleniumHelperClass.click(get_preIncentives_batch());
			return true;
		}
	}

	public void checkIncentiveCalculation() throws Exception
	{
		long startTime=System.currentTimeMillis();
		//	SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy HH:mm:ss");
		Date resultdate = new Date(startTime);
		//	logger.info(sdf.format(resultdate));
		logger.info("Start Time is "+resultdate);
		int Count=1;
		while(Count<=40)
		{
			String calcstatus=getbatchTable("Status",1).getText();
			if(calcstatus.contentEquals("Incentives Calculated"))
			{
				logger.info("Status of the orders  "+calcstatus);
				break;
			}
			else
			{
				Thread.sleep(15000);
				logger.info("Current status :" +calcstatus);
				SeleniumHelperClass.click(get_batch_searchbutton());
				Count++;
			}
		}		
		if(Count>40)
		{
			logger.info("Time exceeded "+Count*15+"seconds");

		}
		long finishTime=System.currentTimeMillis();
		Date enddate = new Date(finishTime);
		//	logger.info(sdf.format(enddate));
		logger.info("End Time"+enddate);

	}

	public void checkCreditCalculation() throws Exception
	{

		long startTime=System.currentTimeMillis();
		//	SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy HH:mm:ss");
		Date resultdate = new Date(startTime);
		//	logger.info(sdf.format(resultdate));
		logger.info("Start Time is "+resultdate);
		int Count=1;
		while(Count<=40)
		{
			String calcstatus=getbatchTable("Status",1).getText();
			if(calcstatus.contentEquals("Credit Calculated"))
			{
				logger.info("Status of the orders"+calcstatus);
				break;
			}
			else
			{
				Thread.sleep(15000);
				logger.info("Current status :" +calcstatus);
				SeleniumHelperClass.click(get_batch_searchbutton());
				Count++;
			}
		}	
		if(Count>40)
		{
			logger.info("Time exceeded "+Count*15+" seconds");

		}
		long finishTime=System.currentTimeMillis();
		Date enddate = new Date(finishTime);
		//	logger.info(sdf.format(enddate));
		logger.info("End Time"+enddate);

	}

	public void checkPreCreditStatus() throws Exception
	{
		long startTime=System.currentTimeMillis();
		//SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy HH:mm:ss");
		Date resultdate = new Date(startTime);
		//logger.info(sdf.format(resultdate));
		logger.info("Start Time is "+resultdate);
		int Count=1;
		while(Count<=40)
		{
			String calcstatus=getbatchTable("Status",1).getText();
			if(calcstatus.contentEquals("Pre Credit"))
			{
				logger.info("Status of the orders "+calcstatus);
				break;
			}
			else
			{
				Thread.sleep(15000);
				logger.info("Current status :" +calcstatus);
				SeleniumHelperClass.click(get_batch_searchbutton());
				Count++;
			}
		}		
		if(Count>40)
		{
			logger.info("Time exceeded "+Count*15+"seconds");

		}
		long finishTime=System.currentTimeMillis();
		Date enddate = new Date(finishTime);
		//logger.info(sdf.format(enddate));
		logger.info("End Time"+enddate);
	}

	public void checkActionStatus(String actiontodo) throws Exception
	{			
		if(actiontodo.equals("CalculateCredits"))        
		{
			checkCreditCalculation();
			Thread.sleep(10000);
		}
		else if(actiontodo.equals("CalculateIncentives"))   
		{
			checkIncentiveCalculation();
		}
		else if(actiontodo.equals("Pre-Credits"))     
		{
			checkPreCreditStatus();
		}
		else if(actiontodo.equals("Pre-Incentives"))    
		{
			checkCreditCalculation();

		}
	}

	public void selectFirstTwoBatches() throws Exception
	{
		for(int i=1;i<=2;i++)
		{ 

			//				String calcstatus=getbatchTable("Current Status",i).getText();	
			//				logger.info(calcstatus);			
			SeleniumHelperClass.click(SeleniumHelperClass.findWebElementbyXpath("//li["+i+"]/div/div[1]/span[1]/input"));
			//					int option=i-1;
			//					
			//					SeleniumHelperClass.findWebElements("//*[@name='selectedBatches']","mainframe").get(option).click();
		}
		Thread.sleep(1000);
		SeleniumHelperClass.click(get_calIncentives_batch());
	}
	
	String createBatchPath = "/queue/batches";
	public Response createBatchAPI(String businessGroups, String batchName, long periodId, String description, String batchTypeId) throws Exception {
		String createBatchPathRequestBody = "{\"businessGroups\":" + businessGroups + ", \"batchName\":\"" + batchName + "\", \"periodId\":" + 
				periodId + ", \"description\" :\"" + description + "\", \"batchTypeId\" :\"" + batchTypeId + "\"}";
		
    	logger.info("Quarter Request Body: " + createBatchPathRequestBody);
		return rest.getPostAPIResponse(createBatchPath, createBatchPathRequestBody);
	}
	
	public Response deleteBatchAPI(String batchId) {
		String deleteBatchPath = createBatchPath + "/" + batchId;
		return rest.deleteAPIResponse(deleteBatchPath);
	}

}

