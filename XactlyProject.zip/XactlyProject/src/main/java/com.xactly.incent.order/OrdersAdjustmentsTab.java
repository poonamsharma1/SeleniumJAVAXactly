package com.xactly.incent.orders;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.xactly.incent.navigation.LeftNavigationUtil;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

/**
 * @author bsulin
 *
 */

public class OrdersAdjustmentsTab {

    public OrdersAdjustmentsTab(String testtype) throws Exception {
        WebDriver driver = SetWebDrivers.getDriver();

        if (testtype.equalsIgnoreCase("gui-new")) {
            LeftNavigationUtil.openLeftNavigation();
            Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
            LeftNavigationUtil.openOrdersTab();
            LeftNavigationUtil.clickOnOrders_AdjustmentTab();

            try {
                Alert alert = driver.switchTo().alert();
                alert.accept();
            } catch (Exception e) {
                Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN * 2);
            }
        }
    }

	/*public Select change_from_period() throws Exception {
		//return(SeleniumHelperClass.findWebElementbyXpath("//div[@id='s2id_periods-selectFrom']/a/span[text()='JAN-2015 (Open)']", "mainFrame"));
		Select from_period=new Select(SeleniumHelperClass.findWebElementbyXpath("//div[@id='s2id_periods-selectFrom']/a", "mainFrame"));
		from_period.selectByValue("JAN-2015 (Open)");
		return from_period;
	}*/

    //Get SEARCH button/icon
    public WebElement get_orderAdjustment_SearchButton() throws Exception {
        return(SeleniumHelperClass.findWebElementbyid("adjustments-search-button","mainFrame"));
    }

    //Get Results count text
    public WebElement get_orderAdjustment_ResultCountText() throws Exception {
        return(SeleniumHelperClass.findWebElementbyid("results-total","mainFrame"));
    }


}
