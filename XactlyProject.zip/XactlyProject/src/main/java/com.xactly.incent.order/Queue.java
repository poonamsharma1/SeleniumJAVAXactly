package com.xactly.incent.orders;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.xactly.xcommons.selenium.SeleniumHelperClass;

public class Queue {
public static Logger logger = Logger.getLogger(Queue.class.getName());

	public WebElement get_queue_link() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("queueLink","mainFrame"));
	}
	
	public WebElement get_Start_Processing() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='startQueue']","mainFrame"));
	}
	
	public WebElement get_Pause_Processing() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='pauseQueue']","mainFrame"));
	}
	
	

	/*
	public WebElement get_QueueProcessingMessage() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("queuePausedMsg","mainFrame"));
		
		.//*[@id='queueStartOrPause']/span[1]/span[2]
		
		.//*[@id='queueStartOrPause']/span[2]/span[2]
	}
	*/
	
	public WebElement get_QueueProcessingMessage() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[1]/span[2]","mainFrame"));
	}
	
	
	public WebElement getqueueTable(String columnName, int rowNum) throws Exception
	{	
		WebElement obj =SeleniumHelperClass.getTableCell_NewUI(columnName,  rowNum, "list ui-sortable", "mainFrame") ;
		Thread.sleep(1000);
		return obj;
	}

	/*To start the queue*/
	public void start_Processing() throws Exception
	{
		get_queue_link().click();
		Thread.sleep(500);
		String Status=get_QueueProcessingMessage().getText();
		if(Status.equals("The Queue is currently processing.") || Status.equals("The queue is ready for processing."))
		{
			logger.info(Status);
		}
		else
		{
			get_Start_Processing().click();
			Thread.sleep(5000);
		}
	}
	
	/*To pause the queue*/
	public void pause_Processing() throws Exception
	{
	String Status=get_QueueProcessingMessage().getText();
	if(Status.equals("The Queue is currently paused.") || Status.equals("The queue has paused after encountering a validation error.") || Status.equals("The queue has paused after encountering an unexpected error. Please contact support.") || Status.equals("The queue encountered an unexpected error. Please contact support."))
	{
			logger.info(Status);
	}
	else
	{
			get_Pause_Processing().click();
	}
	}
	
	public boolean checkforQueueStatus() throws Exception {
		boolean checkStatus=false;
		get_queue_link().click();
		int i=1;
		do {
			//Putting static sleep for sometime and checking queue status
			Thread.sleep(30000);
			String Status=get_QueueProcessingMessage().getText();
			if((Status.trim().equals("The queue is ready for processing."))|(Status.trim().equals("The Queue is ready for processing.")))
			{
				logger.info(Status);
				checkStatus=true;
				break;
			}
			i++;
			if(i==5) {
				logger.info("The queue is taking longer time , may be struck process");
				checkStatus=false;
			}
		}

		while(i<=5);
		return checkStatus;
	}
	
}