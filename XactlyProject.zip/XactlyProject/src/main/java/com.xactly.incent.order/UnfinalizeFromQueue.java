package com.xactly.incent.orders;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.jayway.jsonpath.JsonPath;
import com.xactly.incent.FeatureCalculationAPI.FeatureCalculation_Releases;
import com.xactly.xcommons.restapi.RestAPIHelperClass;
import com.xactly.xcommons.selenium.GetProperties;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

public class UnfinalizeFromQueue {
	public static Logger logger = Logger.getLogger(UnfinalizeFromQueue.class.getName());
	OrderStageAPI OsApi = new OrderStageAPI();
	
	public UnfinalizeFromQueue(String testtype) throws Exception
	{
		if(testtype.equalsIgnoreCase("gui"))
		{
			new Orders("gui");
			SeleniumHelperClass.findWebElementbyid("A_Process Status", "topFrame").click();
			GetProperties.setCalendartable(SetWebDrivers.tableDet.getProperty("incent.setup.calendar"));
			GetProperties.setBusinessgrouptable(SetWebDrivers.tableDet.getProperty("incent.setup.businessgroup"));
			GetProperties.setUsertable(SetWebDrivers.tableDet.getProperty("incent.setup.user"));
			Thread.sleep(5000);
		}
	}
	
	public WebElement get_finalize_link() throws Exception 
	{
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='queueFinalize']/span/span","mainFrame"));
	}
		
	public WebElement get_finalize_period() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='s2id_periods-selectFinalize']/a/span[1]","mainFrame"));
	}
	
	RestAPIHelperClass rest = new RestAPIHelperClass();
	public String unfinalizeInQueue(String periodId, String reason) throws Exception
	{	
		
		logger.info("adding unfinalize to queue...");
		
		String request = "/queue/events/unfinalizeevents";		
		String queueInfo = "{\"periodId\":\""+periodId+"\",\"unfinalizeReason\":\""+reason+"\"}";
		
		logger.info("queueInfo "+queueInfo);            
		String resp = rest.postRestAPI(request,queueInfo);	
		return resp;
	}

	public String getperiodTableRow(String columnName, String Value, String periodId) throws Exception
	{	
		String Period_id =SeleniumHelperClass.getResultIDFromDB(GetProperties.calendartable, periodId, columnName, Value);
		logger.info("Period_id:"+Period_id);
		Thread.sleep(2000);
		return Period_id;
	}
	
	public WebElement getqueueTableRow(String columnName, int rowNum) throws Exception
	{	
    	WebElement obj =SeleniumHelperClass.getTableCell_NewUI_getrow(columnName,  rowNum, "list ui-sortable", "mainFrame") ;
		Thread.sleep(1000);
		return obj;
	}
	
	public String calcBalance(String periodId, String businessGroupId) throws Exception
	{	
		
		logger.info("adding calc balances to queue...");
		
		String request = "/queue/events/calcbalancesevents";	
		String queueInfo="{\"periodId\":\""+periodId+"\",\"includeAll\":true,\"queueEventType\":\"CalcBalances\",\"businessGroupIdList\":["+businessGroupId+"]}";
		
		logger.info("queueInfo "+queueInfo);            
		String resp = rest.postRestAPI(request,queueInfo);	
		return resp;
	}
	
	
	public void queueProcess() throws Exception {
		
				
 		while (Integer.parseInt(OsApi.getQueueEventCount()) != 0 && !OsApi.getQueueStateMessage().toString().toLowerCase().contains("error")) {
			logger.info("polling the queue...");
			Thread.sleep(15000);
		} 
	}
	
	/*Check for the first open period and last closed period, based on the results, if periodToBeinFinalizedState is not in closed or finalized state then finalize it
	  Else if periodToBeinFinalizedState is not the last closed period, bring it to that state*/
	public static void validatePeriodToBeInFinalizedState(String periodToBeinFinalizedState) throws Exception
	{	
		OrderStageAPI orders = new OrderStageAPI();
		FinalizeFromQueue finalz=new FinalizeFromQueue("");
		String firstOpenPeriod = orders.getFirstOpenPeriod();
		String periodName = JsonPath.read(firstOpenPeriod, "$.name");
		String periodID = JsonPath.read(firstOpenPeriod, "$.id").toString();
		if(periodName.equals(periodToBeinFinalizedState))
		{
			logger.info(periodToBeinFinalizedState+" is not in finalized state, finalizing it now");
			finalz.finalizeInQueue(periodID.toString(),"","true");
			FeatureCalculation_Releases calc=new FeatureCalculation_Releases();
			calc.pollQueue();
			logger.info("The selected period has been finalized now, validating the status again...");

		}
		boolean flag=true;
		while(flag==true)
		{
	        String latestClosedPeriod=orders.getLastClosedPeriod();
	        UnfinalizeFromQueue unfinlz=new UnfinalizeFromQueue("");
			logger.info(latestClosedPeriod);
			periodName = JsonPath.read(latestClosedPeriod, "$.name");
			periodID = JsonPath.read(latestClosedPeriod, "$.id").toString();
	  		if(periodName.equals(periodToBeinFinalizedState))
	  		{
	  			flag = false;
	  			logger.info("The"+periodToBeinFinalizedState+" is already finalized");
	  		}
	  			
	  		else
	  		{
	  			unfinlz.unfinalizeInQueue(periodID.toString(),"Unfinalising to check results and reports");
	  			unfinlz.queueProcess();
	          	
			}
		}
	}
}

