package com.xactly.incent.orders;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

public class ProcessesStatus {
	public static Logger logger = Logger.getLogger(ProcessesStatus.class.getName());
	public ProcessesStatus(String testtype) throws Exception
	{
		if(testtype.equalsIgnoreCase("gui"))
		{
			new Orders("gui");			
			WebElement processStatusTab = SeleniumHelperClass.findWebElementbyid("A_Process Status", "topFrame");
			SeleniumHelperClass.isVisible(processStatusTab, 10);
			processStatusTab.click();
			SeleniumHelperClass.isVisible(get_batches_link(), 15);
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		}
		else if(testtype.equalsIgnoreCase("gui-new"))
		{
			new Orders("gui-new");
			WebElement processStatusTab = SeleniumHelperClass.findWebElementbyid("ORDERS_NAV-ORDERS_PROCESS_STATUS_READWRITE", "topFrame");
			SeleniumHelperClass.isVisible(processStatusTab, 10);
			processStatusTab.click();
			SeleniumHelperClass.waitPageLoad();
		}
	}


	public WebElement get_add_process_btn() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("AddProcess","mainFrame"));
	}

	public WebElement get_add_process_group_link() throws Exception {
		return (SeleniumHelperClass.findWebElementbyCssSelector("#openAddProcessGroup > a > span"));

	}

	public WebElement get_pg_select_arrow() throws Exception {
		return (SeleniumHelperClass.findWebElementbyclass("select2-arrow"));
	}


	public WebElement get_pg_select_item_link() throws Exception {
		return (SeleniumHelperClass.findWebElementbyCssSelector("span.selectItem"));
	}

	public WebElement get_pg_select_item_save_btn() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='modal-container']/div[3]/span[2]/div","mainFrame"));
	}

	public WebElement get_pg_save_btn() throws Exception {
		return (SeleniumHelperClass.findWebElementbyCssSelector("#confirm-button > div","mainFrame"));
	}

	public WebElement get_errors_link() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("errorsLink","mainFrame"));
	}

	public WebElement get_batches_link() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("batchesLink","mainFrame"));
	}

	public WebElement get_batches_from_period_dropdown() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='s2id_periods-selectFrom']/a/span[2]/b","mainFrame"));
	}

	public WebElement get_batches_to_period_dropdown() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[@id='s2id_periods-selectTo']/a/span[2]/b","mainFrame"));
	}

	public List<WebElement> get_batches_allperiods() throws Exception {
		return (SeleniumHelperClass.findWebElements("//div[@id='select2-drop']/ul/li/div","mainFrame"));
	}

	public WebElement select_batches_period(int item) throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='select2-drop']/ul/li["+item+"]/div", "mainframe"));
	}
	
	public WebElement get_PPP_tab() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("ppp","mainFrame"));
	}
	
	public WebElement get_Download_Changes() throws Exception{
		return (SeleniumHelperClass.findWebElementbyXpath("//*[text()='Download Changes']"));
	}
	
	public WebElement get_Download_MessagePop() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//*[text()='Ok']"));
	}
	public void getDownloadLinkonHeaderFrame(String testtype) throws Exception{
		if (testtype.equalsIgnoreCase("gui")){
			get_mydownload_folder().click();
		}
		else if (testtype.equalsIgnoreCase("gui-new")) {
			get_mydownload_folderNewGUI().click();
		}
	}
	public WebElement get_mydownload_folder() throws Exception{
	    return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='notifications']//i[@class='fa fa-download']","topframe"));
	    }
	 public WebElement get_mydownload_folderNewGUI() throws Exception {
	     return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='notifications']", "headerFrame"));
       }
	
	public WebElement get_mydownload_serachbox() throws Exception{
	    return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='search-text']","default"));
	    }
	
	public WebElement get_mydownload_serachicon() throws Exception{
	    return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='search']",""));
	    }
	
	public WebElement get_mydownload_download() throws Exception{
	    return (SeleniumHelperClass.findWebElementbyXpath("(//span[@class='download-file'])[1]",""));
	    }
	
	public WebElement get_myDownload_close() throws Exception {	
		return SeleniumHelperClass.findWebElementbyXpath("//div[@class='modal fade right slide-panel modal-show']//button[@type='button'][normalize-space()='Close']","");
		}
	public WebElement expirydate_Sort() throws Exception {	
		return SeleniumHelperClass.findWebElementbyXpath("//span[text()='Expiry Date']","");
		}
	public WebElement get_filename() throws Exception {	
		return SeleniumHelperClass.findWebElementbyXpath("//ul[@id='notification-list']/descendant::span[5]/span","");
		}
	
	//WebElements for ProcessStatus
	public WebElement get_SingePeriodProcess() throws Exception {	
		return SeleniumHelperClass.findWebElementbyXpath("//span[text()='Run Single Period Process']");
		}
	public WebElement get_AddSingePeriodProcessButton() throws Exception {	
		return SeleniumHelperClass.findWebElementbyXpath("//span[@id='confirm-button']","mainFrame");
		}

	// * Processed Orders PPP Download
	public void processedOrdersPPPDownload() throws Exception {
		SeleniumHelperClass.waitforPageToLoad("id", "ddimagetabs", "topFrame");
		SeleniumHelperClass.isClickable(get_PPP_tab(), 10);
		get_PPP_tab().click();
		SeleniumHelperClass.isClickable(get_Download_Changes(), 10);
		get_Download_Changes().click();
		SeleniumHelperClass.isClickable(get_Download_MessagePop(), 10);
		get_Download_MessagePop().click();
		Thread.sleep(60000);
	}

	public void selectbatchesperiod(String periodName) throws Exception {
		int periodsLength = get_batches_allperiods().size();
		logger.info("No of periods:"+periodsLength);
		for (int i=1; i<=periodsLength; i++){
			System.out.printf("Period Name: ",select_batches_period(i).getText());
			if (select_batches_period(i).getText().equalsIgnoreCase(periodName)){
				select_batches_period(i).click();
				System.out.printf("CLICKED.. ");
				break;
			}
		}
	}
	
	// * Download file from myDownloads folder
	
			public String mydownloads() throws Exception {
				logger.info("Downloading file from myDownloads folder");
//				SeleniumHelperClass.isClickable(get_mydownload_folder(), 10);
//				get_mydownload_folder().click();
				getDownloadLinkonHeaderFrame(SetWebDrivers.getNavigationType());
				WebDriver driver = SetWebDrivers.getDriver();
				driver.switchTo().defaultContent();
				SeleniumHelperClass.isClickable(expirydate_Sort(), 10);
				expirydate_Sort().click();
				String downloadFileName = get_filename().getText();
				SeleniumHelperClass.isClickable(get_mydownload_serachbox(), 10);
				get_mydownload_serachbox().sendKeys(downloadFileName);
				SeleniumHelperClass.isClickable(get_mydownload_serachicon(), 10);
				get_mydownload_serachicon().click();
				SeleniumHelperClass.isClickable(get_mydownload_download(), 10);
				get_mydownload_download().click();
				SeleniumHelperClass.isClickable(get_mydownload_serachbox(), 10);
				SeleniumHelperClass.clearElement(get_mydownload_serachbox());
				SeleniumHelperClass.isClickable(get_mydownload_serachicon(), 10);
				get_mydownload_serachicon().click();
				SeleniumHelperClass.isClickable(get_myDownload_close(), 10);
				get_myDownload_close().click();
				return downloadFileName;
				}
		
	public WebElement get_batches_search_textbox() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("batches-search-text","mainFrame"));
	}

	public WebElement get_batches_search_icon() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("batches-search-button","mainFrame"));
	}

	public WebElement select_batch_checkbox() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//ul[@id='batch-list']/li/div/div/span/input","mainFrame"));
	}

	public WebElement get_calculate_through_incentives_link() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='batchLinkCalIncentives']/span","mainFrame"));
	}

	public WebElement get_download_button() throws Exception {
		return (SeleniumHelperClass.findWebElementbyLink("Download Error Log", "mainFrame"));
	}

	public WebElement get_search_box() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("errors-search-text","mainFrame"));
	}

	public WebElement get_search_button() throws Exception {
		return (SeleniumHelperClass.findWebElementbyid("errors-search-button","mainFrame"));
	}

	public WebElement get_otg_rowselect() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='error-list']/li/div","mainFrame"));
	}

	public WebElement get_history_tab_btn() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='historyLink']","mainFrame"));
	}
	
	
	public WebElement clickBatchesSubtub() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[text()='Batches']", "mainFrame");
	}
	
	public WebElement clickCreateBatch() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[text()='Create Batch']", "mainFrame");
	}
	
	public WebElement enterBatchName() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='batchName']", "mainFrame");
	}
	
	public int randomNumber() {
		Random rand = new Random();
		return rand.nextInt(100);
	}
	
	public WebElement selectBatchType() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[text()='Select Batch Type']", "mainFrame");
	}

	public WebElement selectOrderType() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='element-list']/li[6]/div", "mainFrame");
	}
	
	public WebElement clickAddBatchType() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[text()='Add']", "mainFrame");
	}
	
	public WebElement clickSaveBatchType() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[text()='Save']", "mainFrame");
	}
	
	public Boolean verifyFunctionality() throws Exception {
		return SeleniumHelperClass.isElementPresent("xpath", "//*[text()='Create Batch']/parent::div");
	}
	
	public WebElement clickOut() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[text()='x']", "mainFrame");
	}
	
	public WebElement enterBatchNameinSearch() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='batches-search-text']", "mainFrame");
	}
	
	public WebElement clickEnter() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[@id='batches-search-button']", "mainFrame");
	}
	
	public WebElement BatchDelete() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[text()='APR-2015']", "mainFrame");
	}
	
	public void hoverOverBatchDelete() throws Exception {
		SeleniumHelperClass.mouseHover(BatchDelete());
	}
	
	public WebElement clickDelete() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[text()='Delete']/parent::button", "mainFrame");
	}
	
	public WebElement confirmDelete() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//*[text()='Delete']/parent::span", "mainFrame");
	}
	
	public WebElement get_QueueLink() throws Exception {
		
		
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='queueLink']","mainFrame"));
		
			
	}
	
	public WebElement getQueueBatch() throws Exception {
		
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[2]/table/tbody/tr/td[4]/span","mainFrame"));
	}
	
	public WebElement getHistoryBatchName(String batchName) throws Exception {
		
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@title='"+batchName+"']","mainFrame"));
	}
	
	public WebElement getProcessingHeader() throws Exception {
		
		return (SeleniumHelperClass.findWebElementbyXpath(" .//*[@class='sub-level-details list-item-detail']/div[1]/h4","mainFrame"));
		
	}
	
	public WebElement getOrdersWithOutIncentives(String batchName) throws Exception {
		
		//return (SeleniumHelperClass.findWebElementbyXpath(".//*[@class='sub-level-details list-item-detail']/div[1]/table[2]/tbody[1]/tr[6]/td[2]/span","mainFrame"));
		
		return (SeleniumHelperClass.findWebElementbyXpath(".//td[@title='"+batchName+"']/../following-sibling::tr/../../following-sibling::table/tbody//tr//td//span[text()='Orders Without Incentives:']/../following-sibling::td","mainFrame"));
		
		
		
		
	}
	
public WebElement getOrdersWithOutCredits(String batchName) throws Exception {
		
		//return (SeleniumHelperClass.findWebElementbyXpath(".//*[@class='sub-level-details list-item-detail']/div[1]/table[2]/tbody[1]/tr[7]/td[2]/span","mainFrame"));
		
		return (SeleniumHelperClass.findWebElementbyXpath(".//td[@title='"+batchName+"']/../following-sibling::tr/../../following-sibling::table/tbody//tr//td//span[text()='Orders Without Credits:']/../following-sibling::td","mainFrame"));
		
		
	}
	
public WebElement getClickBatchName(String batchName) throws Exception {
	
	return (SeleniumHelperClass.findWebElementbyXpath(".//*[@title='"+batchName+"']","mainFrame"));
}	

public WebElement getClickDiagnostics() throws Exception {
	
	return (SeleniumHelperClass.findWebElementbyXpath("//div[@class='legend']","mainFrame"));
}	

public WebElement getBatchTotalIncentives() throws Exception {
	//return (SeleniumHelperClass.findWebElementbyXpath(".//*[@class='audit-body']/tr[6]/td[text()='Orders Without Incentives']/following-sibling::td[1]","mainFrame"));
	return (SeleniumHelperClass.findWebElementbyXpath(".//*[text()='Orders Without Incentives']/following-sibling::td[1]","mainFrame"));
	
}

public WebElement getBatchTotalCredits() throws Exception {
	//return (SeleniumHelperClass.findWebElementbyXpath(".//*[@class='audit-body']/tr[7]/td[text()='Orders Without Credits']/following-sibling::td[1]","mainFrame"));
	
	return (SeleniumHelperClass.findWebElementbyXpath(".//*[text()='Orders Without Credits']/following-sibling::td[1]","mainFrame"));
	
	
}



	public void downloaderror() throws Exception
	{
		get_errors_link().click();
		get_search_box().sendKeys("FEB-2012_Batch");
		get_search_button().click();
		get_otg_rowselect().click();
		get_download_button().click();
	}

	//Used for adhoc actions that are Passed
	public Map<String,Integer> getBatchDiagnosticsForAdhocAction(String batchName, String periodName) throws Exception{
		
		SeleniumHelperClass.waitUntilLoaderDisappears();
		get_history_tab_btn().click();
		SeleniumHelperClass.waitUntilLoaderDisappears();
		get_batches_from_period_dropdown().click();
		selectbatchesperiod(periodName);
		get_batches_to_period_dropdown().click();
		selectbatchesperiod(periodName);
		Thread.sleep(4000);
		SeleniumHelperClass.waitUntilLoaderDisappears();
		
		int row =1;
		List<WebElement> actionNames = SeleniumHelperClass.findWebElementsInXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody/tr/td[2]/span", "mainFrame");
		for (int i=1; i <= actionNames.size(); i++){
			String actionName = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+i+"]/tr/td[2]/span", "mainFrame").getText();
			if (actionName.contentEquals(batchName)){
				SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+i+"]/tr/td[2]/span", "mainFrame").click();
				Thread.sleep(2000);
				SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+i+"]/tr[2]/td/div/fieldset/div[2]", "mainFrame").click();
				row = i;
				break;
			}
		}
		SeleniumHelperClass.waitUntilLoaderDisappears();
		SeleniumHelperClass.waitUntilLoaderDisappears();
		String totalOrdersProcessed = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+row+"]/tr[2]/td/div/fieldset/div[3]/div[2]/div/table[2]/tbody/tr[1]/td[2]", "mainFrame").getText();
		String directCredits = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+row+"]/tr[2]/td/div/fieldset/div[3]/div[2]/div/table[2]/tbody/tr[2]/td[2]", "mainFrame").getText();
		String inDirectCredits = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+row+"]/tr[2]/td/div/fieldset/div[3]/div[2]/div/table[2]/tbody/tr[3]/td[2]", "mainFrame").getText();
		String totalCommissions = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+row+"]/tr[2]/td/div/fieldset/div[3]/div[2]/div/table[2]/tbody/tr[4]/td[2]", "mainFrame").getText();
		String bonus = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+row+"]/tr[2]/td/div/fieldset/div[3]/div[2]/div/table[2]/tbody/tr[5]/td[2]", "mainFrame").getText();
		String ordersWithoutIncentives = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+row+"]/tr[2]/td/div/fieldset/div[3]/div[2]/div/table[2]/tbody/tr[6]/td[2]", "mainFrame").getText();
		String ordersWithoutCredits = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+row+"]/tr[2]/td/div/fieldset/div[3]/div[2]/div/table[2]/tbody/tr[7]/td[2]", "mainFrame").getText();
		
		Map<String, Integer> diagnostics = new HashMap<String, Integer>();
		diagnostics.put("totalOrdersProcessed", Integer.valueOf(totalOrdersProcessed));
		diagnostics.put("directCredits", Integer.valueOf(directCredits));
		diagnostics.put("inDirectCredits", Integer.valueOf(inDirectCredits));
		diagnostics.put("totalCommissions", Integer.valueOf(totalCommissions));
		diagnostics.put("bonus", Integer.valueOf(bonus));
		diagnostics.put("ordersWithoutIncentives", Integer.valueOf(ordersWithoutIncentives));
		diagnostics.put("ordersWithoutCredits", Integer.valueOf(ordersWithoutCredits));
		return diagnostics;	
		
	}
	
	//Used for PG actions that are Passed
	public Map<String,Integer> getBatchDiagnosticsForPG(String pgName, String stepName, String batchName, String periodName) throws Exception{
		
		SeleniumHelperClass.waitUntilLoaderDisappears();
		get_history_tab_btn().click();
		SeleniumHelperClass.waitUntilLoaderDisappears();
		get_batches_from_period_dropdown().click();
		selectbatchesperiod(periodName);
		get_batches_to_period_dropdown().click();
		selectbatchesperiod(periodName);
		Thread.sleep(4000);
		SeleniumHelperClass.waitUntilLoaderDisappears();
		
		List<WebElement> allTypes = SeleniumHelperClass.findWebElementsInXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody/tr/td[3]", "mainFrame");
		logger.info("Total No of items: "+allTypes.size());
		int pg;
		for (pg = 1;pg <= allTypes.size(); pg++){
			String actionType = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+pg+"]/tr/td[3]", "mainFrame").getText();
			if (actionType.contentEquals("Process Group")){
				break;
			}
		}
		
		logger.info("Pg value: "+pg);
		
		//Select PG
		List<WebElement> actionNames = SeleniumHelperClass.findWebElementsInXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody/tr/td[2]/span[2]", "mainFrame");
		for (int i=pg; i <= 25; i++){
			String actionName = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+i+"]/tr/td[2]/span[2]", "mainFrame").getText();
			if (actionName.contentEquals(pgName)){
				SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+i+"]/tr/td[2]/span[1]/span", "mainFrame").click();
				Thread.sleep(2000);
				break;
			}
		}
		
		//Select PG Step
		List<WebElement> stepNames = SeleniumHelperClass.findWebElementsInXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody/tr[2]/td[2]/span[2]", "mainFrame");
		int stepTr = 1;
		for (int j=pg; j <= 100; j++){
			stepTr = stepTr + 1;
			String step = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+j+"]/tr["+stepTr+"]/td[2]/span[2]", "mainFrame").getText();
			if (step.contentEquals(stepName)){
				SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+j+"]/tr["+stepTr+"]/td[2]/span[1]/span", "mainFrame").click();
				Thread.sleep(2000);
				break;
			}
		}
		
		// Select Batch
		List<WebElement> batchNames = SeleniumHelperClass.findWebElementsInXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody/tr[3]/td[2]/span[2]", "mainFrame");
		int batchTr = 2;
		for (int k=pg; k <= 100; k++){
			batchTr = batchTr +1;
			String batch = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+k+"]/tr["+batchTr+"]/td[2]/span[2]", "mainFrame").getText();
			if (batch.contentEquals(batchName)){
				SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+k+"]/tr["+batchTr+"]/td[2]/span[2]", "mainFrame").click();
				Thread.sleep(2000);
				break;
			}
		}					
				
		logger.info("Batches: "+ batchTr);			
		
		SeleniumHelperClass.waitUntilLoaderDisappears();
		String totalOrdersProcessed = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+pg+"]/tr["+(batchTr+1)+"]/td/div/fieldset/div/table/tbody[2]/tr[1]/td[2]/span[2]", "mainFrame").getText();
		String directCredits = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+pg+"]/tr["+(batchTr+1)+"]/td/div/fieldset/div/table/tbody[2]/tr[2]/td[2]/span[2]", "mainFrame").getText();
		String inDirectCredits = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+pg+"]/tr["+(batchTr+1)+"]/td/div/fieldset/div/table/tbody[2]/tr[3]/td[2]/span[2]", "mainFrame").getText();
		String totalCommissions = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+pg+"]/tr["+(batchTr+1)+"]/td/div/fieldset/div/table/tbody[2]/tr[4]/td[2]/span[2]", "mainFrame").getText();
		String bonus = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+pg+"]/tr["+(batchTr+1)+"]/td/div/fieldset/div/table/tbody[2]/tr[5]/td[2]/span[2]", "mainFrame").getText();
		String ordersWithoutIncentives = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+pg+"]/tr["+(batchTr+1)+"]/td/div/fieldset/div/table/tbody[2]/tr[6]/td[2]/span[2]", "mainFrame").getText();
		String ordersWithoutCredits = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+pg+"]/tr["+(batchTr+1)+"]/td/div/fieldset/div/table/tbody[2]/tr[7]/td[2]/span[2]", "mainFrame").getText();
		
		Map<String, Integer> diagnostics = new HashMap<String, Integer>();
		diagnostics.put("totalOrdersProcessed", Integer.valueOf(totalOrdersProcessed));
		diagnostics.put("directCredits", Integer.valueOf(directCredits));
		diagnostics.put("inDirectCredits", Integer.valueOf(inDirectCredits));
		diagnostics.put("totalCommissions", Integer.valueOf(totalCommissions));
		diagnostics.put("bonus", Integer.valueOf(bonus));
		diagnostics.put("ordersWithoutIncentives", Integer.valueOf(ordersWithoutIncentives));
		diagnostics.put("ordersWithoutCredits", Integer.valueOf(ordersWithoutCredits));
		return diagnostics;	
		
	}
	
	//Used for SPP actions that are Passed
	public Map<String,Integer> getBatchDiagnosticsForSPP(String sppName, String pgName, String stepName, String batchName, String periodName) throws Exception{
		
		SeleniumHelperClass.waitUntilLoaderDisappears();
		get_history_tab_btn().click();
		SeleniumHelperClass.waitUntilLoaderDisappears();
		get_batches_from_period_dropdown().click();
		selectbatchesperiod(periodName);
		get_batches_to_period_dropdown().click();
		selectbatchesperiod(periodName);
		Thread.sleep(4000);
		SeleniumHelperClass.waitUntilLoaderDisappears();
		
		List<WebElement> allTypes = SeleniumHelperClass.findWebElementsInXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody/tr/td[3]", "mainFrame");
		logger.info("Total No of items: "+allTypes.size());
		int spp;
		for (spp = 1; spp <= allTypes.size(); spp++){
			String actionType = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+spp+"]/tr/td[3]", "mainFrame").getText();
			if (actionType.contentEquals("Single Period Process")){
				break;
			}
		}
		
		logger.info("SPP value: "+spp);
		
		//Select SPP
		List<WebElement> sppNames = SeleniumHelperClass.findWebElementsInXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody/tr/td[2]/span[2]", "mainFrame");
		for (int s=spp; s <= 25; s++){
			String sppValue = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+s+"]/tr/td[2]/span[2]", "mainFrame").getText();
			if (sppValue.contentEquals(sppName)){
				SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+s+"]/tr/td[2]/span[1]/span", "mainFrame").click();
				Thread.sleep(2000);
				break;
			}
		}
		
		//Select PG
		List<WebElement> actionNames = SeleniumHelperClass.findWebElementsInXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody/tr[2]/td[2]/span[2]", "mainFrame");
		int stepTr = 1;
		for (int i=spp; i <= 25; i++){
			stepTr = stepTr +1;
			String actionName = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+i+"]/tr["+stepTr+"]/td[2]/span[2]", "mainFrame").getText();
			if (actionName.contentEquals(pgName)){
				SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+i+"]/tr["+stepTr+"]/td[2]/span[1]/span", "mainFrame").click();
				Thread.sleep(2000);
				break;
			}
		}
		
		//Select PG Step
		List<WebElement> stepNames = SeleniumHelperClass.findWebElementsInXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody/tr[3]/td[2]/span[2]", "mainFrame");
		int stepNameTr = 2;
		for (int j=spp; j <= 100; j++){
			stepNameTr = stepNameTr + 1;
			String step = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+j+"]/tr["+stepNameTr+"]/td[2]/span[2]", "mainFrame").getText();
			if (step.contentEquals(stepName)){
				SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+j+"]/tr["+stepNameTr+"]/td[2]/span[1]/span", "mainFrame").click();
				Thread.sleep(2000);
				break;
			}
		}
		
		// Select Batch
		List<WebElement> batchNames = SeleniumHelperClass.findWebElementsInXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody/tr[4]/td[2]/span[2]", "mainFrame");
		int batchTr = 3;
		for (int k=spp; k <= 100; k++){
			batchTr = batchTr + 1;
			String batch = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+k+"]/tr["+batchTr+"]/td[2]/span[2]", "mainFrame").getText();
			if (batch.contentEquals(batchName)){
				SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+k+"]/tr["+batchTr+"]/td[2]/span[2]", "mainFrame").click();
				Thread.sleep(2000);
				break;
			}
		}
					
		logger.info("Batches: "+ batchTr);			
				
		SeleniumHelperClass.waitUntilLoaderDisappears();
		String totalOrdersProcessed = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+spp+"]/tr["+(batchTr+1)+"]/td/div/fieldset/div/table/tbody[2]/tr[1]/td[2]/span[2]", "mainFrame").getText();
		String directCredits = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+spp+"]/tr["+(batchTr+1)+"]/td/div/fieldset/div/table/tbody[2]/tr[2]/td[2]/span[2]", "mainFrame").getText();
		String inDirectCredits = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+spp+"]/tr["+(batchTr+1)+"]/td/div/fieldset/div/table/tbody[2]/tr[3]/td[2]/span[2]", "mainFrame").getText();
		String totalCommissions = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+spp+"]/tr["+(batchTr+1)+"]/td/div/fieldset/div/table/tbody[2]/tr[4]/td[2]/span[2]", "mainFrame").getText();
		String bonus = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+spp+"]/tr["+(batchTr+1)+"]/td/div/fieldset/div/table/tbody[2]/tr[5]/td[2]/span[2]", "mainFrame").getText();
		String ordersWithoutIncentives = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+spp+"]/tr["+(batchTr+1)+"]/td/div/fieldset/div/table/tbody[2]/tr[6]/td[2]/span[2]", "mainFrame").getText();
		String ordersWithoutCredits = SeleniumHelperClass.findWebElementbyXpath(".//*[@id='inner-content']/div[2]/div[3]/table/tbody["+spp+"]/tr["+(batchTr+1)+"]/td/div/fieldset/div/table/tbody[2]/tr[7]/td[2]/span[2]", "mainFrame").getText();
		
		Map<String, Integer> diagnostics = new HashMap<String, Integer>();
		diagnostics.put("totalOrdersProcessed", Integer.valueOf(totalOrdersProcessed));
		diagnostics.put("directCredits", Integer.valueOf(directCredits));
		diagnostics.put("inDirectCredits", Integer.valueOf(inDirectCredits));
		diagnostics.put("totalCommissions", Integer.valueOf(totalCommissions));
		diagnostics.put("bonus", Integer.valueOf(bonus));
		diagnostics.put("ordersWithoutIncentives", Integer.valueOf(ordersWithoutIncentives));
		diagnostics.put("ordersWithoutCredits", Integer.valueOf(ordersWithoutCredits));
		return diagnostics;		
	}
	
	
	
	public WebElement get_batch_name(String batchName) throws Exception {
		
		return (SeleniumHelperClass.findWebElementbyXpath("//span[text()='"+batchName+"']","mainFrame"));
	}
	public WebElement get_createBatch_link() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//span[@data-i18n='createNewBatch']","mainFrame"));
	}
	
/*	public WebElement getbatchSelection() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='inner-content']/div/div/div/span/span","mainFrame"));
		
	}*/
	
	public WebElement selectBatchPeriodId(String periodid ) throws Exception {
		
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='select2-drop']/ul//li/div[text()='"+periodid+"']", "mainFrame"));
	}
	
	public WebElement getSelectBatchSearchText() throws Exception {
		
		return (SeleniumHelperClass.findWebElementbyXpath("//input[@id='search-text']","mainFrame"));
	}
	
	public WebElement getSearchBatchButton() throws Exception {
		
	return (SeleniumHelperClass.findWebElementbyXpath("//a[@id='search-button']","mainFrame"));	
	}
	
	public WebElement getSelectBatchDisplay(String batchType) throws Exception {
		
		return (SeleniumHelperClass.findWebElementbyXpath("//span[text()='"+batchType+"']","mainFrame"));
	}
	
	public WebElement getSelectBatchButton() throws Exception {
		
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[text()='Add']","mainFrame"));
	}

public void createBatchProcess(String name, String periodid, String desc, String batchType) throws Exception
	{
		Boolean flag=false;
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);	
		get_createbatch_name().sendKeys(name);
		get_createbatch_desc().sendKeys(desc);
		Thread.sleep(1000);		
		get_createbatch_period_icon().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		List<WebElement> batchSelect=SeleniumHelperClass.findWebElementsInXpath(".//*[@id='select2-drop']/ul/li", "mainFrame");
		for (WebElement webElement : batchSelect) {
			logger.info("batchSelect:"+webElement.getText());
			
			if(webElement.getText().equals(periodid)&&(flag==false)) {
			flag=true;
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
				selectBatchPeriodId(periodid).click();
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
				get_batchType().click();
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
				getSelectBatchSearchText().sendKeys(batchType);
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
				getSearchBatchButton().click();
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
				getSelectBatchDisplay(batchType).click();
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
				getSelectBatchButton().click();
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
				get_createbatch_batchSave().click();
				Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
			
				break;
			
			
		       }
			
	    	}
		
	}
			
	public WebElement get_createbatch_batchSave() throws Exception {
				
		return (SeleniumHelperClass.findWebElementbyXpath("//div[@data-i18n='save']","mainFrame"));
				
		}
	public WebElement get_processbatch_period_icon() throws Exception {
				
		return (SeleniumHelperClass.findWebElementbyXpath("(.//*[@id='s2id_periods']/a/span[2]/b)[2]","mainFrame"));
				
		}
	
	public WebElement get_createbatch_name() throws Exception {
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@name='batchName']","mainFrame"));
	}
	
	public WebElement get_createbatch_desc() throws Exception {
		
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@name='description']","mainFrame"));
	}
	
public WebElement get_createbatch_period_icon() throws Exception {
		
		return (SeleniumHelperClass.findWebElementbyXpath(".//*[@id='s2id_periods-selectCreateBatch']/a/span[2]/b","mainframe"));
	}

public WebElement get_batchType() throws Exception {
	
	return (SeleniumHelperClass.findWebElementbyXpath("//a[@id='selectBatchType']","mainFrame"));
}
public void editBatchProcess(String editDesc, String editbatchType) throws Exception {
	
	
	
	Thread.sleep(2000);	
	get_createbatch_desc().clear();
	Thread.sleep(2000);
	get_createbatch_desc().sendKeys(editDesc);
	Thread.sleep(1000);		
	get_createbatch_period_icon().click();
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
	get_batchType().click();			
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
	getSelectBatchSearchText().sendKeys(editbatchType);			
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);		
	getSearchBatchButton().click();		
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);		
	getSelectBatchDisplay(editbatchType).click();	
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);		
	getSelectBatchButton().click();			
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);		
	get_createbatch_batchSave().click();			
	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMIN);
		
}	

public WebElement get_noMatchList() throws Exception {
	return (SeleniumHelperClass.findWebElementbyXpath("//div[@id='all-batches-div']/div[3]","mainFrame"));
}

public WebElement get_DeleteButton() throws Exception  {
	return (SeleniumHelperClass.findWebElementbyXpath("//span[@id='confirm-button']/div","mainFrame"));
}

public WebElement get_createbatch_batchCancel() throws Exception {
return (SeleniumHelperClass.findWebElementbyXpath("//span[@data-i18n='cancel']","mainFrame"));
}
public WebElement get_editBatch_getBatchType(String editBatchType) throws Exception {
	return (SeleniumHelperClass.findWebElementbyXpath("//div[@title='"+editBatchType+"']","mainFrame"));
	
}
public WebElement get_tickselectBatch() throws Exception {
return SeleniumHelperClass.findWebElementbyXpath(".//*[@id='element-list']/li/div/span[1]/input","mainFrame");
}
public WebElement get_selectBatchButton() throws Exception {
return SeleniumHelperClass.findWebElementbyXpath(".//*[@id='batchView']/div[1]/div/span[2]","mainFrame");
}

public WebElement getProcessInQueueExpandArrow() throws Exception {		
	return SeleniumHelperClass.findWebElementbyXpath(".//*[@class='fa fa-chevron-right']", "mainFrame");
}

public WebElement getFirstChildProcessInQueueName() throws Exception {	
	return SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'3')]", "mainFrame");
}

	
		
}


