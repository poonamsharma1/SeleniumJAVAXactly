package com.xactly.incent.orders;

import org.apache.log4j.Logger;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.asserts.SoftAssert;

import com.xactly.incent.companydata.Products;
import com.xactly.xcommons.javahelper.ExcelConnector;
import com.xactly.xcommons.selenium.SeleniumHelperClass;
import com.xactly.xcommons.selenium.SetWebDrivers;

public class OrdersSearch {
	public static Logger logger = Logger.getLogger(OrdersSearch.class.getName());
	public Select getDropDown() throws Exception{
		
		return SeleniumHelperClass.selectFromDropdownwithelements("id", "periods", "mainFrame");
		
	}
	
	public WebElement getOrderCode() throws Exception{
		return SeleniumHelperClass.findWebElementbyid("orderCode", "mainFrame");
	}

	public WebElement getOrderList() throws Exception {
	    return  SeleniumHelperClass.findWebElementbyXpath("//div[@class='list-wrapper results-list-wrapper']//ul[@class='list']","mainFrame");
    }

	public WebElement getItemCode() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("itemCode","mainFrame");
	}
	
	public WebElement getOrderSearch() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("selectOrderCode");
	}
	
	public WebElement getItemSearch() throws Exception {
		return SeleniumHelperClass.findWebElementbyid("selectItemCode");
	}
	
	public WebElement getSearchCode() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("//span[@class='person-first-name-column']","mainFrame");
	}
	
    public WebElement getCancel() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("(//span[text()=' Cancel'])");
	}
    
    public WebElement getSearchCancel() throws Exception {
		return SeleniumHelperClass.findWebElementbyXpath("(//span[text()='Cancel'])[2]");
	}
    
    public WebElement getUploadOrderItems() throws Exception{
    	return SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'Upload Order Items')]","mainFrame");
    }
    
    public WebElement getBrowse() throws Exception {
    	return SeleniumHelperClass.findWebElementbyid("orderUploadInputDiv","mainFrame");
    }
    
    public String getUploadFileLocation(String file){
		return this.getClass().getClassLoader().getResource("com.xactly.incent.Orders/OrderUpload/"+file).getFile();
		}
    
    
    public String searchOrderCode(String orderCode) throws Exception {
    	logger.info("Searching the orderCode");
    	
    	getDropDown().selectByVisibleText("FEB-2017 (Open)");;
    	getOrderCode().sendKeys(orderCode);
    	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
    	getOrderSearch().click();
    	String parentWindow = SeleniumHelperClass.switchToPopupWindow();
    	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
    	String Ordertext = getSearchCode().getText();
    	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
    	getCancel().click();
    	SeleniumHelperClass.switchToWindow(parentWindow);
    	logger.info(Ordertext);
    	return Ordertext;
    	
    }
    
    public String searchItemCode(String Itemcode) throws Exception {
    	logger.info("Searching the ItemCode");
    	getDropDown().selectByVisibleText("FEB-2017 (Open)");
    	getItemCode().sendKeys(Itemcode);
    	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
    	getItemSearch().click();
    	String parentWindow = SeleniumHelperClass.switchToPopupWindow();
    	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
    	String ItemText = getSearchCode().getText();
    	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
    	getCancel().click();
    	SeleniumHelperClass.switchToWindow(parentWindow);
    	logger.info(ItemText);
    	return ItemText;
    	
    }
    
    public WebElement getInputField() throws Exception{
    	return SeleniumHelperClass.findWebElementbyXpath("//input[@type='file']", "mainFrame");
    }
    
    public WebElement getUploadButton() throws Exception{
    	return SeleniumHelperClass.findWebElementbyid("confirm-button");
    }
    
    public WebElement getSearchButton() throws Exception {
    	return SeleniumHelperClass.findWebElementbyXpath("//span[@id='searchBtn']","mainFrame");
    }
    
    public WebElement getEditButton() throws Exception{
    	//WebElement e = SeleniumHelperClass.findWebElementbyXpath("//div[@class='list-item-row border-bottom orders-row']", "mainFrame");
    	//SeleniumHelperClass.moveToElement(e);
    	return SeleniumHelperClass.findWebElementbyXpath("//span[@title='testpro1']/..//div[@class='pill-button-grp']//button[@class='pill-button action-button']//span[text()='Edit']", "mainFrame");
    }
    
    public WebElement getDeleteButton() throws Exception {
    	return SeleniumHelperClass.findWebElementbyXpath("//span[@title='testpro1']/..//div[@class='pill-button-grp']//button[@class='pill-button action-button']//span[text()='Delete']", "mainFrame");
    }
    
    public WebElement getPopUpDelete() throws Exception {
    	return SeleniumHelperClass.findWebElementbyXpath("//div[text()='Delete']", "mainFrame");
    }
    public WebElement getCheckbox() throws Exception {
    	return SeleniumHelperClass.findWebElementbyXpath("//span[@title='testpro1']/..//input[@type='checkbox']", "mainFrame");
    }
    
    public WebElement getS1() throws Exception {
    	return  SeleniumHelperClass.findWebElementbyXpath("//input[@type='text' and @data-display-name = 'S1']","mainFrame");
    }
    
    public WebElement getS2() throws Exception {
    	return  SeleniumHelperClass.findWebElementbyXpath("//input[@type='text' and @data-display-name = 'S2']","mainFrame");
    }
    
    public WebElement getS3() throws Exception {
    	return  SeleniumHelperClass.findWebElementbyXpath("//input[@type='text' and @data-display-name = 'S3']","mainFrame");
    }
    public WebElement deletechk() throws Exception {
    	return  SeleniumHelperClass.findWebElementbyXpath("//input[@type='checkbox'and @name='orderListItem']","mainFrame");
    }
    
    public WebElement deleteSelectedchk() throws Exception {
    	return  SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'Delete the selected order(s)')]","mainFrame");
    }
    public WebElement delete() throws Exception {
    	return  SeleniumHelperClass.findWebElementbyXpath("//span[contains(text(),'Delete Order Items')]","mainFrame");
    }
    public WebElement deletepopmsg() throws Exception {
    	return (SeleniumHelperClass.findWebElementbyid("uiActionMsgContent", "mainFrame"));
    }
    
  
   /* 
    public WebElement getCancel() throws Exception{
    	return SeleniumHelperClass.findWebElementbyXpath("(//span[text()='Cancel'])[2]");
    }*/
    public void uploadOrderItem(String url) throws Exception {
		logger.info("Executing uploadItemCode function");
		String message = "";   
		/*getUploadOrderItems().click();
		String parentWindow = SeleniumHelperClass.switchToPopupWindow();*/

		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);

		
			logger.info("Uploading the file");	  
			getInputField().sendKeys(url);

			logger.info("Clicking on the submit button");
            getUploadButton().click();
            Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
            /*Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
            Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
            String text = "Orders have been uploaded successfully.";
            //Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
            Thread.sleep(500);
            SeleniumHelperClass.AcceptAlerts(text);
            Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
			*/
			}

		public WebElement getSearchTopButton() throws Exception {
			return SeleniumHelperClass.findWebElementbyXpath("//a[contains(text(),'More Search Options')]//..//span[@id='searchBtnTop']", "mainFrame");
		}
		
		public boolean OrderAvailable(String orderName) throws Exception{
			//SeleniumHelperClass.findWebElementbyXpath("//span[@title="+orderName+"]", "mainFrame");
			Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*2);
			 boolean isPresent = SeleniumHelperClass.findWebElements("//span[@title='"+orderName+"']", "mainFrame").size()>0;			
		    // logger.info();
			 return isPresent;
		}
    
    public void UploadOrderItem() throws Exception{
    	
    	getSearchButton().click();
        //Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
        
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*2);
        boolean result = (OrderAvailable("testpro1"));
        		logger.info(result);
        if(result){
        	getCheckbox().click();
       
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
        SeleniumHelperClass.isVisible(getDeleteButton(), 10);
        SeleniumHelperClass.moveToElement(getDeleteButton());
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
        getDeleteButton().click();
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
        String newParentWindow = SeleniumHelperClass.switchToPopupWindow();
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
        getPopUpDelete().click();
        Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
        SeleniumHelperClass.switchToWindow(newParentWindow);
        }
        logger.info("Upload the Order Item");
    	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);  	
    	getDropDown().selectByVisibleText("JAN-2017 (Open)");
        String URL = getUploadFileLocation("CustomField_Boolean.xlsx");
        if(!SetWebDrivers.runningOS.equals("Mac") && !SetWebDrivers.runningOS.equalsIgnoreCase("Linux"))
		{
        URL = URL.substring(1, URL.length()).replace("/", "\\");
		}
        ExcelConnector ex = new ExcelConnector();
        logger.info("Reading the values from Excel for custom fields S1,S2,S3");
        String[] SExpValue=new String[3];
        int i = 0; 
        int j = 0;
        
        for ( j= 0,i = 21; i <= 23; i++, j++) {
        	SExpValue[j] = ExcelConnector.ReadXLSXSheet(URL, "Xactly Incent - Orders Upload", 1, i);
        }
        
      /*  String S1ExpValue= ExcelConnector.ReadXLSXSheet(URL, "Xactly Incent - Orders Upload",1,21);
        String S2ExpValue = ex.ReadXLSXSheet(URL, "Xactly Incent - Orders Upload", 1, 22);
        String S3ExpValue = ex.ReadXLSXSheet(URL, "Xactly Incent - Orders Upload", 1, 23)*/;
        
        logger.info("S1ActualValue" + SExpValue[0]);
        logger.info("S2ActualValue" + SExpValue[1]);
        logger.info("S3ActualValue" + SExpValue[2]);
        
        logger.info("Uploading the file");
        getUploadOrderItems().click();
    	String parentWindow = SeleniumHelperClass.switchToPopupWindow();
    	Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*2);
        //getBrowse().click();
       uploadOrderItem(URL);
       Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*2);
       SeleniumHelperClass.switchToWindow(parentWindow);
       logger.info("Searching for the created order");
       Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*2);
       SeleniumHelperClass.isVisible(getSearchTopButton(), 30);
       getSearchTopButton().click();
       Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*2);
       logger.info("Click on the edit button");
     //  getOrderCode().click();
      getCheckbox().click();
      SeleniumHelperClass.isVisible(getEditButton(), 30);
       SeleniumHelperClass.moveToElement(getEditButton());
      // SeleniumHelperClass.isClickable(getEditButton(), 10);
       getEditButton().click();
       Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
       SeleniumHelperClass.executeJavaScriptScroll(getS1());
       logger.info("Reading the custom field values from the application");
       SoftAssert sa = new SoftAssert();
       String SValue;     
      for(int k=1,l = 0;k<=3 ;k++,l++){
    	   String script = "return document.getElementById('string"+k+"').value";
    	   logger.info(script);
    	   SValue = SeleniumHelperClass.ExecuteJavaScript(script);
    	   logger.info("SValue" + SValue.trim());
    	   logger.info("SExpValue[l].trim()"+SExpValue[l].trim());
    	   sa.assertEquals(SValue.trim(), SExpValue[l].trim());
    	   
       }
       sa.assertAll();
       getSearchCancel().click();
       Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*2);
       getCheckbox().click();
       Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*2);
       SeleniumHelperClass.moveToElement(getDeleteButton());
       Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*2);
       SeleniumHelperClass.isVisible(getDeleteButton(), 30);
       getDeleteButton().click();
       Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*2);
       String newParentWindow1 = SeleniumHelperClass.switchToPopupWindow();
       Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX*2);
       getPopUpDelete().click();
       SeleniumHelperClass.switchToWindow(newParentWindow1);
       
       
      /* String script1 = "return document.getElementById('string1').value";
       String script2 = "return document.getElementById('string2').value";
       String script3 = "return document.getElementById('string3').value";*/
       
       
      /* for (int i = 1 ; i <=3 ; i++) {
      SValue[i] = SeleniumHelperClass.ExecuteJavaScript(script[i]);
       
       }*/
       
       /*String S1ActValue = SeleniumHelperClass.ExecuteJavaScript(script1);*/
      
    }
    
    public void DeleteuploadOrd(String orderCode) throws Exception {
    	new OrdersSubtab(SetWebDrivers.getNavigationType());
    	getOrderCode().sendKeys(orderCode);
		getSearchButton().click();
		deletechk().click();
		SeleniumHelperClass.mouseHover(delete());
		deleteSelectedchk().click();
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		SeleniumHelperClass.acceptDeleteConfirmation();
		//deletepop().click();
		String Validatetext = deletepopmsg().getText();
		logger.info(Validatetext);
		//Assert.assertEquals(Validatetext, "Added to Queue","Assertion Failed");
		Thread.sleep(SeleniumHelperClass.system_SpeedlimitMAX);
		
		
	}
}

